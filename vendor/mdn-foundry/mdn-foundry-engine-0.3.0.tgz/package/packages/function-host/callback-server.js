import { randomBytes } from 'node:crypto';
import { createServer } from 'node:http';
const KEEP_ALIVE_TIMEOUT_MS = 30_000;
const HEADERS_TIMEOUT_MS = 35_000;
const REQUEST_TIMEOUT_MS = 35_000;
const isRecord = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);
/** Loopback transport shared by the runtime's authorized Ontology callbacks and offline test stubs. */
export class FunctionCallbackServer {
    server;
    sessions = new Map();
    async open(dispatch, maxResponseBytes) {
        const { url } = await this.listen();
        const token = randomBytes(24).toString('base64url');
        this.sessions.set(token, { dispatch, maxResponseBytes });
        return { callback: { url, token }, close: () => { this.sessions.delete(token); } };
    }
    async close() {
        const listener = this.server;
        if (!listener)
            return;
        this.server = undefined;
        this.sessions.clear();
        let server;
        try {
            ({ server } = await listener);
        }
        catch {
            return;
        }
        const closed = new Promise((resolve, reject) => server.close(error => error ? reject(error) : resolve()));
        // Proactively tear down pooled keep-alive sockets so shutdown never stalls waiting on keepAliveTimeout.
        server.closeIdleConnections();
        server.closeAllConnections();
        await closed;
    }
    listen() {
        return this.server ??= new Promise((resolve, reject) => {
            const server = createServer((request, response) => {
                void this.handle(request, response).catch(() => response.destroy());
            });
            server.keepAliveTimeout = KEEP_ALIVE_TIMEOUT_MS;
            server.headersTimeout = HEADERS_TIMEOUT_MS;
            server.requestTimeout = REQUEST_TIMEOUT_MS;
            server.maxRequestsPerSocket = 0;
            server.on('connection', socket => {
                socket.setNoDelay(true);
            });
            server.once('error', error => {
                this.server = undefined;
                reject(error);
            });
            server.listen(0, '127.0.0.1', () => {
                server.unref();
                resolve({ url: `http://127.0.0.1:${server.address().port}/ontology`, server });
            });
        });
    }
    async handle(request, response) {
        const clientRequestsClose = typeof request.headers.connection === 'string' &&
            request.headers.connection.toLowerCase().split(',').some(token => token.trim() === 'close');
        const reply = (status, body, maxResponseBytes, forceClose = false) => {
            if (response.writableEnded || response.destroyed)
                return;
            let text = JSON.stringify(body);
            if ('result' in body && maxResponseBytes !== undefined && Buffer.byteLength(text) > maxResponseBytes) {
                text = JSON.stringify({ error: { code: 'limit', message: `An Ontology answer is at most ${maxResponseBytes} bytes` } });
            }
            const close = forceClose || clientRequestsClose;
            const headers = {
                'content-type': 'application/json',
                'content-length': Buffer.byteLength(text),
                connection: close ? 'close' : 'keep-alive',
            };
            if (!close)
                headers['keep-alive'] = `timeout=${Math.floor(KEEP_ALIVE_TIMEOUT_MS / 1000)}`;
            response.writeHead(status, headers);
            response.end(text);
        };
        if (request.method !== 'POST' || request.url !== '/ontology')
            return reply(404, { error: { code: 'not-found', message: 'Unknown callback' } }, undefined, true);
        const chunks = [];
        let size = 0;
        for await (const chunk of request) {
            size += chunk.length;
            if (size > 1 << 20)
                return reply(413, { error: { code: 'invalid', message: 'The request is too large' } }, undefined, true);
            chunks.push(chunk);
        }
        let parsed;
        try {
            parsed = JSON.parse(Buffer.concat(chunks).toString());
        }
        catch { /* Refuse malformed input. */ }
        if (!isRecord(parsed) || Object.keys(parsed).length !== 3 || typeof parsed.token !== 'string' ||
            parsed.token.length < 32 || parsed.token.length > 64 || typeof parsed.operation !== 'string' || !isRecord(parsed.arguments))
            return reply(400, { error: { code: 'invalid', message: 'Malformed callback' } });
        const session = this.sessions.get(parsed.token);
        if (!session)
            return reply(404, { error: { code: 'not-found', message: 'The call has ended' } });
        reply(200, await session.dispatch(parsed.operation, parsed.arguments), session.maxResponseBytes);
    }
}
