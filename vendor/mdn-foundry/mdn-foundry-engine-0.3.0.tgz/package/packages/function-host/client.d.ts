/**
 * Client of the function host (`function-host/`, F1). The host runs Functions compiled to WebAssembly components of
 * the world `eigos:function/handler@0.2.0`, one fresh instance per call, within the limits each call gives.
 */
/** Limits of one call. The host refuses a call that asks for more than its maxima (`health().maxima`). */
export type FunctionLimits = {
    fuel: number;
    memoryMb: number;
    deadlineMs: number;
    inputBytes?: number;
    outputBytes?: number;
};
/** Why a call returned no output: the Function's own failure, or the limit or trap that stopped it. */
export type FunctionError = {
    kind: 'failure';
    code: string;
    message: string;
} | {
    kind: 'fuel' | 'memory' | 'deadline' | 'trap' | 'output';
    message: string;
};
/** How a call ended, with the fuel it used, its duration including instantiation, and the end of its stderr. */
export type FunctionOutcome = ({
    output: string;
    error?: undefined;
} | {
    output?: undefined;
    error: FunctionError;
}) & {
    fuelUsed: number;
    ms: number;
    stderr?: string;
};
export type FunctionHostHealth = {
    status: 'ok';
    protocol: number;
    world: string;
    components: number;
    capacity: number;
    slots: number;
    persistent: boolean;
    maxima: {
        fuel: number;
        memoryMb: number;
        deadlineMs: number;
        inputBytes: number;
        outputBytes: number;
        componentBytes: number;
    };
    activeCalls?: number;
    inFlightCallbacks?: number;
    cacheHits?: number;
    cacheMisses?: number;
    slotWaitMsTotal?: number;
};
export type FunctionUpload = {
    sha256: string;
    cached: boolean;
    bytes?: number;
    precompiledBytes?: number;
    compileMs?: number;
    imports?: string[];
};
/** The host refused a request: `status` 404 means it does not know the component, so upload it and call again. */
export declare class FunctionHostError extends Error {
    readonly status: number;
    constructor(status: number, message: string);
}
export declare class FunctionHostClient {
    readonly url: string;
    private readonly child?;
    private constructor();
    /** Starts the host binary on a free loopback port. Every host started here stops when this process exits. */
    static start(binary: string, env?: Record<string, string>): Promise<FunctionHostClient>;
    /** A client for a host service already running at `url`. */
    static connect(url: string): FunctionHostClient;
    /** The host process ID, when this client started it. */
    get pid(): number | undefined;
    health(signal?: AbortSignal): Promise<FunctionHostHealth>;
    /** Uploads a component. The host checks and precompiles it, or answers at once when it already has it. */
    upload(component: Uint8Array<ArrayBuffer>, signal?: AbortSignal): Promise<FunctionUpload>;
    /**
     * Calls the component with SHA-256 `sha256` on a JSON `input`. A refused call throws; a call that ran returns its
     * outcome. `callback` is where the call reads the Ontology, on a host of protocol 2.
     */
    invoke(sha256: string, input: string, limits: FunctionLimits, signal?: AbortSignal, callback?: {
        url: string;
        token: string;
    }): Promise<FunctionOutcome>;
    private protocol?;
    /** Whether the host answers protocol `level`: 2 adds the Ontology callback. A restarted host is reached by a new client. */
    supports(level: number): Promise<boolean>;
    /** Stops a host this client started. */
    stop(): Promise<void>;
    private request;
}
/**
 * The function host this process uses, or undefined when none is configured:
 * - with EIGOS_FUNCTION_HOST_URL, a host service already running there;
 * - with EIGOS_FUNCTION_HOST_BIN, a local host process, started on first use, with the data directory
 *   EIGOS_FUNCTION_HOST_DATA when set.
 * A local host that cannot be reached is started again on the next use.
 */
export declare function defaultFunctionHost(): Promise<FunctionHostClient> | undefined;
/** Forgets a local host that could not be reached, so the next use starts another. */
export declare function lostFunctionHost(host: FunctionHostClient): void;
