/**
 * Lightweight zero-dependency metrics registry (Prometheus 0.0.4 text exposition format)
 * and extensible OpenTelemetry-style SpanRecorder hooks with strict cardinality bounds.
 */
export const PROMETHEUS_CONTENT_TYPE = 'text/plain; version=0.0.4; charset=utf-8';
const METRIC_NAME_RE = /^[a-zA-Z_:][a-zA-Z0-9_:]*$/;
const LABEL_NAME_RE = /^[a-zA-Z_][a-zA-Z0-9_]*$/;
const OVERFLOW_LABEL = '__overflow__';
const MAX_LABEL_VALUE_LENGTH = 128;
const DEFAULT_MAX_SERIES = 512;
export const DEFAULT_DURATION_BUCKETS_MS = Object.freeze([
    1, 5, 10, 25, 50, 100, 250, 500, 1000, 2500, 5000, 10000, 30000,
]);
function validateMetricName(name) {
    if (!METRIC_NAME_RE.test(name))
        throw new Error(`Invalid Prometheus metric name: ${name}`);
}
function validateLabelNames(names, forbidLe = false) {
    const seen = new Set();
    const out = [];
    for (const name of names) {
        if (!LABEL_NAME_RE.test(name) || name.startsWith('__'))
            throw new Error(`Invalid Prometheus label name: ${name}`);
        if (forbidLe && name === 'le')
            throw new Error('Histogram labelNames cannot include reserved label "le"');
        if (seen.has(name))
            throw new Error(`Duplicate Prometheus label name: ${name}`);
        seen.add(name);
        out.push(name);
    }
    return Object.freeze(out);
}
function sanitizeLabelValue(value) {
    if (value === undefined)
        return '';
    return String(value)
        .replace(/[\u0000-\u001f\u007f]+/g, ' ')
        .slice(0, MAX_LABEL_VALUE_LENGTH);
}
function escapeHelp(help) {
    return help.replace(/\\/g, '\\\\').replace(/\n/g, '\\n');
}
function escapeLabelValue(value) {
    return value.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n');
}
function formatNumber(value) {
    if (Number.isNaN(value))
        return 'NaN';
    if (value === Infinity)
        return '+Inf';
    if (value === -Infinity)
        return '-Inf';
    return Object.is(value, -0) ? '0' : String(value);
}
function formatLabels(names, values, extra) {
    if (!names.length && !extra)
        return '';
    const parts = [];
    for (let i = 0; i < names.length; i++) {
        parts.push(`${names[i]}="${escapeLabelValue(values[i] ?? '')}"`);
    }
    if (extra)
        parts.push(`${extra[0]}="${escapeLabelValue(extra[1])}"`);
    return `{${parts.join(',')}}`;
}
class BaseMetric {
    type;
    name;
    help;
    labelNames;
    maxSeries;
    series = new Map();
    overflows = 0;
    constructor(type, options, forbidLe = false) {
        this.type = type;
        validateMetricName(options.name);
        this.name = options.name;
        this.help = options.help;
        this.labelNames = validateLabelNames(options.labelNames ?? [], forbidLe);
        this.maxSeries = Math.max(1, Math.floor(options.maxSeries ?? DEFAULT_MAX_SERIES));
    }
    get seriesCount() {
        return this.series.size;
    }
    get overflowCount() {
        return this.overflows;
    }
    resolve(labels) {
        if (!this.labelNames.length)
            return { key: '', values: [] };
        const values = this.labelNames.map(name => sanitizeLabelValue(labels?.[name]));
        const key = JSON.stringify(values);
        if (this.series.has(key) || this.series.size < this.maxSeries)
            return { key, values };
        this.overflows++;
        const overflowValues = this.labelNames.map(() => OVERFLOW_LABEL);
        return { key: JSON.stringify(overflowValues), values: overflowValues };
    }
    lookupKey(labels) {
        if (!this.labelNames.length)
            return '';
        return JSON.stringify(this.labelNames.map(name => sanitizeLabelValue(labels?.[name])));
    }
    reset() {
        this.series.clear();
        this.overflows = 0;
    }
}
export class Counter extends BaseMetric {
    constructor(options) {
        super('counter', options);
    }
    inc(labels, amount = 1) {
        if (Number.isNaN(amount))
            return;
        if (amount < 0)
            throw new Error(`Counter ${this.name} cannot be decreased by ${amount}`);
        const { key, values } = this.resolve(labels);
        const existing = this.series.get(key);
        if (existing)
            existing.entry += amount;
        else
            this.series.set(key, { values, entry: amount });
    }
    get(labels) {
        return this.series.get(this.lookupKey(labels))?.entry ?? 0;
    }
    renderLines() {
        const lines = [`# HELP ${this.name} ${escapeHelp(this.help)}`, `# TYPE ${this.name} counter`];
        if (!this.series.size && !this.labelNames.length) {
            lines.push(`${this.name} 0`);
            return lines;
        }
        const keys = [...this.series.keys()].sort();
        for (const key of keys) {
            const item = this.series.get(key);
            lines.push(`${this.name}${formatLabels(this.labelNames, item.values)} ${formatNumber(item.entry)}`);
        }
        return lines;
    }
}
export class Gauge extends BaseMetric {
    constructor(options) {
        super('gauge', options);
    }
    set(value, labels) {
        if (Number.isNaN(value))
            return;
        const { key, values } = this.resolve(labels);
        const existing = this.series.get(key);
        if (existing)
            existing.entry = value;
        else
            this.series.set(key, { values, entry: value });
    }
    inc(labels, amount = 1) {
        if (Number.isNaN(amount))
            return;
        const { key, values } = this.resolve(labels);
        const existing = this.series.get(key);
        if (existing)
            existing.entry += amount;
        else
            this.series.set(key, { values, entry: amount });
    }
    dec(labels, amount = 1) {
        this.inc(labels, -amount);
    }
    get(labels) {
        return this.series.get(this.lookupKey(labels))?.entry ?? 0;
    }
    delete(labels) {
        return this.series.delete(this.lookupKey(labels));
    }
    renderLines() {
        const lines = [`# HELP ${this.name} ${escapeHelp(this.help)}`, `# TYPE ${this.name} gauge`];
        if (!this.series.size && !this.labelNames.length) {
            lines.push(`${this.name} 0`);
            return lines;
        }
        const keys = [...this.series.keys()].sort();
        for (const key of keys) {
            const item = this.series.get(key);
            lines.push(`${this.name}${formatLabels(this.labelNames, item.values)} ${formatNumber(item.entry)}`);
        }
        return lines;
    }
}
export class Histogram extends BaseMetric {
    buckets;
    constructor(options) {
        super('histogram', options, true);
        const raw = options.buckets ?? DEFAULT_DURATION_BUCKETS_MS;
        const sorted = [...new Set(raw.filter(b => Number.isFinite(b)))].sort((a, b) => a - b);
        if (!sorted.length)
            throw new Error(`Histogram ${this.name} requires at least one finite bucket`);
        this.buckets = Object.freeze(sorted);
    }
    observe(value, labels) {
        if (!Number.isFinite(value))
            return;
        const { key, values } = this.resolve(labels);
        let item = this.series.get(key);
        if (!item) {
            item = { values, entry: { count: 0, sum: 0, bucketCounts: new Array(this.buckets.length).fill(0) } };
            this.series.set(key, item);
        }
        item.entry.count += 1;
        item.entry.sum += value;
        for (let i = 0; i < this.buckets.length; i++) {
            if (value <= this.buckets[i]) {
                item.entry.bucketCounts[i] += 1;
                break;
            }
        }
    }
    get(labels) {
        const item = this.series.get(this.lookupKey(labels));
        if (!item)
            return undefined;
        const cumulative = new Map();
        let running = 0;
        for (let i = 0; i < this.buckets.length; i++) {
            running += item.entry.bucketCounts[i];
            cumulative.set(this.buckets[i], running);
        }
        return { count: item.entry.count, sum: item.entry.sum, buckets: cumulative };
    }
    renderLines() {
        const lines = [`# HELP ${this.name} ${escapeHelp(this.help)}`, `# TYPE ${this.name} histogram`];
        const keys = [...this.series.keys()].sort();
        for (const key of keys) {
            const { values, entry } = this.series.get(key);
            let cumulative = 0;
            for (let i = 0; i < this.buckets.length; i++) {
                cumulative += entry.bucketCounts[i];
                lines.push(`${this.name}_bucket${formatLabels(this.labelNames, values, ['le', formatNumber(this.buckets[i])])} ${cumulative}`);
            }
            lines.push(`${this.name}_bucket${formatLabels(this.labelNames, values, ['le', '+Inf'])} ${entry.count}`);
            lines.push(`${this.name}_sum${formatLabels(this.labelNames, values)} ${formatNumber(entry.sum)}`);
            lines.push(`${this.name}_count${formatLabels(this.labelNames, values)} ${entry.count}`);
        }
        return lines;
    }
}
export class MetricsRegistry {
    registered = new Map();
    defaultMaxSeries;
    constructor(options = {}) {
        this.defaultMaxSeries = Math.max(1, Math.floor(options.defaultMaxSeries ?? DEFAULT_MAX_SERIES));
    }
    counter(options) {
        return this.register('counter', options, () => new Counter({ maxSeries: this.defaultMaxSeries, ...options }));
    }
    gauge(options) {
        return this.register('gauge', options, () => new Gauge({ maxSeries: this.defaultMaxSeries, ...options }));
    }
    histogram(options) {
        return this.register('histogram', options, () => new Histogram({ maxSeries: this.defaultMaxSeries, ...options }));
    }
    register(type, options, create) {
        const existing = this.registered.get(options.name);
        if (existing) {
            if (existing.type !== type) {
                throw new Error(`Metric ${options.name} already registered with type ${existing.type}`);
            }
            return existing;
        }
        const metric = create();
        this.registered.set(options.name, metric);
        return metric;
    }
    get(name) {
        return this.registered.get(name);
    }
    names() {
        return [...this.registered.keys()];
    }
    reset() {
        for (const metric of this.registered.values())
            metric.reset();
    }
    renderPrometheus() {
        const sections = [];
        for (const name of [...this.registered.keys()].sort()) {
            sections.push(this.registered.get(name).renderLines().join('\n'));
        }
        return sections.length ? sections.join('\n') + '\n' : '';
    }
}
export function metricsTextResponse(registry = metrics) {
    return {
        status: 200,
        contentType: PROMETHEUS_CONTENT_TYPE,
        headers: {
            'content-type': PROMETHEUS_CONTENT_TYPE,
            'cache-control': 'no-store',
        },
        body: registry.renderPrometheus(),
    };
}
/** Express and Node HTTP compatible `/metrics` route handler factory. */
export function createMetricsHandler(registry = metrics) {
    return (_req, res) => {
        const payload = metricsTextResponse(registry);
        if (typeof res.status === 'function' && typeof res.set === 'function' && typeof res.send === 'function') {
            res.status(payload.status);
            res.set(payload.headers);
            res.send(payload.body);
            return;
        }
        if (typeof res.writeHead === 'function') {
            res.writeHead(payload.status, payload.headers);
        }
        else if (typeof res.setHeader === 'function') {
            for (const [key, value] of Object.entries(payload.headers))
                res.setHeader(key, value);
        }
        if (typeof res.end === 'function')
            res.end(payload.body);
    };
}
const noopSpanHandle = Object.freeze({
    setAttribute() { },
    setAttributes() { },
    addEvent() { },
    setStatus() { },
    recordException() { },
    end() { },
});
const spanRecorders = new Set();
/** Registers an external or in-process OTel-style SpanRecorder; returns a dispose callback. */
export function registerSpanRecorder(recorder) {
    spanRecorders.add(recorder);
    return () => { spanRecorders.delete(recorder); };
}
function safeCall(fn) {
    try {
        fn();
    }
    catch { /* telemetry hooks must never disrupt runtime execution */ }
}
export function startSpan(name, options) {
    if (!spanRecorders.size)
        return noopSpanHandle;
    const handles = [];
    for (const recorder of spanRecorders) {
        safeCall(() => { handles.push(recorder.startSpan(name, options)); });
    }
    if (!handles.length)
        return noopSpanHandle;
    if (handles.length === 1) {
        const single = handles[0];
        return {
            setAttribute: (k, v) => safeCall(() => single.setAttribute(k, v)),
            setAttributes: a => safeCall(() => single.setAttributes(a)),
            addEvent: (n, a, t) => safeCall(() => single.addEvent(n, a, t)),
            setStatus: (s, m) => safeCall(() => single.setStatus(s, m)),
            recordException: e => safeCall(() => single.recordException(e)),
            end: t => safeCall(() => single.end(t)),
        };
    }
    return {
        setAttribute: (k, v) => { for (const h of handles)
            safeCall(() => h.setAttribute(k, v)); },
        setAttributes: a => { for (const h of handles)
            safeCall(() => h.setAttributes(a)); },
        addEvent: (n, a, t) => { for (const h of handles)
            safeCall(() => h.addEvent(n, a, t)); },
        setStatus: (s, m) => { for (const h of handles)
            safeCall(() => h.setStatus(s, m)); },
        recordException: e => { for (const h of handles)
            safeCall(() => h.recordException(e)); },
        end: t => { for (const h of handles)
            safeCall(() => h.end(t)); },
    };
}
export async function withSpan(name, options, run) {
    const span = startSpan(name, options);
    try {
        const result = await run(span);
        span.setStatus('ok');
        return result;
    }
    catch (error) {
        span.recordException(error);
        span.setStatus('error', error instanceof Error ? error.message : String(error));
        throw error;
    }
    finally {
        span.end();
    }
}
export class InMemorySpanRecorder {
    maxSpans;
    spans = [];
    constructor(maxSpans = 1000) {
        this.maxSpans = maxSpans;
    }
    clear() {
        this.spans.length = 0;
    }
    startSpan(name, options = {}) {
        const startedAtMs = options.startTimeMs ?? Date.now();
        const startPerf = performance.now();
        const attributes = {};
        const events = [];
        let status = 'unset';
        let statusMessage;
        let ended = false;
        const assign = (attrs) => {
            if (!attrs)
                return;
            for (const [k, v] of Object.entries(attrs)) {
                if (v !== undefined)
                    attributes[k] = v;
            }
        };
        assign(options.attributes);
        return {
            setAttribute: (key, value) => { if (!ended && value !== undefined)
                attributes[key] = value; },
            setAttributes: attrs => { if (!ended)
                assign(attrs); },
            addEvent: (eventName, attrs, timestampMs = Date.now()) => {
                if (ended)
                    return;
                const clean = {};
                if (attrs) {
                    for (const [k, v] of Object.entries(attrs)) {
                        if (v !== undefined)
                            clean[k] = v;
                    }
                }
                events.push({ name: eventName, timestampMs, ...(Object.keys(clean).length ? { attributes: clean } : {}) });
            },
            setStatus: (nextStatus, message) => {
                if (ended)
                    return;
                status = nextStatus;
                statusMessage = message;
            },
            recordException: error => {
                if (ended)
                    return;
                const message = error instanceof Error ? error.message : String(error);
                const type = error instanceof Error ? error.name : typeof error;
                events.push({
                    name: 'exception',
                    timestampMs: Date.now(),
                    attributes: { 'exception.type': type, 'exception.message': message.slice(0, 240) },
                });
            },
            end: endTimeMs => {
                if (ended)
                    return;
                ended = true;
                const durationMs = endTimeMs !== undefined ? Math.max(0, endTimeMs - startedAtMs) : Math.max(0, performance.now() - startPerf);
                const endedAtMs = endTimeMs ?? startedAtMs + durationMs;
                if (this.spans.length >= this.maxSpans)
                    this.spans.shift();
                this.spans.push({
                    name,
                    kind: options.kind ?? 'internal',
                    startedAtMs,
                    endedAtMs,
                    durationMs,
                    status,
                    ...(statusMessage !== undefined ? { statusMessage } : {}),
                    attributes,
                    events,
                });
            },
        };
    }
}
export function bindProviderMetrics(registry) {
    return {
        providerCircuitState: registry.gauge({
            name: 'eigos_provider_circuit_state',
            help: 'Provider circuit breaker state (0=closed, 1=half_open, 2=open)',
            labelNames: ['provider', 'scope'],
            maxSeries: 256,
        }),
        providerOwnerCircuitsOpen: registry.gauge({
            name: 'eigos_provider_owner_circuits_open',
            help: 'Number of owner-isolated circuits currently open for a provider',
            labelNames: ['provider'],
            maxSeries: 256,
        }),
        providerCircuitTransitionsTotal: registry.counter({
            name: 'eigos_provider_circuit_transitions_total',
            help: 'Total provider circuit breaker state transitions',
            labelNames: ['provider', 'scope', 'from', 'to'],
            maxSeries: 512,
        }),
        providerResilienceRejectionsTotal: registry.counter({
            name: 'eigos_provider_resilience_rejections_total',
            help: 'Total provider calls rejected by bulkhead concurrency or circuit breaker',
            labelNames: ['provider', 'scope', 'reason'],
            maxSeries: 256,
        }),
        providerInflight: registry.gauge({
            name: 'eigos_provider_inflight',
            help: 'Current in-flight outbound calls per provider',
            labelNames: ['provider'],
            maxSeries: 256,
        }),
        providerCallsTotal: registry.counter({
            name: 'eigos_provider_calls_total',
            help: 'Total governed provider calls by outcome and execution mode',
            labelNames: ['provider', 'mode', 'outcome'],
            maxSeries: 512,
        }),
        providerCallDurationMs: registry.histogram({
            name: 'eigos_provider_call_duration_ms',
            help: 'Duration of governed provider calls in milliseconds',
            labelNames: ['provider', 'mode', 'outcome'],
            maxSeries: 512,
        }),
    };
}
export const metrics = new MetricsRegistry();
export const runtimeMetrics = {
    operationDurationMs: metrics.histogram({
        name: 'eigos_operation_duration_ms',
        help: 'Duration of timed runtime operations in milliseconds',
        labelNames: ['stage', 'operation', 'outcome'],
        maxSeries: 256,
    }),
    operationsTotal: metrics.counter({
        name: 'eigos_operations_total',
        help: 'Total timed runtime operations',
        labelNames: ['stage', 'operation', 'outcome'],
        maxSeries: 256,
    }),
    operationErrorsTotal: metrics.counter({
        name: 'eigos_operation_errors_total',
        help: 'Total timed runtime operations that threw an error',
        labelNames: ['stage', 'operation'],
        maxSeries: 256,
    }),
    operationDbStatementsTotal: metrics.counter({
        name: 'eigos_operation_db_statements_total',
        help: 'Total PostgreSQL statements executed inside timed runtime operations',
        labelNames: ['stage'],
        maxSeries: 32,
    }),
    operationDbDurationMs: metrics.histogram({
        name: 'eigos_operation_db_duration_ms',
        help: 'Database round-trip duration inside timed runtime operations in milliseconds',
        labelNames: ['stage'],
        maxSeries: 32,
    }),
    operationDbLockTimeoutsTotal: metrics.counter({
        name: 'eigos_operation_db_lock_timeouts_total',
        help: 'Database lock timeouts observed inside timed runtime operations',
        labelNames: ['stage'],
        maxSeries: 32,
    }),
    hotEditBatchesTotal: metrics.counter({
        name: 'eigos_hot_edit_batches_total',
        help: 'Total coalesced hot-edit commit batches',
    }),
    hotEditBatchSize: metrics.histogram({
        name: 'eigos_hot_edit_batch_size',
        help: 'Number of requests merged into each hot-edit batch',
        buckets: [1, 2, 4, 8, 16, 32, 64],
    }),
    commitFallbacksTotal: metrics.counter({
        name: 'eigos_commit_fallbacks_total',
        help: 'Total object-scoped commits that fell back to the exclusive edit lock',
        labelNames: ['operation', 'reason'],
        maxSeries: 128,
    }),
    objectLockWaitsTotal: metrics.counter({
        name: 'eigos_object_lock_waits_total',
        help: 'Total reported object advisory lock wait events',
        labelNames: ['mode'],
        maxSeries: 16,
    }),
    objectLockWaitMs: metrics.histogram({
        name: 'eigos_object_lock_wait_ms',
        help: 'Reported object advisory lock wait duration in milliseconds',
        labelNames: ['mode'],
        maxSeries: 16,
    }),
    runtimeEventsTotal: metrics.counter({
        name: 'eigos_runtime_events_total',
        help: 'Total structured runtime operation events recorded',
        labelNames: ['event'],
        maxSeries: 128,
    }),
    accessCacheTotal: metrics.counter({
        name: 'eigos_access_cache_total',
        help: 'Total permission snapshot cache lookups by result',
        labelNames: ['result'],
        maxSeries: 8,
    }),
    readReplicaFallbacksTotal: metrics.counter({
        name: 'eigos_read_replica_fallbacks_total',
        help: 'Total read-replica queries that fell back to the primary database',
        labelNames: ['reason'],
        maxSeries: 16,
    }),
    kernelFallbacksTotal: metrics.counter({
        name: 'eigos_kernel_fallbacks_total',
        help: 'Total query kernel evaluations that fell back to the reference engine',
        labelNames: ['reason'],
        maxSeries: 16,
    }),
    ...bindProviderMetrics(metrics),
};
