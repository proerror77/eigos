type Correlation = {
    mcpRequestId: string;
} | {
    taskId: string;
    workerRunId: string;
} | {
    workflowRunId: string;
    attemptId: string;
};
type Stage = 'model_session' | 'agent_tool' | 'action_apply' | 'result_read' | 'function' | 'didi_read' | 'didi_rpc' | 'source_read' | 'source_egress';
export declare function withOperationTiming<T>(correlation: Correlation, run: () => Promise<T>): Promise<T>;
/** Keep the owning run when a harness invokes its tools from another connection. */
export declare function bindOperationTiming<Input, Result>(run: (input: Input) => Promise<Result>): (input: Input) => Promise<Result>;
/** Logs one runtime event with the current run's correlation, if any, and bridges it into Prometheus metrics. */
export declare function recordOperationEvent(event: string, fields?: Record<string, string | number | boolean | undefined>, options?: {
    log?: boolean;
}): void;
export declare function timeOperation<T>(stage: Stage, run: () => Promise<T>, operation?: string): Promise<T>;
export {};
