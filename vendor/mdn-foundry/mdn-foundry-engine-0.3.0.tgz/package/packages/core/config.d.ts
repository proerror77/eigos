import { z } from 'zod';
export declare const connectionConfigSchema: z.ZodObject<{
    PUBLIC_URL: z.ZodOptional<z.ZodURL>;
    EIGOS_AUTH_MODE: z.ZodOptional<z.ZodEnum<{
        development: "development";
        jwt: "jwt";
    }>>;
    EIGOS_DIDI_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_DIDI_WATCH_SANDBOX_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_DIDI_PA_READS_ENABLED: z.ZodOptional<z.ZodEnum<{
        false: "false";
        true: "true";
    }>>;
    EIGOS_DIDI_PA_ORDERS_ENABLED: z.ZodOptional<z.ZodEnum<{
        false: "false";
        true: "true";
    }>>;
    EIGOS_SERVICE_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_FLIGGY_FLIGHT_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_FLIGGY_HOTEL_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_PAOTUI_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_WAIMAI_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_TAOBAO_INSTANT_DELIVERY_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_HEMA_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_AMAP_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_BETA_AMAP_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_BETA_FLYAI_TRIAL_UNTIL: z.ZodOptional<z.ZodISODateTime>;
    EIGOS_XIAOHONGSHU_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_DIANPING_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_TABLECHECK_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_MEITUAN_DINING_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_DINING_WEB_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_DINING_MINIPROGRAM_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_JOURNEY_CALENDAR_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_TRAVEL_PA_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_VARIFLIGHT_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_FR24_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_FR24_MCP_ENTRYPOINT: z.ZodOptional<z.ZodString>;
    EIGOS_STRIPE_SANDBOX_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export type ConnectionConfig = z.infer<typeof connectionConfigSchema>;
export declare const configSchema: z.ZodObject<{
    EIGOS_DIDI_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_DIDI_WATCH_SANDBOX_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_DIDI_PA_READS_ENABLED: z.ZodOptional<z.ZodEnum<{
        false: "false";
        true: "true";
    }>>;
    EIGOS_DIDI_PA_ORDERS_ENABLED: z.ZodOptional<z.ZodEnum<{
        false: "false";
        true: "true";
    }>>;
    EIGOS_SERVICE_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_FLIGGY_FLIGHT_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_FLIGGY_HOTEL_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_PAOTUI_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_WAIMAI_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_TAOBAO_INSTANT_DELIVERY_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_HEMA_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_AMAP_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_BETA_AMAP_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_BETA_FLYAI_TRIAL_UNTIL: z.ZodOptional<z.ZodISODateTime>;
    EIGOS_XIAOHONGSHU_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_DIANPING_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_TABLECHECK_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_MEITUAN_DINING_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_DINING_WEB_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_DINING_MINIPROGRAM_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_JOURNEY_CALENDAR_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_TRAVEL_PA_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_VARIFLIGHT_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_FR24_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_FR24_MCP_ENTRYPOINT: z.ZodOptional<z.ZodString>;
    EIGOS_STRIPE_SANDBOX_CONNECTION_FILE: z.ZodOptional<z.ZodString>;
    DATABASE_URL: z.ZodString;
    QUERY_DATABASE_URL: z.ZodOptional<z.ZodString>;
    EIGOS_PG_SCHEMA: z.ZodDefault<z.ZodString>;
    HOST: z.ZodDefault<z.ZodString>;
    PORT: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
    PUBLIC_URL: z.ZodDefault<z.ZodURL>;
    EIGOS_AUTH_MODE: z.ZodDefault<z.ZodEnum<{
        development: "development";
        jwt: "jwt";
    }>>;
    EIGOS_DEV_TOKEN: z.ZodOptional<z.ZodString>;
    OAUTH_WORKBENCH_CLIENT_ID: z.ZodOptional<z.ZodString>;
    OAUTH_MEMBER_CLIENT_ID: z.ZodOptional<z.ZodString>;
    OAUTH_MEMBER_CLIENT_SECRET: z.ZodOptional<z.ZodString>;
    OAUTH_MEMBER_MCP_CLIENT_ID: z.ZodOptional<z.ZodString>;
    OAUTH_EXISTING_CLIENT_IDS: z.ZodOptional<z.ZodString>;
    EIGOS_MCP_OPERATOR_CATALOG: z.ZodOptional<z.ZodString>;
    EIGOS_MCP_OPERATOR_MACHINERY: z.ZodOptional<z.ZodString>;
    OAUTH_MANAGEMENT_CLIENT_ID: z.ZodOptional<z.ZodString>;
    OAUTH_MANAGEMENT_CLIENT_SECRET: z.ZodOptional<z.ZodString>;
    OAUTH_MANAGEMENT_DOMAIN: z.ZodOptional<z.ZodString>;
    OAUTH_ISSUER: z.ZodOptional<z.ZodURL>;
    OAUTH_AUDIENCE: z.ZodOptional<z.ZodString>;
    OAUTH_JWKS_URL: z.ZodOptional<z.ZodURL>;
    OAUTH_TENANT_CLAIM: z.ZodDefault<z.ZodString>;
    EIGOS_SIGNUP: z.ZodDefault<z.ZodEnum<{
        closed: "closed";
        invite: "invite";
        open: "open";
    }>>;
    EIGOS_ENFORCE_OWNER_RLS: z.ZodOptional<z.ZodEnum<{
        false: "false";
        true: "true";
    }>>;
    EIGOS_PORTAL_SECRET: z.ZodOptional<z.ZodString>;
    EIGOS_ACCOUNT_LINK_SECRET: z.ZodOptional<z.ZodString>;
    EIGOS_TRUST_PROXY: z.ZodOptional<z.ZodString>;
    EIGOS_EXTENSION_MODULE: z.ZodOptional<z.ZodString>;
    EIGOS_SOURCE_COMMIT: z.ZodOptional<z.ZodString>;
    EIGOS_METRICS_ENABLED: z.ZodOptional<z.ZodEnum<{
        false: "false";
        true: "true";
    }>>;
    EIGOS_METRICS_REQUIRE_AUTH: z.ZodOptional<z.ZodEnum<{
        false: "false";
        true: "true";
    }>>;
    EIGOS_METRICS_PATH: z.ZodOptional<z.ZodString>;
    EIGOS_HARNESS_BIN: z.ZodOptional<z.ZodString>;
    EIGOS_HARNESS_CREDENTIAL_FILE: z.ZodOptional<z.ZodString>;
    EIGOS_AGENT_SANDBOX_ENABLED: z.ZodOptional<z.ZodEnum<{
        false: "false";
        true: "true";
    }>>;
    EIGOS_HARNESS_MODEL: z.ZodDefault<z.ZodString>;
    EIGOS_HARNESS_REASONING_EFFORT: z.ZodDefault<z.ZodString>;
}, z.core.$strip>;
export type Config = z.infer<typeof configSchema>;
export declare function readConfig(env?: NodeJS.ProcessEnv): Config;
