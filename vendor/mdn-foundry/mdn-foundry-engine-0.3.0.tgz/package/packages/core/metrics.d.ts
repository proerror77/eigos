/**
 * Lightweight zero-dependency metrics registry (Prometheus 0.0.4 text exposition format)
 * and extensible OpenTelemetry-style SpanRecorder hooks with strict cardinality bounds.
 */
export declare const PROMETHEUS_CONTENT_TYPE = "text/plain; version=0.0.4; charset=utf-8";
export type MetricLabelValue = string | number | boolean | undefined;
export type MetricLabels = Readonly<Record<string, MetricLabelValue>>;
export declare const DEFAULT_DURATION_BUCKETS_MS: readonly number[];
export interface MetricOptions {
    name: string;
    help: string;
    labelNames?: readonly string[];
    maxSeries?: number;
}
export interface HistogramOptions extends MetricOptions {
    buckets?: readonly number[];
}
declare abstract class BaseMetric<Entry> {
    readonly type: 'counter' | 'gauge' | 'histogram';
    readonly name: string;
    readonly help: string;
    readonly labelNames: readonly string[];
    readonly maxSeries: number;
    protected readonly series: Map<string, {
        values: readonly string[];
        entry: Entry;
    }>;
    protected overflows: number;
    constructor(type: 'counter' | 'gauge' | 'histogram', options: MetricOptions, forbidLe?: boolean);
    get seriesCount(): number;
    get overflowCount(): number;
    protected resolve(labels?: MetricLabels): {
        key: string;
        values: readonly string[];
    };
    protected lookupKey(labels?: MetricLabels): string;
    reset(): void;
    abstract renderLines(): string[];
}
export declare class Counter extends BaseMetric<number> {
    constructor(options: MetricOptions);
    inc(labels?: MetricLabels, amount?: number): void;
    get(labels?: MetricLabels): number;
    renderLines(): string[];
}
export declare class Gauge extends BaseMetric<number> {
    constructor(options: MetricOptions);
    set(value: number, labels?: MetricLabels): void;
    inc(labels?: MetricLabels, amount?: number): void;
    dec(labels?: MetricLabels, amount?: number): void;
    get(labels?: MetricLabels): number;
    delete(labels?: MetricLabels): boolean;
    renderLines(): string[];
}
interface HistogramSample {
    count: number;
    sum: number;
    /** Per-bucket non-cumulative hit counts aligned with `buckets`. */
    bucketCounts: number[];
}
export interface HistogramSnapshot {
    count: number;
    sum: number;
    buckets: ReadonlyMap<number, number>;
}
export declare class Histogram extends BaseMetric<HistogramSample> {
    readonly buckets: readonly number[];
    constructor(options: HistogramOptions);
    observe(value: number, labels?: MetricLabels): void;
    get(labels?: MetricLabels): HistogramSnapshot | undefined;
    renderLines(): string[];
}
export interface MetricsRegistryOptions {
    defaultMaxSeries?: number;
}
type AnyMetric = Counter | Gauge | Histogram;
export declare class MetricsRegistry {
    private readonly registered;
    private readonly defaultMaxSeries;
    constructor(options?: MetricsRegistryOptions);
    counter(options: MetricOptions): Counter;
    gauge(options: MetricOptions): Gauge;
    histogram(options: HistogramOptions): Histogram;
    private register;
    get(name: string): AnyMetric | undefined;
    names(): string[];
    reset(): void;
    renderPrometheus(): string;
}
export interface MetricsTextResponse {
    status: number;
    contentType: string;
    headers: Record<string, string>;
    body: string;
}
export declare function metricsTextResponse(registry?: MetricsRegistry): MetricsTextResponse;
export interface MetricsHttpResponse {
    status?: (code: number) => MetricsHttpResponse;
    set?: (headers: Record<string, string>) => MetricsHttpResponse;
    setHeader?: (name: string, value: string) => unknown;
    writeHead?: (code: number, headers?: Record<string, string>) => unknown;
    send?: (body: string) => unknown;
    end?: (body?: string) => unknown;
}
/** Express and Node HTTP compatible `/metrics` route handler factory. */
export declare function createMetricsHandler(registry?: MetricsRegistry): (_req: unknown, res: MetricsHttpResponse) => void;
export type SpanKind = 'internal' | 'client' | 'server';
export type SpanStatus = 'unset' | 'ok' | 'error';
export type SpanAttributeValue = string | number | boolean;
export type SpanAttributes = Readonly<Record<string, SpanAttributeValue | undefined>>;
export interface SpanEvent {
    name: string;
    timestampMs: number;
    attributes?: Record<string, SpanAttributeValue>;
}
export interface RecordedSpan {
    name: string;
    kind: SpanKind;
    startedAtMs: number;
    endedAtMs: number;
    durationMs: number;
    status: SpanStatus;
    statusMessage?: string;
    attributes: Record<string, SpanAttributeValue>;
    events: SpanEvent[];
}
export interface StartSpanOptions {
    kind?: SpanKind;
    attributes?: SpanAttributes;
    startTimeMs?: number;
}
export interface SpanHandle {
    setAttribute(key: string, value: SpanAttributeValue | undefined): void;
    setAttributes(attributes: SpanAttributes): void;
    addEvent(name: string, attributes?: SpanAttributes, timestampMs?: number): void;
    setStatus(status: SpanStatus, message?: string): void;
    recordException(error: unknown): void;
    end(endTimeMs?: number): void;
}
export interface SpanRecorder {
    startSpan(name: string, options?: StartSpanOptions): SpanHandle;
}
/** Registers an external or in-process OTel-style SpanRecorder; returns a dispose callback. */
export declare function registerSpanRecorder(recorder: SpanRecorder): () => void;
export declare function startSpan(name: string, options?: StartSpanOptions): SpanHandle;
export declare function withSpan<T>(name: string, options: StartSpanOptions, run: (span: SpanHandle) => Promise<T>): Promise<T>;
export declare class InMemorySpanRecorder implements SpanRecorder {
    private readonly maxSpans;
    readonly spans: RecordedSpan[];
    constructor(maxSpans?: number);
    clear(): void;
    startSpan(name: string, options?: StartSpanOptions): SpanHandle;
}
export interface ProviderMetrics {
    providerCircuitState: Gauge;
    providerOwnerCircuitsOpen: Gauge;
    providerCircuitTransitionsTotal: Counter;
    providerResilienceRejectionsTotal: Counter;
    providerInflight: Gauge;
    providerCallsTotal: Counter;
    providerCallDurationMs: Histogram;
}
export declare function bindProviderMetrics(registry: MetricsRegistry): ProviderMetrics;
export declare const metrics: MetricsRegistry;
export declare const runtimeMetrics: {
    providerCircuitState: Gauge;
    providerOwnerCircuitsOpen: Gauge;
    providerCircuitTransitionsTotal: Counter;
    providerResilienceRejectionsTotal: Counter;
    providerInflight: Gauge;
    providerCallsTotal: Counter;
    providerCallDurationMs: Histogram;
    operationDurationMs: Histogram;
    operationsTotal: Counter;
    operationErrorsTotal: Counter;
    operationDbStatementsTotal: Counter;
    operationDbDurationMs: Histogram;
    operationDbLockTimeoutsTotal: Counter;
    hotEditBatchesTotal: Counter;
    hotEditBatchSize: Histogram;
    commitFallbacksTotal: Counter;
    objectLockWaitsTotal: Counter;
    objectLockWaitMs: Histogram;
    runtimeEventsTotal: Counter;
    accessCacheTotal: Counter;
    readReplicaFallbacksTotal: Counter;
    kernelFallbacksTotal: Counter;
};
export {};
