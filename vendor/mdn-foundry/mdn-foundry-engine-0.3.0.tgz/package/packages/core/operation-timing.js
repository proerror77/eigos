import { AsyncLocalStorage } from 'node:async_hooks';
import { profileDatabase, profileSummary } from './database-profile.js';
import { runtimeMetrics, startSpan } from './metrics.js';
const timing = new AsyncLocalStorage();
const CIRCUIT_STATE_VALUE = { closed: 0, half_open: 1, open: 2 };
export function withOperationTiming(correlation, run) {
    return timing.run(correlation, run);
}
/** Keep the owning run when a harness invokes its tools from another connection. */
export function bindOperationTiming(run) {
    const correlation = timing.getStore();
    return correlation ? (input) => timing.run(correlation, () => run(input)) : run;
}
/** Logs one runtime event with the current run's correlation, if any, and bridges it into Prometheus metrics. */
export function recordOperationEvent(event, fields = {}, options) {
    if (options?.log !== false) {
        console.info(JSON.stringify({ event, ...timing.getStore(), ...fields, at: new Date().toISOString() }));
    }
    runtimeMetrics.runtimeEventsTotal.inc({ event });
    if (event === 'hot_edit_batch') {
        runtimeMetrics.hotEditBatchesTotal.inc();
        if (typeof fields.requests === 'number')
            runtimeMetrics.hotEditBatchSize.observe(fields.requests);
    }
    else if (event === 'commit_fallback') {
        runtimeMetrics.commitFallbacksTotal.inc({
            operation: typeof fields.operation === 'string' && fields.operation ? fields.operation : 'unknown',
            reason: typeof fields.reason === 'string' && fields.reason ? fields.reason : 'unknown',
        });
    }
    else if (event === 'object_lock_wait') {
        // Intentionally omit high-cardinality objectKey from Prometheus labels.
        const mode = fields.mode === 'shared' || fields.mode === 'exclusive' ? fields.mode : 'unknown';
        runtimeMetrics.objectLockWaitsTotal.inc({ mode });
        if (typeof fields.waitMs === 'number')
            runtimeMetrics.objectLockWaitMs.observe(fields.waitMs, { mode });
    }
    else if (event === 'access_cache_hit') {
        runtimeMetrics.accessCacheTotal.inc({ result: 'hit' });
    }
    else if (event === 'access_cache_miss') {
        runtimeMetrics.accessCacheTotal.inc({ result: 'miss' });
    }
    else if (event === 'read_replica_fallback') {
        const reason = typeof fields.reason === 'string' && fields.reason ? fields.reason : 'unknown';
        runtimeMetrics.readReplicaFallbacksTotal.inc({ reason });
    }
    else if (event === 'kernel_fallback') {
        const reason = typeof fields.reason === 'string' && fields.reason ? fields.reason : 'unknown';
        runtimeMetrics.kernelFallbacksTotal.inc({ reason });
    }
    else if (event === 'provider_circuit_state') {
        const provider = typeof fields.provider === 'string' && fields.provider ? fields.provider : 'unknown';
        const scope = fields.scope === 'owner' ? 'owner' : 'provider';
        const state = typeof fields.state === 'string' ? CIRCUIT_STATE_VALUE[fields.state] : undefined;
        if (state !== undefined)
            runtimeMetrics.providerCircuitState.set(state, { provider, scope });
        if (typeof fields.openOwnerCircuits === 'number') {
            runtimeMetrics.providerOwnerCircuitsOpen.set(fields.openOwnerCircuits, { provider });
        }
    }
    else if (event === 'provider_circuit_transition') {
        const provider = typeof fields.provider === 'string' && fields.provider ? fields.provider : 'unknown';
        const scope = fields.scope === 'owner' ? 'owner' : 'provider';
        const from = typeof fields.from === 'string' && fields.from ? fields.from : 'unknown';
        const to = typeof fields.to === 'string' && fields.to ? fields.to : 'unknown';
        runtimeMetrics.providerCircuitTransitionsTotal.inc({ provider, scope, from, to });
        const state = CIRCUIT_STATE_VALUE[to];
        if (scope === 'provider' && state !== undefined) {
            runtimeMetrics.providerCircuitState.set(state, { provider, scope });
        }
        if (typeof fields.openOwnerCircuits === 'number') {
            runtimeMetrics.providerOwnerCircuitsOpen.set(fields.openOwnerCircuits, { provider });
        }
    }
    else if (event === 'provider_resilience_rejected') {
        const provider = typeof fields.provider === 'string' && fields.provider ? fields.provider : 'unknown';
        const scope = fields.scope === 'owner' ? 'owner' : 'provider';
        const reason = typeof fields.reason === 'string' && fields.reason ? fields.reason : 'unknown';
        runtimeMetrics.providerResilienceRejectionsTotal.inc({ provider, scope, reason });
    }
}
export async function timeOperation(stage, run, operation) {
    const correlation = timing.getStore();
    const opLabel = operation && operation.length ? operation : 'default';
    const started = performance.now();
    const span = startSpan(`eigos.${stage}`, {
        kind: 'internal',
        attributes: {
            'eigos.stage': stage,
            'eigos.operation': opLabel,
        },
    });
    if (!correlation) {
        let outcome = 'threw';
        try {
            const result = await run();
            outcome = 'returned';
            span.setStatus('ok');
            return result;
        }
        catch (error) {
            span.recordException(error);
            span.setStatus('error', error instanceof Error ? error.message : String(error));
            runtimeMetrics.operationErrorsTotal.inc({ stage, operation: opLabel });
            throw error;
        }
        finally {
            const durationMs = Math.max(0, performance.now() - started);
            runtimeMetrics.operationsTotal.inc({ stage, operation: opLabel, outcome });
            runtimeMetrics.operationDurationMs.observe(durationMs, { stage, operation: opLabel, outcome });
            span.setAttribute('eigos.outcome', outcome);
            span.end();
        }
    }
    const startedAt = new Date().toISOString();
    return profileDatabase(async (profile) => {
        let outcome = 'threw';
        try {
            const result = await run();
            outcome = 'returned';
            span.setStatus('ok');
            return result;
        }
        catch (error) {
            span.recordException(error);
            span.setStatus('error', error instanceof Error ? error.message : String(error));
            runtimeMetrics.operationErrorsTotal.inc({ stage, operation: opLabel });
            throw error;
        }
        finally {
            const elapsedMs = Math.max(0, performance.now() - started);
            const db = profileSummary(profile);
            runtimeMetrics.operationsTotal.inc({ stage, operation: opLabel, outcome });
            runtimeMetrics.operationDurationMs.observe(elapsedMs, { stage, operation: opLabel, outcome });
            if (db.statements > 0) {
                runtimeMetrics.operationDbStatementsTotal.inc({ stage }, db.statements);
                runtimeMetrics.operationDbDurationMs.observe(db.durationMs, { stage });
            }
            if (db.lockTimeouts > 0) {
                runtimeMetrics.operationDbLockTimeoutsTotal.inc({ stage }, db.lockTimeouts);
            }
            span.setAttributes({
                'eigos.outcome': outcome,
                'eigos.db.statements': db.statements,
                'eigos.db.duration_ms': db.durationMs,
                'eigos.db.lock_timeouts': db.lockTimeouts,
            });
            span.end();
            console.info(JSON.stringify({
                event: 'stage_timing', ...correlation, stage, operation, outcome,
                startedAt, finishedAt: new Date().toISOString(), durationMs: Math.round(elapsedMs),
                db,
            }));
        }
    });
}
