import { analyzeProposal } from './machinery-proposal.js';
import { ChangeSubscriptions, watchMachinerySchema } from './change-subscriptions.js';
import { MachineryWatchPlanner } from './machinery-watch.js';
import { ObservationInterests, startInterestSchema, listInterestsSchema, cancelInterestSchema } from './observation-interests.js';
import { ProcessNotifications, notificationsSchema, readNotificationSchema } from './process-notifications.js';
import { digest } from '../core/identity.js';
import { randomUUID } from 'node:crypto';
import { isScenarioReviewAction, scenarioReviewActions } from '../ontology/scenario-definition.js';
import { resourceGroups } from '../ontology/resource-mapping.js';
import { EntityResolution, bindEntitySchema, entityLookupSchema, entityHistorySchema, } from './entity-resolution.js';
import { Applications, objectViewSchema, graphSchema, mapSchema } from './applications.js';
import { Automation, processBindingsSchema, workflowSchema, saveRuleSchema, runWorkflowSchema, automationPreviewSchema, publishWorkflowSchema, withdrawWorkflowSchema, runPublishedWorkflowSchema } from './automation.js';
import { analyzeMachinery, listMachineryProcesses, machineryAnalysisSchema } from './machinery-analysis.js';
import { ingestMachineryHistory, machineryHistorySchema } from './machinery-history.js';
import { MachineryReviews, machineryReviewSchema } from './machinery-reviews.js';
import { processStatusSchema } from './process-automation.js';
import { SemanticSearch, semanticConfigureSchema, semanticIndexSchema, semanticSearchSchema, semanticStatusSchema, } from './semantic.js';
import { OntologyPackages, exportPackageSchema, importPackageSchema, migrateDefinitionsSchema, migrateOntologyDataSchema, readDataMigrationSchema, } from './ontology-packages.js';
import { Tasks, publicTask } from './tasks.js';
import { z } from 'zod';
import { Conflict, PermissionDenied, requireScope } from '../core/identity.js';
import { machineryModelSchema, objectRefSchema, ontologyName } from '../ontology/schema.js';
import { MachineryExecution, machineryNextActionsInput, machineryReplanInput } from './machinery-execution.js';
import { Access } from './access.js';
import { ScenarioEvaluations, compareScenariosSchema, trialScenariosSchema, saveEvaluationSuiteSchema, runEvaluationSuiteSchema, promoteEvaluationSchema, evaluationCasesFromSetSchema } from './scenario-evaluation.js';
import { Scenarios, continueScenarioSchema } from './scenarios.js';
import { Objects } from './objects.js';
import { ObjectSets, evaluateSetViewSchema, aggregateSetViewSchema, saveSetSchema, listSetsSchema, } from './object-sets.js';
import { Indexing, indexingInputSchema } from './indexing.js';
import { Materializations, materializationInputSchema } from './materializations.js';
import { EditHistory, conflictPolicySchema, setConflictPolicy } from './edit-history.js';
import { ExecutionTrace, executionTraceSchema } from './execution-trace.js';
import { actionBatchSchema, actionCallSchema } from '../ontology/invocation.js';
import { actionLogSchema, listActionLog } from './action-log.js';
import { Governance, projectSchema, assignProjectSchema, branchCreateSchema, branchRevisionSchema, branchReviewSchema, branchUpdateSchema, } from './governance.js';
const mcpOntologyExtension = { _ontology: z.string().optional() };
function buildMcpServiceSchema(schema) {
    return schema.safeExtend(mcpOntologyExtension);
}
const mcpSchemaCache = new WeakMap();
function extendMcpServiceSchema(schema) {
    let extended = mcpSchemaCache.get(schema);
    if (!extended) {
        extended = buildMcpServiceSchema(schema);
        mcpSchemaCache.set(schema, extended);
    }
    return extended;
}
export const DEFAULT_ONTOLOGY_SERVICE_CACHE_SIZE = 32;
/** Bounded LRU cache for non-default Ontology service maps; the default ontology stays pinned. */
export class OntologyServiceCache {
    defaultOntologyId;
    build;
    defaultServices;
    maxEntries;
    entries = new Map();
    hitCount = 0;
    missCount = 0;
    constructor(defaultOntologyId, build, maxEntries = DEFAULT_ONTOLOGY_SERVICE_CACHE_SIZE) {
        this.defaultOntologyId = defaultOntologyId;
        this.build = build;
        this.maxEntries = Number.isFinite(maxEntries)
            ? Math.max(0, Math.trunc(maxEntries))
            : DEFAULT_ONTOLOGY_SERVICE_CACHE_SIZE;
        this.defaultServices = build(defaultOntologyId);
    }
    get(ontologyId) {
        if (!ontologyId || ontologyId === this.defaultOntologyId)
            return this.defaultServices;
        const cached = this.entries.get(ontologyId);
        if (cached) {
            this.hitCount++;
            this.entries.delete(ontologyId);
            this.entries.set(ontologyId, cached);
            return cached;
        }
        this.missCount++;
        const created = this.build(ontologyId);
        if (this.maxEntries > 0) {
            if (this.entries.size >= this.maxEntries) {
                const oldest = this.entries.keys().next().value;
                if (oldest !== undefined)
                    this.entries.delete(oldest);
            }
            this.entries.set(ontologyId, created);
        }
        return created;
    }
    get size() {
        return this.entries.size;
    }
    stats() {
        return { hits: this.hitCount, misses: this.missCount, size: this.entries.size, maxEntries: this.maxEntries };
    }
}
const emptyObjectSchema = z.strictObject({});
const idSchema = z.strictObject({ id: z.uuid() });
const deleteSetSchema = idSchema.extend({ revision: z.number().int().positive() });
const readMaterializationSchema = idSchema.extend({ cursor: z.string().optional() });
const materializedLinksSchema = idSchema.extend({ after: z.number().int().min(0).optional() });
const editHistorySchema = z.strictObject({
    object: objectRefSchema,
    after: z.string().optional(),
    limit: z.number().int().min(1).max(100).optional(),
});
const editPolicySchema = z.strictObject({ type: z.string(), policy: conflictPolicySchema });
const effectStatusSchema = z.strictObject({ requestId: z.string().min(1).max(128) });
const retryEffectSchema = z.strictObject({ id: z.string().regex(/^[a-f0-9]{64}$/) });
const readObjectSchema = z.strictObject({ object: objectRefSchema, scenarioId: z.uuid().optional() });
const followLinksSchema = z.strictObject({ object: objectRefSchema, link: z.string(), scenarioId: z.uuid().optional() });
const objectViewInputSchema = z.strictObject({ type: z.string() });
const exploreGraphSchema = graphSchema.extend({ scenarioId: z.uuid().optional() });
const mapObjectsSchema = mapSchema.extend({ scenarioId: z.uuid().optional() });
const semanticSearchServiceSchema = semanticSearchSchema.extend({ scenarioId: z.uuid().optional() });
const semanticStatusServiceSchema = semanticStatusSchema.extend({ scenarioId: z.uuid().optional() });
const openScenarioSessionSchema = z.strictObject({ ttlSeconds: z.number().int().min(60).max(86400).optional() });
const closeScenarioSessionSchema = z.strictObject({ sessionId: z.uuid() });
const trialCandidateScenariosSchema = z.strictObject({
    release: z.string().regex(/^[0-9a-f]{64}$/),
    trial: trialScenariosSchema,
});
const inspectScenarioContinuationSchema = z.strictObject({ id: z.uuid(), revision: z.number().int().positive() });
const shareScenarioSchema = z.strictObject({
    id: z.uuid(),
    revision: z.number().int().positive(),
    readers: z.array(z.string()).max(100),
});
const undoActionSchema = z.strictObject({ originalRequestId: z.string().min(1), requestId: z.string().min(1) });
const scenarioRevisionSchema = idSchema.extend({ revision: z.number().int().positive() });
const inviteScenarioReviewersSchema = scenarioRevisionSchema.extend({
    reviewers: z.array(z.string().min(1).max(200)).max(100),
});
const pendingScenarioReviewsSchema = z.strictObject({ page: z.number().int().min(1).max(1000).default(1) });
const approveScenarioReviewSchema = scenarioRevisionSchema.extend({
    snapshot: z.string().regex(/^[a-f0-9]{64}$/),
    decision: z.record(z.string(), z.unknown()).optional(),
});
const rejectScenarioReviewSchema = scenarioRevisionSchema.extend({ snapshot: z.string().regex(/^[a-f0-9]{64}$/) });
const saveMachineryCasesSchema = z.strictObject({
    analysis: machineryAnalysisSchema,
    name: z.string().min(1).max(200),
    requestId: z.string().min(1).max(128),
    mode: z.enum(['static', 'dynamic']).default('static'),
});
const machineryProposeModelSchema = z.strictObject({
    type: ontologyName,
    model: machineryModelSchema,
    name: z.string().min(1).max(200),
    release: z.string().regex(/^[0-9a-f]{64}$/),
    project: ontologyName.optional(),
    analysis: machineryAnalysisSchema.optional(),
});
const refreshMachineryProposalEvidenceSchema = branchRevisionSchema.extend({ analysis: machineryAnalysisSchema });
export function ontologyServices(db, metadata, bindings, functions, effects, actions, ontologyId = metadata.ontologyId) {
    const active = () => metadata.active(ontologyId);
    const evaluations = new ScenarioEvaluations(db, actions, functions);
    const applications = new Applications(db), automation = new Automation(db, metadata, actions), machinery = new MachineryReviews(db, metadata, evaluations), notifications = new ProcessNotifications(db, metadata), semantic = new SemanticSearch(db, functions), packages = new OntologyPackages(db, metadata, bindings);
    const sets = new ObjectSets(db), indexing = new Indexing(db, metadata), materializations = new Materializations(db), governance = new Governance(db, metadata, bindings);
    const ontology = z.strictObject({ ontology: z.string().default(ontologyId) });
    const services = new Map();
    const register = (name, description, schema, write, run, options) => {
        const invoke = async (principal, raw, mcpOperatorRead) => {
            if (!mcpOperatorRead)
                requireScope(principal, write ? 'ontology:write' : 'ontology:read');
            const access = await Access.load(db, principal);
            if (mcpOperatorRead)
                access.require(ontologyId, 'view_definition', ontologyId, true);
            const result = await run(access, schema.parse(raw));
            if (!write && !(await access.canReturn(access.dataRequirements())))
                throw new PermissionDenied('Result permissions changed');
            return result;
        };
        services.set(name, {
            schema,
            mcpInputSchema: extendMcpServiceSchema(schema),
            description,
            invoke: (principal, raw) => invoke(principal, raw, false),
            ...(!write && options?.mcpOperatorRead && ontologyId === 'Eigos' && {
                invokeForMcpOperator: (principal, raw) => invoke(principal, raw, true),
            }),
        });
    };
    const define = async (access) => {
        const model = await active();
        access.require(model.document.id, 'edit_definition', model.document.id);
        return model;
    };
    register('workbench_access', 'Report the verified account’s Workbench role and available editing scope.', emptyObjectSchema, false, async (a) => {
        const model = await active(), ontology = model.document.id;
        a.require(ontology, 'view_definition', ontology);
        const role = a.workbenchRole(ontology), writable = a.principal.scopes.includes('ontology:write');
        return { role, ontology, version: model.document.version, release: model.release,
            canAuthorWorkflows: writable && a.allows({ ontology, resource: ontology, permission: 'edit_definition' }),
            canPublishWorkflows: writable && role === 'admin' };
    });
    register('published_workflows', 'List compatible published Workflows the caller can use.', emptyObjectSchema, false, async (a) => automation.listPublishedWorkflows(a, await active()));
    register('publish_workflow', 'Publish an exact Workflow draft revision for authorized users.', publishWorkflowSchema, true, async (a, input) => automation.publishWorkflow(a, await active(), input));
    register('withdraw_workflow', 'Withdraw an exact published Workflow revision.', withdrawWorkflowSchema, true, async (a, input) => automation.withdrawWorkflow(a, await active(), input));
    register('run_published_workflow', 'Execute an exact published Workflow revision against the caller’s authorized object.', runPublishedWorkflowSchema, true, async (a, input) => automation.runPublishedWorkflow(a, await active(), input));
    const view = async (access, scenarioId) => {
        const model = await active();
        return scenarioId ? new Scenarios(db).view(access, model, scenarioId) : model;
    };
    register('evaluate_set', 'Evaluate a composed or saved object set with current permissions.', evaluateSetViewSchema, false, async (a, { scenarioId, ...input }) => sets.evaluate(a, await view(a, scenarioId), input));
    register('aggregate_set', 'Group and aggregate a complete authorized object set.', aggregateSetViewSchema, false, async (a, { scenarioId, ...input }) => sets.aggregate(a, await view(a, scenarioId), input));
    register('save_set', 'Save static membership or a dynamic set definition with explicit readers.', saveSetSchema, true, async (a, input) => sets.save(a, await active(), input));
    register('get_set', 'Read a saved object set definition permitted to this identity.', idSchema, false, async (a, input) => sets.get(a, await active(), input.id));
    register('list_sets', 'List owned and shared set definitions.', listSetsSchema, false, async (a, input) => sets.list(a, await active(), input));
    register('delete_set', 'Delete an owned saved set at its reviewed revision.', deleteSetSchema, true, async (a, input) => sets.remove(a, await active(), input.id, input.revision));
    register('submit_index', 'Submit an authorized source transaction with ordered offset.', indexingInputSchema, true, async (a, input) => indexing.submit(a, await active(), input));
    register('index_status', 'Read durable source indexing progress.', idSchema, false, async (a, input) => indexing.inspect(a, await active(), input.id));
    register('retry_index', 'Retry a failed source transaction with its original identity.', idSchema, true, async (a, input) => indexing.retry(a, await active(), input.id));
    register('cancel_index', 'Cancel an owned source transaction and skip its ordered offset.', idSchema, true, async (a, input) => indexing.cancel(a, await active(), input.id));
    register('materialize', 'Capture resolved objects and links in an atomic authorized dataset.', materializationInputSchema, true, async (a, input) => materializations.capture(a, await active(), input));
    register('read_materialization', 'Read a captured dataset after current object and property authorization.', readMaterializationSchema, false, async (a, input) => materializations.read(a, await active(), input.id, input.cursor));
    register('materialized_links', 'Read authorized relationships from a materialization.', materializedLinksSchema, false, async (a, input) => materializations.links(a, await active(), input.id, input.after));
    register('edit_history', 'Read object edit history under current security policies.', editHistorySchema, false, async (a, input) => new EditHistory(db).read(new Objects(db, await active(), a), input.object, input.after, input.limit));
    register('execution_trace', 'Read causal identities and states for an owned task or committed Action.', executionTraceSchema, false, (a, input) => new ExecutionTrace(db, metadata).read(a, ontologyId, input));
    register('validate_action', 'Check a published Action’s parameters, object access and submission criteria without executing it.', actionCallSchema, true, async (a, input) => actions.validate(a, await view(a, input.scenarioId), input));
    register('apply_action_batch', 'Atomically submit up to 20 live declarative Actions without declared effects or Scenario merges, each with its own request ID.', actionBatchSchema, true, async (a, input) => actions.applyBatch(a, await active(), input));
    register('list_action_log', 'List committed Action receipts for one publication using current Action definition permissions.', actionLogSchema, false, (a, input) => listActionLog(db, metadata, a, ontologyId, input));
    register('edit_policy', 'Configure source and user edit conflict resolution.', editPolicySchema, true, async (a, input) => setConflictPolicy(db, a, await active(), input.type, input.policy));
    register('project', 'Create or update a project for Ontology resource ownership.', projectSchema, true, (a, input) => governance.project(a, input));
    if (ontologyId === metadata.ontologyId)
        bindings.registerServices?.(register, db, metadata, actions);
    register('assign_project', 'Assign published resources to a project.', assignProjectSchema, true, (a, input) => governance.assign(a, input));
    register('create_branch', 'Create an isolated Ontology definition branch.', branchCreateSchema, true, (a, input) => governance.create(a, input));
    register('get_branch', 'Inspect a definition branch and proposal.', idSchema, false, (a, input) => governance.read(a, input.id));
    register('list_branches', 'List accessible Ontology branches.', ontology, false, (a, input) => governance.list(a, input.ontology));
    register('update_branch', 'Update a branch at its expected revision.', branchUpdateSchema, true, (a, input) => governance.update(a, input));
    register('prepare_branch', 'Validate branch bindings and prepare a candidate projection.', branchRevisionSchema, true, (a, input) => governance.prepare(a, input));
    register('review_branch', 'Approve the exact candidate publication for a branch.', branchReviewSchema, true, (a, input) => governance.review(a, input));
    register('merge_branch', 'Activate a reviewed candidate publication atomically.', branchReviewSchema, true, (a, input) => governance.merge(a, input));
    register('rebase_branch', 'Rebase a branch onto the current Ontology definition.', branchRevisionSchema, true, (a, input) => governance.rebase(a, input));
    register('catch_up_branch', 'Synchronize candidate data and require a fresh proposal review.', branchRevisionSchema, true, (a, input) => governance.catchUp(a, input));
    register('function_versions', 'List registered function versions visible to this identity.', emptyObjectSchema, false, async (a) => {
        const model = await active();
        return functions
            .versions()
            .filter((fn) => model.functions.has(fn.name) && a.canDefine(model, 'function', fn.name));
    });
    register('effect_status', 'Read Action effect delivery state.', effectStatusSchema, false, (a, input) => effects.status(a, input.requestId));
    register('retry_effect', 'Retry a failed Action effect using its stable idempotency key.', retryEffectSchema, true, (a, input) => effects.retry(a, input.id));
    register('raw_definition', 'Read the complete definition for authorized editing.', emptyObjectSchema, false, async (a) => {
        const model = await active();
        a.require(model.document.id, 'view_definition', model.document.id);
        if (a.workbenchRole(model.document.id) === 'member')
            throw new PermissionDenied('Ontology management requires service team access');
        return model.document;
    });
    register('read_object', 'Read one authorized object.', readObjectSchema, false, async (a, input) => new Objects(db, await view(a, input.scenarioId), a).read(input.object));
    register('follow_links', 'Read up to 100 objects related by a published Link. Use query_ontology with from and cursor for larger relationships.', followLinksSchema, false, async (a, input) => new Objects(db, await view(a, input.scenarioId), a).follow(input.object, input.link, input.object.type, 100));
    register('object_view', 'Read the configured object view.', objectViewInputSchema, false, async (a, input) => applications.view(a, await active(), input.type));
    register('save_object_view', 'Save an object view configuration.', objectViewSchema, true, async (a, input) => applications.saveView(a, await active(), input));
    register('explore_graph', 'Expand relationships from an authorized object.', exploreGraphSchema, false, async (a, { scenarioId, ...input }) => applications.graph(a, await view(a, scenarioId), input));
    register('map_objects', 'Read authorized object coordinates.', mapObjectsSchema, false, async (a, { scenarioId, ...input }) => applications.map(a, await view(a, scenarioId), input));
    register('semantic_configure', 'Configure a published embedding Function and vector index.', semanticConfigureSchema, true, async (a, input) => semantic.configure(a, await active(), input));
    register('semantic_index', 'Index authorized current object text using the configured embedding Function.', semanticIndexSchema, true, async (a, input) => semantic.index(a, await active(), input));
    register('semantic_search', 'Search authorized objects by meaning in the live Ontology or a Scenario. Pass from for documents linked to a business object.', semanticSearchServiceSchema, false, async (a, { scenarioId, ...input }) => semantic.search(a, await view(a, scenarioId), input));
    register('semantic_status', 'Read semantic index coverage and model binding in the live Ontology or a Scenario.', semanticStatusServiceSchema, false, async (a, { scenarioId, name }) => semantic.status(a, await view(a, scenarioId), name));
    register('export_package', 'Export authorized ontology resources with dependency closure.', exportPackageSchema, false, (a, input) => packages.export(a, input));
    register('import_package', 'Prepare a shared or copied package import as a definition proposal.', importPackageSchema, true, (a, input) => packages.import(a, input));
    register('migrate_definitions', 'Map resources into another Ontology through a proposal.', migrateDefinitionsSchema, true, (a, input) => packages.migrate(a, input));
    register('open_scenario_session', 'Open a session for temporary scenarios.', openScenarioSessionSchema, true, (a, input) => new Scenarios(db).openSession(a, input.ttlSeconds));
    register('close_scenario_session', 'Close the session and clean its temporary scenarios.', closeScenarioSessionSchema, true, (a, input) => new Scenarios(db).closeSession(a, input.sessionId));
    register('trial_candidate_scenarios', 'Run an offline trial against a prepared definition and release projection without activating it.', trialCandidateScenariosSchema, true, async (a, input) => {
        requireScope(a.principal, 'ontology:read');
        const current = await active();
        a.require(current.document.id, 'edit_definition', current.document.id);
        const candidate = await metadata.get(input.release);
        if (candidate.document.id !== current.document.id)
            throw new Conflict('Candidate belongs to another Ontology');
        metadata.checkBindings(candidate, bindings);
        return evaluations.trial(a, candidate, input.trial, current.release);
    });
    register('evaluation_suites', 'List saved evaluation suites and run references.', emptyObjectSchema, false, async (a) => evaluations.listSuites(a, await active()));
    register('evaluation_cases_from_set', 'Generate trial case inputs from authorized Object Set members and their current revisions.', evaluationCasesFromSetSchema, false, async (a, input) => evaluations.casesFromSet(a, await active(), input));
    register('save_evaluation_suite', 'Save a revisioned Scenario trial, optionally scoped to a Machinery Object Set.', saveEvaluationSuiteSchema, true, async (a, input) => evaluations.saveSuite(a, await active(), input));
    register('run_evaluation_suite', 'Run a saved revision and retain a release-bound result receipt.', runEvaluationSuiteSchema, true, async (a, input) => {
        requireScope(a.principal, 'ontology:read');
        return evaluations.runSuite(a, await active(), input);
    });
    register('promote_evaluation_candidate', 'Re-evaluate a selected trial result and create a persisted Scenario for invited reviewers.', promoteEvaluationSchema, true, async (a, input) => {
        requireScope(a.principal, 'ontology:read');
        return evaluations.promote(a, await active(), input);
    });
    register('scenario_continuation_sources', 'List owned temporary or previous-release drafts with Action-journal readiness and recovery reasons.', emptyObjectSchema, false, async (a) => new Scenarios(db).continuationSources(a, await active()));
    register('inspect_scenario_continuation', 'Read an owned historical draft difference under current permissions before re-proposing its business edits.', inspectScenarioContinuationSchema, false, async (a, input) => new Scenarios(db).inspectContinuation(a, await active(), input.id, input.revision));
    register('continue_scenario', 'Replay a compatible Scenario journal into a new persisted draft with fresh review.', continueScenarioSchema, true, async (a, input) => new Scenarios(db).continueScenario(a, await active(), input));
    register('preview_automation', 'Evaluate a saved automation against Scenario revisions and preview its Actions without enqueuing a live run.', automationPreviewSchema, true, async (a, input) => automation.preview(a, await define(a), input));
    register('scenario_trial_options', 'List the authorized Actions and read-only Functions available for an offline Scenario trial.', emptyObjectSchema, false, async (access) => evaluations.options(access, await active()));
    register('compare_scenarios', 'Compare exact Scenario revisions and shared metrics against one current Ontology baseline.', compareScenariosSchema, false, async (access, input) => evaluations.compare(access, await active(), input));
    register('trial_scenarios', 'Execute published Action variants offline on the same evidence, then roll back every trial.', trialScenariosSchema, true, async (access, input) => {
        requireScope(access.principal, 'ontology:read');
        return evaluations.trial(access, await active(), input);
    });
    register('share_scenario', 'Share persisted Scenario metadata with specific readers.', shareScenarioSchema, true, async (a, input) => new Scenarios(db).share(a, await active(), input.id, input.revision, input.readers));
    register('undo_action', 'Compensate recorded data edits after revision and permission checks.', undoActionSchema, true, async (a, input) => actions.undo(a, await active(), input.originalRequestId, input.requestId));
    register('rebase_scenario', 'Rebase an owned proposal over compatible live object changes and issue a new revision.', scenarioRevisionSchema, true, async (a, input) => new Scenarios(db).rebase(a, await active(), input.id, input.revision));
    register('invite_scenario_reviewers', 'Require an invited separate identity to approve the exact owned proposal revision before merge.', inviteScenarioReviewersSchema, true, async (a, input) => {
        const model = await active();
        if (!isScenarioReviewAction(model.actions.get(scenarioReviewActions.submit)))
            return new Scenarios(db).inviteReviewers(a, model, input.id, input.revision, input.reviewers);
        await actions.apply(a, model, scenarioReviewActions.submit, input, randomUUID());
        return { id: input.id, revision: input.revision + 1, reviewers: [...new Set(input.reviewers)].sort() };
    });
    register('pending_scenario_reviews', 'List Scenario reviews invited to the authenticated account and currently visible to it.', pendingScenarioReviewsSchema, false, async (a, { page }) => new Scenarios(db).pendingReviews(a, await active(), page));
    register('inspect_scenario_review', 'Read the proposed edits as an invited reviewer under current object and property permissions.', idSchema, false, async (a, input) => new Scenarios(db, bindings.scenarioDecisions).inspectReview(a, await active(), input.id));
    register('approve_scenario_review', 'Approve the revision and snapshot returned by the invited reviewer inspection.', approveScenarioReviewSchema, true, async (a, input) => {
        const model = await active();
        if (!isScenarioReviewAction(model.actions.get(scenarioReviewActions.approve)))
            return new Scenarios(db, bindings.scenarioDecisions).approveReview(a, model, input.id, input.revision, input.snapshot, input.decision);
        await actions.apply(a, model, scenarioReviewActions.approve, input, randomUUID());
        return { id: input.id, revision: input.revision, reviewer: a.principal.owner, approved: true };
    });
    register('reject_scenario_review', 'Reject the exact reviewed Scenario revision and snapshot.', rejectScenarioReviewSchema, true, async (a, input) => {
        const model = await active();
        if (!isScenarioReviewAction(model.actions.get(scenarioReviewActions.reject)))
            throw new Conflict('The published Scenario rejection Action is unavailable');
        await actions.apply(a, model, scenarioReviewActions.reject, input, randomUUID());
        return { id: input.id, revision: input.revision, reviewer: a.principal.owner, rejected: true };
    });
    register('save_workflow', 'Save an authorized sequence of Actions with an optional reviewed Scenario proposal.', workflowSchema, true, async (a, input) => automation.workflow(a, await define(a), input));
    register('save_rule', 'Configure an object-set entry or field-change rule, or a committed process transition rule with optional related-object inputs.', saveRuleSchema, true, async (a, input) => automation.rule(a, await define(a), input));
    register('workflows', 'List workflows.', emptyObjectSchema, false, async (a) => automation.list(a, await define(a), 'workflows'));
    register('rules', 'List rules and monitoring state.', emptyObjectSchema, false, async (a) => automation.list(a, await define(a), 'object_rules'));
    register('process_status', 'Read the current process state, its most recent visible transition and how long the state has been recorded.', processStatusSchema, false, async (a, input) => automation.processStatus(a, await active(), input));
    register('machinery_rule_bindings', 'Read this owner’s process conditions, direct Action or Workflow effects, and latest visible run for each current revision.', processBindingsSchema, false, async (a, input) => automation.processBindings(a, await active(), input));
    const interests = new ObservationInterests(db, metadata);
    register('start_observation_interest', 'Authorize an ordered, bounded observation of one original business object.', startInterestSchema, true, async (a, input) => interests.start(a, await active(), input));
    register('observation_interests', 'Read owned observation progress, its next original-object check and continuity gaps.', listInterestsSchema, false, async (a, input) => interests.list(a, await active(), input));
    register('cancel_observation_interest', 'Withdraw an owned observation interest and stop its outstanding checks.', cancelInterestSchema, true, async (a, input) => interests.cancel(a, await active(), input));
    register('process_notifications', 'Read the delivered notifications of your process rules, newest first; unread only on request.', notificationsSchema, false, async (a, input) => notifications.list(a, input));
    register('read_process_notification', 'Mark one of your process rule notifications as read.', readNotificationSchema, true, async (a, input) => notifications.read(a, input));
    register('machinery_processes', 'Discover authorized Ontology processes and their published reference models.', emptyObjectSchema, false, async (a) => listMachineryProcesses(a, await active()), { mcpOperatorRead: true });
    register('machinery_next_actions', 'Read the published Action transitions available to this process object.', machineryNextActionsInput, false, async (a, input) => new MachineryExecution(db, actions).nextActions(await active(), a, input), { mcpOperatorRead: true });
    const processWatches = new ChangeSubscriptions(db, new Tasks(db, metadata), new MachineryWatchPlanner(db, metadata, new MachineryExecution(db, actions)));
    register('watch_machinery_process', 'Watch one process and refresh its Action candidates and observation schedules on committed changes.', watchMachinerySchema, true, async (a, input) => processWatches.watchMachinery(a, await active(), input));
    register('cancel_machinery_watch', 'Stop a change subscription owned by the caller.', idSchema, true, async (a, { id }) => { await processWatches.cancel(a, id, true); return { id }; });
    register('machinery_replan_changes', 'Refresh Action candidates for changed objects and their linked dependent processes. For a removed link, include its surviving process endpoint.', machineryReplanInput, false, async (a, input) => new MachineryExecution(db, actions).replan(await active(), a, input), { mcpOperatorRead: true });
    register('machinery_analysis', 'Mine authorized process paths, compare observed transitions with a reference, and analyze dwell time.', machineryAnalysisSchema, false, async (a, input) => analyzeMachinery(db, a, await active(), input), { mcpOperatorRead: true });
    register('ingest_machinery_history', 'Import idempotent observed transitions for an authorized history source.', machineryHistorySchema, true, async (a, input) => ingestMachineryHistory(db, a, await active(), input));
    register('save_machinery_cases', 'Save the authorized matches of a Machinery filter as an Object Set: static keeps today\'s cases, dynamic analyzes again on each read.', saveMachineryCasesSchema, true, async (a, input) => {
        requireScope(a.principal, 'ontology:read');
        const model = await active(), result = await analyzeMachinery(db, a, model, input.analysis, true);
        if (!result.members?.length)
            throw new Conflict('The analysis contains no visible cases');
        if (!await a.canReturn(a.dataRequirements()))
            throw new Conflict('Machinery case permissions changed');
        if (input.mode === 'dynamic') {
            if (input.analysis.setId || input.analysis.focus)
                throw new Conflict('A dynamic Machinery selection analyzes all readable processes or one object');
            return sets.save(a, model, { requestId: input.requestId, name: input.name, mode: 'dynamic', set: { op: 'machinery', analysis: input.analysis } });
        }
        return sets.save(a, model, { requestId: input.requestId, name: input.name, mode: 'static', set: { op: 'refs', objects: result.members } });
    });
    register('machinery_propose_model', 'Open a definition branch for a manual or mined process model at the observed release.', machineryProposeModelSchema, true, async (a, input) => {
        const current = await active();
        if (current.release !== input.release)
            throw new Conflict('Ontology changed; refresh the process analysis');
        const body = structuredClone(current.document);
        const definition = body.objectTypes.find(type => type.apiName === input.type);
        if (!definition)
            throw new Conflict('Select a local process definition in this Ontology');
        definition.machinery = input.model;
        const evidence = input.analysis && await analyzeProposal(db, a, current, input.analysis, input.type, input.model);
        return governance.create(a, { ontology: ontologyId, name: input.name, project: input.project,
            body, baseRelease: current.release }, evidence);
    });
    register('refresh_machinery_proposal_evidence', 'Recompute the evidence for this Machinery branch revision and reopen it for review.', refreshMachineryProposalEvidenceSchema, true, async (a, input) => governance.refreshMachineryEvidence(a, input.id, input.revision, input.analysis));
    register('save_machinery_review', 'Save or disable periodic review of an authorized Machinery process.', machineryReviewSchema, true, async (a, input) => machinery.save(a, await active(), input));
    register('machinery_reviews', 'List owned periodic Machinery reviews and their latest analyzed windows.', emptyObjectSchema, false, async (a) => machinery.list(a, await active()));
    register('machinery_review', 'Read the last analyzed window with current process permissions.', idSchema, false, async (a, { id }) => machinery.read(a, await active(), id, false));
    register('run_machinery_review', 'Analyze the configured process now and record the authorized analysis window.', idSchema, true, async (a, { id }) => {
        requireScope(a.principal, 'ontology:read');
        return machinery.read(a, await active(), id, true);
    });
    register('workflow_runs', 'List workflow execution progress.', emptyObjectSchema, false, async (a) => automation.list(a, await active(), 'workflow_runs'));
    register('run_workflow', 'Run a saved workflow against an authorized object.', runWorkflowSchema, true, async (a, input) => automation.run(a, await define(a), input));
    register('retry_workflow', 'Resume the remaining steps of a failed workflow.', idSchema, true, async (a, input) => automation.retry(a, await active(), input.id));
    register('tasks', 'Read recent owned task runs.', emptyObjectSchema, false, async (a) => {
        const rows = (await db.query(`SELECT id FROM ${db.schema}.tasks WHERE owner=$1 AND ontology=$2 ORDER BY created_at DESC LIMIT 100`, [
            a.principal.owner, ontologyId,
        ])).rows;
        const tasks = new Tasks(db, metadata);
        return {
            items: await Promise.all(rows.map(async (row) => publicTask(await tasks.get(a.principal, row.id), bindings.projectTaskResult))),
        };
    });
    register('bind_entity', 'Bind a published source identity to a readable canonical object.', bindEntitySchema, true, async (a, input) => new EntityResolution(db).bind(a, await active(), input));
    register('lookup_entity', 'Resolve a published source identity.', entityLookupSchema, false, async (a, input) => new EntityResolution(db).lookup(a, await active(), input));
    register('entity_history', 'Read canonical identity binding audit.', entityHistorySchema, false, async (a, input) => new EntityResolution(db).history(a, await active(), input));
    register('cancel_workflow', 'Cancel uncommitted workflow steps while preserving completed history.', idSchema, true, async (a, input) => automation.cancel(a, await active(), input.id));
    register('migrate_data', 'Copy explicitly mapped authorized data into another Ontology.', migrateOntologyDataSchema, true, (a, input) => packages.migrateData(a, input));
    register('migration_receipt', 'Read current-authorized cross-Ontology migration provenance.', readDataMigrationSchema, false, (a, input) => packages.migrationReceipt(a, input));
    register('proposal_diff', 'Compare a definition proposal to its base.', idSchema, false, async (a, input) => {
        const branch = await governance.read(a, input.id), base = await metadata.get(branch.base_release), changes = [];
        for (const [kind, field] of Object.entries(resourceGroups)) {
            const key = (item) => item.apiName + (item.version ? '@' + item.version : '');
            const before = new Map((base.document[field] ?? []).map(item => [key(item), item]));
            const after = new Map((branch.body[field] ?? []).map((item) => [key(item), item]));
            for (const name of new Set([...before.keys(), ...after.keys()]))
                if (digest(before.get(name) ?? null) !== digest(after.get(name) ?? null))
                    changes.push({ kind, name, before: before.get(name) ?? null, after: after.get(name) ?? null });
        }
        return { id: branch.id, revision: branch.revision, changes };
    });
    return services;
}
