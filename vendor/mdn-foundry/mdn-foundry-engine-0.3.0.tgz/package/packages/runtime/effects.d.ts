import { type Principal } from '../core/identity.js';
import { Access } from './access.js';
import type { Database, Sql } from './database.js';
import { type PublishedOntology } from './metadata.js';
import { type ActionSourceWebhooks } from './action-webhooks.js';
export declare function isTransientError(error: unknown): boolean;
export declare function sanitizeErrorMessage(error: unknown): string;
export declare function errorDiagnostic(error: unknown): {
    name: string;
    code?: string;
    summary: string;
    message: string;
};
export declare function retryBackoffSeconds(attempts: number): number;
export declare function initializeEffects(db: Database): Promise<void>;
export interface EffectContext {
    idempotencyKey: string;
    principal: Principal;
    signal: AbortSignal;
}
export type EffectHandler = (payload: Record<string, unknown>, context: EffectContext) => Promise<void | 'canceled'>;
export interface ActionEffect {
    name: string;
    handler: string;
    payload: Record<string, unknown>;
}
export declare class Effects {
    private readonly db;
    private readonly handlers;
    private readonly webhooks?;
    private readonly writeBudgets;
    private readonly metadata;
    constructor(db: Database, handlers: ReadonlyMap<string, EffectHandler>, webhooks?: ActionSourceWebhooks | undefined);
    check(names: readonly string[]): void;
    enqueue(client: Sql, access: Access, model: PublishedOntology, action: string, requestId: string, effects: ActionEffect[]): Promise<void>;
    status(access: Access, requestId: string): Promise<import("pg").QueryResultRow[]>;
    retry(access: Access, id: string): Promise<{
        id: string;
        state: string;
    }>;
    runOne(signal?: AbortSignal): Promise<boolean>;
}
