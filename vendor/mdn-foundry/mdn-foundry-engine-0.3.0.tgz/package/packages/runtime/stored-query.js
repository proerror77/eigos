import { valueKinds } from '../ontology/property-path.js';
function isPostgresScalar(value) {
    return typeof value !== 'string' || !/[\u0000\uD800-\uDFFF]/u.test(value);
}
/**
 * UTF-8 (COLLATE "C") and UTF-16 code unit order are mathematically identical whenever the
 * comparison bound only contains code points in U+0001..U+D7FF (covers ASCII, ISO timestamps,
 * Latin, Greek, Cyrillic, CJK Unified Ideographs, Hangul, etc.).
 */
function isSafeStringRangeBound(value) {
    return typeof value === 'string' && /^[\u0001-\uD7FF]*$/u.test(value);
}
/**
 * ASCII-after-NFKC text predicates match JS `.normalize('NFKC').toLowerCase().includes(term)`
 * identically in PostgreSQL `strpos(lower(normalize(..., NFKC)) COLLATE "C", term) > 0` across all locales.
 */
function isSafeTextPredicate(value) {
    return typeof value === 'string' && isPostgresScalar(value) && /^[\x09\x0A\x0D\x20-\x7E]*$/.test(value.normalize('NFKC'));
}
export function supportsStoredPredicate(predicate) {
    if (!predicate)
        return true;
    switch (predicate.op) {
        case 'all':
        case 'any': return predicate.predicates.every(supportsStoredPredicate);
        case 'not': return supportsStoredPredicate(predicate.predicate);
        case 'regex': return false;
        case 'text': return isSafeTextPredicate(predicate.value);
        case 'gt':
        case 'gte':
        case 'lt':
        case 'lte': return typeof predicate.value === 'number' || isSafeStringRangeBound(predicate.value);
        case 'in': return predicate.values.every(isPostgresScalar);
        default: return isPostgresScalar(predicate.value);
    }
}
export function isNumeric(schema) {
    const kinds = valueKinds(schema).filter(kind => kind !== 'null');
    return kinds.length > 0 && kinds.every(kind => kind === 'number' || kind === 'integer');
}
export function supportsStoredOrder(schema) {
    return isNumeric(schema) || valueKinds(schema).every(kind => kind === 'boolean' || kind === 'null');
}
export function storedPredicate(predicate, property, bind) {
    switch (predicate.op) {
        case 'all':
        case 'any': return '(' + predicate.predicates.map(child => storedPredicate(child, property, bind)).join(predicate.op === 'all' ? ' AND ' : ' OR ') + ')';
        case 'not': return 'NOT (' + storedPredicate(predicate.predicate, property, bind) + ')';
        case 'in': return `EXISTS(SELECT 1 FROM jsonb_array_elements(${bind(JSON.stringify(predicate.values))}::jsonb) AS candidate(value) WHERE candidate.value=${property(predicate.property)})`;
        case 'text': {
            if (typeof predicate.value !== 'string')
                return 'FALSE';
            const terms = predicate.value.normalize('NFKC').toLowerCase().split(/\s+/).filter(Boolean);
            if (!terms.length)
                return 'FALSE';
            const field = property(predicate.property);
            const haystack = `lower(normalize((${field}#>>'{}'), NFKC)) COLLATE "C"`;
            return `(jsonb_typeof(${field})='string' AND ${terms.map(term => `strpos(${haystack},${bind(term)}::text)>0`).join(' AND ')})`;
        }
        default: {
            const field = property(predicate.property);
            if (predicate.op === 'eq' || predicate.op === 'ne') {
                const value = bind(JSON.stringify(predicate.value));
                return `${field}${predicate.op === 'eq' ? '=' : '<>'}${value}::jsonb`;
            }
            if (predicate.op === 'contains') {
                const value = bind(JSON.stringify(predicate.value));
                return `CASE jsonb_typeof(${field})
        WHEN 'string' THEN jsonb_typeof(${value}::jsonb)='string' AND strpos((${field}#>>'{}') COLLATE "C",${value}::jsonb#>>'{}')>0
        WHEN 'array' THEN EXISTS(SELECT 1 FROM jsonb_array_elements(${field}) AS element(value) WHERE element.value=${value}::jsonb)
        ELSE FALSE END`;
            }
            const operation = { gt: '>', gte: '>=', lt: '<', lte: '<=' }[predicate.op];
            if (!operation)
                throw new Error('Unsupported stored predicate');
            if (typeof predicate.value === 'number') {
                const value = bind(JSON.stringify(predicate.value));
                return `(jsonb_typeof(${field})='number' AND ${field}${operation}${value}::jsonb)`;
            }
            if (typeof predicate.value === 'string' && isSafeStringRangeBound(predicate.value)) {
                return `(jsonb_typeof(${field})='string' AND (${field}#>>'{}') COLLATE "C"${operation}${bind(predicate.value)}::text COLLATE "C")`;
            }
            throw new Error('Unsupported stored predicate');
        }
    }
}
