import { spawn } from 'node:child_process';
import { createInterface } from 'node:readline';
import { Conflict, digest, InvalidInput, NotFound, PermissionDenied } from '../../core/identity.js';
import { combineClassification, marksClassification, sensitivityRank } from '../../ontology/classification.js';
import { latestCommit } from '../change-feed.js';
import { projectView } from '../object-view.js';
import { nestedValue } from '../query-filter.js';
import { compileAggregate, compileFollow, compileQueryOrder, compileSet, loadedColumns, showsType } from './plan.js';
/**
 * Records what the reference records for every row it reads, or returns false so the reference evaluates the set:
 * - each row's label combines the document, its type, its row classification and its markings, and observing the
 *   combination is the same as observing each;
 * - a policy-bound type records a row dependency for every row; past the limit the kernel reports, the reference
 *   decides whether its complete evaluation can hold them;
 * - the markings of rows read are read markings;
 * - reading a row with its derived values checks the visibility of each derived property.
 */
function observeReads(access, model, plan, reads) {
    if (reads.some(read => read.count && plan.members.get(read.type)?.track && (read.overLimit || !read.ids)))
        return false;
    const labels = Object.entries(sensitivityRank);
    for (const read of reads) {
        if (!read.count)
            continue;
        if (plan.members.get(read.type)?.track)
            access.trackRows(model, read.type, read.ids);
        if (read.markings?.length)
            access.observeReadMarkings(read.markings);
        const sensitivity = read.rank === null || read.rank === undefined ? undefined : labels.find(([, rank]) => rank === read.rank)?.[0];
        const row = sensitivity || read.compartments?.length ? { sensitivity: sensitivity ?? 'PUBLIC', compartments: read.compartments ?? [] } : undefined;
        access.observeClassification(combineClassification(model.document.classification, model.object(read.type).classification, row, read.markings?.length ? marksClassification(read.markings) : undefined));
        if (read.enriched)
            for (const name of plan.enriched.get(read.type) ?? [])
                access.cellRule(model, read.type, name);
    }
    return true;
}
/**
 * The kernel could not answer: it could not be reached, holds no projection, or failed on the query. The reference
 * answers instead. `lost` means the kernel can answer nothing until it loads the projection again.
 */
export class KernelFailed extends Error {
    lost;
    constructor(message, lost) {
        super(message);
        this.lost = lost;
        this.name = 'KernelFailed';
    }
}
/**
 * Every kernel process this process started that still runs. They are stopped when this process exits, whoever started
 * them: a kernel holds this process's output stream, so one left running would also keep a reader of it waiting.
 */
const running = new Set();
let stopAtExit = false;
/** A running query kernel on the loopback interface. */
export class KernelClient {
    url;
    child;
    constructor(url, child) {
        this.url = url;
        this.child = child;
    }
    /** Starts the kernel binary on a free loopback port, with extra environment settings. */
    static async start(binary, env = {}) {
        const child = spawn(binary, [], { env: { ...process.env, ...env, EIGOS_KERNEL_PORT: '0' }, stdio: ['ignore', 'pipe', 'inherit'] });
        running.add(child);
        child.once('exit', () => running.delete(child));
        if (!stopAtExit) {
            stopAtExit = true;
            process.once('exit', () => { for (const kernel of running)
                if (kernel.exitCode === null)
                    kernel.kill('SIGTERM'); });
        }
        const lines = createInterface({ input: child.stdout });
        const port = await new Promise((resolve, reject) => {
            child.once('exit', code => reject(new Error('Kernel exited with ' + code)));
            lines.once('line', line => resolve(JSON.parse(line).port));
        });
        // The kernel answers over HTTP, so neither its process nor its output keeps this process running.
        child.unref();
        child.stdout.unref?.();
        return new KernelClient(`http://127.0.0.1:${port}`, child);
    }
    /** A client for a kernel service already running at `url`. */
    static connect(url) { return new KernelClient(url.replace(/\/$/, '')); }
    protocol;
    /**
     * Whether the kernel answers protocol `level`: 2 adds query pages and Scenario overlays. A kernel that predates them
     * would ignore a Scenario and answer from the live data, so a Scenario goes to the reference instead. A restarted
     * kernel is reached through a new client, which asks again.
     */
    async supports(level) {
        this.protocol ??= this.health().then(health => health.protocol ?? 1, () => 0);
        return await this.protocol >= level;
    }
    /** The kernel process ID, when this client started it. */
    get pid() { return this.child?.pid; }
    /** Asks the kernel process this client started to stop, without waiting for it. */
    kill() { if (this.child && this.child.exitCode === null)
        this.child.kill('SIGTERM'); }
    async stop() {
        if (!this.child || this.child.exitCode !== null)
            return;
        // Held until the kernel exits, so this process does not end first.
        this.child.ref();
        const exited = new Promise(resolve => this.child.once('exit', resolve));
        this.child.kill('SIGTERM');
        await exited;
    }
    /**
     * Undefined when the kernel leaves the query to the reference: the reference's evaluation fails, or the kernel cannot
     * read the request (422); or the kernel cannot answer from the version the query needs (409). Throws `KernelFailed`
     * when the kernel cannot be reached or fails.
     */
    async post(path, body) {
        let status, text;
        try {
            const response = await fetch(this.url + path, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
            status = response.status;
            text = await response.text();
        }
        catch (error) {
            throw new KernelFailed(`Kernel ${path} unreachable: ${error instanceof Error ? error.message : String(error)}`, true);
        }
        if (status === 422 || status === 409)
            return undefined;
        let value;
        try {
            value = JSON.parse(text);
        }
        catch {
            value = undefined;
        }
        // 503: the kernel holds no projection, after it restarted.
        if (status < 200 || status > 299 || value === undefined)
            throw new KernelFailed(`Kernel ${path} failed with ${status}: ${value?.error ?? text.slice(0, 300)}`, status === 503);
        return value;
    }
    /**
     * Loads the projection of `model` from the database the kernel can reach at `database`, or restores the kernel's last
     * checkpoint of it when that belongs to the database; `restored` says which.
     */
    async load(db, model, database) {
        const loaded = await this.post('/load', {
            database, schema: db.schema.replaceAll('"', ''), projection: model.projection,
            types: [...model.objects.keys()].map(name => ({ name, columns: loadedColumns(model, name), classification: model.object(name).classificationProperty })),
            links: [...model.links.keys()], ranks: sensitivityRank,
        });
        if (!loaded)
            throw new Error('Kernel load failed');
        return loaded;
    }
    page(owner, plan, offset, limit, version) {
        return this.post('/query', { owner, set: plan.set, rows: plan.rows, derived: plan.derived, members: [...plan.members.values()],
            output: { kind: 'page', offset, limit }, ...version });
    }
    aggregate(owner, plan, output, version) {
        return this.post('/query', { owner, set: plan.set, rows: plan.rows, derived: plan.derived, members: [...plan.members.values()],
            output, ...version });
    }
    query(owner, plan, output, version) {
        return this.post('/query', { owner, set: plan.set, rows: plan.rows, derived: plan.derived, members: [...plan.members.values()],
            output, ...version });
    }
    async health() {
        return await (await fetch(this.url + '/health')).json();
    }
    /** The last commit the kernel has applied for each owner. */
    async positions() { return await (await fetch(this.url + '/positions')).json(); }
    /** Writes a checkpoint of the kernel's current version to its data directory. */
    async checkpoint() {
        const written = await this.post('/checkpoint', {});
        if (!written)
            throw new Error('Kernel checkpoint failed');
        return written;
    }
}
/**
 * The checks the reference makes on a view before it evaluates a set: true when the principal may see the view, false
 * when the view's label is beyond the clearance (the reference then shows nothing), and undefined when the reference
 * reports an error or the kernel path does not cover the view: an Interface with labelled properties, whose labels the
 * reference observes on each object it projects.
 */
function viewShown(access, model, view) {
    const contract = model.interfaces.get(view);
    try {
        access.definition(model, contract ? 'interface' : 'object', view);
    }
    catch (error) {
        if (error instanceof PermissionDenied || error instanceof NotFound || error instanceof InvalidInput)
            return undefined;
        throw error;
    }
    if (contract && Object.values(contract.properties).some(property => property.classification))
        return undefined;
    const label = (contract ?? model.objects.get(view))?.classification;
    if (!access.canSeeModelData(label))
        return false;
    access.observeClassification(label);
    return true;
}
/**
 * Evaluates one page of an Object Set with the kernel and reads the page's objects through `graph`, shown in `view`.
 * Undefined means the set has no kernel plan, or the reference's evaluation would fail, so the caller evaluates it with
 * the reference.
 */
export async function evaluateWithKernel(kernel, model, access, graph, input) {
    const shown = input.view ? viewShown(access, model, input.view) : true;
    if (shown === undefined)
        return undefined;
    if (!shown)
        return { items: [], total: 0, elapsedMs: 0 };
    const version = await versionOf(kernel, model, access, graph);
    if (!version)
        return undefined;
    const plan = await compileSet(model, access, graph, input.set);
    if (!plan)
        return undefined;
    const response = await kernel.page(access.principal.owner, plan, input.offset ?? 0, input.limit, version);
    if (!response || !observeReads(access, model, plan, response.reads))
        return undefined;
    // The reference shows every member in the view, and fails for a member of a type the view cannot show.
    if (input.view && response.types.some(type => !showsType(model, input.view, type)))
        return undefined;
    const objects = await hydrate(graph, response.refs);
    // A member deleted or hidden since the kernel answered, or a Scenario edited since, leaves the page to the reference.
    if (!objects || !await unchangedSince(graph, model, access.principal.owner, version))
        return undefined;
    const items = objects.map(object => projectView(access, model, object, input.view));
    return { items, total: response.total, membership: response.membership, commit: response.commit, elapsedMs: response.elapsedMs };
}
/** Reads a page's objects as `read` does, together and in page order: undefined when one of them is gone or no longer visible. */
async function hydrate(graph, refs) {
    if (!refs.length)
        return [];
    const found = new Map((await graph.readBatch(refs)).map(object => [digest(object.ref), object]));
    const objects = refs.map(ref => found.get(digest({ type: ref.type, id: ref.id })));
    return objects.every(Boolean) ? objects : undefined;
}
const singleLinksCache = new WeakMap();
function singleLinksOf(model) {
    let single = singleLinksCache.get(model);
    if (!single) {
        single = Object.fromEntries([...model.links].map(([name, link]) => [name, [link.from.cardinality === 'one', link.to.cardinality === 'one']]));
        singleLinksCache.set(model, single);
    }
    return single;
}
/**
 * The version a query needs, read before it starts: every commit of the owner visible then, and in a Scenario its
 * revision and validity in one SQL round-trip. Undefined for a Scenario that is unavailable, closed, expired or of
 * another publication.
 */
async function versionOf(kernel, model, access, graph) {
    if (model.scenario && !await kernel.supports(2))
        return undefined;
    const owner = access.principal.owner;
    if (!model.scenario) {
        const minCommit = Number(await latestCommit(graph.db, owner, graph.client));
        return { projection: model.projection, minCommit };
    }
    const { rows: [row] } = await graph.db.query(`SELECT
       (SELECT coalesce(max(commit_seq), 0)::text FROM ${graph.db.schema}.change_commits WHERE owner=$1) AS commit,
       s.revision::text AS revision,
       s.release AS release,
       s.state AS state,
       (s.expires_at > now() AND (s.session_id IS NULL OR (session.closed_at IS NULL AND session.expires_at > now()))) AS current
     FROM (SELECT 1) AS one
     LEFT JOIN ${graph.db.schema}.scenarios s ON s.id=$2 AND s.owner=$1
     LEFT JOIN ${graph.db.schema}.scenario_sessions session ON session.id=s.session_id`, [owner, model.scenario], graph.client);
    if (!row || row.revision === null || row.release !== model.release || row.state !== 'open' || !row.current)
        return undefined;
    return { projection: model.projection, minCommit: Number(row.commit), scenario: { id: model.scenario, revision: Number(row.revision), single: singleLinksOf(model) } };
}
async function scenarioRevision(graph, model, owner) {
    const row = (await graph.db.query(`SELECT revision FROM ${graph.db.schema}.scenarios WHERE id=$1 AND owner=$2`, [model.scenario, owner], graph.client)).rows[0];
    return row ? Number(row.revision) : undefined;
}
/** Whether the version a page's objects were read at is the one the kernel answered: no commit, and no Scenario edit, since. */
async function unchangedSince(graph, model, owner, version, commit) {
    if (commit !== undefined && version.scenario) {
        const { rows: [row] } = await graph.db.query(`SELECT
         (SELECT coalesce(max(commit_seq), 0)::text FROM ${graph.db.schema}.change_commits WHERE owner=$1) AS commit,
         (SELECT revision::text FROM ${graph.db.schema}.scenarios WHERE id=$2 AND owner=$1) AS revision`, [owner, model.scenario], graph.client);
        return Boolean(row) && Number(row.commit) === commit && row.revision !== null && Number(row.revision) === version.scenario.revision;
    }
    if (commit !== undefined && Number(await latestCommit(graph.db, owner, graph.client)) !== commit)
        return false;
    return !version.scenario || await scenarioRevision(graph, model, owner) === version.scenario.revision;
}
/** Aggregates an Object Set with the kernel. Undefined means the reference aggregates it, as for `evaluateWithKernel`. */
export async function aggregateWithKernel(kernel, model, access, graph, input) {
    const shown = input.view ? viewShown(access, model, input.view) : true;
    if (shown === undefined)
        return undefined;
    if (!shown) {
        // The reference aggregates no members, after it checks the fields against the view.
        try {
            for (const field of [...input.groupBy, ...Object.values(input.metrics).flatMap(metric => metric.property ? [metric.property] : [])])
                model.propertyPath(input.view, field);
        }
        catch (error) {
            if (error instanceof InvalidInput)
                return undefined;
            throw error;
        }
        return { count: 0, elapsedMs: 0, items: input.groupBy.length ? [] : [{ group: {},
                    metrics: Object.fromEntries(Object.entries(input.metrics).map(([name, metric]) => [name, metric.op === 'count' ? 0 : null])) }] };
    }
    const version = await versionOf(kernel, model, access, graph);
    if (!version)
        return undefined;
    const plan = await compileSet(model, access, graph, input.set);
    const output = plan && compileAggregate(model, access, plan, input);
    if (!plan || !output)
        return undefined;
    const response = await kernel.aggregate(access.principal.owner, plan, output, version);
    if (!response || !observeReads(access, model, plan, response.reads))
        return undefined;
    for (const item of response.items)
        for (const value of Object.values(item.metrics))
            if (typeof value === 'number' && !Number.isFinite(value))
                throw new Conflict('Numeric aggregation overflow');
    return { count: response.count, items: response.items, commit: response.commit, elapsedMs: response.elapsedMs };
}
/**
 * One page of a query with the kernel, as `Objects.query` gives a query the reference evaluates completely: the members
 * in the reference's order, read through `graph`, each projected into the query's type and its selected fields.
 * Undefined leaves the query to the reference: it has no kernel plan; the reference's evaluation would fail; a member
 * is gone or hidden; or the owner committed after the kernel answered, so the objects read could be newer than the
 * order.
 */
export async function queryWithKernel(kernel, model, access, graph, input) {
    const { query } = input;
    const { limit, cursor: _cursor, select, ...members } = query;
    try {
        for (const field of select ?? [])
            model.propertyPath(query.type, field);
    }
    catch (error) {
        if (error instanceof InvalidInput || error instanceof NotFound)
            return undefined;
        throw error;
    }
    const version = await versionOf(kernel, model, access, graph);
    if (!version)
        return undefined;
    // A classified field may be observed only on a row that actually has a visible value.
    // The ordinary row hydrator records that evidence if the first page contains every match.
    const properties = model.objects.get(query.type)?.properties;
    const keys = [...Object.keys(query.where ?? {}), ...(query.orderBy ?? []).map(order => order.property)];
    const completePage = properties && Boolean(query.orderBy?.length) && input.offset === 0 && !query.from && !query.filter && !query.intervalOverlap && !select &&
        Object.values(properties).some(property => property.classification) && !Object.values(properties).some(property => property.derived) &&
        keys.every(key => !key.includes('.') && properties[key] && !properties[key].classification);
    const plan = await compileSet(model, access, graph, { op: 'query', query: members }, completePage ? query.type : undefined);
    const output = plan && compileQueryOrder(model, access, plan, query, input.offset, limit, graph.recordsStoredOrderFields(query));
    if (!plan || !output)
        return undefined;
    const response = await kernel.query(access.principal.owner, plan, output, version);
    if (completePage && response && response.total !== response.refs.length)
        return undefined;
    if (!response || !observeReads(access, model, plan, response.reads))
        return undefined;
    const objects = await hydrate(graph, response.refs);
    if (!objects || ((response.refs.length > 0 || version.scenario) && !await unchangedSince(graph, model, access.principal.owner, version, response.commit)))
        return undefined;
    const contract = model.interfaces.get(query.type);
    const definitions = contract?.properties ?? model.object(query.type).properties;
    const items = objects.map(object => {
        // As the reference projects each match: every field of the query's type, null where the type maps none.
        const projected = { ...object, properties: Object.fromEntries(Object.keys(definitions).map(field => {
                const local = model.propertyName(object.ref.type, query.type, field);
                const label = contract?.properties[field]?.classification;
                const visible = Boolean(local) && access.canSeeModelData(label);
                if (visible)
                    access.observeClassification(label);
                return [field, visible ? object.properties[local] ?? null : null];
            })) };
        return select ? { ...projected, properties: Object.fromEntries(select.map(field => [field, nestedValue(projected.properties, field)])) } : projected;
    });
    return { items, total: response.total, membership: response.membership, commit: response.commit, elapsedMs: response.elapsedMs };
}
/**
 * One object's relationship with the kernel, as `Objects.follow` reads it: the targets in id order, byte by byte, read
 * through `graph`. Undefined leaves it to the reference: there is no kernel plan, the reference's evaluation would fail,
 * there are more targets than `maximum` (the reference reports that), a target is gone or hidden, or the owner committed
 * or the Scenario changed while the targets were read.
 */
export async function followWithKernel(kernel, model, access, graph, input) {
    const version = await versionOf(kernel, model, access, graph);
    if (!version)
        return undefined;
    const plan = await compileFollow(model, access, graph, input.ref, input.link, input.view);
    if (!plan)
        return undefined;
    // One source and a single-valued link already bound the frontier by construction.
    const many = model.navigation(input.ref.type, input.link, input.view).cardinality === 'many';
    const bounded = many && plan.set.op === 'traverse'
        ? { ...plan, set: { ...plan.set, op: 'boundedTraverse', limit: input.maximum } } : plan;
    const response = await kernel.page(access.principal.owner, bounded, 0, input.maximum + 1, version);
    if (!response || !observeReads(access, model, plan, response.reads) || response.total > input.maximum)
        return undefined;
    const refs = [...response.refs].sort((left, right) => Buffer.compare(Buffer.from(left.id), Buffer.from(right.id)));
    const objects = await hydrate(graph, refs);
    if (!objects || ((refs.length > 0 || version.scenario) && !await unchangedSince(graph, model, access.principal.owner, version, response.commit)))
        return undefined;
    return objects;
}
