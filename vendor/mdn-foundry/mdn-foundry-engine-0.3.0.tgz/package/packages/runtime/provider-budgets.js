import { AsyncLocalStorage } from 'node:async_hooks';
import { z } from 'zod';
import { Conflict, InvalidInput, NotFound, PermissionDenied, SourceReadFailure } from '../core/identity.js';
import { bindProviderMetrics, metrics, startSpan } from '../core/metrics.js';
import { recordOperationEvent } from '../core/operation-timing.js';
/**
 * Provider budgets (runtime budget 06.3): each owner may call each provider at a bounded rate. A token bucket per owner
 * and provider, kept in PostgreSQL so every process shares it, refills at `perMinute` tokens a minute up to `burst`.
 * A call without a token is deferred, not failed: a task resumes when the bucket has refilled, and a direct request
 * learns when to retry.
 */
const rateLimit = z.strictObject({ perMinute: z.number().positive().max(100000), burst: z.number().int().min(1).max(100000) });
export const providerRatesSchema = z.record(z.string().min(1).max(80), rateLimit);
const actionWriteRatesSchema = z.record(z.string().regex(/^[^/]+\/[^/]+$/).max(161), rateLimit);
const providerQuotasSchema = z.record(z.string().min(1).max(80), z.strictObject({ period: z.enum(['day', 'month']), calls: z.number().int().min(1).max(2147483647) }));
/** The rates of EIGOS_PROVIDER_RATES, a JSON object by source name; providers not named are not limited. */
export function configuredProviderRates(text = process.env.EIGOS_PROVIDER_RATES) {
    return text ? providerRatesSchema.parse(JSON.parse(text)) : {};
}
function configuredProviderQuotas(text = process.env.EIGOS_PROVIDER_QUOTAS) {
    return text ? providerQuotasSchema.parse(JSON.parse(text)) : {};
}
/** A provider call over its owner's budget or resilience gate. A Worker defers the task until `until`; a request answers 429. */
export class ProviderBudgetExceeded extends Error {
    provider;
    until;
    reason;
    constructor(provider, until, reason) {
        super(reason === 'circuit_open' ? `The ${provider} circuit breaker is open until ${until}`
            : reason === 'concurrency' ? `The ${provider} concurrency limit is reached until ${until}`
                : reason === 'half_open_limit' ? `The ${provider} half-open probe limit is reached until ${until}`
                    : `The ${provider} budget is used up until ${until}`);
        this.provider = provider;
        this.until = until;
        this.reason = reason;
    }
}
export async function initializeProviderBudgets(db) {
    await db.query(`CREATE TABLE IF NOT EXISTS ${db.schema}.provider_budgets (
    owner text NOT NULL, provider text NOT NULL, tokens double precision NOT NULL, refilled_at timestamptz NOT NULL,
    PRIMARY KEY (owner, provider))`);
    await db.query(`CREATE TABLE IF NOT EXISTS ${db.schema}.provider_quotas (
    owner text NOT NULL, provider text NOT NULL, period text NOT NULL CHECK (period IN ('day','month')),
    period_start timestamptz NOT NULL, calls integer NOT NULL CHECK (calls > 0),
    PRIMARY KEY (owner, provider, period))`);
    await db.query(`CREATE TABLE IF NOT EXISTS ${db.schema}.action_write_budgets (
    owner text NOT NULL, action_key text NOT NULL, tokens double precision NOT NULL, refilled_at timestamptz NOT NULL,
    PRIMARY KEY (owner, action_key))`);
}
export class ProviderBudgets {
    db;
    rates;
    quotas;
    constructor(db, rates = configuredProviderRates(), quotas = configuredProviderQuotas()) {
        this.db = db;
        this.rates = rates;
        this.quotas = quotas;
    }
    /** Admits one attempt across the configured budgets, or throws with the time to try again. */
    async take(owner, provider) {
        const rate = Object.hasOwn(this.rates, provider) ? this.rates[provider] : undefined;
        const quota = Object.hasOwn(this.quotas, provider) ? this.quotas[provider] : undefined;
        if (!quota) {
            if (rate)
                await takeRate(this.db, 'provider_budgets', owner, provider, rate);
            return;
        }
        if (!rate)
            return this.takeQuota(owner, provider, quota);
        await this.db.transaction(async (client) => {
            await this.takeQuota(owner, provider, quota, client);
            await takeRate(this.db, 'provider_budgets', owner, provider, rate, client);
        });
    }
    /** Storing the current UTC window per period bounds the table to two rows per owner and provider. */
    async takeQuota(owner, provider, quota, client) {
        const window = "date_trunc($3, statement_timestamp(), 'UTC')";
        const key = [owner, provider, quota.period];
        const taken = await this.db.query(`INSERT INTO ${this.db.schema}.provider_quotas AS q(owner,provider,period,period_start,calls)
      VALUES($1,$2,$3,${window},1)
      ON CONFLICT(owner,provider,period) DO UPDATE SET calls=CASE
        WHEN q.period_start=excluded.period_start THEN q.calls+1 ELSE 1 END,
        period_start=excluded.period_start
      WHERE q.period_start<excluded.period_start OR q.period_start=excluded.period_start AND q.calls<$4
      RETURNING calls`, [...key, quota.calls], client);
        if (taken.rowCount)
            return;
        const { rows: [current] } = await this.db.query(`SELECT
      ((period_start AT TIME ZONE 'UTC') + CASE period WHEN 'day' THEN interval '1 day' ELSE interval '1 month' END)
        AT TIME ZONE 'UTC' AS until
      FROM ${this.db.schema}.provider_quotas WHERE owner=$1 AND provider=$2 AND period=$3`, key, client);
        if (!current)
            throw new Error('Provider quota window is unavailable');
        throw new ProviderBudgetExceeded(provider, current.until.toISOString(), 'quota');
    }
}
const actionWriting = new AsyncLocalStorage();
export function withActionWriteBudget(ontology, action, run) {
    return actionWriting.run(`${ontology}/${action}`, run);
}
/** Source reads and external Action writes use independent buckets. */
export class ActionWriteBudgets {
    db;
    rates;
    constructor(db, text = process.env.EIGOS_ACTION_WRITE_RATES) {
        this.db = db;
        this.rates = text ? actionWriteRatesSchema.parse(JSON.parse(text)) : {};
    }
    async take(owner, client, action = actionWriting.getStore()) {
        if (action && Object.hasOwn(this.rates, action))
            await takeRate(this.db, 'action_write_budgets', owner, action, this.rates[action], client);
    }
}
async function takeRate(db, table, owner, key, rate, client) {
    const column = table === 'provider_budgets' ? 'provider' : 'action_key';
    const perSecond = rate.perMinute / 60;
    // Refill since the last take, capped at the burst, then take one token if there is one.
    const refilled = `least($3::double precision, b.tokens + extract(epoch FROM clock_timestamp()-b.refilled_at)::double precision*$4::double precision)`;
    const args = [owner, key, rate.burst, perSecond];
    const taken = await db.query(`INSERT INTO ${db.schema}.${table} AS b(owner,${column},tokens,refilled_at)
    VALUES($1,$2,$3::double precision-1,clock_timestamp())
    ON CONFLICT (owner,${column}) DO UPDATE SET tokens=${refilled}-1, refilled_at=clock_timestamp() WHERE ${refilled}>=1
    RETURNING tokens`, args, client);
    if (taken.rowCount)
        return;
    const { rows: [left] } = await db.query(`SELECT ${refilled} AS tokens FROM ${db.schema}.${table} b
    WHERE owner=$1 AND ${column}=$2`, args, client);
    const seconds = Math.max(0, (1 - Number(left?.tokens ?? 0)) / perSecond);
    throw new ProviderBudgetExceeded(key, new Date(Date.now() + Math.ceil(seconds * 1000)).toISOString(), 'rate');
}
export const circuitBreakerSchema = z.strictObject({
    failureThreshold: z.number().int().min(1).max(10000).optional(),
    failureRateThreshold: z.number().gt(0).lte(1).optional(),
    minSamples: z.number().int().min(1).max(10000).default(5),
    windowMs: z.number().int().min(50).max(3_600_000).default(60_000),
    cooldownMs: z.number().int().min(10).max(3_600_000).default(30_000),
    maxRetryAfterMs: z.number().int().min(100).max(3_600_000).default(300_000),
    halfOpenMaxConcurrent: z.number().int().min(1).max(100).default(1),
    halfOpenSuccessThreshold: z.number().int().min(1).max(100).default(2),
    halfOpenRampStep: z.number().int().min(0).max(100).default(1),
    allowReadReconcile: z.boolean().default(true),
}).refine(value => value.failureThreshold !== undefined || value.failureRateThreshold !== undefined, 'Configure failureThreshold or failureRateThreshold for circuitBreaker');
export const providerResilienceRuleSchema = z.strictObject({
    maxConcurrent: z.number().int().min(1).max(10000).optional(),
    maxConcurrentPerOwner: z.number().int().min(1).max(10000).optional(),
    concurrencyBackoffMs: z.number().int().min(10).max(600_000).default(1000),
    reconcileMaxConcurrent: z.number().int().min(1).max(1000).optional(),
    circuitBreaker: circuitBreakerSchema.optional(),
    ownerCircuitBreaker: circuitBreakerSchema.optional(),
});
export const providerResilienceSchema = z.record(z.string().min(1).max(80), providerResilienceRuleSchema);
/** Parses EIGOS_PROVIDER_RESILIENCE JSON; unconfigured providers keep default unlimited behavior. */
export function configuredProviderResilience(text = process.env.EIGOS_PROVIDER_RESILIENCE) {
    return text ? providerResilienceSchema.parse(JSON.parse(text)) : {};
}
const TIMEOUT_ERROR_CODES = new Set([
    'ETIMEDOUT', 'UND_ERR_CONNECT_TIMEOUT', 'UND_ERR_HEADERS_TIMEOUT', 'UND_ERR_BODY_TIMEOUT',
]);
const CONNECTION_ERROR_CODES = new Set([
    'ECONNRESET', 'ECONNREFUSED', 'EPIPE', 'EAI_AGAIN', 'ENOTFOUND', 'EHOSTUNREACH',
    'ENETUNREACH', 'UND_ERR_SOCKET', 'ERR_SOCKET_CLOSED', 'ECONNABORTED', 'ERR_STREAM_PREMATURE_CLOSE',
]);
/** Parses an RFC 9110 Retry-After value (delay-seconds or HTTP-date) into clamped milliseconds. */
export function parseRetryAfterMs(header, now = Date.now(), maxMs = 300_000) {
    if (header === null || header === undefined)
        return undefined;
    if (typeof header === 'number') {
        if (!Number.isFinite(header) || header < 0)
            return undefined;
        return Math.min(maxMs, Math.ceil(header * 1000));
    }
    const trimmed = header.trim();
    if (!trimmed)
        return undefined;
    if (/^\d+(?:\.\d+)?$/.test(trimmed)) {
        const seconds = Number(trimmed);
        if (!Number.isFinite(seconds) || seconds < 0)
            return undefined;
        return Math.min(maxMs, Math.ceil(seconds * 1000));
    }
    const target = Date.parse(trimmed);
    if (!Number.isFinite(target))
        return undefined;
    return Math.min(maxMs, Math.max(0, Math.ceil(target - now)));
}
export function classifyProviderFailure(error, callerSignal, now = Date.now()) {
    if (callerSignal?.aborted) {
        return { kind: 'aborted', tripWorthy: false };
    }
    if (error instanceof PermissionDenied ||
        error instanceof InvalidInput ||
        error instanceof NotFound ||
        error instanceof Conflict ||
        error instanceof ProviderBudgetExceeded ||
        error instanceof z.ZodError) {
        return { kind: 'client_error', tripWorthy: false };
    }
    const candidates = [error, error?.cause];
    let retryAfterMs;
    let status;
    for (const candidate of candidates) {
        if (!candidate || typeof candidate !== 'object')
            continue;
        const rec = candidate;
        if (status === undefined) {
            if (typeof rec.status === 'number')
                status = rec.status;
            else if (typeof rec.statusCode === 'number')
                status = rec.statusCode;
        }
        if (retryAfterMs === undefined) {
            if (typeof rec.retryAfterMs === 'number' && Number.isFinite(rec.retryAfterMs) && rec.retryAfterMs >= 0) {
                retryAfterMs = Math.ceil(rec.retryAfterMs);
            }
            else if (typeof rec.retryAfter === 'string' || typeof rec.retryAfter === 'number') {
                retryAfterMs = parseRetryAfterMs(rec.retryAfter, now);
            }
            else if (rec.headers && typeof rec.headers === 'object') {
                const raw = rec.headers['retry-after'] ?? rec.headers['Retry-After'];
                if (typeof raw === 'string' || typeof raw === 'number')
                    retryAfterMs = parseRetryAfterMs(raw, now);
            }
        }
    }
    if (status !== undefined) {
        if (status === 429)
            return { kind: 'rate_limited', tripWorthy: true, status, retryAfterMs };
        if (status === 408)
            return { kind: 'timeout', tripWorthy: true, status, retryAfterMs };
        if (status >= 500)
            return { kind: 'server_error', tripWorthy: true, status, retryAfterMs };
        if (status >= 400 && status < 500)
            return { kind: 'client_error', tripWorthy: false, status };
    }
    for (const candidate of candidates) {
        if (!candidate || typeof candidate !== 'object')
            continue;
        const rec = candidate;
        if (rec.name === 'TimeoutError' || (typeof rec.code === 'string' && TIMEOUT_ERROR_CODES.has(rec.code))) {
            return { kind: 'timeout', tripWorthy: true, retryAfterMs };
        }
        if (typeof rec.code === 'string' && CONNECTION_ERROR_CODES.has(rec.code)) {
            return { kind: 'connection_error', tripWorthy: true, retryAfterMs };
        }
        if (rec.name === 'AbortError') {
            return { kind: 'aborted', tripWorthy: false };
        }
    }
    if (error instanceof SourceReadFailure) {
        return { kind: 'connection_error', tripWorthy: true, retryAfterMs };
    }
    return { kind: 'connection_error', tripWorthy: true, retryAfterMs };
}
const CIRCUIT_STATE_NUM = { closed: 0, half_open: 1, open: 2 };
const MAX_OWNER_CIRCUITS_PER_PROVIDER = 4096;
function createBreakerRecord(cfg) {
    return {
        state: 'closed',
        consecutiveFailures: 0,
        samples: [],
        openedUntil: 0,
        halfOpenInFlight: 0,
        halfOpenSuccesses: 0,
        halfOpenAllowedConcurrency: cfg.halfOpenMaxConcurrent,
    };
}
function pruneSamples(breaker, windowMs, now, maxSamples) {
    const cutoff = now - windowMs;
    let firstValid = 0;
    while (firstValid < breaker.samples.length && breaker.samples[firstValid].at < cutoff)
        firstValid++;
    if (firstValid > 0)
        breaker.samples.splice(0, firstValid);
    if (breaker.samples.length > maxSamples) {
        breaker.samples.splice(0, breaker.samples.length - maxSamples);
    }
}
const noopPermit = (provider) => ({
    provider,
    mode: 'normal',
    recordSuccess() { },
    recordNeutral() { },
    recordHttpStatus() { },
    recordFailure() { },
    recordError() { },
    release() { },
});
/**
 * Per-provider and per-(owner, provider) bulkhead concurrency isolation and circuit breaker
 * (docs/scaling.md 09.4). Unconfigured providers pass through with zero overhead.
 */
export class ProviderResilience {
    config;
    buckets = new Map();
    now;
    providerMetrics;
    emitEvents;
    constructor(config, init = {}) {
        this.config = config ? providerResilienceSchema.parse(config) : configuredProviderResilience();
        this.now = init.now ?? (() => Date.now());
        this.providerMetrics = bindProviderMetrics(init.registry ?? metrics);
        this.emitEvents = init.emitEvents ?? true;
    }
    hasPolicy(provider) {
        return Object.hasOwn(this.config, provider);
    }
    bucket(provider) {
        let entry = this.buckets.get(provider);
        if (!entry) {
            entry = { inflight: 0, reconcileInflight: 0, ownerInflight: new Map(), ownerCircuits: new Map() };
            this.buckets.set(provider, entry);
        }
        return entry;
    }
    getOrCreateBreaker(bucket, scope, cfg, owner) {
        if (scope === 'provider') {
            bucket.providerCircuit ??= createBreakerRecord(cfg);
            return bucket.providerCircuit;
        }
        let rec = bucket.ownerCircuits.get(owner);
        if (!rec) {
            if (bucket.ownerCircuits.size >= MAX_OWNER_CIRCUITS_PER_PROVIDER) {
                const now = this.now();
                for (const [key, candidate] of bucket.ownerCircuits) {
                    if (candidate.state === 'closed' && candidate.consecutiveFailures === 0 && candidate.halfOpenInFlight === 0) {
                        pruneSamples(candidate, cfg.windowMs, now, Math.max(cfg.minSamples * 20, 500));
                        if (!candidate.samples.length) {
                            bucket.ownerCircuits.delete(key);
                            if (bucket.ownerCircuits.size < MAX_OWNER_CIRCUITS_PER_PROVIDER)
                                break;
                        }
                    }
                }
            }
            rec = createBreakerRecord(cfg);
            bucket.ownerCircuits.set(owner, rec);
        }
        return rec;
    }
    countOpenOwnerCircuits(bucket, now) {
        let open = 0;
        for (const rec of bucket.ownerCircuits.values()) {
            if (rec.state === 'open' && now < rec.openedUntil)
                open++;
        }
        return open;
    }
    transitionBreaker(provider, bucket, scope, breaker, to, now, details = {}) {
        const from = breaker.state;
        if (from === to)
            return;
        breaker.state = to;
        this.providerMetrics.providerCircuitTransitionsTotal.inc({ provider, scope, from, to });
        if (scope === 'provider') {
            this.providerMetrics.providerCircuitState.set(CIRCUIT_STATE_NUM[to], { provider, scope: 'provider' });
        }
        const openOwners = this.countOpenOwnerCircuits(bucket, now);
        this.providerMetrics.providerOwnerCircuitsOpen.set(openOwners, { provider });
        if (this.emitEvents) {
            // Per docs/scaling.md 09.4: alerts include only source alias, category, and aggregate metrics.
            recordOperationEvent('provider_resilience_alert', {
                provider,
                scope,
                from,
                to,
                reason: details.reason,
                cooldownMs: details.cooldownMs,
                retryAfterMs: details.retryAfterMs,
                openOwnerCircuits: openOwners,
            });
        }
    }
    evaluateBreakerGate(provider, bucket, scope, breaker, cfg, rule, wantsReconcile, now) {
        if (breaker.state === 'open') {
            if (now >= breaker.openedUntil) {
                breaker.halfOpenInFlight = 0;
                breaker.halfOpenSuccesses = 0;
                breaker.halfOpenAllowedConcurrency = cfg.halfOpenMaxConcurrent;
                this.transitionBreaker(provider, bucket, scope, breaker, 'half_open', now, { reason: 'cooldown_elapsed' });
            }
            else {
                if (wantsReconcile && cfg.allowReadReconcile) {
                    return { admitted: true, mode: 'reconcile' };
                }
                return { admitted: false, reason: 'circuit_open', untilMs: breaker.openedUntil };
            }
        }
        if (breaker.state === 'half_open') {
            if (breaker.halfOpenInFlight < breaker.halfOpenAllowedConcurrency) {
                return { admitted: true, mode: 'probe' };
            }
            if (wantsReconcile && cfg.allowReadReconcile) {
                return { admitted: true, mode: 'reconcile' };
            }
            return { admitted: false, reason: 'half_open_limit', untilMs: now + rule.concurrencyBackoffMs };
        }
        return { admitted: true, mode: 'normal' };
    }
    recordRejection(provider, scope, reason, bucket, now) {
        this.providerMetrics.providerResilienceRejectionsTotal.inc({ provider, scope, reason });
        if (this.emitEvents) {
            recordOperationEvent('provider_resilience_alert', {
                provider,
                scope,
                reason,
                inflight: bucket.inflight,
                openOwnerCircuits: this.countOpenOwnerCircuits(bucket, now),
            });
        }
    }
    /** Acquires bulkhead concurrency and circuit-breaker admission synchronously, or throws ProviderBudgetExceeded. */
    acquire(provider, options = {}) {
        const rule = Object.hasOwn(this.config, provider) ? this.config[provider] : undefined;
        if (!rule)
            return noopPermit(provider);
        const now = this.now();
        const startedPerf = performance.now();
        const bucket = this.bucket(provider);
        const owner = options.owner;
        const wantsReconcile = options.allowReadReconcile === true;
        let ownerBreaker;
        let ownerGate;
        if (rule.ownerCircuitBreaker && owner) {
            ownerBreaker = this.getOrCreateBreaker(bucket, 'owner', rule.ownerCircuitBreaker, owner);
            const result = this.evaluateBreakerGate(provider, bucket, 'owner', ownerBreaker, rule.ownerCircuitBreaker, rule, wantsReconcile, now);
            if (!result.admitted) {
                this.recordRejection(provider, 'owner', result.reason, bucket, now);
                throw new ProviderBudgetExceeded(provider, new Date(result.untilMs).toISOString(), result.reason);
            }
            ownerGate = result;
        }
        let providerBreaker;
        let providerGate;
        if (rule.circuitBreaker) {
            providerBreaker = this.getOrCreateBreaker(bucket, 'provider', rule.circuitBreaker);
            const result = this.evaluateBreakerGate(provider, bucket, 'provider', providerBreaker, rule.circuitBreaker, rule, wantsReconcile, now);
            if (!result.admitted) {
                this.recordRejection(provider, 'provider', result.reason, bucket, now);
                throw new ProviderBudgetExceeded(provider, new Date(result.untilMs).toISOString(), result.reason);
            }
            providerGate = result;
        }
        const mode = ownerGate?.mode === 'reconcile' || providerGate?.mode === 'reconcile' ? 'reconcile'
            : ownerGate?.mode === 'probe' || providerGate?.mode === 'probe' ? 'probe'
                : 'normal';
        // Bulkhead concurrency checks (atomic before mutating any counter).
        if (mode === 'reconcile' && rule.reconcileMaxConcurrent !== undefined) {
            if (bucket.reconcileInflight >= rule.reconcileMaxConcurrent) {
                this.recordRejection(provider, 'provider', 'concurrency', bucket, now);
                throw new ProviderBudgetExceeded(provider, new Date(now + rule.concurrencyBackoffMs).toISOString(), 'concurrency');
            }
        }
        if (rule.maxConcurrent !== undefined && bucket.inflight >= rule.maxConcurrent) {
            this.recordRejection(provider, 'provider', 'concurrency', bucket, now);
            throw new ProviderBudgetExceeded(provider, new Date(now + rule.concurrencyBackoffMs).toISOString(), 'concurrency');
        }
        if (rule.maxConcurrentPerOwner !== undefined && owner) {
            const currentOwner = bucket.ownerInflight.get(owner) ?? 0;
            if (currentOwner >= rule.maxConcurrentPerOwner) {
                this.recordRejection(provider, 'owner', 'concurrency', bucket, now);
                throw new ProviderBudgetExceeded(provider, new Date(now + rule.concurrencyBackoffMs).toISOString(), 'concurrency');
            }
        }
        // All gates admitted: reserve slots atomically.
        bucket.inflight += 1;
        if (mode === 'reconcile')
            bucket.reconcileInflight += 1;
        if (owner)
            bucket.ownerInflight.set(owner, (bucket.ownerInflight.get(owner) ?? 0) + 1);
        const providerProbe = providerGate?.mode === 'probe' && providerBreaker !== undefined;
        const ownerProbe = ownerGate?.mode === 'probe' && ownerBreaker !== undefined;
        if (providerProbe)
            providerBreaker.halfOpenInFlight += 1;
        if (ownerProbe)
            ownerBreaker.halfOpenInFlight += 1;
        this.providerMetrics.providerInflight.set(bucket.inflight, { provider });
        if (providerBreaker) {
            this.providerMetrics.providerCircuitState.set(CIRCUIT_STATE_NUM[providerBreaker.state], { provider, scope: 'provider' });
        }
        let recorded = false;
        let released = false;
        const recordOutcomeMetrics = (outcome) => {
            const elapsedMs = Math.max(0, performance.now() - startedPerf);
            this.providerMetrics.providerCallsTotal.inc({ provider, mode, outcome });
            this.providerMetrics.providerCallDurationMs.observe(elapsedMs, { provider, mode, outcome });
        };
        const applySuccessToBreaker = (scope, breaker, cfg, wasProbe, wasReconcile, at) => {
            if (wasReconcile)
                return;
            if (breaker.state === 'half_open' && wasProbe) {
                breaker.halfOpenSuccesses += 1;
                if (breaker.halfOpenSuccesses >= cfg.halfOpenSuccessThreshold) {
                    breaker.consecutiveFailures = 0;
                    breaker.samples.length = 0;
                    breaker.openedUntil = 0;
                    breaker.halfOpenSuccesses = 0;
                    breaker.halfOpenAllowedConcurrency = cfg.halfOpenMaxConcurrent;
                    this.transitionBreaker(provider, bucket, scope, breaker, 'closed', at, { reason: 'probe_recovered' });
                }
                else if (cfg.halfOpenRampStep > 0) {
                    const ceiling = rule.maxConcurrent ?? Number.MAX_SAFE_INTEGER;
                    breaker.halfOpenAllowedConcurrency = Math.min(ceiling, breaker.halfOpenAllowedConcurrency + cfg.halfOpenRampStep);
                }
                return;
            }
            if (breaker.state === 'closed') {
                breaker.consecutiveFailures = 0;
                const maxSamples = Math.max(cfg.minSamples * 20, 500);
                breaker.samples.push({ at, failed: false });
                pruneSamples(breaker, cfg.windowMs, at, maxSamples);
            }
        };
        const applyFailureToBreaker = (scope, breaker, cfg, wasProbe, failure, at) => {
            const clampedRetryAfter = failure.retryAfterMs !== undefined
                ? Math.min(cfg.maxRetryAfterMs, Math.max(0, failure.retryAfterMs))
                : undefined;
            const effectiveCooldown = Math.max(cfg.cooldownMs, clampedRetryAfter ?? 0);
            if (breaker.state === 'open') {
                // Respect a fresher Retry-After even while already open (e.g., concurrent in-flight or reconcile).
                if (clampedRetryAfter !== undefined) {
                    breaker.openedUntil = Math.max(breaker.openedUntil, at + clampedRetryAfter);
                }
                return;
            }
            if (breaker.state === 'half_open' && wasProbe) {
                breaker.halfOpenSuccesses = 0;
                breaker.halfOpenAllowedConcurrency = cfg.halfOpenMaxConcurrent;
                breaker.openedUntil = at + effectiveCooldown;
                this.transitionBreaker(provider, bucket, scope, breaker, 'open', at, {
                    reason: failure.kind,
                    cooldownMs: effectiveCooldown,
                    retryAfterMs: clampedRetryAfter,
                });
                return;
            }
            if (breaker.state === 'closed') {
                breaker.consecutiveFailures += 1;
                const maxSamples = Math.max(cfg.minSamples * 20, 500);
                breaker.samples.push({ at, failed: true });
                pruneSamples(breaker, cfg.windowMs, at, maxSamples);
                const consecutiveHit = cfg.failureThreshold !== undefined && breaker.consecutiveFailures >= cfg.failureThreshold;
                let rateHit = false;
                if (cfg.failureRateThreshold !== undefined && breaker.samples.length >= cfg.minSamples) {
                    let failures = 0;
                    for (const sample of breaker.samples)
                        if (sample.failed)
                            failures++;
                    rateHit = (failures / breaker.samples.length) >= cfg.failureRateThreshold;
                }
                if (consecutiveHit || rateHit) {
                    breaker.openedUntil = at + effectiveCooldown;
                    breaker.halfOpenSuccesses = 0;
                    breaker.halfOpenAllowedConcurrency = cfg.halfOpenMaxConcurrent;
                    this.transitionBreaker(provider, bucket, scope, breaker, 'open', at, {
                        reason: failure.kind,
                        cooldownMs: effectiveCooldown,
                        retryAfterMs: clampedRetryAfter,
                    });
                }
            }
        };
        const permit = {
            provider,
            mode,
            recordSuccess: () => {
                if (recorded)
                    return;
                recorded = true;
                const at = this.now();
                if (ownerBreaker && rule.ownerCircuitBreaker) {
                    applySuccessToBreaker('owner', ownerBreaker, rule.ownerCircuitBreaker, ownerProbe, ownerGate?.mode === 'reconcile', at);
                }
                if (providerBreaker && rule.circuitBreaker) {
                    applySuccessToBreaker('provider', providerBreaker, rule.circuitBreaker, providerProbe, providerGate?.mode === 'reconcile', at);
                }
                recordOutcomeMetrics('success');
            },
            recordNeutral: () => {
                if (recorded)
                    return;
                recorded = true;
                recordOutcomeMetrics('client_error');
            },
            recordHttpStatus: (status, retryAfter) => {
                if (recorded)
                    return;
                if (status === 429) {
                    permit.recordFailure({ kind: 'rate_limited', status, retryAfter });
                }
                else if (status === 408) {
                    permit.recordFailure({ kind: 'timeout', status, retryAfter });
                }
                else if (status >= 500) {
                    permit.recordFailure({ kind: 'server_error', status, retryAfter });
                }
                else if (status >= 200 && status < 300) {
                    permit.recordSuccess();
                }
                else {
                    permit.recordNeutral();
                }
            },
            recordFailure: failure => {
                if (recorded)
                    return;
                recorded = true;
                const at = this.now();
                const retryAfterMs = failure.retryAfterMs !== undefined
                    ? failure.retryAfterMs
                    : parseRetryAfterMs(failure.retryAfter, at, 3_600_000);
                if (failure.kind !== 'client_error' && failure.kind !== 'aborted') {
                    if (ownerBreaker && rule.ownerCircuitBreaker) {
                        applyFailureToBreaker('owner', ownerBreaker, rule.ownerCircuitBreaker, ownerProbe, { kind: failure.kind, retryAfterMs }, at);
                    }
                    if (providerBreaker && rule.circuitBreaker) {
                        applyFailureToBreaker('provider', providerBreaker, rule.circuitBreaker, providerProbe, { kind: failure.kind, retryAfterMs }, at);
                    }
                }
                recordOutcomeMetrics(failure.kind);
            },
            recordError: (error, callerSignal) => {
                if (recorded)
                    return;
                const classified = classifyProviderFailure(error, callerSignal, this.now());
                if (!classified.tripWorthy) {
                    recorded = true;
                    recordOutcomeMetrics(classified.kind);
                    return;
                }
                permit.recordFailure({
                    kind: classified.kind,
                    status: classified.status,
                    retryAfterMs: classified.retryAfterMs,
                });
            },
            release: () => {
                if (released)
                    return;
                released = true;
                bucket.inflight = Math.max(0, bucket.inflight - 1);
                if (mode === 'reconcile')
                    bucket.reconcileInflight = Math.max(0, bucket.reconcileInflight - 1);
                if (owner) {
                    const next = (bucket.ownerInflight.get(owner) ?? 1) - 1;
                    if (next <= 0)
                        bucket.ownerInflight.delete(owner);
                    else
                        bucket.ownerInflight.set(owner, next);
                }
                if (providerProbe && providerBreaker) {
                    providerBreaker.halfOpenInFlight = Math.max(0, providerBreaker.halfOpenInFlight - 1);
                }
                if (ownerProbe && ownerBreaker) {
                    ownerBreaker.halfOpenInFlight = Math.max(0, ownerBreaker.halfOpenInFlight - 1);
                }
                this.providerMetrics.providerInflight.set(bucket.inflight, { provider });
            },
        };
        return permit;
    }
    /** Runs a provider operation under bulkhead concurrency and circuit-breaker protection. */
    async execute(provider, options, run, callerSignal) {
        if (!this.hasPolicy(provider)) {
            return run(noopPermit(provider));
        }
        const permit = this.acquire(provider, options);
        const span = startSpan('provider.egress', {
            kind: 'client',
            attributes: {
                'provider.name': provider,
                'provider.mode': permit.mode,
                ...(options.operation ? { 'provider.operation': options.operation } : {}),
            },
        });
        try {
            const result = await run(permit);
            permit.recordSuccess();
            span.setStatus('ok');
            return result;
        }
        catch (error) {
            permit.recordError(error, callerSignal);
            span.recordException(error);
            span.setStatus('error', error instanceof Error ? error.message : String(error));
            throw error;
        }
        finally {
            permit.release();
            span.end();
        }
    }
    snapshot(provider, owner) {
        const rule = Object.hasOwn(this.config, provider) ? this.config[provider] : undefined;
        if (!rule) {
            return { configured: false, inflight: 0, ownerInflight: 0, openOwnerCircuits: 0, providerCircuit: null, ownerCircuit: null };
        }
        const now = this.now();
        const bucket = this.buckets.get(provider);
        const toSnap = (rec, cfg) => {
            if (!rec || !cfg)
                return null;
            pruneSamples(rec, cfg.windowMs, now, Math.max(cfg.minSamples * 20, 500));
            let windowFailures = 0;
            for (const s of rec.samples)
                if (s.failed)
                    windowFailures++;
            const effectiveState = rec.state === 'open' && now >= rec.openedUntil ? 'half_open' : rec.state;
            return {
                state: effectiveState,
                consecutiveFailures: rec.consecutiveFailures,
                openedUntil: rec.openedUntil,
                halfOpenInFlight: rec.halfOpenInFlight,
                halfOpenSuccesses: rec.halfOpenSuccesses,
                halfOpenAllowedConcurrency: rec.halfOpenAllowedConcurrency,
                windowSamples: rec.samples.length,
                windowFailures,
            };
        };
        return {
            configured: true,
            inflight: bucket?.inflight ?? 0,
            ownerInflight: owner ? (bucket?.ownerInflight.get(owner) ?? 0) : 0,
            openOwnerCircuits: bucket ? this.countOpenOwnerCircuits(bucket, now) : 0,
            providerCircuit: toSnap(bucket?.providerCircuit, rule.circuitBreaker),
            ownerCircuit: owner ? toSnap(bucket?.ownerCircuits.get(owner), rule.ownerCircuitBreaker) : null,
        };
    }
    reset(provider) {
        if (provider !== undefined) {
            this.buckets.delete(provider);
            this.providerMetrics.providerInflight.set(0, { provider });
            this.providerMetrics.providerCircuitState.set(0, { provider, scope: 'provider' });
            this.providerMetrics.providerOwnerCircuitsOpen.set(0, { provider });
            return;
        }
        for (const name of this.buckets.keys()) {
            this.providerMetrics.providerInflight.set(0, { provider: name });
            this.providerMetrics.providerCircuitState.set(0, { provider: name, scope: 'provider' });
            this.providerMetrics.providerOwnerCircuitsOpen.set(0, { provider: name });
        }
        this.buckets.clear();
    }
}
