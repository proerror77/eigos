import { z } from 'zod';
import type { ObjectRef } from '../ontology/schema.js';
import type { Database, Sql } from './database.js';
import type { Objects } from './objects.js';
import type { Access } from './access.js';
import type { PublishedOntology } from './metadata.js';
export declare const conflictPolicySchema: z.ZodEnum<{
    latest_value: "latest_value";
    user_wins: "user_wins";
}>;
export type ConflictPolicy = z.infer<typeof conflictPolicySchema>;
export declare const propertyPoliciesSchema: z.ZodRecord<z.ZodString, z.ZodEnum<{
    latest_value: "latest_value";
    user_wins: "user_wins";
}>>;
export declare const sourcePrioritiesSchema: z.ZodRecord<z.ZodString, z.ZodArray<z.ZodString>>;
export interface ResolvedSourcePolicy {
    policy: ConflictPolicy;
    propertyPolicies?: Record<string, ConflictPolicy>;
    sourcePriorities?: Record<string, string[]>;
}
type Properties = Record<string, unknown>;
type Override = {
    value: unknown;
    at: string;
};
export interface EditState {
    overrides: Record<string, Override>;
    deleted: boolean;
    created: boolean;
}
export interface SourceBaseline {
    source: string;
    properties: Properties | null;
    observed_at: unknown;
}
export declare function resolveObjectState(sources: readonly SourceBaseline[], edits: EditState, config: ResolvedSourcePolicy, allowedFields?: Record<string, unknown>): {
    value: Properties | null;
    winningSources: Record<string, string>;
};
export declare function initializeEditHistory(db: Database): Promise<void>;
/**
 * Journals the relationships a statement's CTE returned (type, from_type, from_id, to_type, to_id), with the
 * graph's change identity. Appends its parameters to `values`; `projection` and `owner` are placeholders already bound.
 */
export declare function journalLinks(graph: Objects, operation: 'link' | 'unlink', rows: string, projection: string, owner: string, values: unknown[], source?: string | null): string;
export declare function setConflictPolicy(db: Database, access: Access, model: PublishedOntology, type: string, policy: unknown, options?: {
    propertyPolicies?: Record<string, ConflictPolicy>;
    sourcePriorities?: Record<string, string[]>;
}): Promise<{
    type: string;
    policy: "latest_value" | "user_wins";
    propertyPolicies?: Record<string, "latest_value" | "user_wins"> | undefined;
    sourcePriorities?: Record<string, string[]> | undefined;
}>;
type ObjectEdit = {
    ref: ObjectRef;
    before: Properties | null;
    after: Properties | null;
    changedFields?: Properties;
    kind: 'create' | 'edit' | 'delete';
};
/** Called after the live mutation, in the same transaction. Scenario deltas are journaled when merged. */
export declare function recordObjectEdit(graph: Objects, ref: ObjectRef, before: Properties | null, after: Properties | null, changedFields?: Properties, kind?: 'create' | 'edit' | 'delete'): Promise<void>;
/** Unique live edits in an Action, with the same source baselines and overrides as individual writes. */
export declare function recordObjectEdits(graph: Objects, edits: readonly ObjectEdit[]): Promise<void>;
/** One source observation of an object, with the stored value it may replace. */
export interface SourceObservation {
    ref: ObjectRef;
    incoming: Properties | null;
    before: Properties | null;
}
/** The value to store for an observed object. A stale observation leaves the stored value current. */
export interface ResolvedSource {
    value: Properties | null;
    current: boolean;
}
/**
 * Persists the source baselines of a batch and resolves each object with its user edits, in input order.
 * Each object needs the same decisions as a single observation; the statements are shared by the batch.
 * The caller writes the returned object values in the same transaction.
 */
export declare function resolveSourceEdits(graph: Objects, observations: readonly SourceObservation[], source?: string, observedAt?: string): Promise<ResolvedSource[]>;
export declare class EditHistory {
    private readonly db;
    private readonly archive;
    /** `archive` reads history that commit log retention archived; without it, only the tables' history is read. */
    constructor(db: Database, archive?: {
        dir: string;
        codec: import("./log-retention.js").ArchiveCodec;
    } | undefined);
    read(graph: Objects, ref: ObjectRef, after?: string, limit?: number): Promise<{
        items: {
            sequence: string;
            operation: string;
            source: string | null;
            before: Record<string, unknown> | null;
            after: Record<string, unknown> | null;
            actor: string;
            at: Date;
            release: string;
            action: string | null;
            requestId: string | null;
            taskId: string | null;
            observedAt: Date | null;
            indexTx: string | null;
            winningSources: Record<string, string> | null;
            executor: {
                kind: string;
                id: string;
            } | null;
        }[];
        cursor: string | undefined;
        archive?: "unavailable" | undefined;
    }>;
    /** The object's archived history after `after`, in this ontology's releases, as the tables would return it. */
    private archived;
}
/** A replacement publication carries conflict baselines and overlays forward with the resolved objects. */
export declare function copyEditState(db: Database, from: string, to: string, client: Sql, types?: readonly string[]): Promise<void>;
export {};
