import { z } from 'zod';
import { type MetricsRegistry } from '../core/metrics.js';
import type { Database, Sql } from './database.js';
export declare const providerRatesSchema: z.ZodRecord<z.ZodString, z.ZodObject<{
    perMinute: z.ZodNumber;
    burst: z.ZodNumber;
}, z.core.$strict>>;
export type ProviderRates = z.output<typeof providerRatesSchema>;
declare const providerQuotasSchema: z.ZodRecord<z.ZodString, z.ZodObject<{
    period: z.ZodEnum<{
        day: "day";
        month: "month";
    }>;
    calls: z.ZodNumber;
}, z.core.$strict>>;
type ProviderQuotas = z.output<typeof providerQuotasSchema>;
/** The rates of EIGOS_PROVIDER_RATES, a JSON object by source name; providers not named are not limited. */
export declare function configuredProviderRates(text?: string | undefined): ProviderRates;
export type ProviderBudgetReason = 'rate' | 'quota' | 'concurrency' | 'circuit_open' | 'half_open_limit';
/** A provider call over its owner's budget or resilience gate. A Worker defers the task until `until`; a request answers 429. */
export declare class ProviderBudgetExceeded extends Error {
    readonly provider: string;
    readonly until: string;
    readonly reason?: ProviderBudgetReason | undefined;
    constructor(provider: string, until: string, reason?: ProviderBudgetReason | undefined);
}
export declare function initializeProviderBudgets(db: Database): Promise<void>;
export declare class ProviderBudgets {
    private readonly db;
    private readonly rates;
    private readonly quotas;
    constructor(db: Database, rates?: ProviderRates, quotas?: ProviderQuotas);
    /** Admits one attempt across the configured budgets, or throws with the time to try again. */
    take(owner: string, provider: string): Promise<void>;
    /** Storing the current UTC window per period bounds the table to two rows per owner and provider. */
    private takeQuota;
}
export declare function withActionWriteBudget<T>(ontology: string, action: string, run: () => Promise<T>): Promise<T>;
/** Source reads and external Action writes use independent buckets. */
export declare class ActionWriteBudgets {
    private readonly db;
    private readonly rates;
    constructor(db: Database, text?: string | undefined);
    take(owner: string, client?: Sql, action?: string | undefined): Promise<void>;
}
export type CircuitState = 'closed' | 'open' | 'half_open';
export type ProviderFailureKind = 'rate_limited' | 'server_error' | 'timeout' | 'connection_error' | 'client_error' | 'aborted';
export type ProviderExecutionMode = 'normal' | 'probe' | 'reconcile';
export declare const circuitBreakerSchema: z.ZodObject<{
    failureThreshold: z.ZodOptional<z.ZodNumber>;
    failureRateThreshold: z.ZodOptional<z.ZodNumber>;
    minSamples: z.ZodDefault<z.ZodNumber>;
    windowMs: z.ZodDefault<z.ZodNumber>;
    cooldownMs: z.ZodDefault<z.ZodNumber>;
    maxRetryAfterMs: z.ZodDefault<z.ZodNumber>;
    halfOpenMaxConcurrent: z.ZodDefault<z.ZodNumber>;
    halfOpenSuccessThreshold: z.ZodDefault<z.ZodNumber>;
    halfOpenRampStep: z.ZodDefault<z.ZodNumber>;
    allowReadReconcile: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>;
export declare const providerResilienceRuleSchema: z.ZodObject<{
    maxConcurrent: z.ZodOptional<z.ZodNumber>;
    maxConcurrentPerOwner: z.ZodOptional<z.ZodNumber>;
    concurrencyBackoffMs: z.ZodDefault<z.ZodNumber>;
    reconcileMaxConcurrent: z.ZodOptional<z.ZodNumber>;
    circuitBreaker: z.ZodOptional<z.ZodObject<{
        failureThreshold: z.ZodOptional<z.ZodNumber>;
        failureRateThreshold: z.ZodOptional<z.ZodNumber>;
        minSamples: z.ZodDefault<z.ZodNumber>;
        windowMs: z.ZodDefault<z.ZodNumber>;
        cooldownMs: z.ZodDefault<z.ZodNumber>;
        maxRetryAfterMs: z.ZodDefault<z.ZodNumber>;
        halfOpenMaxConcurrent: z.ZodDefault<z.ZodNumber>;
        halfOpenSuccessThreshold: z.ZodDefault<z.ZodNumber>;
        halfOpenRampStep: z.ZodDefault<z.ZodNumber>;
        allowReadReconcile: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strict>>;
    ownerCircuitBreaker: z.ZodOptional<z.ZodObject<{
        failureThreshold: z.ZodOptional<z.ZodNumber>;
        failureRateThreshold: z.ZodOptional<z.ZodNumber>;
        minSamples: z.ZodDefault<z.ZodNumber>;
        windowMs: z.ZodDefault<z.ZodNumber>;
        cooldownMs: z.ZodDefault<z.ZodNumber>;
        maxRetryAfterMs: z.ZodDefault<z.ZodNumber>;
        halfOpenMaxConcurrent: z.ZodDefault<z.ZodNumber>;
        halfOpenSuccessThreshold: z.ZodDefault<z.ZodNumber>;
        halfOpenRampStep: z.ZodDefault<z.ZodNumber>;
        allowReadReconcile: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const providerResilienceSchema: z.ZodRecord<z.ZodString, z.ZodObject<{
    maxConcurrent: z.ZodOptional<z.ZodNumber>;
    maxConcurrentPerOwner: z.ZodOptional<z.ZodNumber>;
    concurrencyBackoffMs: z.ZodDefault<z.ZodNumber>;
    reconcileMaxConcurrent: z.ZodOptional<z.ZodNumber>;
    circuitBreaker: z.ZodOptional<z.ZodObject<{
        failureThreshold: z.ZodOptional<z.ZodNumber>;
        failureRateThreshold: z.ZodOptional<z.ZodNumber>;
        minSamples: z.ZodDefault<z.ZodNumber>;
        windowMs: z.ZodDefault<z.ZodNumber>;
        cooldownMs: z.ZodDefault<z.ZodNumber>;
        maxRetryAfterMs: z.ZodDefault<z.ZodNumber>;
        halfOpenMaxConcurrent: z.ZodDefault<z.ZodNumber>;
        halfOpenSuccessThreshold: z.ZodDefault<z.ZodNumber>;
        halfOpenRampStep: z.ZodDefault<z.ZodNumber>;
        allowReadReconcile: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strict>>;
    ownerCircuitBreaker: z.ZodOptional<z.ZodObject<{
        failureThreshold: z.ZodOptional<z.ZodNumber>;
        failureRateThreshold: z.ZodOptional<z.ZodNumber>;
        minSamples: z.ZodDefault<z.ZodNumber>;
        windowMs: z.ZodDefault<z.ZodNumber>;
        cooldownMs: z.ZodDefault<z.ZodNumber>;
        maxRetryAfterMs: z.ZodDefault<z.ZodNumber>;
        halfOpenMaxConcurrent: z.ZodDefault<z.ZodNumber>;
        halfOpenSuccessThreshold: z.ZodDefault<z.ZodNumber>;
        halfOpenRampStep: z.ZodDefault<z.ZodNumber>;
        allowReadReconcile: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strict>>;
}, z.core.$strict>>;
export type CircuitBreakerConfig = z.output<typeof circuitBreakerSchema>;
export type ProviderResilienceRule = z.output<typeof providerResilienceRuleSchema>;
export type ProviderResilienceConfig = z.output<typeof providerResilienceSchema>;
export type ProviderResilienceInput = z.input<typeof providerResilienceSchema>;
/** Parses EIGOS_PROVIDER_RESILIENCE JSON; unconfigured providers keep default unlimited behavior. */
export declare function configuredProviderResilience(text?: string | undefined): ProviderResilienceConfig;
/** Parses an RFC 9110 Retry-After value (delay-seconds or HTTP-date) into clamped milliseconds. */
export declare function parseRetryAfterMs(header: string | number | null | undefined, now?: number, maxMs?: number): number | undefined;
export interface ClassifiedProviderFailure {
    kind: ProviderFailureKind;
    tripWorthy: boolean;
    status?: number;
    retryAfterMs?: number;
}
export declare function classifyProviderFailure(error: unknown, callerSignal?: AbortSignal, now?: number): ClassifiedProviderFailure;
export interface CircuitSnapshot {
    state: CircuitState;
    consecutiveFailures: number;
    openedUntil: number;
    halfOpenInFlight: number;
    halfOpenSuccesses: number;
    halfOpenAllowedConcurrency: number;
    windowSamples: number;
    windowFailures: number;
}
export interface ProviderResilienceSnapshot {
    configured: boolean;
    inflight: number;
    ownerInflight: number;
    openOwnerCircuits: number;
    providerCircuit: CircuitSnapshot | null;
    ownerCircuit: CircuitSnapshot | null;
}
export interface ProviderResilienceOptions {
    owner?: string;
    /** Exempts a read-only reconciliation call from an open circuit when allowed by the rule. */
    allowReadReconcile?: boolean;
    /** Optional low-cardinality operation tag for telemetry. */
    operation?: string;
}
export interface ProviderResiliencePermit {
    readonly provider: string;
    readonly mode: ProviderExecutionMode;
    recordSuccess(): void;
    recordNeutral(): void;
    recordHttpStatus(status: number, retryAfter?: string | number | null): void;
    recordFailure(failure: {
        kind: ProviderFailureKind;
        retryAfter?: string | number | null;
        retryAfterMs?: number;
        status?: number;
    }): void;
    recordError(error: unknown, callerSignal?: AbortSignal): void;
    release(): void;
}
export interface ProviderResilienceInit {
    now?: () => number;
    registry?: MetricsRegistry;
    emitEvents?: boolean;
}
/**
 * Per-provider and per-(owner, provider) bulkhead concurrency isolation and circuit breaker
 * (docs/scaling.md 09.4). Unconfigured providers pass through with zero overhead.
 */
export declare class ProviderResilience {
    private readonly config;
    private readonly buckets;
    private readonly now;
    private readonly providerMetrics;
    private readonly emitEvents;
    constructor(config?: ProviderResilienceInput, init?: ProviderResilienceInit);
    hasPolicy(provider: string): boolean;
    private bucket;
    private getOrCreateBreaker;
    private countOpenOwnerCircuits;
    private transitionBreaker;
    private evaluateBreakerGate;
    private recordRejection;
    /** Acquires bulkhead concurrency and circuit-breaker admission synchronously, or throws ProviderBudgetExceeded. */
    acquire(provider: string, options?: ProviderResilienceOptions): ProviderResiliencePermit;
    /** Runs a provider operation under bulkhead concurrency and circuit-breaker protection. */
    execute<T>(provider: string, options: ProviderResilienceOptions, run: (permit: ProviderResiliencePermit) => Promise<T>, callerSignal?: AbortSignal): Promise<T>;
    snapshot(provider: string, owner?: string): ProviderResilienceSnapshot;
    reset(provider?: string): void;
}
export {};
