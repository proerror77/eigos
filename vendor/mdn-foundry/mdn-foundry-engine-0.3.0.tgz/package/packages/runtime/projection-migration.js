import { Conflict, digest } from '../core/identity.js';
import { resolveObjectState } from './edit-history.js';
function resolve(sources, edits, config) {
    return resolveObjectState(sources, edits, config).value;
}
/** Migrate the reconstructable source/edit layers, then verify they reproduce the prepared object. */
export async function migrateProjectionState(db, from, to, model, transform, client) {
    const identities = (await db.query(`SELECT owner,type,id FROM ${db.schema}.objects WHERE projection=$1
    UNION SELECT owner,type,id FROM ${db.schema}.source_values WHERE projection=$1
    UNION SELECT owner,type,id FROM ${db.schema}.object_edits WHERE projection=$1`, [to], client)).rows;
    for (const identity of identities) {
        const ref = { type: identity.type, id: identity.id };
        const key = [to, identity.owner, ref.type, ref.id];
        const fields = model.object(ref.type).properties;
        const apply = (properties) => {
            const value = transform(ref, structuredClone(properties));
            if (!value || typeof value !== 'object' || Array.isArray(value))
                throw new Conflict('Projection transformation must return object properties');
            return Object.fromEntries(Object.entries(value).filter(([name]) => fields[name]));
        };
        const sourceRows = (await db.query(`SELECT source,properties,observed_at FROM ${db.schema}.source_values
      WHERE projection=$1 AND owner=$2 AND type=$3 AND id=$4 ORDER BY observed_at,source`, key, client)).rows;
        const editRow = (await db.query(`SELECT overrides,deleted,created FROM ${db.schema}.object_edits
      WHERE projection=$1 AND owner=$2 AND type=$3 AND id=$4`, key, client)).rows[0];
        const edits = editRow ?? { overrides: {}, deleted: false, created: false };
        const target = (await db.query(`SELECT properties FROM ${db.schema}.objects WHERE projection=$1 AND owner=$2 AND type=$3 AND id=$4`, key, client)).rows[0]?.properties;
        const sourceObject = (await db.query(`SELECT properties FROM ${db.schema}.objects WHERE projection=$1 AND owner=$2 AND type=$3 AND id=$4`, [from, ...key.slice(1)], client)).rows[0]?.properties;
        const policyRow = (await db.query(`SELECT policy,property_policies,source_priorities FROM ${db.schema}.edit_policies WHERE ontology=$1 AND type=$2`, [model.document.id, ref.type], client)).rows[0];
        const policyConfig = {
            policy: (policyRow?.policy ?? 'user_wins'),
            propertyPolicies: (policyRow?.property_policies ?? {}),
            sourcePriorities: (policyRow?.source_priorities ?? {}),
        };
        const migratedSources = sourceRows.map(source => ({ ...source, properties: source.properties && apply(source.properties) }));
        const migratedOverrides = {};
        const baseline = resolve(sourceRows, { overrides: {}, deleted: false, created: edits.created }, { policy: 'user_wins', sourcePriorities: policyConfig.sourcePriorities }) ?? {};
        const allEdits = { ...baseline, ...Object.fromEntries(Object.entries(edits.overrides).map(([name, edit]) => [name, edit.value])) };
        const transformedEdits = Object.keys(edits.overrides).length ? apply(allEdits) : {};
        for (const [name, edit] of Object.entries(edits.overrides)) {
            // Same-name mappings retain explicit same-value edits and their original ordering timestamps.
            if (fields[name] && Object.hasOwn(transformedEdits, name))
                migratedOverrides[name] = { value: transformedEdits[name], at: edit.at };
            const without = { ...allEdits };
            if (Object.hasOwn(baseline, name))
                without[name] = baseline[name];
            else
                delete without[name];
            // Created objects can lack required inputs when one field is removed. Newly produced fields
            // are assigned below from their complete creation state.
            if (edits.created && !Object.hasOwn(baseline, name))
                continue;
            const transformedWithout = apply(without);
            for (const [mappedName, value] of Object.entries(transformedEdits)) {
                if (digest({ value }) === digest({ value: transformedWithout[mappedName] }))
                    continue;
                const previous = migratedOverrides[mappedName];
                if (!previous || Date.parse(previous.at) < Date.parse(edit.at))
                    migratedOverrides[mappedName] = { value, at: edit.at };
            }
            if (!fields[name] && digest(transformedWithout) === digest(transformedEdits))
                throw new Conflict('Projection transformation cannot infer the target of an explicit edit; provide a compatible state migration');
        }
        if (edits.created && Object.keys(edits.overrides).length) {
            const creationTime = Object.values(edits.overrides).map(edit => edit.at).sort((left, right) => Date.parse(left) - Date.parse(right))[0];
            for (const [name, value] of Object.entries(transformedEdits))
                migratedOverrides[name] ??= { value, at: creationTime };
        }
        // Pre-history objects have no layers. Preserve their migrated state as the legacy source baseline.
        if (!sourceRows.length && !editRow && sourceObject && target)
            migratedSources.push({ source: '__legacy__', properties: target, observed_at: -Infinity });
        const migratedEdits = { ...edits, overrides: migratedOverrides };
        const resolved = resolve(migratedSources, migratedEdits, policyConfig);
        if (digest(resolved) !== digest(target ?? null))
            throw new Conflict('Transformed source and edit state does not reconstruct the candidate object');
        for (const source of migratedSources) {
            const at = source.observed_at === -Infinity ? '-infinity' : source.observed_at;
            await db.query(`INSERT INTO ${db.schema}.source_values(projection,owner,type,id,source,properties,observed_at) VALUES($1,$2,$3,$4,$5,$6,$7)
        ON CONFLICT(projection,owner,type,id,source) DO UPDATE SET properties=excluded.properties`, [...key, source.source, source.properties, at], client);
        }
        if (editRow)
            await db.query(`UPDATE ${db.schema}.object_edits SET overrides=$5 WHERE projection=$1 AND owner=$2 AND type=$3 AND id=$4`, [...key, migratedOverrides], client);
    }
}
