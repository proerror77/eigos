import { z } from 'zod';
import type { Database, Sql } from './database.js';
export declare function getSecurityCacheGeneration(db: Database): number;
export declare function notifySecurityCacheInvalidated(db: Database): void;
export declare function attachSecurityEpochTrigger(db: Database, table: string): Promise<void>;
export declare function bumpSecurityEpoch(db: Database, client?: Sql): Promise<string>;
export declare const expressionSchema: z.ZodObject<{
    all: z.ZodDefault<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        op: z.ZodLiteral<"equals">;
        property: z.ZodString;
        value: z.ZodUnion<readonly [z.ZodString, z.ZodNumber, z.ZodBoolean, z.ZodNull]>;
    }, z.core.$strict>, z.ZodObject<{
        op: z.ZodLiteral<"subject">;
        property: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        op: z.ZodLiteral<"member">;
        property: z.ZodString;
    }, z.core.$strict>], "op">>>;
    any: z.ZodDefault<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        op: z.ZodLiteral<"equals">;
        property: z.ZodString;
        value: z.ZodUnion<readonly [z.ZodString, z.ZodNumber, z.ZodBoolean, z.ZodNull]>;
    }, z.core.$strict>, z.ZodObject<{
        op: z.ZodLiteral<"subject">;
        property: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        op: z.ZodLiteral<"member">;
        property: z.ZodString;
    }, z.core.$strict>], "op">>>;
}, z.core.$strict>;
export declare const objectPolicySchema: z.ZodObject<{
    read: z.ZodOptional<z.ZodObject<{
        all: z.ZodDefault<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            op: z.ZodLiteral<"equals">;
            property: z.ZodString;
            value: z.ZodUnion<readonly [z.ZodString, z.ZodNumber, z.ZodBoolean, z.ZodNull]>;
        }, z.core.$strict>, z.ZodObject<{
            op: z.ZodLiteral<"subject">;
            property: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            op: z.ZodLiteral<"member">;
            property: z.ZodString;
        }, z.core.$strict>], "op">>>;
        any: z.ZodDefault<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            op: z.ZodLiteral<"equals">;
            property: z.ZodString;
            value: z.ZodUnion<readonly [z.ZodString, z.ZodNumber, z.ZodBoolean, z.ZodNull]>;
        }, z.core.$strict>, z.ZodObject<{
            op: z.ZodLiteral<"subject">;
            property: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            op: z.ZodLiteral<"member">;
            property: z.ZodString;
        }, z.core.$strict>], "op">>>;
    }, z.core.$strict>>;
    properties: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodObject<{
        all: z.ZodDefault<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            op: z.ZodLiteral<"equals">;
            property: z.ZodString;
            value: z.ZodUnion<readonly [z.ZodString, z.ZodNumber, z.ZodBoolean, z.ZodNull]>;
        }, z.core.$strict>, z.ZodObject<{
            op: z.ZodLiteral<"subject">;
            property: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            op: z.ZodLiteral<"member">;
            property: z.ZodString;
        }, z.core.$strict>], "op">>>;
        any: z.ZodDefault<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            op: z.ZodLiteral<"equals">;
            property: z.ZodString;
            value: z.ZodUnion<readonly [z.ZodString, z.ZodNumber, z.ZodBoolean, z.ZodNull]>;
        }, z.core.$strict>, z.ZodObject<{
            op: z.ZodLiteral<"subject">;
            property: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            op: z.ZodLiteral<"member">;
            property: z.ZodString;
        }, z.core.$strict>], "op">>>;
    }, z.core.$strict>>>;
    markingsProperty: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type ObjectPolicy = z.infer<typeof objectPolicySchema>;
type Expression = z.infer<typeof expressionSchema>;
export type SecurityContext = {
    subject: string;
    groups: string[];
    markings: string[];
};
export declare function initializeSecurity(db: Database): Promise<void>;
export declare function permits(expression: Expression | undefined, properties: Record<string, unknown>, context: SecurityContext): boolean;
export declare function markingsOf(policy: ObjectPolicy | undefined, properties: Record<string, unknown>): string[];
export declare function policySql(expression: Expression | undefined, values: unknown[], context: SecurityContext, column?: string): string;
export {};
