import { z } from 'zod';
import { type Classification } from '../ontology/classification.js';
import { ComponentSourceSecrets } from './component-source-secrets.js';
import { ComponentOAuthGrants } from './component-source-oauth.js';
import type { Database } from './database.js';
import { ProviderResilience } from './provider-budgets.js';
declare const method: z.ZodEnum<{
    DELETE: "DELETE";
    GET: "GET";
    HEAD: "HEAD";
    PATCH: "PATCH";
    POST: "POST";
    PUT: "PUT";
}>;
export declare const componentHttpConnections: z.ZodRecord<z.ZodString, z.ZodObject<{
    baseUrl: z.ZodPipe<z.ZodURL, z.ZodTransform<URL, string>>;
    methods: z.ZodArray<z.ZodEnum<{
        DELETE: "DELETE";
        GET: "GET";
        HEAD: "HEAD";
        PATCH: "PATCH";
        POST: "POST";
        PUT: "PUT";
    }>>;
    networks: z.ZodOptional<z.ZodArray<z.ZodString>>;
    bearerSecret: z.ZodOptional<z.ZodString>;
    oauth: z.ZodOptional<z.ZodDiscriminatedUnion<[z.ZodObject<{
        tokenUrl: z.ZodPipe<z.ZodURL, z.ZodTransform<URL, string>>;
        clientId: z.ZodString;
        clientSecret: z.ZodString;
        grant: z.ZodLiteral<"client_credentials">;
        scope: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        tokenUrl: z.ZodPipe<z.ZodURL, z.ZodTransform<URL, string>>;
        clientId: z.ZodString;
        clientSecret: z.ZodString;
        grant: z.ZodLiteral<"refresh_token">;
        refreshTokenSecret: z.ZodString;
    }, z.core.$strict>], "grant">>;
    webhooks: z.ZodOptional<z.ZodArray<z.ZodObject<{
        method: z.ZodEnum<{
            DELETE: "DELETE";
            PATCH: "PATCH";
            POST: "POST";
            PUT: "PUT";
        }>;
        path: z.ZodString;
        clearance: z.ZodObject<{
            sensitivity: z.ZodEnum<{
                CONFIDENTIAL: "CONFIDENTIAL";
                INTERNAL: "INTERNAL";
                PUBLIC: "PUBLIC";
                RESTRICTED: "RESTRICTED";
            }>;
            compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>;
    }, z.core.$strict>>>;
}, z.core.$strict>>;
type Method = z.infer<typeof method>;
type OutboundContext = ({
    mode: 'read';
} | {
    mode: 'effect';
    idempotencyKey: string;
    classification: Classification;
}) & {
    signal: AbortSignal;
    owner?: string;
    allowReadReconcile?: boolean;
    /** Revalidates the current source permission and, for effects, the persisted dispatch authorization. */
    authorize: (source: string, method: Method) => Promise<void>;
    secret: (name: string) => Promise<string>;
};
type RequestOptions = {
    method: Method;
    body?: string;
    headers: Record<string, string>;
    networks?: string[];
    signal: AbortSignal;
};
type ReadResponse = {
    status: number;
    contentType: string | null;
    body: string;
    retryAfter?: string | null;
};
type Transport = (url: URL, options: RequestOptions) => Promise<ReadResponse>;
type EgressRecord = {
    source: string;
    outcome: 'returned' | 'denied' | 'failed';
    status?: number;
};
/** A Function receives access to one declared Source. The runtime owns authorization, connection details and credentials. */
export declare class ComponentSourceEgress {
    private readonly transport;
    private readonly audit;
    private readonly grants?;
    private readonly resilience;
    private readonly connections;
    private readonly tokens;
    constructor(configuration: unknown, transport?: Transport, audit?: (entry: EgressRecord) => void, grants?: ComponentOAuthGrants | undefined, resilience?: ProviderResilience);
    binding(source: string): string;
    webhookBinding(source: string, method: Method, path: string, label?: Classification): string;
    private clientToken;
    private refreshToken;
    private exchangeToken;
    send(source: string, expectedBinding: string, raw: unknown, context: OutboundContext): Promise<ReadResponse>;
}
export type ConfiguredComponentSources = {
    egress: ComponentSourceEgress;
    secrets?: Pick<ComponentSourceSecrets, 'get'>;
};
export declare function configuredComponentSources(db: Database, env?: NodeJS.ProcessEnv): ConfiguredComponentSources | undefined;
export {};
