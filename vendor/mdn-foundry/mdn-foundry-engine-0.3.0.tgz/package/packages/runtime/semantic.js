import { documentChunkType, documentType } from '../ontology/documents.js';
import { isProtected } from '../ontology/classification.js';
import { processLogTarget } from '../ontology/process-definition.js';
import { z } from 'zod';
import { Conflict, digest, NotFound } from '../core/identity.js';
import { objectRefSchema } from '../ontology/schema.js';
import { Objects, querySchema } from './objects.js';
import { checkScenario, viewTables } from './scenario-store.js';
import { scenarioMetadataType } from './scenario-metadata.js';
import { pgvectorNamespace } from './semantic-pgvector.js';
import { semanticIndexBinding } from './semantic-publication.js';
import { nestedValue, propertyPathSchema } from './query-filter.js';
const indexName = z
    .string()
    .regex(/^[A-Za-z][A-Za-z0-9]*$/)
    .max(80);
export const semanticConfigureSchema = z.strictObject({
    name: indexName,
    type: z.string().min(1),
    property: propertyPathSchema,
    embeddingFunction: z.string().min(1),
    dimensions: z.number().int().min(1).max(4096),
});
export const semanticIndexSchema = z.strictObject({
    name: indexName,
    objects: z.array(objectRefSchema).min(1).max(100),
});
export const semanticSearchSchema = z.strictObject({
    name: indexName,
    text: z.string().min(1).max(32000),
    from: querySchema.shape.from,
    limit: z.number().int().min(1).max(100).default(10),
});
export const semanticSearchViewSchema = semanticSearchSchema.extend({ scenarioId: z.uuid().optional() });
export const semanticStatusSchema = z.strictObject({ name: indexName });
export async function initializeSemantic(db) {
    await db.query(`CREATE TABLE IF NOT EXISTS ${db.schema}.semantic_indexes (
    ontology text NOT NULL,release text NOT NULL REFERENCES ${db.schema}.releases(digest),name text NOT NULL,
    type text NOT NULL,property text NOT NULL,embedding_function text NOT NULL,embedding_version text NOT NULL,binding text NOT NULL,dimensions integer NOT NULL,
    PRIMARY KEY(ontology,release,name));
    ALTER TABLE ${db.schema}.semantic_indexes ADD COLUMN IF NOT EXISTS embedding_version text;
    CREATE TABLE IF NOT EXISTS ${db.schema}.semantic_vectors (
      ontology text NOT NULL,release text NOT NULL,name text NOT NULL,owner text NOT NULL,type text NOT NULL,id text NOT NULL,
      revision bigint NOT NULL,text_digest text NOT NULL,binding text NOT NULL,dimensions integer NOT NULL,vector jsonb NOT NULL,
      indexed_at timestamptz NOT NULL DEFAULT now(),PRIMARY KEY(ontology,release,name,owner,type,id),
      FOREIGN KEY(ontology,release,name) REFERENCES ${db.schema}.semantic_indexes(ontology,release,name));`);
}
function chunkCitation(object) {
    const { documentId, index, startOffset, endOffset, page, paragraph } = object.properties;
    if (typeof documentId !== 'string' || typeof index !== 'number' || typeof startOffset !== 'number' || typeof endOffset !== 'number')
        return undefined;
    return {
        version: { type: documentType, id: documentId }, chunk: object.ref, index, startOffset, endOffset,
        ...(typeof page === 'number' ? { page } : {}), ...(typeof paragraph === 'number' ? { paragraph } : {}),
    };
}
const DEFAULT_EMBED_CONCURRENCY = 6;
const MAX_EMBED_CONCURRENCY = 16;
const normalizeConcurrency = (value) => {
    if (typeof value !== 'number' || !Number.isFinite(value))
        return DEFAULT_EMBED_CONCURRENCY;
    const rounded = Math.trunc(value);
    if (rounded < 1)
        return 1;
    return Math.min(MAX_EMBED_CONCURRENCY, rounded);
};
const normalized = (raw, dimensions) => {
    if (!Array.isArray(raw) || raw.length !== dimensions) {
        z.array(z.number().finite()).length(dimensions).parse(raw);
    }
    const arr = raw;
    let normSq = 0;
    for (let i = 0; i < dimensions; i++) {
        const value = arr[i];
        if (typeof value !== 'number' || !Number.isFinite(value)) {
            z.array(z.number().finite()).length(dimensions).parse(raw);
        }
        const num = value;
        normSq += num * num;
    }
    let norm = Math.sqrt(normSq);
    if (!Number.isFinite(norm) || norm === 0)
        norm = Math.hypot(...arr);
    if (!Number.isFinite(norm) || norm === 0)
        throw new Conflict('Embedding must have a finite nonzero norm');
    const unit = new Array(dimensions);
    for (let i = 0; i < dimensions; i++)
        unit[i] = arr[i] / norm;
    return unit;
};
function cosineScore(raw, query) {
    const dimensions = query.length;
    if (!Array.isArray(raw) || raw.length !== dimensions) {
        z.array(z.number().finite()).length(dimensions).parse(raw);
    }
    const arr = raw;
    let dot = 0;
    let normSq = 0;
    for (let i = 0; i < dimensions; i++) {
        const value = arr[i];
        if (typeof value !== 'number' || !Number.isFinite(value)) {
            z.array(z.number().finite()).length(dimensions).parse(raw);
        }
        const num = value;
        dot += num * query[i];
        normSq += num * num;
    }
    let norm = Math.sqrt(normSq);
    if (!Number.isFinite(norm) || norm === 0) {
        norm = Math.hypot(...arr);
        if (!Number.isFinite(norm) || norm === 0)
            throw new Conflict('Embedding must have a finite nonzero norm');
        let scaledDot = 0;
        for (let i = 0; i < dimensions; i++)
            scaledDot += (arr[i] / norm) * query[i];
        return scaledDot;
    }
    return dot / norm;
}
/** Keep only the top-K items under `compare` (where compare(a, b) < 0 means `a` ranks ahead of `b`). */
function pushTopK(heap, limit, item, compare) {
    if (heap.length < limit) {
        heap.push(item);
        let i = heap.length - 1;
        while (i > 0) {
            const parent = (i - 1) >> 1;
            if (compare(heap[i], heap[parent]) <= 0)
                break;
            const tmp = heap[i];
            heap[i] = heap[parent];
            heap[parent] = tmp;
            i = parent;
        }
        return;
    }
    if (compare(item, heap[0]) >= 0)
        return;
    heap[0] = item;
    let i = 0;
    const n = heap.length;
    for (;;) {
        const left = (i << 1) + 1;
        const right = left + 1;
        let worst = i;
        if (left < n && compare(heap[left], heap[worst]) > 0)
            worst = left;
        if (right < n && compare(heap[right], heap[worst]) > 0)
            worst = right;
        if (worst === i)
            break;
        const tmp = heap[i];
        heap[i] = heap[worst];
        heap[worst] = tmp;
        i = worst;
    }
}
const compareScoredCandidate = (a, b) => b.score - a.score || a.ordinal - b.ordinal;
const compareKeyedScore = (a, b) => b.score - a.score || (a.type < b.type ? -1 : a.type > b.type ? 1 : a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
export class SemanticSearch {
    db;
    functions;
    defaultEmbedConcurrency;
    constructor(db, functions, options) {
        this.db = db;
        this.functions = functions;
        const envConcurrency = process.env.EIGOS_SEMANTIC_INDEX_CONCURRENCY
            ? Number(process.env.EIGOS_SEMANTIC_INDEX_CONCURRENCY)
            : undefined;
        this.defaultEmbedConcurrency = normalizeConcurrency(options?.embedConcurrency ?? envConcurrency);
    }
    async configure(access, model, raw) {
        const input = semanticConfigureSchema.parse(raw);
        if (model.scenario)
            throw new Conflict('Configure semantic indexes on a published live Ontology');
        await access.refresh();
        access.require(model.document.id, 'manage_definition', model.document.id);
        const { binding, modelVersion } = semanticIndexBinding(model, model.bindings, input);
        return this.db.transaction(async (client) => {
            await new Objects(this.db, model, access, client).lockWrites();
            const existing = (await this.db.query(`SELECT * FROM ${this.db.schema}.semantic_indexes WHERE ontology=$1 AND release=$2 AND name=$3`, [model.document.id, model.release, input.name], client)).rows[0];
            if (existing &&
                (existing.type !== input.type ||
                    existing.property !== input.property ||
                    existing.embedding_function !== input.embeddingFunction ||
                    existing.dimensions !== input.dimensions ||
                    existing.binding !== binding ||
                    existing.embedding_version !== modelVersion))
                throw new Conflict('A semantic index configuration is immutable; use another name or publication');
            await this.db.query(`INSERT INTO ${this.db.schema}.semantic_indexes(ontology,release,name,type,property,embedding_function,binding,dimensions,embedding_version)
        VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) ON CONFLICT DO NOTHING`, [
                model.document.id,
                model.release,
                input.name,
                input.type,
                input.property,
                input.embeddingFunction,
                binding,
                input.dimensions,
                modelVersion,
            ], client);
            const configured = (await this.db.query(`SELECT type,property,embedding_function,embedding_version,dimensions,binding FROM ${this.db.schema}.semantic_indexes WHERE ontology=$1 AND release=$2 AND name=$3`, [model.document.id, model.release, input.name], client)).rows[0];
            if (configured.type !== input.type ||
                configured.property !== input.property ||
                configured.embedding_function !== input.embeddingFunction ||
                Number(configured.dimensions) !== input.dimensions ||
                configured.binding !== binding ||
                configured.embedding_version !== modelVersion)
                throw new Conflict('Concurrent semantic configuration differs');
            await access.refresh(client);
            return { ...input, release: model.release, binding, modelVersion };
        });
    }
    async configuration(access, model, name) {
        indexName.parse(name);
        await access.refresh();
        const row = (await this.db.query(`SELECT * FROM ${this.db.schema}.semantic_indexes WHERE ontology=$1 AND release=$2 AND name=$3`, [model.document.id, model.release, name])).rows[0];
        if (!row)
            throw new NotFound('Semantic index is unavailable for this publication');
        access.read(model, row.type);
        access.function(model, row.embedding_function);
        if (row.binding !== model.bindings.functions[row.embedding_function] ||
            row.embedding_version !== model.functions.get(row.embedding_function)?.version)
            throw new Conflict('Semantic index model binding changed');
        return {
            name,
            type: row.type,
            property: row.property,
            embeddingFunction: row.embedding_function,
            dimensions: Number(row.dimensions),
            release: row.release,
            binding: row.binding,
            modelVersion: row.embedding_version,
        };
    }
    async embed(access, model, configuration, text, signal) {
        const timeout = AbortSignal.timeout(30000);
        const effectiveSignal = signal ? AbortSignal.any([signal, timeout]) : timeout;
        const result = await this.functions.invoke(model, configuration.embeddingFunction, { text }, {
            principal: access.principal,
            objects: new Objects(this.db, model, access),
            signal: effectiveSignal,
        });
        return normalized(result, configuration.dimensions);
    }
    async readIndexObjects(graph, access, model, configuration, refs, checkEgress) {
        const enforceEgress = (classification) => {
            if (checkEgress && isProtected(classification) && configuration.embeddingFunction !== 'embedTextLocal')
                throw new Conflict('Protected embedding input requires the local embedding Function');
        };
        if (configuration.type === scenarioMetadataType || processLogTarget(model, configuration.type)) {
            const objects = [];
            for (const ref of refs) {
                if (checkEgress) {
                    const scoped = await access.measureEgress(() => graph.readStored(ref));
                    enforceEgress(scoped.classification);
                    objects.push(scoped.result);
                }
                else {
                    objects.push(await graph.readStored(ref));
                }
            }
            return objects;
        }
        const ids = refs.map(ref => ref.id);
        if (this.db.objectScoped(graph.client)) {
            await this.db.lockObjects(graph.client, refs.map(ref => this.db.lockKey('object', model.projection, access.principal.owner, ref.type, ref.id)), 'shared');
        }
        if (configuration.type === documentChunkType) {
            const loadChunks = async () => {
                access.read(model, documentChunkType);
                const values = [access.principal.owner, documentChunkType, ids, model.projection];
                const policy = access.rowSql(model, documentChunkType, values, 'o.properties');
                const runQuery = () => this.db.readQuery(`SELECT type,id,revision,properties FROM ${this.db.schema}.objects o
           WHERE owner=$1 AND type=$2 AND id=ANY($3::text[]) AND projection=$4 AND ${policy}`, values, graph.client);
                const { rows } = this.db.objectScoped(graph.client)
                    ? await this.db.withObjectAccess(runQuery)
                    : await runQuery();
                const rowById = new Map(rows.map(row => [String(row.id), row]));
                const orderedRows = refs.map(ref => {
                    const row = rowById.get(ref.id);
                    if (!row)
                        throw new NotFound('Object is unavailable');
                    return row;
                });
                return graph.hydrateStoredRows(orderedRows);
            };
            if (!checkEgress)
                return loadChunks();
            const scoped = await access.measureEgress(loadChunks);
            enforceEgress(scoped.classification);
            return scoped.result;
        }
        access.read(model, configuration.type);
        const runQuery = () => this.db.readQuery(`SELECT type,id,revision,properties FROM ${this.db.schema}.objects
       WHERE owner=$1 AND type=$2 AND id=ANY($3::text[]) AND projection=$4`, [access.principal.owner, configuration.type, ids, model.projection], graph.client);
        const { rows } = this.db.objectScoped(graph.client)
            ? await this.db.withObjectAccess(runQuery)
            : await runQuery();
        const rowById = new Map(rows.map(row => [String(row.id), row]));
        const orderedRows = refs.map(ref => {
            const row = rowById.get(ref.id);
            if (!row)
                throw new NotFound('Object is unavailable');
            return row;
        });
        if (!checkEgress)
            return graph.hydrateStoredRows(orderedRows);
        const objects = [];
        for (const row of orderedRows) {
            const scoped = await access.measureEgress(async () => (await graph.hydrateStoredRows([row]))[0]);
            enforceEgress(scoped.classification);
            objects.push(scoped.result);
        }
        return objects;
    }
    async index(access, model, raw, options) {
        const input = semanticIndexSchema.parse(raw), configuration = await this.configuration(access, model, input.name);
        if (model.scenario)
            throw new Conflict('Index live objects before opening a Scenario');
        const refs = [...new Map(input.objects.map((ref) => [digest(ref), ref])).values()];
        for (const ref of refs) {
            if (ref.type !== configuration.type)
                throw new Conflict('Object type differs from the semantic index');
        }
        options?.signal?.throwIfAborted();
        // Stage 1: batch read + per-object egress classification and text validation.
        const graph = new Objects(this.db, model, access);
        const objects = await this.readIndexObjects(graph, access, model, configuration, refs, true);
        const prepared = objects.map((object, index) => {
            const text = nestedValue(object.properties, configuration.property);
            if (typeof text !== 'string' || !text.length || text.length > 32000)
                throw new Conflict('Embedding input must be an authorized string of 1 to 32000 characters');
            return { ref: refs[index], revision: object.revision, text, textDigest: digest(text) };
        });
        // Stage 2: bounded-concurrency embedding generation with cooperative abort propagation.
        const concurrency = Math.min(prepared.length, normalizeConcurrency(options?.concurrency ?? this.defaultEmbedConcurrency));
        const vectors = new Array(prepared.length);
        const batchAbort = new AbortController();
        const sharedSignal = options?.signal ? AbortSignal.any([options.signal, batchAbort.signal]) : batchAbort.signal;
        let nextIndex = 0;
        let failed = false;
        let firstError;
        const worker = async () => {
            while (!failed) {
                if (sharedSignal.aborted) {
                    if (!failed) {
                        failed = true;
                        firstError = sharedSignal.reason ?? new Conflict('Semantic indexing aborted');
                    }
                    return;
                }
                const index = nextIndex++;
                if (index >= prepared.length)
                    return;
                try {
                    vectors[index] = await this.embed(access, model, configuration, prepared[index].text, sharedSignal);
                }
                catch (error) {
                    if (!failed) {
                        failed = true;
                        firstError = error;
                        batchAbort.abort(error);
                    }
                    return;
                }
            }
        };
        await Promise.all(Array.from({ length: concurrency }, worker));
        if (failed)
            throw firstError;
        options?.signal?.throwIfAborted();
        // Stage 3: single object-scoped transaction for lock, freshness/permission verification, and bulk upsert.
        await this.db.objectScopedTransaction(async (client) => {
            const currentGraph = new Objects(this.db, model, access, client);
            await currentGraph.lockWrites();
            const currentObjects = await this.readIndexObjects(currentGraph, access, model, configuration, refs, true);
            for (let i = 0; i < prepared.length; i++) {
                const item = prepared[i];
                const current = currentObjects[i];
                const currentText = nestedValue(current.properties, configuration.property);
                if (current.revision !== item.revision ||
                    typeof currentText !== 'string' ||
                    digest(currentText) !== item.textDigest)
                    throw new Conflict('Object changed while its embedding was generated; retry indexing');
            }
            if (!(await this.db.withObjectAccess(() => access.canReturn(access.dataRequirements(), client))))
                throw new Conflict('Embedding input permissions changed');
            const payload = prepared.map((item, i) => ({
                type: item.ref.type,
                id: item.ref.id,
                revision: currentObjects[i].revision,
                text_digest: item.textDigest,
                vector: vectors[i],
            }));
            await this.db.query(`INSERT INTO ${this.db.schema}.semantic_vectors(ontology,release,name,owner,type,id,revision,text_digest,binding,dimensions,vector)
        SELECT $1,$2,$3,$4,r.type,r.id,r.revision,r.text_digest,$5,$6,r.vector
        FROM jsonb_to_recordset($7::jsonb) AS r(type text,id text,revision bigint,text_digest text,vector jsonb)
        ON CONFLICT(ontology,release,name,owner,type,id)
        DO UPDATE SET revision=excluded.revision,text_digest=excluded.text_digest,binding=excluded.binding,dimensions=excluded.dimensions,vector=excluded.vector,indexed_at=now()`, [
                model.document.id,
                model.release,
                input.name,
                access.principal.owner,
                configuration.binding,
                configuration.dimensions,
                JSON.stringify(payload),
            ], client);
        }, 'semantic.index');
        return {
            name: input.name,
            indexed: prepared.length,
            release: model.release,
            dimensions: configuration.dimensions,
            binding: configuration.binding,
            modelVersion: configuration.modelVersion,
        };
    }
    async documentChunks(graph, from) {
        if (graph.model.navigation(from.object.type, from.link, from.as).target !== documentType) {
            throw new Conflict('Document search scope must link to a document version');
        }
        const ids = [];
        let cursor;
        do {
            const page = await graph.queryStored({ type: documentType, from, select: ['id'], limit: 100, cursor });
            ids.push(...page.items.map(item => item.ref.id));
            if (ids.length > 10000)
                throw new Conflict('Document search scope exceeds 10000 authorized document versions');
            cursor = page.cursor;
        } while (cursor);
        if (!ids.length)
            return [];
        const chunks = await graph.followSet(documentType, ids, 'chunks', undefined, 10000);
        if (!chunks)
            throw new Conflict('Document search scope needs a stored document chunk relationship');
        const approved = new Set(ids);
        return chunks.filter(chunk => typeof chunk.properties.documentId === 'string' && approved.has(chunk.properties.documentId));
    }
    async withCandidates(access, model, configuration, read, from) {
        return this.db.transaction(async (client) => {
            await this.db.query('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ', [], client);
            await access.refresh(client);
            const graph = new Objects(this.db, model, access, client), candidates = [];
            let seen = 0;
            const accept = (objects) => {
                seen += objects.length;
                if (seen > 10000)
                    throw new Conflict('Exact semantic search exceeds 10000 authorized objects');
                for (const object of objects) {
                    const text = nestedValue(object.properties, configuration.property);
                    if (typeof text !== 'string')
                        continue;
                    const citation = object.ref.type === documentChunkType ? chunkCitation(object) : undefined;
                    if (object.ref.type === documentChunkType && !citation)
                        continue;
                    candidates.push({ object, citation, textDigest: digest(text), tie: digest(object.ref) });
                }
            };
            if (from)
                accept(await this.documentChunks(graph, from));
            else {
                let cursor;
                do {
                    const page = await graph.queryStored({ type: configuration.type, limit: 100, cursor });
                    accept(page.items);
                    cursor = page.cursor;
                } while (cursor);
            }
            // Stable identity order breaks equal scores the same way in each backend.
            candidates.sort((a, b) => a.tie < b.tie ? -1 : a.tie > b.tie ? 1 : 0);
            const values = [
                model.document.id, model.release, configuration.name, access.principal.owner, configuration.binding, configuration.dimensions,
                JSON.stringify(candidates.map(({ object, textDigest }, ordinal) => ({ ...object.ref, revision: object.revision, text_digest: textDigest, ordinal }))),
            ];
            const match = `FROM ${this.db.schema}.semantic_vectors v
        JOIN jsonb_to_recordset($7::jsonb) AS accepted(type text,id text,revision bigint,text_digest text,ordinal integer)
          ON (v.type,v.id,v.revision,v.text_digest)=(accepted.type,accepted.id,accepted.revision,accepted.text_digest)
        WHERE v.ontology=$1 AND v.release=$2 AND v.name=$3 AND v.owner=$4 AND v.binding=$5 AND v.dimensions=$6`;
            const namespace = await pgvectorNamespace(this.db, client);
            const backend = namespace ? 'pgvector' : 'jsonb';
            return { backend, value: await read({ candidates, client, namespace, match, values }) };
        });
    }
    async rank(snapshot, query, limit) {
        if (!snapshot.candidates.length)
            return [];
        const { namespace, values, match, client } = snapshot;
        if (namespace) {
            // Materialize the ACL- and freshness-matched vectors before scoring. The planner cannot use an
            // approximate vector index in place of the exact authorized ranking, even if one was added separately.
            const result = await this.db.query(`WITH eligible AS MATERIALIZED (
        SELECT accepted.ordinal,v.pg_embedding ${match}
      ), scored AS (
        SELECT ordinal, pg_embedding OPERATOR(${namespace}.<=>) $8::${namespace}.vector AS distance FROM eligible
      )
      SELECT ordinal,1-distance AS score FROM scored ORDER BY distance,ordinal LIMIT $9`, [...values, JSON.stringify(query), limit], client);
            return result.rows;
        }
        const result = await this.db.query(`SELECT accepted.ordinal,v.vector ${match}`, values, client);
        const top = [];
        for (const { ordinal, vector } of result.rows) {
            const score = cosineScore(vector, query);
            if (top.length < limit || score >= top[0].score) {
                pushTopK(top, limit, { ordinal, score }, compareScoredCandidate);
            }
        }
        return top.sort(compareScoredCandidate);
    }
    canPushSql(model, configuration, from) {
        if (from)
            return false;
        if (configuration.type === scenarioMetadataType ||
            configuration.type === documentChunkType ||
            processLogTarget(model, configuration.type))
            return false;
        const [rootProp, ...nestedProps] = configuration.property.split('.');
        if (!rootProp || model.object(configuration.type).properties[rootProp]?.derived)
            return false;
        if (nestedProps.some(part => /^0[0-9]+$|^[0-9]{10,}$/.test(part)))
            return false;
        return true;
    }
    buildSqlScope(access, model, configuration) {
        access.read(model, configuration.type);
        const [rootProp, ...nestedProps] = configuration.property.split('.');
        if (!access.canRead(model, configuration.type))
            return null;
        const values = [
            model.projection, access.principal.owner, model.document.id, model.release,
            configuration.name, configuration.type, configuration.binding, configuration.dimensions,
        ];
        const bind = (value) => { values.push(value); return '$' + values.length; };
        const tables = viewTables(this.db, model, access.principal.owner, values, [configuration.type]);
        const rowSql = access.rowSql(model, configuration.type, values, 'o.properties');
        const cellSql = access.cellSql(model, configuration.type, rootProp, values, 'o.properties');
        const propPath = bind([rootProp, ...nestedProps]);
        const propExpr = `(o.properties#>${propPath}::text[])`;
        const extraClauses = [];
        if (configuration.type === documentChunkType) {
            for (const field of ['documentId', 'index', 'startOffset', 'endOffset']) {
                extraClauses.push(access.cellSql(model, documentChunkType, field, values, 'o.properties'));
            }
            extraClauses.push(`jsonb_typeof(o.properties->'documentId')='string'`, `jsonb_typeof(o.properties->'index')='number'`, `jsonb_typeof(o.properties->'startOffset')='number'`, `jsonb_typeof(o.properties->'endOffset')='number'`);
        }
        const fromWhere = `FROM ${this.db.schema}.semantic_vectors v
      JOIN ${tables.objects} o
        ON o.projection=$1 AND o.owner=$2 AND o.type=v.type AND o.id=v.id AND o.revision=v.revision
      WHERE v.ontology=$3 AND v.release=$4 AND v.name=$5 AND v.owner=$2
        AND v.type=$6 AND v.binding=$7 AND v.dimensions=$8
        AND ${rowSql} AND ${cellSql}
        AND jsonb_typeof(${propExpr})='string'
        AND v.text_digest=encode(sha256(convert_to(to_json((${propExpr}#>>'{}'))::text,'UTF8')),'hex')
        ${extraClauses.length ? 'AND ' + extraClauses.join(' AND ') : ''}`;
        return { prefix: tables.prefix, objectsTable: tables.objects, fromWhere, values, bind };
    }
    async search(access, model, raw) {
        const input = semanticSearchSchema.parse(raw), configuration = await this.configuration(access, model, input.name);
        if (input.from && configuration.type !== documentChunkType)
            throw new Conflict('Search from an object requires a document chunk index');
        const query = await this.embed(access, model, configuration, input.text);
        let backend;
        let items;
        if (this.canPushSql(model, configuration, input.from)) {
            const outcome = await this.db.transaction(async (client) => {
                await this.db.query('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ', [], client);
                await access.refresh(client, [model.document.id]);
                await checkScenario(this.db, model, access.principal.owner, client);
                const namespace = await pgvectorNamespace(this.db, client);
                const resolvedBackend = namespace ? 'pgvector' : 'jsonb';
                const scope = this.buildSqlScope(access, model, configuration);
                if (!scope)
                    return { backend: resolvedBackend, items: [] };
                const graph = new Objects(this.db, model, access, client);
                if (namespace) {
                    const queryParam = scope.bind(JSON.stringify(query));
                    const limitParam = scope.bind(input.limit);
                    const result = await this.db.readQuery(`${scope.prefix}SELECT o.type,o.id,o.revision,o.properties,
              1-(v.pg_embedding OPERATOR(${namespace}.<=>) ${queryParam}::${namespace}.vector) AS score
            ${scope.fromWhere}
            ORDER BY v.pg_embedding OPERATOR(${namespace}.<=>) ${queryParam}::${namespace}.vector, o.type COLLATE "C", o.id COLLATE "C"
            LIMIT ${limitParam}`, scope.values, client);
                    const hydrated = await graph.hydrateStoredRows(result.rows);
                    const mapped = hydrated.map((object, index) => {
                        const citation = object.ref.type === documentChunkType ? chunkCitation(object) : undefined;
                        return { object, ...(citation ? { citation } : {}), score: Number(result.rows[index].score) };
                    });
                    return { backend: resolvedBackend, items: mapped };
                }
                const vectorRows = await this.db.readQuery(`${scope.prefix}SELECT v.type,v.id,v.vector ${scope.fromWhere}`, scope.values, client);
                const topHeap = [];
                for (const { type, id, vector } of vectorRows.rows) {
                    const score = cosineScore(vector, query);
                    if (topHeap.length < input.limit || score >= topHeap[0].score) {
                        pushTopK(topHeap, input.limit, { type, id, score }, compareKeyedScore);
                    }
                }
                const top = topHeap.sort(compareKeyedScore);
                if (!top.length)
                    return { backend: resolvedBackend, items: [] };
                const hydrateValues = [
                    model.projection, access.principal.owner,
                    JSON.stringify(top.map((item, ordinal) => ({ type: item.type, id: item.id, ordinal }))),
                ];
                const hydrateTables = viewTables(this.db, model, access.principal.owner, hydrateValues, [configuration.type]);
                const hydratedResult = await this.db.readQuery(`${hydrateTables.prefix}SELECT k.ordinal,o.type,o.id,o.revision,o.properties
          FROM jsonb_to_recordset($3::jsonb) AS k(type text,id text,ordinal integer)
          JOIN ${hydrateTables.objects} o ON o.projection=$1 AND o.owner=$2 AND o.type=k.type AND o.id=k.id
          ORDER BY k.ordinal`, hydrateValues, client);
                const hydrated = await graph.hydrateStoredRows(hydratedResult.rows);
                const mapped = hydrated.map((object, index) => {
                    const citation = object.ref.type === documentChunkType ? chunkCitation(object) : undefined;
                    const ordinal = Number(hydratedResult.rows[index].ordinal);
                    return { object, ...(citation ? { citation } : {}), score: top[ordinal].score };
                });
                return { backend: resolvedBackend, items: mapped };
            });
            backend = outcome.backend;
            items = outcome.items;
        }
        else {
            const outcome = await this.withCandidates(access, model, configuration, async (snapshot) => (await this.rank(snapshot, query, input.limit)).map(({ ordinal, score }) => {
                const { object, citation } = snapshot.candidates[ordinal];
                return { object, ...(citation ? { citation } : {}), score };
            }), input.from);
            backend = outcome.backend;
            items = outcome.value;
        }
        if (!(await access.canReturn(access.dataRequirements())))
            throw new Conflict('Semantic result permissions changed');
        return {
            name: input.name,
            items,
            dimensions: configuration.dimensions,
            binding: configuration.binding,
            modelVersion: configuration.modelVersion,
            search: 'exact_cosine',
            backend,
        };
    }
    async status(access, model, name) {
        const configuration = await this.configuration(access, model, name);
        let backend;
        let currentAuthorizedObjects;
        if (this.canPushSql(model, configuration)) {
            const outcome = await this.db.transaction(async (client) => {
                await this.db.query('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ', [], client);
                await access.refresh(client, [model.document.id]);
                await checkScenario(this.db, model, access.principal.owner, client);
                const namespace = await pgvectorNamespace(this.db, client);
                const resolvedBackend = namespace ? 'pgvector' : 'jsonb';
                const scope = this.buildSqlScope(access, model, configuration);
                if (!scope)
                    return { backend: resolvedBackend, count: 0 };
                const result = await this.db.readQuery(`${scope.prefix}SELECT count(*) AS count ${scope.fromWhere}`, scope.values, client);
                return { backend: resolvedBackend, count: Number(result.rows[0]?.count ?? 0) };
            });
            backend = outcome.backend;
            currentAuthorizedObjects = outcome.count;
        }
        else {
            const outcome = await this.withCandidates(access, model, configuration, async ({ candidates, client, match, values }) => candidates.length
                ? Number((await this.db.query(`SELECT count(*) AS count ${match}`, values, client)).rows[0]?.count ?? 0)
                : 0);
            backend = outcome.backend;
            currentAuthorizedObjects = outcome.value;
        }
        if (!(await access.canReturn(access.dataRequirements())))
            throw new Conflict('Semantic status permissions changed');
        return { ...configuration, currentAuthorizedObjects, search: 'exact_cosine', backend };
    }
}
