import type { Database } from './database.js';
export interface PartitionPlanOptions {
    /** Authoritative table name in db.schema (default: 'objects'). */
    table?: string;
    /** Hash partition key column (default: 'owner'). */
    partitionKey?: string;
    /** Number of hash child partitions (MODULUS N, N >= 1). */
    partitions: number;
    /** Partitioned shadow table name (default: `${table}_shadow`). */
    shadowTable?: string;
    /** Change capture log table name (default: `${table}_part_changes`). */
    changeLogTable?: string;
    /** Reverse change capture log table name installed on cutover (default: `${table}_rev_changes`). */
    reverseChangeLogTable?: string;
    /** Persistent migration state table name (default: `${table}_part_state`). */
    stateTable?: string;
    /** Name given to the original table after cutover for rollback retention (default: `${table}_legacy`). */
    legacyTable?: string;
}
export interface ResolvedPartitionPlan {
    schemaName: string;
    schemaSql: string;
    table: string;
    partitionKey: string;
    partitions: number;
    shadowTable: string;
    changeLogTable: string;
    reverseChangeLogTable: string;
    stateTable: string;
    legacyTable: string;
    captureFunction: string;
    captureTrigger: string;
    reverseCaptureFunction: string;
    reverseCaptureTrigger: string;
}
export declare function resolvePartitionPlan(db: Database, options: PartitionPlanOptions): ResolvedPartitionPlan;
export interface ForeignKeyInventory {
    constraintName: string;
    referencingSchema: string;
    referencingTable: string;
    definition: string;
}
export interface TriggerInventory {
    name: string;
    definition: string;
    functionOid: number;
    functionSchema: string;
}
export interface CreateShadowPartitionsResult {
    table: string;
    shadowTable: string;
    partitionKey: string;
    partitions: string[];
    primaryKeyColumns: string[];
    copiedConstraints: string[];
    copiedIndexes: string[];
    copiedPolicies: string[];
    incomingForeignKeys: ForeignKeyInventory[];
    userTriggers: TriggerInventory[];
}
/**
 * Creates a HASH-partitioned shadow table by `partitionKey` (default `owner`) with N child partitions,
 * copies columns, defaults, constraints, indexes, RLS policies and grants, and validates that every
 * unique constraint/index contains the partition key (docs/scaling.md 09.1 step 1).
 */
export declare function createShadowHashPartitions(db: Database, options: PartitionPlanOptions): Promise<CreateShadowPartitionsResult>;
export interface InstallChangeCaptureResult {
    table: string;
    changeLogTable: string;
    triggerName: string;
    functionName: string;
    primaryKeyColumns: string[];
}
/**
 * Installs same-transaction change capture (INSERT, UPDATE, DELETE, and primary-key moves)
 * on the authoritative table before historical chunked backfill begins (docs/scaling.md 09.1 step 2).
 */
export declare function installChangeCapture(db: Database, options: PartitionPlanOptions): Promise<InstallChangeCaptureResult>;
export interface BackfillChunkOptions extends PartitionPlanOptions {
    /** Rows to scan and copy per chunk (default 1000). */
    chunkSize?: number;
    /** Optional exported PostgreSQL consistent snapshot ID (`pg_export_snapshot()`). */
    snapshotId?: string;
}
export interface BackfillChunkResult {
    scanned: number;
    copied: number;
    totalCopied: number;
    done: boolean;
    cursor: Record<string, unknown> | null;
}
/**
 * Opens a `REPEATABLE READ READ ONLY` transaction, exports its PostgreSQL consistent snapshot ID,
 * and passes it to `run` so multiple `backfillChunk` calls can read from one exact consistent snapshot.
 */
export declare function withConsistentSnapshot<T>(db: Database, run: (snapshotId: string) => Promise<T>): Promise<T>;
/**
 * Copies one primary-key-ordered chunk of historical rows from the authoritative table into the
 * partitioned shadow table and persists the PK cursor atomically (docs/scaling.md 09.1 step 2).
 */
export declare function backfillChunk(db: Database, options: BackfillChunkOptions): Promise<BackfillChunkResult>;
export interface ReplayChangesOptions extends PartitionPlanOptions {
    /** Maximum change-log rows consumed in one transaction (default 500). */
    batchSize?: number;
    /** Permit replaying before backfill finishes (default false per docs/scaling.md 09.1 step 3). */
    allowBeforeBackfillDone?: boolean;
}
export interface ReplayChangesResult {
    processedEvents: number;
    distinctKeys: number;
    upserted: number;
    deleted: number;
    replayCursor: number;
    remaining: number;
}
/**
 * Deduplicates captured change keys, re-reads latest values from the authoritative table
 * (deleting removed keys from the shadow table), and persists the replay cursor in the same
 * transaction (docs/scaling.md 09.1 step 3).
 */
export declare function replayChanges(db: Database, options: ReplayChangesOptions): Promise<ReplayChangesResult>;
export interface ReconcileShadowOptions extends PartitionPlanOptions {
    /** Grouping columns for chunked reconciliation (defaults to ['owner', 'projection'] when present, else [partitionKey]). */
    groupByColumns?: readonly string[];
    /** Number of group slices reconciled per SQL batch (default 100). */
    sliceChunkSize?: number;
    /** Maximum sample mismatch keys returned per category (default 20). */
    maxSampleMismatches?: number;
    /** Compare arbitrary pair (default: plan.table vs plan.shadowTable). */
    sourceTable?: string;
    targetTable?: string;
}
export interface ReconcileSliceReport {
    group: Record<string, unknown>;
    sourceCount: number;
    shadowCount: number;
    sourceFingerprint: string;
    shadowFingerprint: string;
    missingInShadow: number;
    extraInShadow: number;
    contentMismatches: number;
    matched: boolean;
}
export interface ReconcileShadowResult {
    matched: boolean;
    groupByColumns: string[];
    totalSlices: number;
    mismatchedSlices: number;
    sourceRows: number;
    shadowRows: number;
    missingInShadowTotal: number;
    extraInShadowTotal: number;
    contentMismatchTotal: number;
    slices: ReconcileSliceReport[];
    sampleMissingInShadow: Record<string, unknown>[];
    sampleExtraInShadow: Record<string, unknown>[];
    sampleContentMismatch: Record<string, unknown>[];
}
/**
 * Reconciles authoritative and shadow tables chunk-by-chunk across `(owner, projection)` slices
 * in a single repeatable-read snapshot: row counts, SHA-256 content fingerprints, forward diff,
 * reverse diff (extra rows in shadow), and content mismatches (docs/scaling.md 09.1 step 4).
 */
export declare function reconcileShadow(db: Database, options: ReconcileShadowOptions): Promise<ReconcileShadowResult>;
export interface CutoverShadowOptions extends PartitionPlanOptions {
    /** Bounded lock timeout in milliseconds for the table-swap window (default 1000ms). */
    lockTimeoutMs?: number;
    /** Statement timeout inside the cutover window (default 15000ms). */
    statementTimeoutMs?: number;
    /** Install reverse change-capture trigger on the newly active partitioned table for rollback (default true). */
    installReverseCapture?: boolean;
    /** Batch size while draining remaining incremental changes under lock (default 1000). */
    drainBatchSize?: number;
}
export interface CutoverShadowResult {
    status: 'cutover' | 'lock_timeout';
    table: string;
    legacyTable: string;
    drainedEvents: number;
    reboundForeignKeys: string[];
    migratedTriggers: string[];
    reverseCaptureInstalled: boolean;
    errorCode?: string;
}
/**
 * Performs a bounded-lock cutover: sets `SET LOCAL lock_timeout`, acquires exclusive locks, drains all
 * remaining change-log events, swaps table names (`table -> legacyTable`, `shadowTable -> table`),
 * rebinds OID-pinned incoming foreign keys and user triggers, and installs reverse change capture so
 * the legacy table can be synced and restored safely if rollback is needed (docs/scaling.md 09.1 steps 5-6).
 *
 * On lock contention (`55P03`), aborts cleanly and rolls back without affecting the live table.
 */
export declare function cutoverShadow(db: Database, options: CutoverShadowOptions): Promise<CutoverShadowResult>;
/**
 * Replays post-cutover writes (INSERT, UPDATE, DELETE, PK moves) from the active partitioned table
 * back into the retained legacy table so rollback preserves every write made after cutover.
 */
export declare function syncReverseChanges(db: Database, options: PartitionPlanOptions & {
    batchSize?: number;
}): Promise<ReplayChangesResult>;
export interface RollbackCutoverResult {
    status: 'rolled_back' | 'lock_timeout';
    table: string;
    shadowTable: string;
    drainedReverseEvents: number;
    reboundForeignKeys: string[];
    migratedTriggers: string[];
    errorCode?: string;
}
/**
 * Drains reverse changes back into the legacy table under a bounded `lock_timeout` and swaps
 * the legacy table back into place as the authoritative table (docs/scaling.md 09.1 step 6).
 */
export declare function rollbackCutover(db: Database, options: CutoverShadowOptions): Promise<RollbackCutoverResult>;
