import { z } from 'zod';
import { type ObjectRef } from '../ontology/schema.js';
import type { Access } from './access.js';
import type { Actions } from './actions.js';
import type { Database, Sql } from './database.js';
import type { Functions } from './functions.js';
import { PublishedOntology } from './metadata.js';
declare const objectVersion: z.ZodObject<{
    object: z.ZodObject<{
        type: z.ZodString;
        id: z.ZodString;
    }, z.core.$strict>;
    revision: z.ZodNumber;
}, z.core.$strict>;
declare const scalar: z.ZodUnion<readonly [z.ZodNumber, z.ZodBoolean, z.ZodString, z.ZodNull]>;
export declare const compareScenariosSchema: z.ZodObject<{
    scenarios: z.ZodArray<z.ZodObject<{
        id: z.ZodUUID;
        revision: z.ZodNumber;
    }, z.core.$strict>>;
    aggregates: z.ZodDefault<z.ZodArray<z.ZodObject<{
        set: z.ZodPipe<z.ZodUnknown, z.ZodType<import("./object-sets.js").SetExpression, unknown, z.core.$ZodTypeInternals<import("./object-sets.js").SetExpression, unknown>>>;
        view: z.ZodOptional<z.ZodString>;
        groupBy: z.ZodDefault<z.ZodArray<z.ZodString>>;
        metrics: z.ZodRecord<z.ZodString, z.ZodDiscriminatedUnion<[z.ZodObject<{
            op: z.ZodLiteral<"count">;
            property: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            op: z.ZodEnum<{
                avg: "avg";
                max: "max";
                min: "min";
                sum: "sum";
            }>;
            property: z.ZodString;
        }, z.core.$strict>], "op">>;
    }, z.core.$strict>>>;
    metrics: z.ZodDefault<z.ZodArray<z.ZodObject<{
        function: z.ZodString;
        path: z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
        name: z.ZodString;
        input: z.ZodRecord<z.ZodString, z.ZodUnknown>;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export declare const trialScenariosSchema: z.ZodObject<{
    cases: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        inputs: z.ZodRecord<z.ZodString, z.ZodUnknown>;
        evaluatedAt: z.ZodOptional<z.ZodISODateTime>;
        evidence: z.ZodArray<z.ZodObject<{
            object: z.ZodObject<{
                type: z.ZodString;
                id: z.ZodString;
            }, z.core.$strict>;
            revision: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    variants: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        steps: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"action">;
            name: z.ZodString;
            action: z.ZodString;
            input: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                value: z.ZodUnknown;
            }, z.core.$strict>, z.ZodObject<{
                input: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                result: z.ZodString;
            }, z.core.$strict>]>>;
        }, z.core.$strict>, z.ZodObject<{
            function: z.ZodString;
            path: z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
            kind: z.ZodLiteral<"check">;
            name: z.ZodString;
            input: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                value: z.ZodUnknown;
            }, z.core.$strict>, z.ZodObject<{
                input: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                result: z.ZodString;
            }, z.core.$strict>]>>;
            equals: z.ZodUnion<readonly [z.ZodNumber, z.ZodBoolean, z.ZodString, z.ZodNull]>;
        }, z.core.$strict>], "kind">>;
    }, z.core.$strict>>;
    metrics: z.ZodArray<z.ZodObject<{
        function: z.ZodString;
        path: z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
        name: z.ZodString;
        input: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
            value: z.ZodUnknown;
        }, z.core.$strict>, z.ZodObject<{
            input: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            result: z.ZodString;
        }, z.core.$strict>]>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const saveEvaluationSuiteSchema: z.ZodObject<{
    id: z.ZodOptional<z.ZodUUID>;
    revision: z.ZodOptional<z.ZodNumber>;
    requestId: z.ZodString;
    name: z.ZodString;
    trial: z.ZodObject<{
        cases: z.ZodArray<z.ZodObject<{
            name: z.ZodString;
            inputs: z.ZodRecord<z.ZodString, z.ZodUnknown>;
            evaluatedAt: z.ZodOptional<z.ZodISODateTime>;
            evidence: z.ZodArray<z.ZodObject<{
                object: z.ZodObject<{
                    type: z.ZodString;
                    id: z.ZodString;
                }, z.core.$strict>;
                revision: z.ZodNumber;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        variants: z.ZodArray<z.ZodObject<{
            name: z.ZodString;
            steps: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"action">;
                name: z.ZodString;
                action: z.ZodString;
                input: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                    value: z.ZodUnknown;
                }, z.core.$strict>, z.ZodObject<{
                    input: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    result: z.ZodString;
                }, z.core.$strict>]>>;
            }, z.core.$strict>, z.ZodObject<{
                function: z.ZodString;
                path: z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
                kind: z.ZodLiteral<"check">;
                name: z.ZodString;
                input: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                    value: z.ZodUnknown;
                }, z.core.$strict>, z.ZodObject<{
                    input: z.ZodString;
                }, z.core.$strict>, z.ZodObject<{
                    result: z.ZodString;
                }, z.core.$strict>]>>;
                equals: z.ZodUnion<readonly [z.ZodNumber, z.ZodBoolean, z.ZodString, z.ZodNull]>;
            }, z.core.$strict>], "kind">>;
        }, z.core.$strict>>;
        metrics: z.ZodArray<z.ZodObject<{
            function: z.ZodString;
            path: z.ZodArray<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
            name: z.ZodString;
            input: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                value: z.ZodUnknown;
            }, z.core.$strict>, z.ZodObject<{
                input: z.ZodString;
            }, z.core.$strict>, z.ZodObject<{
                result: z.ZodString;
            }, z.core.$strict>]>>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    machinerySet: z.ZodOptional<z.ZodUUID>;
}, z.core.$strict>;
export declare const runEvaluationSuiteSchema: z.ZodObject<{
    id: z.ZodUUID;
    revision: z.ZodNumber;
}, z.core.$strict>;
export declare const evaluationCasesFromSetSchema: z.ZodObject<{
    set: z.ZodUUID;
    parameter: z.ZodString;
    limit: z.ZodDefault<z.ZodNumber>;
}, z.core.$strict>;
export declare const promoteEvaluationSchema: z.ZodObject<{
    run: z.ZodUUID;
    case: z.ZodString;
    variant: z.ZodString;
    requestId: z.ZodString;
    reviewers: z.ZodArray<z.ZodString>;
}, z.core.$strict>;
export declare function initializeScenarioEvaluations(db: Database): Promise<void>;
type CompareInput = z.output<typeof compareScenariosSchema>;
type TrialInput = z.output<typeof trialScenariosSchema>;
type EvaluationStep = {
    name: string;
    operation: string;
    status: 'completed' | 'rejected';
    value?: z.output<typeof scalar> | ObjectRef;
};
export declare class ScenarioEvaluations {
    private readonly db;
    private readonly actions;
    private readonly functions;
    private readonly scenarios;
    private readonly sets;
    constructor(db: Database, actions: Actions, functions: Functions);
    options(access: Access, model: PublishedOntology): {
        actions: string[];
        functions: string[];
    };
    private snapshot;
    /**
     * Runs an offline trial inside a REPEATABLE READ snapshot without holding the exclusive owner write lock
     * (`lockEdits`). Every variant executes inside a SAVEPOINT that is always rolled back, so concurrent live
     * owner writes proceed unblocked while the trial observes a consistent point-in-time snapshot.
     */
    private trialSnapshot;
    private requireMetric;
    private scalar;
    compare(access: Access, model: PublishedOntology, input: CompareInput): Promise<{
        release: string;
        evaluatedAt: string;
        baseline: {
            metrics: {
                [k: string]: string | number | boolean | null;
            };
            aggregates: {
                count: number;
                items: {
                    group: Record<string, unknown>;
                    metrics: Record<string, number | null>;
                }[] | {
                    group: {};
                    metrics: {
                        [k: string]: number | null;
                    };
                }[];
            }[];
        };
        scenarios: {
            metrics: {
                [k: string]: string | number | boolean | null;
            };
            aggregates: {
                count: number;
                items: {
                    group: Record<string, unknown>;
                    metrics: Record<string, number | null>;
                }[] | {
                    group: {};
                    metrics: {
                        [k: string]: number | null;
                    };
                }[];
            }[];
            id: string;
            name: string;
            revision: number;
            changes: {
                objectsCreated: number;
                objectsEdited: number;
                objectsDeleted: number;
                linksAdded: number;
                linksRemoved: number;
                conflicts: boolean;
            };
            preview: {
                objects: {
                    ref: {
                        type: string;
                        id: string;
                    };
                    before: Record<string, unknown> | null;
                    after: Record<string, unknown> | null;
                    editedFields: string[];
                    conflict: boolean;
                }[];
                links: {
                    type: string;
                    from: {
                        type: string;
                        id: string;
                    };
                    to: {
                        type: string;
                        id: string;
                    };
                    removed: boolean;
                    conflict: boolean;
                }[];
            };
        }[];
    }>;
    trial(access: Access, model: PublishedOntology, input: TrialInput, candidateBase?: string): Promise<{
        cases: {
            variants: ({
                name: string;
                status: 'completed';
                steps: EvaluationStep[];
                metrics: {
                    [k: string]: string | number | boolean | null;
                };
                changes: {
                    objectsCreated: number;
                    objectsEdited: number;
                    objectsDeleted: number;
                    linksAdded: number;
                    linksRemoved: number;
                    conflicts: boolean;
                };
            } | {
                name: string;
                status: 'rejected';
                reason: string;
                steps: EvaluationStep[];
            })[];
            name: string;
            evidence: z.output<typeof objectVersion>[];
            evaluatedAt: string;
            inputDigest: string;
        }[];
        mode: 'offline';
        release: string;
        evaluatedAt: string;
        experimentDigest: string;
        summary: {
            name: string;
            completed: number;
            rejected: number;
            attemptedSteps: number;
        }[];
    }>;
    private publicTrial;
    private trialReport;
    saveSuite(access: Access, model: PublishedOntology, raw: unknown): Promise<{
        id: any;
        revision: number;
    }>;
    casesFromSet(access: Access, model: PublishedOntology, raw: unknown): Promise<{
        cases: {
            name: string;
            inputs: {
                [x: string]: {
                    type: string;
                    id: string;
                };
            };
            evidence: {
                object: {
                    type: string;
                    id: string;
                };
                revision: number;
            }[];
        }[];
        total: number;
    }>;
    private requireCaseSet;
    listSuites(access: Access, model: PublishedOntology): Promise<{
        suites: import("pg").QueryResultRow[];
        runs: import("pg").QueryResultRow[];
    }>;
    private loadSuite;
    private outcome;
    runSuite(access: Access, model: PublishedOntology, raw: unknown, receiptClient?: Sql): Promise<{
        cases: {
            variants: ({
                name: string;
                status: 'completed';
                steps: EvaluationStep[];
                metrics: {
                    [k: string]: string | number | boolean | null;
                };
                changes: {
                    objectsCreated: number;
                    objectsEdited: number;
                    objectsDeleted: number;
                    linksAdded: number;
                    linksRemoved: number;
                    conflicts: boolean;
                };
            } | {
                name: string;
                status: 'rejected';
                reason: string;
                steps: EvaluationStep[];
            })[];
            name: string;
            evidence: z.output<typeof objectVersion>[];
            evaluatedAt: string;
            inputDigest: string;
        }[];
        mode: 'offline';
        release: string;
        evaluatedAt: string;
        experimentDigest: string;
        summary: {
            name: string;
            completed: number;
            rejected: number;
            attemptedSteps: number;
        }[];
        run: `${string}-${string}-${string}-${string}-${string}`;
        suite: string;
        suiteRevision: number;
    }>;
    promote(access: Access, model: PublishedOntology, raw: unknown): Promise<{
        id: string;
        revision: number;
        run: string;
        reviewers?: undefined;
    } | {
        id: string;
        revision: number;
        run: string;
        reviewers: string[];
    }>;
    private runVariant;
}
export type ScenarioComparisonInput = z.input<typeof compareScenariosSchema>;
export type ScenarioComparison = Awaited<ReturnType<ScenarioEvaluations['compare']>>;
export type ScenarioTrialInput = z.input<typeof trialScenariosSchema>;
export type ScenarioTrial = Awaited<ReturnType<ScenarioEvaluations['trial']>>;
export {};
