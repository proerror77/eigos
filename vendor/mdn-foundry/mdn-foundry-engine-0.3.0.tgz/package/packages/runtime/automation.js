import { checkWorkflowDependencies } from './workflow-compatibility.js';
import { randomUUID } from 'node:crypto';
import { withOperationTiming } from '../core/operation-timing.js';
import { profileDatabase, profileSummary } from '../core/database-profile.js';
import { z } from 'zod';
import { Conflict, InvalidInput, NotFound, digest, requireScope } from '../core/identity.js';
import { validator } from '../ontology/model.js';
import { ontologyName, objectRefSchema } from '../ontology/schema.js';
import { Access, PermissionDenied } from './access.js';
import { Objects, querySchema } from './objects.js';
import { matchingTransition, processRelatedPath, relatedProcessObjects, processRuleSchema, processStatusSchema, processTarget, processTriggerSchema, readProcessStatus } from './process-automation.js';
import { processLogTarget } from '../ontology/process-definition.js';
import { documentChunkType } from '../ontology/documents.js';
import { withoutExternalDispatch } from './external-operations.js';
import { processStart, readCommittedTransitions, readProcessTransitions } from './process-logs.js';
import { notifySchema, queueNotification } from './process-notifications.js';
import { changedObjects, footprintChanged, latestCommit, queryFootprint } from './change-feed.js';
import { authorizeCognitive, cognitiveContextSchema, cognitiveResultSchema, cognitiveStepSchema, workflowMerge } from './cognitive-workflow.js';
import { lockEdits } from './scenario-store.js';
import { Scenarios } from './scenarios.js';
import { appendTrace } from './execution-trace.js';
import { insertWorkflowRecord, readWorkflowRecord } from './workflow-records.js';
import { errorDiagnostic, isTransientError, retryBackoffSeconds } from './effects.js';
const MAX_TRIGGER_DEPTH = 8;
const RULE_FAILURE_THRESHOLD = 5;
const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const storedPrincipalSchema = z.object({ scopes: z.array(z.string()), memberAccess: z.literal(true).optional() });
const encodePrincipalScopes = (principal) => JSON.stringify(principal.memberAccess ? { scopes: principal.scopes, memberAccess: true } : principal.scopes);
const decodePrincipal = (owner, raw) => {
    const identity = storedPrincipalSchema.parse(Array.isArray(raw) ? { scopes: raw } : raw);
    return { owner, ...identity };
};
const binding = z.union([
    z.strictObject({ literal: z.unknown() }),
    z.strictObject({ property: z.string().min(1).max(500) }),
    z.strictObject({ object: z.literal(true) }),
    z.strictObject({ step: z.string().min(1).max(80) }),
]);
const relatedEffect = z.strictObject({
    path: processRelatedPath,
    sourceParameter: ontologyName,
    transitionParameter: ontologyName,
    targetParameter: ontologyName,
});
const singleAction = z.strictObject({
    action: ontologyName,
    input: z.record(z.string(), binding.refine(value => !('step' in value), 'A direct Action has no previous step')),
    related: relatedEffect.optional(),
});
const step = z.strictObject({
    name: z.string().min(1).max(80),
    action: z.string().min(1).max(80),
    input: z.record(z.string(), binding),
});
export const workflowSchema = z.strictObject({
    id: z.uuid().optional(),
    revision: z.number().int().min(0).default(0),
    name: z.string().min(1).max(200),
    description: z.string().max(2000).default(''),
    steps: z.array(step).max(20),
    proposal: cognitiveStepSchema.optional(),
}).superRefine((workflow, context) => {
    if (!workflow.steps.length && !workflow.proposal)
        context.addIssue({ code: 'custom', message: 'Workflow requires at least one step', path: ['steps'] });
    const previous = new Set();
    workflow.steps.forEach((item, index) => {
        if (previous.has(item.name)) {
            context.addIssue({ code: 'custom', message: 'Workflow step names must be unique', path: ['steps', index, 'name'] });
        }
        for (const [parameter, binding] of Object.entries(item.input)) {
            if ('step' in binding && !previous.has(binding.step)) {
                context.addIssue({
                    code: 'custom', message: 'Step bindings must reference a prior named step',
                    path: ['steps', index, 'input', parameter],
                });
            }
        }
        previous.add(item.name);
    });
});
const baseRule = z.strictObject({
    id: z.uuid().optional(),
    revision: z.number().int().min(0).default(0),
    name: z.string().min(1).max(200),
    workflow: z.uuid(),
    enabled: z.boolean().default(false),
});
const ruleQuerySchema = querySchema.omit({ cursor: true, limit: true, select: true });
/** Object-set rules become due this often, field-change rules every five seconds; a scan without a relevant change reads only the commit journal. */
const objectRuleSeconds = 30;
/** An object-set rule re-reads its whole set at least this often, besides the changes it consumes. */
const reconcileSeconds = 600;
const onModified = z.strictObject({
    watch: z.array(z.strictObject({
        path: z.array(ontologyName).max(3).default([]),
        properties: z.array(ontologyName).min(1).max(12),
    })).min(1).max(12),
    includeAdded: z.boolean().default(false),
});
const objectRule = baseRule.extend({ query: ruleQuerySchema, onModified: onModified.optional(), onRemoved: z.boolean().optional() });
const processRule = z.union([
    baseRule.extend({ process: processRuleSchema }),
    baseRule.omit({ workflow: true }).extend({ process: processRuleSchema, effect: singleAction, replayFrom: z.string().regex(/^\d{1,19}$/).optional() }),
    // A notification to the rule's owner, instead of a workflow or an Action.
    baseRule.omit({ workflow: true }).extend({ process: processRuleSchema, notify: notifySchema }),
]);
const ruleSchema = z.union([objectRule, processRule]);
export const saveRuleSchema = baseRule.extend({
    workflow: z.uuid().optional(), effect: singleAction.optional(), notify: notifySchema.optional(),
    query: ruleQuerySchema.optional(), onModified: onModified.optional(), onRemoved: z.boolean().optional(), replayFrom: z.string().regex(/^\d{1,19}$/).optional(),
    process: processRuleSchema.optional(),
}).refine(rule => Boolean(rule.query) !== Boolean(rule.process), 'Select one object query or process transition condition')
    .refine(rule => !rule.notify || !rule.workflow && !rule.effect && !!rule.process, 'A notification rule needs a process condition, without a workflow or an Action')
    .refine(rule => !!rule.notify || Boolean(rule.workflow) !== Boolean(rule.effect) && (!rule.effect || !!rule.process), 'Select a saved workflow or a single Action for a process trigger')
    .refine(rule => rule.replayFrom === undefined || !!rule.effect?.related, 'Replay requires a related-object Action')
    .refine(rule => rule.onModified === undefined || !!rule.query, 'Field changes require an object-set rule')
    .refine(rule => rule.onRemoved === undefined || !!rule.query, 'Object removal triggers require an object-set rule');
export const processBindingsSchema = z.strictObject({
    type: ontologyName, cursor: z.uuid().optional(),
});
export const runWorkflowSchema = z.strictObject({
    workflow: z.uuid(),
    object: objectRefSchema,
    requestId: z.string().min(1).max(128),
});
export const publishWorkflowSchema = z.strictObject({
    id: z.uuid(), revision: z.number().int().positive(), targetType: ontologyName,
});
export const withdrawWorkflowSchema = z.strictObject({ id: z.uuid(), revision: z.number().int().positive() });
export const runPublishedWorkflowSchema = runWorkflowSchema.extend({ revision: z.number().int().positive() });
export const automationPreviewSchema = z.strictObject({
    rule: z.uuid(), revision: z.number().int().positive(),
    scenarios: z.array(z.strictObject({ id: z.uuid(), revision: z.number().int().positive() })).min(1).max(6),
    elapsedSeconds: z.number().int().min(0).max(31 * 86400).default(0),
}).refine(input => new Set(input.scenarios.map(item => item.id)).size === input.scenarios.length, 'Select distinct Scenarios');
function bindWorkflowInput(item, object, previousResults) {
    return Object.fromEntries(Object.entries(item.input).map(([key, binding]) => {
        if ('literal' in binding)
            return [key, binding.literal];
        if ('object' in binding)
            return [key, object.ref];
        if ('step' in binding)
            return [key, previousResults.get(binding.step)];
        if (binding.property === '$revision')
            return [key, object.revision];
        let value = object.properties;
        for (const field of binding.property.split('.'))
            value = value && typeof value === 'object' && Object.hasOwn(value, field) ? Reflect.get(value, field) : undefined;
        return [key, value];
    }));
}
function validateFieldWatch(graph, type, watches) {
    for (const watch of watches ?? []) {
        const target = watch.path.reduce((current, link) => {
            const navigation = graph.model.navigation(current, link);
            graph.access.definition(graph.model, 'link', navigation.link);
            graph.access.read(graph.model, navigation.target);
            return navigation.target;
        }, type);
        const properties = graph.model.object(target).properties;
        if (watch.properties.some(field => !properties[field] || properties[field].derived))
            throw new Conflict('Watch stored ontology properties on the selected relationship path');
        if (watch.properties.some(field => !graph.access.property(graph.model, target, field)))
            throw new PermissionDenied('A watched field is unavailable');
    }
}
async function fieldWatchDigest(graph, root, watches) {
    const snapshots = [];
    for (const watch of watches) {
        const entries = [];
        const targets = watch.path.length ? await relatedProcessObjects(graph, root.ref, watch.path) : [root.ref];
        for (const target of targets) {
            const item = watch.path.length ? await graph.read(target) : root;
            const values = [];
            for (const field of watch.properties) {
                if (!await graph.propertyVisible(item.ref, field))
                    throw new PermissionDenied('A watched field is unavailable');
                values.push(Object.hasOwn(item.properties, field) ? { value: item.properties[field] } : {});
            }
            entries.push({ ref: item.ref, values });
        }
        snapshots.push(entries.sort((a, b) => digest(a.ref).localeCompare(digest(b.ref))));
    }
    return digest(snapshots);
}
export async function initializeAutomation(db) {
    await db.query(`CREATE TABLE IF NOT EXISTS ${db.schema}.workflows(id uuid PRIMARY KEY,owner text NOT NULL,ontology text NOT NULL,name text NOT NULL,body jsonb NOT NULL,revision integer NOT NULL);
    ALTER TABLE ${db.schema}.workflows ADD COLUMN IF NOT EXISTS published_body jsonb,
      ADD COLUMN IF NOT EXISTS published_revision integer,
      ADD COLUMN IF NOT EXISTS published_release text,
      ADD COLUMN IF NOT EXISTS published_target text;
    CREATE TABLE IF NOT EXISTS ${db.schema}.object_rules(id uuid PRIMARY KEY,owner text NOT NULL,ontology text NOT NULL,name text NOT NULL,body jsonb NOT NULL,revision integer NOT NULL,enabled boolean NOT NULL DEFAULT false,last_scan timestamptz,error text);
    ALTER TABLE ${db.schema}.object_rules ADD COLUMN IF NOT EXISTS scopes jsonb;
    ALTER TABLE ${db.schema}.object_rules ADD COLUMN IF NOT EXISTS process_cursor bigint;
    -- A process rule's position is (process_commit, process_cursor); commit 0 is history from before the commit journal.
    ALTER TABLE ${db.schema}.object_rules ADD COLUMN IF NOT EXISTS process_commit bigint NOT NULL DEFAULT 0;
    ALTER TABLE ${db.schema}.object_rules ADD COLUMN IF NOT EXISTS effect_release text REFERENCES ${db.schema}.releases(digest);
    -- An object-set rule's position: the last commit it consumed (NULL until its first full evaluation), and the
    -- publication, visibility and time of its last full evaluation.
    ALTER TABLE ${db.schema}.object_rules ADD COLUMN IF NOT EXISTS match_commit bigint;
    ALTER TABLE ${db.schema}.object_rules ADD COLUMN IF NOT EXISTS match_release text;
    ALTER TABLE ${db.schema}.object_rules ADD COLUMN IF NOT EXISTS match_visibility text;
    ALTER TABLE ${db.schema}.object_rules ADD COLUMN IF NOT EXISTS match_reconciled_at timestamptz;
    ALTER TABLE ${db.schema}.object_rules ADD COLUMN IF NOT EXISTS consecutive_failures integer NOT NULL DEFAULT 0;
    UPDATE ${db.schema}.object_rules SET enabled=false,error='Re-save the rule to record its original authorization scopes' WHERE scopes IS NULL AND enabled;
    CREATE TABLE IF NOT EXISTS ${db.schema}.rule_matches(rule_id uuid NOT NULL REFERENCES ${db.schema}.object_rules(id),type text NOT NULL,id text NOT NULL,matched boolean NOT NULL,revision bigint NOT NULL,PRIMARY KEY(rule_id,type,id));
    ALTER TABLE ${db.schema}.rule_matches ADD COLUMN IF NOT EXISTS generation bigint NOT NULL DEFAULT 0;
    ALTER TABLE ${db.schema}.rule_matches ADD COLUMN IF NOT EXISTS observed_digest text;
    CREATE TABLE IF NOT EXISTS ${db.schema}.workflow_runs(id uuid PRIMARY KEY,owner text NOT NULL,ontology text NOT NULL,release text NOT NULL REFERENCES ${db.schema}.releases(digest),request_id text NOT NULL,digest text NOT NULL,workflow_id uuid NOT NULL REFERENCES ${db.schema}.workflows(id),body jsonb NOT NULL,object_ref jsonb NOT NULL,scopes jsonb NOT NULL,step integer NOT NULL DEFAULT 0,state text NOT NULL DEFAULT 'pending',error text,token uuid,lease_until timestamptz,results jsonb NOT NULL DEFAULT '[]',created_at timestamptz NOT NULL DEFAULT now(),updated_at timestamptz NOT NULL DEFAULT now(),UNIQUE(owner,request_id));
    ALTER TABLE ${db.schema}.workflow_runs ALTER COLUMN workflow_id DROP NOT NULL;
    ALTER TABLE ${db.schema}.workflow_runs ADD COLUMN IF NOT EXISTS available_at timestamptz NOT NULL DEFAULT now();
    ALTER TABLE ${db.schema}.workflow_runs ADD COLUMN IF NOT EXISTS process_trigger jsonb;
    ALTER TABLE ${db.schema}.workflow_runs ADD COLUMN IF NOT EXISTS proposal_task uuid;
    ALTER TABLE ${db.schema}.workflow_runs ADD COLUMN IF NOT EXISTS proposal_scenario uuid;
    ALTER TABLE ${db.schema}.workflow_runs ADD COLUMN IF NOT EXISTS proposal_deadline timestamptz;
    ALTER TABLE ${db.schema}.workflow_runs ADD COLUMN IF NOT EXISTS attempts integer NOT NULL DEFAULT 0;
    ALTER TABLE ${db.schema}.workflow_runs ADD COLUMN IF NOT EXISTS max_attempts integer NOT NULL DEFAULT 3;
    ALTER TABLE ${db.schema}.workflow_runs ADD COLUMN IF NOT EXISTS trigger_depth integer NOT NULL DEFAULT 0;
    ALTER TABLE ${db.schema}.tasks ADD COLUMN IF NOT EXISTS cognitive_context jsonb;
    ALTER TABLE ${db.schema}.tasks ADD COLUMN IF NOT EXISTS cognitive_evidence jsonb;
    ALTER TABLE ${db.schema}.tasks ADD COLUMN IF NOT EXISTS cognitive_tool_calls integer NOT NULL DEFAULT 0;
    ALTER TABLE ${db.schema}.tasks ADD COLUMN IF NOT EXISTS attempts integer NOT NULL DEFAULT 0;
    ALTER TABLE ${db.schema}.tasks ADD COLUMN IF NOT EXISTS max_attempts integer NOT NULL DEFAULT 3;
    CREATE TABLE IF NOT EXISTS ${db.schema}.workflow_steps(run_id uuid NOT NULL REFERENCES ${db.schema}.workflow_runs(id),position integer NOT NULL,
      action text NOT NULL,input jsonb NOT NULL,requirements jsonb NOT NULL,request_id text NOT NULL,result jsonb,completed_at timestamptz,
      PRIMARY KEY(run_id,position));
    ALTER TABLE ${db.schema}.workflow_steps ADD COLUMN IF NOT EXISTS read_markings jsonb;
    CREATE INDEX IF NOT EXISTS workflow_runs_queue ON ${db.schema}.workflow_runs(state,created_at);
    CREATE INDEX IF NOT EXISTS workflow_runs_owner_fairness ON ${db.schema}.workflow_runs(owner,updated_at DESC) WHERE attempts>0;
    CREATE INDEX IF NOT EXISTS workflow_runs_process_rule ON ${db.schema}.workflow_runs
      (owner,ontology,(process_trigger->>'ruleId'),(process_trigger->>'revision'),created_at DESC,id DESC)
      WHERE process_trigger IS NOT NULL;
    CREATE INDEX IF NOT EXISTS workflow_runs_due ON ${db.schema}.workflow_runs(available_at) WHERE state='pending';`);
}
const failureMessage = 'Workflow execution failed; check current permissions, publication and Action input before retrying';
class MissingFrozenSecurityContext extends Conflict {
}
class ProcessTriggerInactive extends Conflict {
}
const missingSecurityContextMessage = 'Frozen input security context is unavailable; submit a new workflow run';
const revisionMatches = (id, revision) => {
    if (id ? revision < 1 : revision !== 0)
        throw new Conflict('Updates require the current revision; creates use revision zero');
};
export class Automation {
    db;
    metadata;
    actions;
    constructor(db, metadata, actions) {
        this.db = db;
        this.metadata = metadata;
        this.actions = actions;
    }
    authorize(access, model, steps) {
        for (const item of steps) {
            model.action(item.action);
            access.action(model, item.action);
        }
    }
    async active(model, client) {
        if (model.scenario ||
            (await this.metadata.active(model.document.id, client, true)).release !== model.release)
            throw new Conflict('Automation requires the current live publication');
    }
    async workflow(access, model, raw, transaction) {
        requireScope(access.principal, 'ontology:write');
        const input = workflowSchema.parse(raw);
        revisionMatches(input.id, input.revision);
        await access.refresh(transaction);
        access.require(model.document.id, 'view_definition', model.document.id);
        this.authorize(access, model, input.steps);
        if (input.proposal)
            authorizeCognitive(access, model, input.proposal);
        if (new Set(input.steps.map((item) => item.name)).size !== input.steps.length)
            throw new Conflict('Workflow step names must be unique');
        const id = input.id ?? randomUUID();
        const save = async (client) => {
            await this.active(model, client);
            const result = input.id
                ? await this.db.query(`UPDATE ${this.db.schema}.workflows SET name=$3,body=$4,revision=revision+1 WHERE id=$1 AND owner=$2 AND revision=$5 AND ontology=$6 AND body->>'kind' IS NULL RETURNING revision`, [id, access.principal.owner, input.name, input, input.revision, model.document.id], client)
                : await insertWorkflowRecord(this.db, client, {
                    id, owner: access.principal.owner, ontology: model.document.id, name: input.name, body: input,
                });
            if (!result.rowCount)
                throw new Conflict('Workflow changed or is unavailable');
            await access.refresh(client);
            return { ...input, id, revision: Number(result.rows[0].revision) };
        };
        return transaction ? save(transaction) : this.db.transaction(save);
    }
    async ruleDefinition(rule, owner, ontology, client, lock = false) {
        // A notification runs no steps; its scan queues the message instead of a workflow run.
        if ('notify' in rule)
            return { definition: { name: rule.name, description: '', revision: 0, steps: [] }, revision: null };
        if ('effect' in rule) {
            const definition = workflowSchema.parse({ name: rule.name, steps: [{ name: 'Action', action: rule.effect.action, input: rule.effect.input }] });
            return { definition, revision: null };
        }
        const record = await readWorkflowRecord(this.db, { id: rule.workflow, owner, ontology }, client, null, lock);
        if (!record)
            throw new NotFound('Rule workflow is unavailable');
        return { definition: workflowSchema.parse(record.body), revision: Number(record.revision) };
    }
    relatedContract(graph, source, process, actionName, related, input) {
        const { access, model } = graph;
        const action = model.action(actionName);
        const fn = action.function && model.functions.get(action.function);
        if (action.effects?.length || (fn && fn.source && !action.typeClasses?.some(tag => tag.kind === 'observation' && tag.name === 'readback')))
            throw new Conflict('Related-object rules require an internal Action or a published observation Action');
        const target = related.path.reduce((type, link) => {
            const nav = model.navigation(type, link);
            access.definition(model, 'link', nav.link);
            access.read(model, nav.target);
            return nav.target;
        }, source);
        const bindings = [[related.sourceParameter, source], [related.transitionParameter, process], [related.targetParameter, target]];
        if (new Set(bindings.map(([key]) => key)).size !== bindings.length)
            throw new Conflict('Related Action parameters must be distinct');
        for (const [key, type] of bindings) {
            const parameter = action.objectParameters[key];
            if (Object.hasOwn(input, key) || !parameter || !model.concreteTypes(parameter).includes(type))
                throw new Conflict('Related object cannot bind to ' + actionName + '/' + key);
        }
        return bindings.map(([key]) => key);
    }
    async checkDirectEffect(model, rule, release, client) {
        if (!release)
            throw new Conflict('Re-save the process rule to confirm its Action contract');
        if (release === model.release)
            return;
        const previous = await this.metadata.get(release, client);
        let sourceType = processLogTarget(previous, rule.process.type)?.objectType;
        const linkTypes = [];
        for (const link of rule.effect.related?.path ?? []) {
            if (!sourceType)
                throw new Conflict('Original process source type is unavailable');
            const nav = previous.navigation(sourceType, link);
            linkTypes.push(nav.link);
            sourceType = nav.target;
        }
        checkWorkflowDependencies(previous, model, {
            actions: [rule.effect.action], objectTypes: [rule.process.type], linkTypes,
        }, new Set());
    }
    async rule(access, model, raw, transaction) {
        requireScope(access.principal, 'ontology:write');
        const input = ruleSchema.parse(raw);
        revisionMatches(input.id, input.revision);
        await access.refresh(transaction);
        access.require(model.document.id, 'view_definition', model.document.id);
        const id = input.id ?? randomUUID();
        const save = async (client) => {
            if (input.id && !(await this.db.query(`SELECT 1 FROM ${this.db.schema}.object_rules WHERE id=$1 AND owner=$2 AND revision=$3 AND ontology=$4 FOR UPDATE`, [id, access.principal.owner, input.revision, model.document.id], client)).rowCount)
                throw new Conflict('Rule changed or is unavailable');
            await this.active(model, client);
            const { definition } = await this.ruleDefinition(input, access.principal.owner, model.document.id, client);
            this.authorize(access, model, definition.steps);
            if (definition.proposal)
                authorizeCognitive(access, model, definition.proposal);
            const graph = new Objects(this.db, model, access, client);
            const target = 'process' in input ? processTarget(graph, input.process) : undefined;
            if ('effect' in input && target) {
                const action = model.action(input.effect.action);
                const related = input.effect.related;
                if (input.replayFrom !== undefined && (!related || BigInt(input.replayFrom) > 9223372036854775807n))
                    throw new Conflict('Invalid related process replay cursor');
                const bound = related ? this.relatedContract(graph, target.objectType, target.type, action.apiName, related, input.effect.input) : [];
                const required = (action.parameters.required ?? []);
                if (required.some(key => !Object.hasOwn(input.effect.input, key) && !bound.includes(key)))
                    throw new Conflict('The rule is missing a required Action parameter');
                for (const [key, binding] of Object.entries(input.effect.input)) {
                    const type = action.objectParameters[key];
                    if ('object' in binding && type && (related || !model.concreteTypes(type).includes(target.objectType)))
                        throw new Conflict('The process object cannot bind to ' + input.effect.action + '/' + key);
                }
            }
            if ('query' in input) {
                for (const type of model.concreteTypes(input.query.type)) {
                    access.read(model, type);
                    validateFieldWatch(graph, type, input.onModified?.watch);
                }
            }
            const result = input.id
                ? await this.db.query(`UPDATE ${this.db.schema}.object_rules SET name=$3,body=$4,enabled=$5,revision=revision+1,error=NULL,consecutive_failures=0,scopes=$8,last_scan=NULL,process_cursor=NULL,process_commit=0,
              match_commit=NULL,match_release=NULL,match_visibility=NULL,match_reconciled_at=NULL WHERE id=$1 AND owner=$2 AND revision=$6 AND ontology=$7 AND NOT (body ? 'machineryReview') RETURNING revision`, [
                    id,
                    access.principal.owner,
                    input.name,
                    input,
                    input.enabled,
                    input.revision,
                    model.document.id,
                    encodePrincipalScopes(access.principal),
                ], client)
                : await this.db.query(`INSERT INTO ${this.db.schema}.object_rules(id,owner,ontology,name,body,revision,enabled,scopes) VALUES($1,$2,$3,$4,$5,1,$6,$7) RETURNING revision`, [
                    id,
                    access.principal.owner,
                    model.document.id,
                    input.name,
                    input,
                    input.enabled,
                    encodePrincipalScopes(access.principal),
                ], client);
            if (!result.rowCount)
                throw new Conflict('Rule changed or is unavailable');
            if (input.id)
                await this.db.query(`DELETE FROM ${this.db.schema}.rule_matches WHERE rule_id=$1`, [id], client);
            if ('effect' in input)
                await this.db.query(`UPDATE ${this.db.schema}.object_rules SET effect_release=$2 WHERE id=$1`, [id, model.release], client);
            if (target) {
                await this.db.setOwner(client, graph.owner);
                // Commit numbers follow visibility, so the start needs no write lock: a transition that commits later is after it.
                const start = await processStart(this.db, graph.owner, target, client, 'replayFrom' in input ? input.replayFrom : undefined);
                await this.db.query(`UPDATE ${this.db.schema}.object_rules SET process_commit=$2,process_cursor=$3 WHERE id=$1`, [id, start.commit, start.sequence], client);
            }
            await access.refresh(client);
            return { ...input, id, revision: Number(result.rows[0].revision) };
        };
        return transaction ? save(transaction) : this.db.transaction(save);
    }
    async disableObjectRule(graph, id) {
        requireScope(graph.access.principal, 'ontology:write');
        await this.active(graph.model, graph.client);
        await this.db.query(`UPDATE ${this.db.schema}.object_rules SET enabled=false,revision=revision+1
      WHERE id=$1 AND owner=$2 AND ontology=$3 AND enabled AND body ? 'query'`, [id, graph.owner, graph.model.document.id], graph.client);
    }
    async processBindings(access, model, raw) {
        const { type, cursor } = processBindingsSchema.parse(raw);
        requireScope(access.principal, 'ontology:read');
        access.require(model.document.id, 'view_definition', model.document.id);
        return this.db.withOwner(access.principal.owner, () => this.db.transaction(async (client) => {
            await this.active(model, client);
            await access.refresh(client);
            const graph = new Objects(this.db, model, access, client);
            const target = processTarget(graph, { type });
            if (!access.property(model, target.objectType, target.property)
                || !access.canSeeModelData(model.object(target.objectType).properties[target.property]?.classification))
                throw new PermissionDenied('Process state is unavailable');
            const rows = (await this.db.query(`SELECT rule.id,rule.name,rule.body,rule.revision,rule.enabled,rule.error,rule.last_scan,
          latest.id AS run_id,latest.process_trigger,latest.object_ref,latest.state,latest.updated_at
        FROM ${this.db.schema}.object_rules rule LEFT JOIN LATERAL (
          SELECT id,state,updated_at,process_trigger,object_ref FROM ${this.db.schema}.workflow_runs run
          WHERE run.process_trigger IS NOT NULL AND run.owner=rule.owner AND run.ontology=rule.ontology AND run.process_trigger->>'ruleId'=rule.id::text
            AND run.process_trigger->>'revision'=rule.revision::text
          ORDER BY created_at DESC,id DESC LIMIT 1
        ) latest ON true
        WHERE rule.owner=$1 AND rule.ontology=$2 AND rule.body->'process'->>'type'=$3 AND ($4::uuid IS NULL OR rule.id>$4)
        ORDER BY rule.id LIMIT 51`, [graph.owner, model.document.id, type, cursor ?? null], client)).rows;
            const items = [];
            for (const row of rows.slice(0, 50)) {
                const rule = processRule.parse(row.body);
                if ('effect' in rule && (!model.actions.has(rule.effect.action) || !access.canDefine(model, 'action', rule.effect.action)
                    || !access.canSeeModelData(model.action(rule.effect.action).classification)))
                    continue;
                const trigger = row.process_trigger && processTriggerSchema.parse(row.process_trigger);
                const visibleRun = trigger && await this.visibleProcessRun(graph, objectRefSchema.parse(row.object_ref), trigger);
                items.push({ id: String(row.id), revision: Number(row.revision), name: String(row.name), process: rule.process,
                    enabled: Boolean(row.enabled), error: row.error, lastScan: row.last_scan,
                    effect: 'effect' in rule ? { action: rule.effect.action } : 'notify' in rule ? { notify: true } : { workflow: rule.workflow },
                    latestRun: visibleRun ? { id: String(row.run_id), state: String(row.state), updatedAt: row.updated_at } : null });
            }
            await access.refresh(client);
            return { owner: graph.owner, release: model.release, items, cursor: rows.length > 50 ? String(rows[49].id) : null };
        }));
    }
    async processStatus(access, model, raw) {
        requireScope(access.principal, 'ontology:read');
        const input = processStatusSchema.parse(raw);
        return this.db.transaction(async (client) => {
            await this.db.query('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ', [], client);
            await this.db.setOwner(client, access.principal.owner);
            await this.active(model, client);
            await access.refresh(client);
            return readProcessStatus(new Objects(this.db, model, access, client), input);
        });
    }
    async list(access, model, kind) {
        requireScope(access.principal, 'ontology:read');
        z.enum(['workflows', 'object_rules', 'workflow_runs']).parse(kind);
        await access.refresh();
        access.require(model.document.id, 'view_definition', model.document.id);
        const rows = (await this.db.query(`SELECT * FROM ${this.db.schema}.${kind} WHERE owner=$1 AND ontology=$2 ${kind === 'object_rules' ? "AND NOT (body ? 'machineryReview')" : ''} ORDER BY id DESC LIMIT 101`, [access.principal.owner, model.document.id])).rows;
        const graph = new Objects(this.db, model, access), items = [];
        const visible = async (raw) => {
            try {
                const ref = objectRefSchema.parse(raw);
                await graph.read(ref);
                return ref;
            }
            catch (error) {
                if (error instanceof PermissionDenied || error instanceof NotFound)
                    return null;
                throw error;
            }
        };
        for (const row of rows) {
            if (kind === 'workflow_runs') {
                const trigger = row.process_trigger && processTriggerSchema.parse(row.process_trigger);
                if (trigger && (!model.objects.has(trigger.process.type) ||
                    !await this.visibleProcessRun(graph, objectRefSchema.parse(row.object_ref), trigger)))
                    continue;
                const object = await visible(row.object_ref), results = [];
                const receipts = (await this.db.query(`SELECT position,requirements,result FROM ${this.db.schema}.workflow_steps WHERE run_id=$1 AND result IS NOT NULL ORDER BY position`, [row.id])).rows;
                for (const receipt of receipts) {
                    const allowed = await (await Access.load(this.db, access.principal)).canReturn(receipt.requirements);
                    results.push({
                        step: row.body.steps[receipt.position]?.name,
                        object: allowed ? await visible(receipt.result) : null,
                    });
                }
                items.push({
                    id: row.id,
                    name: row.body.name,
                    object,
                    state: row.state,
                    step: row.step,
                    stepCount: row.body.steps.length + Number(Boolean(row.body.proposal)),
                    ...(object && row.proposal_task && access.principal.scopes.includes('tasks:read') ? {
                        proposal: {
                            taskId: row.proposal_task, scenarioId: row.proposal_scenario, deadline: row.proposal_deadline,
                            mergeAction: row.body.proposal.mergeAction, mergeObjectParameter: row.body.proposal.mergeObjectParameter,
                        },
                    } : {}),
                    error: row.error,
                    results,
                    createdAt: row.created_at,
                });
            }
            else
                items.push({
                    ...row.body,
                    name: row.name,
                    id: row.id,
                    revision: row.revision,
                    ...(kind === 'workflows' && row.published_revision ? { publication: {
                            revision: Number(row.published_revision), targetType: row.published_target,
                        } } : {}),
                    enabled: row.enabled,
                    lastScan: row.last_scan,
                    error: row.error,
                });
        }
        await access.refresh();
        return { items: items.slice(0, 100), hasMore: items.length > 100 };
    }
    async preview(access, model, raw) {
        const input = automationPreviewSchema.parse(raw), owner = access.principal.owner;
        requireScope(access.principal, 'ontology:read');
        requireScope(access.principal, 'ontology:write');
        return this.db.withOwner(owner, () => this.db.transaction(async (client) => {
            const rule = (await this.db.query(`SELECT body,scopes,enabled,revision,effect_release FROM ${this.db.schema}.object_rules
        WHERE id=$1 AND owner=$2 AND ontology=$3 FOR SHARE`, [input.rule, owner, model.document.id], client)).rows[0];
            if (!rule || Number(rule.revision) !== input.revision)
                throw new Conflict('Automation revision changed or is unavailable');
            const savedIdentity = decodePrincipal(owner, rule.scopes ?? []);
            const savedScopes = savedIdentity.scopes;
            if (!savedScopes.includes('ontology:write'))
                throw new PermissionDenied('Save the rule with current write permission before previewing');
            const configuration = ruleSchema.parse(rule.body);
            if ('effect' in configuration && configuration.effect.related)
                throw new Conflict('Preview a related rule with a committed synthetic ProcessLog in an isolated database');
            if ('effect' in configuration)
                await this.checkDirectEffect(model, configuration, rule.effect_release, client);
            const { definition, revision: workflowRevision } = await this.ruleDefinition(configuration, owner, model.document.id, client, true);
            await lockEdits(this.db, model, owner, client);
            await access.refresh(client);
            this.authorize(access, model, definition.steps);
            const runnerPrincipal = { ...access.principal, scopes: access.principal.scopes.filter(scope => savedScopes.includes(scope)),
                ...(savedIdentity.memberAccess || access.principal.memberAccess ? { memberAccess: true } : {}) };
            const evaluatedAt = Date.now() + input.elapsedSeconds * 1000, signal = AbortSignal.timeout(15_000);
            const scenarios = new Scenarios(this.db), reports = [];
            const live = new Objects(this.db, model, access, client);
            const match = async (graph, query) => {
                const page = await graph.query({ ...query, limit: 100 });
                if (page.cursor || page.items.length > 100)
                    throw new Conflict('Narrow conditions to at most 100 matching objects before previewing');
                return page.items;
            };
            const baseline = new Map();
            if ('query' in configuration) {
                for (const item of await match(live, configuration.query)) {
                    baseline.set(digest(item.ref), {
                        ref: item.ref,
                        observed: configuration.onModified
                            ? await fieldWatchDigest(live, item, configuration.onModified.watch) : undefined,
                    });
                }
            }
            for (const selected of input.scenarios) {
                signal.throwIfAborted();
                const view = await scenarios.view(access, model, selected.id, client);
                const diff = await scenarios.inspect(access, model, selected.id, client);
                if (diff.revision !== selected.revision)
                    throw new Conflict('Scenario revision changed; reload the selection');
                if (diff.conflicts)
                    throw new Conflict('Resolve Scenario conflicts before previewing automations');
                const branch = await Access.load(this.db, runnerPrincipal, client), graph = new Objects(this.db, view, branch, client);
                const waiting = [];
                let entered;
                if ('query' in configuration) {
                    entered = [];
                    const currentKeys = new Set();
                    for (const item of await match(graph, configuration.query)) {
                        const key = digest(item.ref);
                        currentKeys.add(key);
                        const watched = configuration.onModified;
                        if (!baseline.has(key) ? !watched || watched.includeAdded
                            : watched && baseline.get(key).observed !== await fieldWatchDigest(graph, item, watched.watch)) {
                            entered.push(item.ref);
                        }
                    }
                    if (configuration.onRemoved) {
                        for (const [key, entry] of baseline) {
                            if (!currentKeys.has(key))
                                entered.push(entry.ref);
                        }
                    }
                }
                else {
                    const target = processTarget(graph, configuration.process);
                    entered = diff.objects.filter(item => {
                        if (item.ref.type !== target.objectType || !item.after || typeof item.after[target.property] !== 'string')
                            return false;
                        if (item.before && !Object.hasOwn(item.before, target.property))
                            return false;
                        const prev = item.before?.[target.property] ?? null, next = item.after[target.property];
                        return prev !== next && (configuration.process.from === undefined || configuration.process.from === prev)
                            && (configuration.process.to === undefined || configuration.process.to === next);
                    }).map(item => item.ref);
                    if ((configuration.process.dwellSeconds ?? 0) > input.elapsedSeconds)
                        waiting.push(...entered.splice(0));
                }
                if (entered.length > 20 || entered.length * Math.max(1, definition.steps.length) > 60)
                    throw new Conflict('Automation preview exceeds its execution budget; narrow the condition');
                const results = [];
                for (const ref of entered) {
                    const steps = [];
                    let status = 'completed', reason;
                    await this.db.query('SAVEPOINT automation_preview', [], client);
                    try {
                        const bindings = new Map();
                        for (const item of definition.steps) {
                            try {
                                const object = await graph.read(ref);
                                const result = await this.actions.apply(branch, view, item.action, bindWorkflowInput(item, object, bindings), randomUUID(), undefined, undefined, signal, undefined, { client, evaluatedAt });
                                bindings.set(item.name, result);
                                steps.push({ name: item.name, action: item.action, status: 'completed' });
                            }
                            catch (error) {
                                if (!(error instanceof Conflict || error instanceof NotFound))
                                    throw error;
                                steps.push({ name: item.name, action: item.action, status: 'rejected' });
                                status = 'rejected';
                                reason = error.message;
                                break;
                            }
                        }
                        if (status === 'completed' && definition.proposal)
                            status = 'proposal_required';
                        await branch.refresh(client);
                    }
                    finally {
                        await this.db.query('ROLLBACK TO SAVEPOINT automation_preview', [], client);
                        await this.db.query('RELEASE SAVEPOINT automation_preview', [], client);
                    }
                    results.push({ object: ref, status, reason, steps });
                }
                await branch.refresh(client);
                access.adoptReads(branch);
                reports.push({ id: selected.id, revision: selected.revision, name: diff.name, waiting, results });
            }
            await access.refresh(client);
            return { rule: input.rule, revision: input.revision, enabled: rule.enabled, workflowRevision,
                release: model.release, mode: 'scenario_preview', scenarios: reports };
        }));
    }
    async publishWorkflow(access, model, raw) {
        const input = publishWorkflowSchema.parse(raw), ontology = model.document.id;
        access.require(ontology, 'manage_definition', ontology);
        model.object(input.targetType);
        return this.db.transaction(async (client) => {
            await this.active(model, client);
            await access.refresh(client);
            const { rows: [draft] } = await this.db.query(`SELECT body,revision FROM ${this.db.schema}.workflows
         WHERE id=$1 AND ontology=$2 AND body->>'kind' IS NULL FOR UPDATE`, [input.id, ontology], client);
            if (!draft || Number(draft.revision) !== input.revision)
                throw new Conflict('Workflow draft changed or is unavailable');
            const definition = workflowSchema.parse(draft.body);
            this.authorize(access, model, definition.steps);
            for (const step of definition.steps) {
                const parameters = model.action(step.action).objectParameters;
                for (const [key, binding] of Object.entries(step.input)) {
                    const required = parameters[key];
                    if ('object' in binding && required && !model.concreteTypes(required).includes(input.targetType))
                        throw new Conflict('The workflow target cannot bind to ' + step.name + '/' + key);
                }
            }
            if (definition.proposal)
                authorizeCognitive(access, model, definition.proposal);
            await this.db.query(`UPDATE ${this.db.schema}.workflows SET published_body=body,published_revision=revision,published_release=$3,published_target=$4
          WHERE id=$1 AND ontology=$2`, [input.id, ontology, model.release, input.targetType], client);
            return { id: input.id, revision: input.revision, release: model.release, targetType: input.targetType };
        });
    }
    async withdrawWorkflow(access, model, raw) {
        const input = withdrawWorkflowSchema.parse(raw), ontology = model.document.id;
        access.require(ontology, 'manage_definition', ontology);
        return this.db.transaction(async (client) => {
            await this.active(model, client);
            await access.refresh(client);
            const result = await this.db.query(`UPDATE ${this.db.schema}.workflows SET published_body=NULL,published_revision=NULL,
          published_release=NULL,published_target=NULL WHERE id=$1 AND ontology=$2 AND published_revision=$3`, [input.id, ontology, input.revision], client);
            if (!result.rowCount)
                throw new Conflict('Published workflow changed or is unavailable');
            return { id: input.id, withdrawn: true };
        });
    }
    async checkPublishedWorkflow(access, model, row, client) {
        const definition = workflowSchema.parse(row.published_body);
        const ontology = model.document.id;
        access.require(ontology, 'view_definition', ontology);
        access.read(model, row.published_target);
        this.authorize(access, model, definition.steps);
        if (definition.proposal)
            authorizeCognitive(access, model, definition.proposal);
        if (row.published_release !== model.release) {
            const prior = await this.metadata.findAncestor(model, row.published_release, client, 'release');
            if (!prior)
                throw new Conflict('Published workflow requires review for this Ontology release');
            const proposal = definition.proposal;
            checkWorkflowDependencies(prior, model, {
                objectTypes: [row.published_target],
                actions: [...definition.steps.map(step => step.action), ...(proposal ? [...proposal.actions, proposal.mergeAction] : [])],
                functions: proposal ? [...proposal.functions, proposal.validation.function] : [],
            }, new Set());
        }
        return definition;
    }
    async listPublishedWorkflows(access, model) {
        access.require(model.document.id, 'view_definition', model.document.id);
        const { rows } = await this.db.query(`SELECT id,published_body,published_revision,published_release,published_target FROM ${this.db.schema}.workflows
        WHERE ontology=$1 AND published_body IS NOT NULL ORDER BY published_body->>'name',id LIMIT 101`, [model.document.id]);
        const items = [];
        for (const row of rows.slice(0, 100)) {
            const candidate = await access.fork();
            try {
                const body = await this.checkPublishedWorkflow(candidate, model, row);
                await candidate.refresh();
                access.adoptReads(candidate);
                items.push({ id: row.id, name: body.name, description: body.description, revision: Number(row.published_revision), targetType: row.published_target });
            }
            catch (error) {
                if (!(error instanceof NotFound || error instanceof PermissionDenied || error instanceof Conflict))
                    throw error;
            }
        }
        await access.refresh();
        return { items, hasMore: rows.length > 100 };
    }
    async runPublishedWorkflow(access, model, raw) {
        const { revision, ...input } = runPublishedWorkflowSchema.parse(raw);
        return this.run(access, model, input, revision);
    }
    async run(access, model, raw, publishedRevision) {
        requireScope(access.principal, 'ontology:write');
        const input = runWorkflowSchema.parse(raw);
        await access.refresh();
        return this.db.transaction(async (client) => {
            await this.active(model, client);
            let workflow;
            if (publishedRevision !== undefined) {
                const { rows: [published] } = await this.db.query(`SELECT id,published_body,published_revision,published_release,published_target FROM ${this.db.schema}.workflows
            WHERE id=$1 AND ontology=$2 AND published_revision=$3 AND published_body IS NOT NULL FOR SHARE`, [input.workflow, model.document.id, publishedRevision], client);
                if (!published)
                    throw new NotFound('Published workflow revision is unavailable');
                if (published.published_target !== input.object.type)
                    throw new Conflict('Select an object of the published workflow target type');
                await this.checkPublishedWorkflow(access, model, published, client);
                workflow = { body: published.published_body, revision: published.published_revision };
            }
            else {
                workflow = await readWorkflowRecord(this.db, {
                    id: input.workflow, owner: access.principal.owner, ontology: model.document.id,
                }, client);
                if (!workflow)
                    throw new NotFound('Workflow is unavailable');
                const definition = workflowSchema.parse(workflow.body);
                this.authorize(access, model, definition.steps);
                if (definition.proposal)
                    authorizeCognitive(access, model, definition.proposal);
            }
            await new Objects(this.db, model, access, client).read(input.object);
            const fingerprint = digest({
                input,
                body: workflow.body,
                revision: workflow.revision,
                ...(publishedRevision === undefined ? {} : { published: true }),
                release: model.release,
            });
            const inserted = await this.db.query(`INSERT INTO ${this.db.schema}.workflow_runs(id,owner,ontology,release,request_id,digest,workflow_id,body,object_ref,scopes) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) ON CONFLICT(owner,request_id) DO NOTHING RETURNING id`, [
                randomUUID(),
                access.principal.owner,
                model.document.id,
                model.release,
                input.requestId,
                fingerprint,
                input.workflow,
                workflow.body,
                input.object,
                encodePrincipalScopes(access.principal),
            ], client);
            if (inserted.rowCount)
                await this.db.query("SELECT pg_notify('eigos_automation','run')", [], client);
            const row = (await this.db.query(`SELECT id,state,digest FROM ${this.db.schema}.workflow_runs WHERE owner=$1 AND request_id=$2`, [access.principal.owner, input.requestId], client)).rows[0];
            if (row.digest !== fingerprint)
                throw new Conflict('Workflow request ID has different input');
            await access.refresh(client);
            return { id: String(row.id), state: String(row.state) };
        });
    }
    async scanOne() {
        const object = await this.scanObjectRules();
        const process = await this.scanProcessRules();
        return object || process;
    }
    /** Scans one due object-set rule, reporting whether one was due. */
    scanObjectRules() { return this.scanRule(false); }
    /** Scans one due process rule, reporting whether one was due. */
    scanProcessRules() { return this.scanRule(true); }
    async resolveTriggerDepth(client, owner, ref, sequence) {
        let executorKind = null;
        let executorId = null;
        if (sequence !== undefined) {
            const edit = (await this.db.query(`SELECT executor_kind,executor_id FROM ${this.db.schema}.edit_history
          WHERE owner=$1 AND type=$2 AND id=$3 AND sequence=$4`, [owner, ref.type, ref.id, sequence], client)).rows[0];
            executorKind = edit?.executor_kind ?? null;
            executorId = edit?.executor_id ?? null;
        }
        else {
            const edit = (await this.db.query(`SELECT executor_kind,executor_id,happened_at FROM ${this.db.schema}.edit_history
          WHERE owner=$1 AND type=$2 AND id=$3 ORDER BY sequence DESC LIMIT 1`, [owner, ref.type, ref.id], client)).rows[0];
            const link = (await this.db.query(`SELECT executor_kind,executor_id,happened_at FROM ${this.db.schema}.link_history
          WHERE owner=$1 AND ((from_type=$2 AND from_id=$3) OR (to_type=$2 AND to_id=$3))
          ORDER BY sequence DESC LIMIT 1`, [owner, ref.type, ref.id], client)).rows[0];
            const latest = !edit ? link : !link ? edit : (link.happened_at.getTime() > edit.happened_at.getTime() ? link : edit);
            executorKind = latest?.executor_kind ?? null;
            executorId = latest?.executor_id ?? null;
        }
        if (executorKind !== 'workflow' || !executorId || !uuidPattern.test(executorId))
            return { depth: 0 };
        const parent = (await this.db.query(`SELECT trigger_depth FROM ${this.db.schema}.workflow_runs WHERE id=$1 AND owner=$2`, [executorId, owner], client)).rows[0];
        return { depth: Number(parent?.trigger_depth ?? 0) + 1, parentRunId: executorId };
    }
    async scanRule(process) {
        return this.db.transaction(async (client) => {
            if (!process)
                await this.db.query('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ', [], client);
            const rule = (await this.db.query(`SELECT *, match_reconciled_at IS NULL OR match_reconciled_at<=now()-$3*interval '1 second' AS reconcile_due
            FROM ${this.db.schema}.object_rules WHERE enabled AND NOT (body ? 'machineryReview') AND (process_cursor IS NOT NULL)=$1
            AND (last_scan IS NULL OR last_scan<=now()-(CASE WHEN body ? 'onModified' THEN 5 ELSE $2 END)*interval '1 second') ORDER BY last_scan NULLS FIRST FOR UPDATE SKIP LOCKED LIMIT 1`, [process, process ? 1 : objectRuleSeconds, reconcileSeconds], client)).rows[0];
            if (!rule)
                return false;
            await this.db.setOwner(client, String(rule.owner));
            await this.db.query(`UPDATE ${this.db.schema}.object_rules SET last_scan=now() WHERE id=$1`, [rule.id], client);
            await this.db.query('SAVEPOINT rule_scan', [], client);
            try {
                const principal = decodePrincipal(String(rule.owner), rule.scopes);
                requireScope(principal, 'ontology:write');
                const model = await this.metadata.active(rule.ontology, client, true), access = await Access.load(this.db, principal, client);
                const input = ruleSchema.parse(rule.body);
                if ('effect' in input)
                    await this.checkDirectEffect(model, input, rule.effect_release, client);
                const { definition: body } = await this.ruleDefinition(input, principal.owner, model.document.id, client);
                this.authorize(access, model, body.steps);
                const graph = new Objects(this.db, model, access, client);
                if ('process' in input) {
                    await this.scanProcess(graph, String(rule.id), Number(rule.revision), { commit: String(rule.process_commit), sequence: String(rule.process_cursor) }, input, body);
                }
                else {
                    await this.scanMatches(graph, rule, input, body);
                }
                await access.refresh(client);
                await this.db.query(`UPDATE ${this.db.schema}.object_rules SET consecutive_failures=0,error=NULL WHERE id=$1`, [rule.id], client);
                await this.db.query('RELEASE SAVEPOINT rule_scan', [], client);
            }
            catch (error) {
                await this.db.query('ROLLBACK TO SAVEPOINT rule_scan', [], client);
                const diag = errorDiagnostic(error);
                const code = error?.code;
                const retryableConflict = code === '55P03' || code === '40001' || code === '40P01';
                console.error(JSON.stringify({
                    event: 'rule_scan_error', ruleId: String(rule.id), owner: String(rule.owner),
                    ontology: String(rule.ontology), process, retryableConflict,
                    consecutiveFailures: Number(rule.consecutive_failures ?? 0),
                    errorName: diag.name, errorCode: diag.code, message: diag.message,
                }));
                if (retryableConflict)
                    return true;
                const permanent = error instanceof PermissionDenied || error instanceof Conflict || error instanceof NotFound
                    || error instanceof InvalidInput || error instanceof z.ZodError;
                const storedError = `Rule scan failed; review permissions, publication and trigger before enabling it again [${diag.summary}]`;
                if (permanent) {
                    await this.db.query(`UPDATE ${this.db.schema}.object_rules SET enabled=false,consecutive_failures=consecutive_failures+1,error=$2 WHERE id=$1`, [rule.id, storedError], client);
                }
                else {
                    await this.db.query(`UPDATE ${this.db.schema}.object_rules
              SET consecutive_failures=consecutive_failures+1,
                  enabled=CASE WHEN consecutive_failures+1>=$3 THEN false ELSE enabled END,
                  error=$2
              WHERE id=$1`, [rule.id, storedError, RULE_FAILURE_THRESHOLD], client);
                }
            }
            return true;
        });
    }
    /**
     * An object-set rule consumes its owner's committed changes from its own position. It re-reads its whole set on its
     * first scan, after the publication or the rule principal's visibility changed, when more objects changed than one
     * scan re-evaluates, when a change touched the footprint of a rule that depends on relationships or derived
     * properties, and once per reconcile interval. Otherwise it re-evaluates only the objects that changed, and a scan
     * without a relevant change reads only the journal.
     */
    async scanMatches(graph, rule, input, body) {
        const { access, client, model, owner } = graph;
        for (const type of model.concreteTypes(input.query.type)) {
            access.read(model, type);
            validateFieldWatch(graph, type, input.onModified?.watch);
        }
        const ruleId = String(rule.id), revision = Number(rule.revision);
        const latest = await latestCommit(this.db, owner, client), visibility = access.visibilityDigest;
        const full = async () => {
            await this.evaluateMatches(graph, ruleId, revision, input, body);
            await this.db.query(`UPDATE ${this.db.schema}.object_rules SET match_commit=$2,match_release=$3,match_visibility=$4,match_reconciled_at=now()
        WHERE id=$1`, [ruleId, latest, model.release, visibility], client);
        };
        if (rule.match_commit === null || rule.match_release !== model.release || rule.match_visibility !== visibility || rule.reconcile_due)
            return full();
        const position = String(rule.match_commit);
        const footprint = queryFootprint(model, input.query, input.onModified?.watch);
        let end;
        if (footprint.local) {
            const changed = await changedObjects(this.db, owner, model.projection, footprint.types, client, position, latest);
            if (!changed.refs)
                return full();
            if (changed.refs.length)
                await this.evaluateMatches(graph, ruleId, revision, input, body, changed.refs);
            end = changed.end;
        }
        else {
            const changed = await footprintChanged(this.db, owner, footprint, client, position, latest);
            if (changed.changed)
                return full();
            end = changed.end;
        }
        // A window that stopped short of the latest commit leaves the rule due, so the backlog drains on the next scans.
        await this.db.query(`UPDATE ${this.db.schema}.object_rules SET match_commit=$2${end === latest ? '' : ',last_scan=NULL'} WHERE id=$1`, [ruleId, end], client);
    }
    /** Updates a rule's matches from its whole set, or from `candidates` alone, and submits runs for the objects that triggered. */
    async evaluateMatches(graph, ruleId, revision, input, body, candidates) {
        const { access, client, model, owner } = graph;
        const matched = new Map();
        const limit = input.onModified ? 100 : 10000;
        if (candidates) {
            const keys = new Set(candidates.map(ref => digest(ref)));
            for (let i = 0; i < candidates.length; i += 100)
                for (const item of await graph.queryAmong(input.query, candidates.slice(i, i + 100).map(ref => ref.id)))
                    if (keys.has(digest(item.ref)))
                        matched.set(digest(item.ref), item);
        }
        else {
            let cursor;
            do {
                const page = await graph.query({ ...input.query, limit: 100, cursor });
                cursor = page.cursor;
                for (const item of page.items) {
                    matched.set(digest(item.ref), item);
                    if (matched.size > limit)
                        throw new Conflict('Rule matches more than ' + limit + ' objects');
                }
            } while (cursor);
        }
        const previous = (candidates
            ? await this.db.query(`SELECT m.* FROM ${this.db.schema}.rule_matches m
          JOIN unnest($2::text[],$3::text[]) AS candidate(type,id) ON candidate.type=m.type AND candidate.id=m.id WHERE m.rule_id=$1`, [ruleId, candidates.map(ref => ref.type), candidates.map(ref => ref.id)], client)
            : await this.db.query(`SELECT * FROM ${this.db.schema}.rule_matches WHERE rule_id=$1`, [ruleId], client)).rows;
        const prior = new Map(previous.map((item) => [digest({ type: item.type, id: item.id }), item]));
        let enqueued = false;
        for (const [key, item] of matched) {
            const before = prior.get(key);
            const observed = input.onModified ? await fieldWatchDigest(graph, item, input.onModified.watch) : null;
            const triggered = !before?.matched ? !input.onModified || input.onModified.includeAdded
                : Boolean(input.onModified && before.observed_digest !== observed);
            const generation = Number(before?.generation ?? 0) + (triggered ? 1 : 0);
            if (!triggered && before?.matched && Number(before.revision) === item.revision && (before.observed_digest ?? null) === observed)
                continue;
            if (triggered) {
                const { depth, parentRunId } = await this.resolveTriggerDepth(client, owner, item.ref);
                if (depth > MAX_TRIGGER_DEPTH) {
                    console.error(JSON.stringify({
                        event: 'automation_recursion_limit', ruleId, owner, ontology: model.document.id,
                        objectRef: item.ref, parentWorkflowRunId: parentRunId, triggerDepth: depth, maxTriggerDepth: MAX_TRIGGER_DEPTH,
                    }));
                }
                else {
                    const fingerprint = digest([ruleId, revision, item.ref, generation]);
                    const requestId = 'rule:' + fingerprint;
                    const inserted = await this.db.query(`INSERT INTO ${this.db.schema}.workflow_runs(id,owner,ontology,release,request_id,digest,workflow_id,body,object_ref,scopes,trigger_depth) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) ON CONFLICT(owner,request_id) DO NOTHING RETURNING id`, [
                        randomUUID(),
                        owner,
                        model.document.id,
                        model.release,
                        requestId,
                        fingerprint,
                        input.workflow,
                        body,
                        item.ref,
                        encodePrincipalScopes(access.principal),
                        depth,
                    ], client);
                    if (inserted.rowCount)
                        enqueued = true;
                }
            }
            await this.db.query(`INSERT INTO ${this.db.schema}.rule_matches(rule_id,type,id,matched,revision,generation,observed_digest)
          VALUES($1,$2,$3,true,$4,$5,$6) ON CONFLICT(rule_id,type,id)
          DO UPDATE SET matched=true,revision=excluded.revision,generation=excluded.generation,observed_digest=excluded.observed_digest`, [ruleId, item.ref.type, item.ref.id, item.revision, generation, observed], client);
        }
        for (const [key, item] of prior) {
            if (matched.has(key))
                continue;
            if (item.matched && input.onRemoved) {
                const ref = { type: String(item.type), id: String(item.id) };
                const generation = Number(item.generation ?? 0) + 1;
                const { depth, parentRunId } = await this.resolveTriggerDepth(client, owner, ref);
                if (depth > MAX_TRIGGER_DEPTH) {
                    console.error(JSON.stringify({
                        event: 'automation_recursion_limit', ruleId, owner, ontology: model.document.id,
                        objectRef: ref, parentWorkflowRunId: parentRunId, triggerDepth: depth, maxTriggerDepth: MAX_TRIGGER_DEPTH,
                        trigger: 'onRemoved',
                    }));
                }
                else {
                    const fingerprint = digest([ruleId, revision, ref, generation, 'removed']);
                    const requestId = 'rule:' + fingerprint;
                    const inserted = await this.db.query(`INSERT INTO ${this.db.schema}.workflow_runs(id,owner,ontology,release,request_id,digest,workflow_id,body,object_ref,scopes,trigger_depth) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) ON CONFLICT(owner,request_id) DO NOTHING RETURNING id`, [
                        randomUUID(),
                        owner,
                        model.document.id,
                        model.release,
                        requestId,
                        fingerprint,
                        input.workflow,
                        body,
                        ref,
                        encodePrincipalScopes(access.principal),
                        depth,
                    ], client);
                    if (inserted.rowCount)
                        enqueued = true;
                }
                await this.db.query(`UPDATE ${this.db.schema}.rule_matches SET matched=false,generation=$4 WHERE rule_id=$1 AND type=$2 AND id=$3`, [ruleId, item.type, item.id, generation], client);
            }
            else if (item.matched) {
                await this.db.query(`UPDATE ${this.db.schema}.rule_matches SET matched=false WHERE rule_id=$1 AND type=$2 AND id=$3`, [ruleId, item.type, item.id], client);
            }
        }
        if (candidates && matched.size) {
            const { rows: [count] } = await this.db.query(`SELECT count(*)::int AS n FROM ${this.db.schema}.rule_matches WHERE rule_id=$1 AND matched`, [ruleId], client);
            if (count.n > limit)
                throw new Conflict('Rule matches more than ' + limit + ' objects');
        }
        if (enqueued)
            await this.db.query("SELECT pg_notify('eigos_automation','run')", [], client);
    }
    async visibleProcessRun(graph, object, trigger) {
        const log = await matchingTransition(graph, trigger.process, trigger.sequence);
        if (!log)
            return false;
        if (!trigger.relatedPath)
            return true;
        const type = processLogTarget(graph.model, trigger.process.type)?.objectType;
        if (!type || typeof log.properties.processId !== 'string')
            return false;
        try {
            const targets = await relatedProcessObjects(graph, { type, id: log.properties.processId }, trigger.relatedPath);
            return targets.some(ref => ref.type === object.type && ref.id === object.id);
        }
        catch (error) {
            if (error instanceof NotFound || error instanceof PermissionDenied)
                return false;
            throw error;
        }
    }
    async scanProcess(graph, ruleId, revision, position, input, body) {
        const { access, client, model, owner } = graph;
        const target = processTarget(graph, input.process);
        // Reading in commit order cannot pass a transition that commits later, so the scan does not block writers.
        const { transitions: page, position: next } = await readCommittedTransitions(this.db, model, owner, target, client, position, 100);
        const related = 'effect' in input ? input.effect.related : undefined;
        if ('effect' in input && related)
            this.relatedContract(graph, target.objectType, target.type, input.effect.action, related, input.effect.input);
        let enqueued = false;
        for (const item of page) {
            const log = await matchingTransition(graph, input.process, item.sequence);
            if (!log)
                continue;
            const source = { type: target.objectType, id: item.objectId };
            const { depth, parentRunId } = await this.resolveTriggerDepth(client, owner, source, item.sequence);
            if (depth > MAX_TRIGGER_DEPTH) {
                console.error(JSON.stringify({
                    event: 'automation_recursion_limit', ruleId, owner, ontology: model.document.id,
                    objectRef: source, sequence: item.sequence, parentWorkflowRunId: parentRunId,
                    triggerDepth: depth, maxTriggerDepth: MAX_TRIGGER_DEPTH,
                }));
                continue;
            }
            const trigger = {
                ruleId, revision, sequence: item.sequence, process: input.process,
                ...(related ? { relatedPath: related.path } : {}),
            };
            let targets = [source];
            if (related) {
                try {
                    targets = await relatedProcessObjects(graph, source, related.path);
                }
                catch (error) {
                    if (error instanceof NotFound)
                        continue;
                    throw error;
                }
            }
            const availableAt = new Date(item.recordedAt.getTime() + (input.process.dwellSeconds ?? 0) * 1000);
            for (const object of targets) {
                const fingerprint = digest(related ? [trigger, object] : trigger);
                if ('notify' in input) {
                    await queueNotification(this.db, client, { owner, ontology: model.document.id, ruleId, requestId: 'process-rule:' + fingerprint,
                        object, trigger, scopes: access.principal.scopes, message: input.notify.message, availableAt });
                    continue;
                }
                const bound = related ? {
                    ...body, steps: [{
                            ...body.steps[0], input: {
                                ...body.steps[0].input,
                                [related.sourceParameter]: { literal: source },
                                [related.transitionParameter]: { literal: log.ref },
                                [related.targetParameter]: { literal: object },
                            },
                        }],
                } : body;
                const inserted = await this.db.query(`INSERT INTO ${this.db.schema}.workflow_runs(id,owner,ontology,release,request_id,digest,workflow_id,body,object_ref,scopes,available_at,process_trigger,trigger_depth)
            VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13) ON CONFLICT(owner,request_id) DO NOTHING RETURNING id`, [randomUUID(), owner, model.document.id, model.release, 'process-rule:' + fingerprint, fingerprint, 'workflow' in input ? input.workflow : null,
                    bound, object, encodePrincipalScopes(access.principal), availableAt, trigger, depth], client);
                if (inserted.rowCount)
                    enqueued = true;
            }
        }
        if (enqueued)
            await this.db.query("SELECT pg_notify('eigos_automation','run')", [], client);
        if (next.commit !== position.commit || next.sequence !== position.sequence)
            await this.db.query(`UPDATE ${this.db.schema}.object_rules SET process_commit=$2,process_cursor=$3 WHERE id=$1`, [ruleId, next.commit, next.sequence], client);
    }
    async verifyProcessTrigger(graph, object, trigger, firstStep) {
        const { access, client, model, owner } = graph;
        await this.db.setOwner(client, owner);
        const current = await this.db.query(`SELECT 1 FROM ${this.db.schema}.object_rules WHERE id=$1 AND owner=$2 AND ontology=$3 AND revision=$4 AND enabled FOR SHARE`, [trigger.ruleId, owner, model.document.id, trigger.revision], client);
        if (!current.rowCount)
            throw new ProcessTriggerInactive('Process rule changed or was disabled');
        const target = processTarget(graph, trigger.process);
        // The rule lock comes before the owner write lock; scans and rule updates take only the rule lock.
        await graph.lockWrites();
        const log = await matchingTransition(graph, trigger.process, trigger.sequence);
        if (!log || typeof log.properties.processId !== 'string')
            throw new PermissionDenied('The triggering process transition is unavailable');
        const source = { type: target.objectType, id: log.properties.processId };
        if (trigger.relatedPath) {
            const targets = await relatedProcessObjects(graph, source, trigger.relatedPath);
            if (!targets.some(ref => ref.type === object.type && ref.id === object.id))
                throw new ProcessTriggerInactive('Related object no longer matches this process rule');
        }
        else if (source.type !== object.type || source.id !== object.id) {
            throw new PermissionDenied('The triggering process transition is unavailable');
        }
        if (firstStep && (trigger.relatedPath || trigger.process.dwellSeconds)) {
            const [latest] = await readProcessTransitions(this.db, model, owner, target, client, { latestFor: source.id });
            const current = await graph.read(source);
            if (latest?.sequence !== trigger.sequence || current.properties[target.property] !== log.properties.newState)
                throw new ProcessTriggerInactive('A later transition ended the state before the workflow could start');
        }
        // A trigger can depend on a historically marked state even after the live object has been cleared.
        const history = (await this.db.query(`SELECT before_values,after_values FROM ${this.db.schema}.edit_history WHERE owner=$1 AND sequence=$2 AND type=$3 AND id=$4`, [owner, trigger.sequence, source.type, source.id], client)).rows[0];
        for (const snapshot of [history.before_values, history.after_values])
            if (snapshot)
                access.readRow(model, source.type, snapshot);
    }
    async runOne(signal = AbortSignal.timeout(120000)) {
        signal.throwIfAborted();
        const token = randomUUID();
        const claim = await this.db.transaction(async (client) => {
            const deadLettered = await this.db.query(`WITH dead AS (
          SELECT id FROM ${this.db.schema}.workflow_runs
          WHERE state='working' AND lease_until<now() AND attempts>=max_attempts
          FOR UPDATE SKIP LOCKED LIMIT 100
        )
        UPDATE ${this.db.schema}.workflow_runs r
        SET state='failed',
            error='Workflow run exceeded max attempts after lease expiration (dead-lettered)',
            token=NULL,lease_until=NULL,updated_at=now()
        FROM dead WHERE r.id=dead.id
        RETURNING r.id,r.owner,r.ontology,r.proposal_task`, [], client);
            for (const dead of deadLettered.rows) {
                if (dead.proposal_task)
                    await this.cancelProposalTask(client, dead.owner, dead.proposal_task);
                console.error(JSON.stringify({
                    event: 'workflow_run_dead_letter', workflowRunId: dead.id, owner: dead.owner,
                    ontology: dead.ontology, reason: 'max_attempts_exceeded_after_lease_expiration',
                }));
            }
            const found = (await this.db.query(`SELECT r.* FROM ${this.db.schema}.workflow_runs r
            WHERE (r.state='pending' AND r.available_at<=now())
              OR (r.state='working' AND r.lease_until<now() AND r.attempts<r.max_attempts)
              OR (r.state='waiting-proposal' AND EXISTS (
                SELECT 1 FROM ${this.db.schema}.tasks task WHERE task.id=r.proposal_task
                AND task.state IN ('completed','failed','canceled')))
              OR (r.state IN ('waiting-proposal','waiting-approval') AND r.proposal_deadline<=now())
            ORDER BY
              (SELECT count(*) FROM ${this.db.schema}.workflow_runs active WHERE active.owner=r.owner AND active.state='working' AND active.lease_until>=now()),
              COALESCE((SELECT max(recent.updated_at) FROM ${this.db.schema}.workflow_runs recent WHERE recent.owner=r.owner AND recent.attempts>0), '-infinity'::timestamptz),
              r.created_at,r.id
            FOR UPDATE OF r SKIP LOCKED LIMIT 1`, [], client)).rows[0];
            if (!found)
                return undefined;
            const claimed = (await this.db.query(`UPDATE ${this.db.schema}.workflow_runs
          SET state='working',token=$2,lease_until=now()+interval '150 seconds',
              attempts=CASE WHEN state IN ('pending','working') THEN attempts+1 ELSE attempts END,
              updated_at=clock_timestamp()
          WHERE id=$1 RETURNING updated_at,attempts,max_attempts`, [found.id, token], client)).rows[0];
            return { row: { ...found, attempts: claimed.attempts, max_attempts: claimed.max_attempts }, claimedAt: claimed.updated_at };
        });
        if (!claim)
            return false;
        const { row, claimedAt } = claim, correlation = { workflowRunId: String(row.id), attemptId: token };
        const availableAt = row.available_at instanceof Date ? row.available_at : undefined;
        console.info(JSON.stringify({
            event: 'workflow_claim', ...correlation, runCreatedAt: new Date(row.created_at).toISOString(),
            runAvailableAt: availableAt?.toISOString(), claimedAt: claimedAt.toISOString(),
            queuedMs: availableAt ? claimedAt.getTime() - availableAt.getTime() : undefined,
        }));
        const started = performance.now();
        let profile;
        try {
            await this.db.withOwner(String(row.owner), () => withOperationTiming(correlation, () => profileDatabase(measured => { profile = measured; return this.executeRun(row, token, signal); })));
        }
        finally {
            console.info(JSON.stringify({
                event: 'workflow_finish', ...correlation, finishedAt: new Date().toISOString(),
                durationMs: Math.round(performance.now() - started), db: profile && profileSummary(profile),
            }));
        }
        return true;
    }
    async executeRun(row, token, signal) {
        const executionSignal = AbortSignal.any([signal, AbortSignal.timeout(120000)]);
        const guard = async (client) => {
            executionSignal.throwIfAborted();
            if (!(await this.db.query(`SELECT 1 FROM ${this.db.schema}.workflow_runs WHERE id=$1 AND token=$2 AND state='working' AND lease_until>now() FOR UPDATE`, [row.id, token], client)).rowCount)
                throw new Conflict('Workflow execution lease ended');
        };
        try {
            if (Number(row.trigger_depth ?? 0) > MAX_TRIGGER_DEPTH) {
                throw new Conflict(`Workflow recursion limit exceeded (depth ${Number(row.trigger_depth)} > ${MAX_TRIGGER_DEPTH})`);
            }
            const model = await this.metadata.get(row.release), access = await Access.load(this.db, decodePrincipal(String(row.owner), row.scopes));
            requireScope(access.principal, 'ontology:write');
            const { steps, proposal } = workflowSchema.parse(row.body);
            const trigger = row.process_trigger ? processTriggerSchema.parse(row.process_trigger) : undefined;
            const triggeringObject = objectRefSchema.parse(row.object_ref);
            for (let position = Number(row.step); position < steps.length; position++) {
                const item = steps[position], requestId = 'workflow:' + row.id + ':' + position;
                const frozen = await this.db.transaction(async (client) => {
                    await guard(client);
                    await this.active(model, client);
                    await access.refresh(client);
                    const prior = (await this.db.query(`SELECT * FROM ${this.db.schema}.workflow_steps WHERE run_id=$1 AND position=$2`, [row.id, position], client)).rows[0];
                    if (prior)
                        return prior;
                    const graph = new Objects(this.db, model, access, client);
                    let object;
                    try {
                        object = await graph.read(triggeringObject);
                    }
                    catch (error) {
                        if (!(error instanceof NotFound) ||
                            trigger ||
                            triggeringObject.type === documentChunkType ||
                            processLogTarget(model, triggeringObject.type)) {
                            throw error;
                        }
                        access.read(model, triggeringObject.type);
                        const tombstone = (await this.db.query(`SELECT h.before_values,h.after_values
                  FROM ${this.db.schema}.edit_history h JOIN ${this.db.schema}.releases r ON r.digest=h.release
                  WHERE r.body->>'id'=$1 AND h.owner=$2 AND h.type=$3 AND h.id=$4
                  ORDER BY h.sequence DESC LIMIT 1`, [model.document.id, row.owner, triggeringObject.type, triggeringObject.id], client)).rows[0];
                        if (!tombstone || tombstone.after_values !== null)
                            throw error;
                        let lastProperties = tombstone.before_values;
                        if (!lastProperties) {
                            const priorSnapshot = (await this.db.query(`SELECT COALESCE(h.after_values,h.before_values) AS snapshot
                    FROM ${this.db.schema}.edit_history h JOIN ${this.db.schema}.releases r ON r.digest=h.release
                    WHERE r.body->>'id'=$1 AND h.owner=$2 AND h.type=$3 AND h.id=$4
                      AND (h.after_values IS NOT NULL OR h.before_values IS NOT NULL)
                    ORDER BY h.sequence DESC LIMIT 1`, [model.document.id, row.owner, triggeringObject.type, triggeringObject.id], client)).rows[0];
                            lastProperties = priorSnapshot?.snapshot ?? null;
                        }
                        let properties = {};
                        if (lastProperties) {
                            const masked = access.maskHistoricalSnapshot(model, triggeringObject.type, lastProperties);
                            if (!masked)
                                throw new PermissionDenied('Object policy denied access');
                            properties = masked;
                        }
                        object = { ref: triggeringObject, revision: 0, properties };
                    }
                    this.authorize(access, model, [item]);
                    const previousResults = new Map();
                    for (const binding of Object.values(item.input)) {
                        if (!('step' in binding) || previousResults.has(binding.step))
                            continue;
                        const previousPosition = steps.findIndex(candidate => candidate.name === binding.step);
                        if (previousPosition < 0 || previousPosition >= position) {
                            throw new Conflict('Step binding must reference a prior step');
                        }
                        const receipt = (await this.db.query(`SELECT s.action,s.input,s.result,s.request_id,a.digest,a.result AS committed_result FROM ${this.db.schema}.workflow_steps s
               JOIN ${this.db.schema}.actions a ON a.owner=$3 AND a.request_id=s.request_id
               WHERE s.run_id=$1 AND s.position=$2 AND s.result IS NOT NULL AND s.completed_at IS NOT NULL`, [row.id, previousPosition, row.owner], client)).rows[0];
                        if (!receipt || receipt.digest !== digest({ release: model.release, action: receipt.action, input: receipt.input })) {
                            throw new Conflict('Prior workflow step has no committed result');
                        }
                        if (digest(receipt.result) !== digest(receipt.committed_result)) {
                            throw new Conflict('Prior workflow step result differs from its Action receipt');
                        }
                        const reference = objectRefSchema.parse(receipt.committed_result);
                        await graph.read(reference);
                        previousResults.set(binding.step, reference);
                    }
                    const input = bindWorkflowInput(item, object, previousResults);
                    const validated = validator(model.action(item.action).parameters).parse(input);
                    if (JSON.stringify(validated).length > 64000)
                        throw new Conflict('Workflow step input exceeds 64000 characters');
                    await access.refresh(client);
                    return (await this.db.query(`INSERT INTO ${this.db.schema}.workflow_steps(run_id,position,action,input,requirements,request_id,read_markings) VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING *`, [
                        row.id,
                        position,
                        item.action,
                        validated,
                        JSON.stringify(await access.finalDataRequirements(client)),
                        requestId,
                        JSON.stringify(access.readMarkingsSnapshot()),
                    ], client)).rows[0];
                });
                const committed = (await this.db.query(`SELECT digest,result FROM ${this.db.schema}.actions WHERE owner=$1 AND request_id=$2`, [row.owner, requestId])).rows[0];
                let result;
                if (committed) {
                    if (committed.digest !==
                        digest({ release: model.release, action: frozen.action, input: frozen.input }))
                        throw new Conflict('Workflow Action receipt has different input');
                    result = objectRefSchema.parse(committed.result);
                }
                else {
                    if (frozen.read_markings === null || frozen.read_markings === undefined) {
                        throw new MissingFrozenSecurityContext(missingSecurityContextMessage);
                    }
                    const markings = z.array(z.string()).parse(frozen.read_markings);
                    await access.restoreReads(frozen.requirements, markings);
                    if (trigger)
                        await this.db.transaction(async (client) => {
                            await guard(client);
                            await this.verifyProcessTrigger(new Objects(this.db, model, access, client), triggeringObject, trigger, position === 0);
                        });
                    const boundResults = Object.entries(item.input)
                        .filter(([, binding]) => 'step' in binding)
                        .map(([parameter]) => objectRefSchema.parse(frozen.input[parameter]));
                    for (const reference of boundResults)
                        await new Objects(this.db, model, access).read(reference);
                    let checkedInputs = false;
                    let checkedTransaction;
                    const checkCommit = async (client) => {
                        await guard(client);
                        const transaction = trigger ? String((await this.db.query('SELECT pg_current_xact_id()::text AS id', [], client)).rows[0].id) : undefined;
                        // Authorize before edits under the write lock; a valid Action may subsequently delete its input.
                        if (!checkedInputs || checkedTransaction !== transaction) {
                            const graph = new Objects(this.db, model, access, client);
                            if (trigger)
                                await this.verifyProcessTrigger(graph, triggeringObject, trigger, position === 0);
                            else
                                await graph.lockWrites();
                            await access.restoreReads(frozen.requirements, markings, client);
                            for (const reference of boundResults)
                                await graph.read(reference);
                            checkedInputs = true;
                            checkedTransaction = transaction;
                        }
                        await this.db.query(`UPDATE ${this.db.schema}.workflow_steps SET requirements=$3,read_markings=$4 WHERE run_id=$1 AND position=$2`, [
                            row.id,
                            position,
                            JSON.stringify(await access.finalDataRequirements(client)),
                            JSON.stringify(access.readMarkingsSnapshot()),
                        ], client);
                    };
                    const commitGuard = (client) => trigger && client === this.db.pool ? this.db.transaction(checkCommit) : checkCommit(client);
                    const apply = () => this.actions.apply(access, model, frozen.action, frozen.input, requestId, commitGuard, undefined, executionSignal, { kind: 'workflow', id: String(row.id) });
                    result = await (trigger?.relatedPath ? withoutExternalDispatch(apply) : apply());
                }
                await this.db.transaction(async (client) => {
                    await guard(client);
                    await this.active(model, client);
                    await this.db.query(`UPDATE ${this.db.schema}.workflow_steps SET result=$3,completed_at=now() WHERE run_id=$1 AND position=$2`, [row.id, position, result], client);
                    await this.db.query(`UPDATE ${this.db.schema}.workflow_runs SET step=$3,results=results||$4::jsonb,updated_at=now() WHERE id=$1 AND token=$2 AND state='working'`, [row.id, token, position + 1, JSON.stringify([{ step: item.name, object: result }])], client);
                });
            }
            if (proposal) {
                await this.runProposal(row, token, model, access, proposal, triggeringObject, trigger, guard);
                return;
            }
            await this.db.transaction(async (client) => {
                await guard(client);
                await this.active(model, client);
                await this.db.query(`UPDATE ${this.db.schema}.workflow_runs SET state='completed',token=NULL,lease_until=NULL,error=NULL,updated_at=now() WHERE id=$1 AND token=$2`, [row.id, token], client);
            });
        }
        catch (error) {
            const diag = errorDiagnostic(error);
            const attempts = Number(row.attempts ?? 1);
            const maxAttempts = Number(row.max_attempts ?? 3);
            const transient = !signal.aborted && isTransientError(error)
                && !(error instanceof ProcessTriggerInactive)
                && !(error instanceof MissingFrozenSecurityContext);
            const willRetry = transient && attempts < maxAttempts;
            console.error(JSON.stringify({
                event: 'workflow_run_error', workflowRunId: String(row.id), attemptId: token,
                owner: String(row.owner), ontology: String(row.ontology), step: Number(row.step ?? 0),
                attempts, maxAttempts, transient, willRetry,
                errorName: diag.name, errorCode: diag.code, message: diag.message,
            }));
            const storedError = error instanceof ProcessTriggerInactive || error instanceof MissingFrozenSecurityContext
                ? error.message : `${failureMessage} [${diag.summary}]`;
            await this.db.transaction(async (client) => {
                if (willRetry) {
                    const backoffSeconds = retryBackoffSeconds(attempts);
                    await this.db.query(`UPDATE ${this.db.schema}.workflow_runs
              SET state='pending',available_at=now()+$3::int*interval '1 second',error=$4,token=NULL,lease_until=NULL,updated_at=now()
              WHERE id=$1 AND token=$2 AND state='working'`, [row.id, token, backoffSeconds, storedError], client);
                    return;
                }
                const ended = (await this.db.query(`UPDATE ${this.db.schema}.workflow_runs SET state=$3,error=$4,token=NULL,lease_until=NULL,updated_at=now()
            WHERE id=$1 AND token=$2 AND state='working' RETURNING owner,proposal_task`, [row.id, token, error instanceof ProcessTriggerInactive ? 'canceled' : 'failed', storedError], client)).rows[0];
                if (ended?.proposal_task)
                    await this.cancelProposalTask(client, ended.owner, ended.proposal_task);
            });
        }
    }
    async runProposal(row, token, model, access, proposal, object, trigger, guard) {
        await this.db.transaction(async (client) => {
            await guard(client);
            const status = row.proposal_task ? (await this.db.query(`SELECT task.state,task.result,task.result_permissions,run.proposal_deadline<=clock_timestamp() AS expired,
            scenario.revision,scenario.state AS scenario_state
          FROM ${this.db.schema}.workflow_runs run JOIN ${this.db.schema}.tasks task ON task.id=run.proposal_task AND task.owner=run.owner
          LEFT JOIN ${this.db.schema}.scenarios scenario ON scenario.id=run.proposal_scenario AND scenario.owner=run.owner
          WHERE run.id=$1 AND run.token=$2`, [row.id, token], client)).rows[0] : undefined;
            if (row.proposal_task && !status)
                throw new Conflict('Workflow proposal task is unavailable');
            // Closing an expired proposal is lifecycle work. It must survive revoked execution access.
            if (status && (status.expired || !status.scenario_state)) {
                await this.finishProposal(client, row, token, model, 'expired');
                return;
            }
            await this.active(model, client);
            await access.refresh(client);
            authorizeCognitive(access, model, proposal);
            const owner = access.principal.owner;
            const graph = new Objects(this.db, model, access, client);
            if (!status) {
                if (trigger)
                    await this.verifyProcessTrigger(graph, object, trigger, row.body.steps.length === 0);
                const taskId = randomUUID(), requestId = 'workflow-proposal:' + row.id;
                const { reviewers, timeoutSeconds, mergeAction: _mergeAction, mergeObjectParameter: _mergeObjectParameter, ...manifest } = proposal;
                const scenario = await new Scenarios(this.db).create(access, model, {
                    requestId, name: proposal.name, ttlSeconds: timeoutSeconds,
                }, undefined, { client, runId: row.id, reviewers });
                workflowMerge(model, proposal, object, scenario.id, scenario.revision);
                const input = await graph.read(object);
                const context = cognitiveContextSchema.parse({
                    ...manifest, runId: row.id, scenarioId: scenario.id, object, revision: input.revision,
                });
                const taskInput = { requestId, message: proposal.goal, ...(access.principal.memberAccess ? { memberAccess: true } : {}) };
                await this.db.query(`INSERT INTO ${this.db.schema}.tasks(id,owner,request_id,input_digest,input,release,scopes,cognitive_context,cognitive_evidence)
            VALUES($1,$2,$3,$4,$5,$6,$7,$8,'[]'::jsonb)`, [taskId, owner, requestId, digest(taskInput), taskInput, model.release, JSON.stringify(access.principal.scopes), context], client);
                await this.db.query(`UPDATE ${this.db.schema}.workflow_runs SET state='waiting-proposal',proposal_task=$2,proposal_scenario=$3,
            proposal_deadline=$4,token=NULL,lease_until=NULL,updated_at=now() WHERE id=$1`, [row.id, taskId, scenario.id, scenario.expiresAt], client);
                await appendTrace(this.db, { owner, taskId, scenarioId: scenario.id, release: model.release, projection: model.projection }, { kind: 'proposal' }, client, await access.finalDataRequirements(client));
                await this.db.query("SELECT pg_notify('eigos_tasks','ready')", [], client);
                return;
            }
            const result = cognitiveResultSchema.safeParse(status.result?.proposal);
            const ready = status.scenario_state === 'open' && status.state === 'completed'
                && result.success && result.data.scenarioId === row.proposal_scenario && result.data.revision === Number(status.revision)
                && status.result_permissions && await access.canReturn(status.result_permissions, client);
            await this.finishProposal(client, row, token, model, ready ? 'waiting-approval' : 'failed', await access.finalDataRequirements(client));
        });
    }
    async finishProposal(client, row, token, model, state, requirements = []) {
        if (state !== 'waiting-approval')
            await this.cancelProposalTask(client, row.owner, row.proposal_task);
        await appendTrace(this.db, { owner: row.owner, taskId: row.proposal_task, release: model.release, projection: model.projection }, { kind: 'workflow', runId: row.id, state }, client, requirements);
        await this.db.query(`UPDATE ${this.db.schema}.workflow_runs SET state=$3,error=$4,token=NULL,lease_until=NULL,updated_at=now() WHERE id=$1 AND token=$2`, [row.id, token, state, state === 'expired' ? 'Workflow proposal expired'
                : state === 'failed' ? 'Workflow proposal did not complete with a valid Scenario' : null], client);
    }
    async cancelProposalTask(client, owner, taskId) {
        await this.db.query(`UPDATE ${this.db.schema}.tasks SET state='canceled',token=NULL,lease_until=NULL,updated_at=now()
        WHERE owner=$1 AND id=$2 AND state IN ('submitted','working','input-required')`, [owner, taskId], client);
    }
    async retry(access, model, id) {
        requireScope(access.principal, 'ontology:write');
        z.uuid().parse(id);
        await access.refresh();
        return this.db.transaction(async (client) => {
            await this.active(model, client);
            const row = (await this.db.query(`SELECT * FROM ${this.db.schema}.workflow_runs WHERE id=$1 AND owner=$2 AND ontology=$3 AND state='failed' AND proposal_task IS NULL FOR UPDATE`, [id, access.principal.owner, model.document.id], client)).rows[0];
            if (!row)
                throw new NotFound('Failed workflow is unavailable');
            if (row.release !== model.release)
                throw new Conflict('Workflow retry requires its original active publication');
            this.authorize(access, model, workflowSchema.parse(row.body).steps.slice(Number(row.step)));
            await access.refresh(client);
            await this.db.query(`UPDATE ${this.db.schema}.workflow_runs SET state='pending',attempts=0,available_at=now(),error=NULL,token=NULL,lease_until=NULL,updated_at=now() WHERE id=$1`, [id], client);
            await this.db.query("SELECT pg_notify('eigos_automation','run')", [], client);
            return { id, state: 'pending' };
        });
    }
    async cancel(access, model, id) {
        requireScope(access.principal, 'ontology:write');
        z.uuid().parse(id);
        await access.refresh();
        return this.db.transaction(async (client) => {
            const row = (await this.db.query(`SELECT * FROM ${this.db.schema}.workflow_runs WHERE id=$1 AND owner=$2 AND ontology=$3 FOR UPDATE`, [id, access.principal.owner, model.document.id], client)).rows[0];
            if (!row)
                throw new NotFound('Workflow run is unavailable');
            if (row.state === 'completed')
                throw new Conflict('Completed workflow cannot be canceled');
            if (row.proposal_task)
                await this.cancelProposalTask(client, access.principal.owner, row.proposal_task);
            let completed = Number(row.step);
            const results = row.results;
            const receipts = (await this.db.query(`SELECT s.position,s.action,s.input,a.digest,a.result FROM ${this.db.schema}.workflow_steps s
        JOIN ${this.db.schema}.actions a ON a.owner=$2 AND a.request_id=s.request_id
        WHERE s.run_id=$1 AND s.position>=$3 ORDER BY s.position`, [id, access.principal.owner, completed], client)).rows;
            for (const receipt of receipts) {
                if (Number(receipt.position) !== completed ||
                    receipt.digest !== digest({ release: row.release, action: receipt.action, input: receipt.input }))
                    break;
                const result = objectRefSchema.parse(receipt.result);
                await this.db.query(`UPDATE ${this.db.schema}.workflow_steps SET result=$3,completed_at=coalesce(completed_at,now()) WHERE run_id=$1 AND position=$2`, [id, completed, result], client);
                results.push({ step: row.body.steps[completed].name, object: result });
                completed++;
            }
            await this.db.query(`UPDATE ${this.db.schema}.workflow_runs SET state='canceled',step=$2,results=$3,token=NULL,lease_until=NULL,error=NULL,updated_at=now() WHERE id=$1`, [id, completed, JSON.stringify(results)], client);
            await access.refresh(client);
            return { id, state: 'canceled', step: completed };
        });
    }
}
