/** Pure UI/browser assets (CSS, HTML, workbench frontend) do not affect Ontology runtime semantics. */
export declare function isRuntimeImplementationPath(relativePath: string): boolean;
/** Computes the runtime implementation digest for a workspace root directory. */
export declare function computeImplementationDigest(root: string): string;
/** Identity of the shipped runtime implementation inputs, identical in source and built execution. */
export declare function implementationDigest(): string;
