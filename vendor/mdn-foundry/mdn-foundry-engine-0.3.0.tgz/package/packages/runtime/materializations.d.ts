import { z } from 'zod';
import type { ObjectData } from '../ontology/schema.js';
import type { Database } from './database.js';
import type { Access } from './access.js';
import type { PublishedOntology } from './metadata.js';
export interface MaterializedObjectProvenance {
    revision: number;
    historySequence?: string;
    operation?: string;
    source?: string;
    requestId?: string;
    taskId?: string;
    indexTx?: string;
    observedAt?: string;
    release?: string;
}
export type MaterializedObjectData = ObjectData & {
    provenance?: MaterializedObjectProvenance;
};
export declare const materializationInputSchema: z.ZodObject<{
    requestId: z.ZodString;
    name: z.ZodString;
    types: z.ZodArray<z.ZodString>;
}, z.core.$strict>;
export declare function initializeMaterializations(db: Database): Promise<void>;
export declare class Materializations {
    private readonly db;
    constructor(db: Database);
    private header;
    capture(access: Access, model: PublishedOntology, raw: unknown): Promise<{
        id: string;
    }>;
    read(access: Access, model: PublishedOntology, id: string, cursor?: string): Promise<{
        id: string;
        name: any;
        release: any;
        capturedAt: any;
        items: MaterializedObjectData[];
        cursor: string | undefined;
    }>;
    links(access: Access, model: PublishedOntology, id: string, after?: number): Promise<{
        items: {
            type: string;
            from: {
                type: string;
                id: string;
            };
            to: {
                type: string;
                id: string;
            };
        }[];
        cursor: number | undefined;
    }>;
}
