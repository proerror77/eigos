import { createHash } from 'node:crypto';
import { existsSync, readFileSync, readdirSync } from 'node:fs';
import { dirname, join, relative } from 'node:path';
import { fileURLToPath } from 'node:url';
let cached;
/** Pure UI/browser assets (CSS, HTML, workbench frontend) do not affect Ontology runtime semantics. */
export function isRuntimeImplementationPath(relativePath) {
    const normalized = relativePath.replaceAll('\\', '/');
    if (normalized.startsWith('apps/workbench/'))
        return false;
    return /\.(ts|json|js)$/.test(normalized);
}
/** Computes the runtime implementation digest for a workspace root directory. */
export function computeImplementationDigest(root) {
    const paths = ['package.json', 'package-lock.json', 'tsconfig.json'];
    const visit = (path) => {
        if (!existsSync(path))
            return;
        for (const entry of readdirSync(path, { withFileTypes: true })) {
            const child = join(path, entry.name);
            if (entry.isDirectory())
                visit(child);
            else {
                const rel = relative(root, child);
                if (isRuntimeImplementationPath(rel))
                    paths.push(rel);
            }
        }
    };
    visit(join(root, 'apps'));
    visit(join(root, 'packages'));
    const hash = createHash('sha256');
    for (const path of paths.sort()) {
        hash.update(path);
        hash.update('\0');
        hash.update(readFileSync(join(root, path)));
        hash.update('\0');
    }
    return hash.digest('hex');
}
/** Identity of the shipped runtime implementation inputs, identical in source and built execution. */
export function implementationDigest() {
    if (cached)
        return cached;
    let root = fileURLToPath(new URL('../../', import.meta.url));
    const artifact = join(root, 'implementation.json');
    if (existsSync(artifact))
        return cached = JSON.parse(readFileSync(artifact, 'utf8')).digest;
    if (!existsSync(join(root, 'package.json')))
        root = dirname(root);
    return cached = computeImplementationDigest(root);
}
