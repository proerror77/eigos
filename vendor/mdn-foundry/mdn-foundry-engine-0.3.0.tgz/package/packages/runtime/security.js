import pg from 'pg';
import { z } from 'zod';
import { digest } from '../core/identity.js';
import { initializeModelEgress } from './model-egress.js';
const securityEpochTables = [
    'resource_grants',
    'property_security',
    'object_policies',
    'security_memberships',
    'ontology_resource_projects',
    'accounts',
];
const localSecurityGenerations = new WeakMap();
export function getSecurityCacheGeneration(db) {
    return localSecurityGenerations.get(db) ?? 0;
}
export function notifySecurityCacheInvalidated(db) {
    localSecurityGenerations.set(db, (localSecurityGenerations.get(db) ?? 0) + 1);
}
export async function attachSecurityEpochTrigger(db, table) {
    if (!/^[a-z_][a-z0-9_]*$/.test(table))
        throw new Error(`Invalid table name: ${table}`);
    const s = db.schema;
    const rel = pg.escapeLiteral(`${s}.${table}`);
    const fn = pg.escapeLiteral(`${s}.bump_security_epoch()`);
    const createTrigger = pg.escapeLiteral(`CREATE TRIGGER eigos_bump_security_epoch AFTER INSERT OR UPDATE OR DELETE OR TRUNCATE ON ${s}.${table} FOR EACH STATEMENT EXECUTE FUNCTION ${s}.bump_security_epoch()`);
    await db.query(`DO $sec$
  DECLARE
    rel_oid regclass := to_regclass(${rel});
    fn_oid regprocedure := to_regprocedure(${fn});
  BEGIN
    IF rel_oid IS NOT NULL AND fn_oid IS NOT NULL
       AND NOT EXISTS (
         SELECT 1 FROM pg_trigger
         WHERE tgrelid = rel_oid AND tgname = 'eigos_bump_security_epoch' AND NOT tgisinternal
       ) THEN
      EXECUTE ${createTrigger};
    END IF;
  END $sec$;`);
}
export async function bumpSecurityEpoch(db, client) {
    const s = db.schema;
    const seq = pg.escapeLiteral(`${s}.security_epoch_seq`);
    const rawSchema = pg.escapeLiteral(s.slice(1, -1));
    const result = await db.query(`WITH bumped AS (
      INSERT INTO ${s}.security_epoch(singleton, epoch)
        VALUES (true, nextval(${seq}))
      ON CONFLICT (singleton) DO UPDATE
        SET epoch = nextval(${seq})
      RETURNING epoch
    ), notified AS (
      SELECT pg_notify('eigos_security_epoch', ${rawSchema} || ':' || epoch::text) FROM bumped
    )
    SELECT epoch::text AS epoch FROM bumped`, [], client);
    notifySecurityCacheInvalidated(db);
    return result.rows[0].epoch;
}
const scalar = z.union([z.string(), z.number(), z.boolean(), z.null()]);
const condition = z.discriminatedUnion('op', [
    z.strictObject({ op: z.literal('equals'), property: z.string().min(1), value: scalar }),
    z.strictObject({ op: z.literal('subject'), property: z.string().min(1) }),
    z.strictObject({ op: z.literal('member'), property: z.string().min(1) }),
]);
export const expressionSchema = z.strictObject({ all: z.array(condition).max(20).default([]), any: z.array(condition).max(20).default([]) });
export const objectPolicySchema = z.strictObject({
    read: expressionSchema.optional(),
    properties: z.record(z.string(), expressionSchema).default({}),
    markingsProperty: z.string().optional(),
});
export async function initializeSecurity(db) {
    const s = db.schema;
    const seqLiteral = pg.escapeLiteral(`${s}.security_epoch_seq`);
    const rawSchemaLiteral = pg.escapeLiteral(s.slice(1, -1));
    await db.query(`CREATE TABLE IF NOT EXISTS ${s}.security_memberships (
    subject text NOT NULL, kind text NOT NULL CHECK(kind IN ('group','marking')), name text NOT NULL, PRIMARY KEY(subject,kind,name));
    CREATE TABLE IF NOT EXISTS ${s}.object_policies (
    ontology text NOT NULL, type text NOT NULL, policy jsonb NOT NULL, PRIMARY KEY(ontology,type));
    CREATE SEQUENCE IF NOT EXISTS ${s}.security_epoch_seq START 2;
    CREATE TABLE IF NOT EXISTS ${s}.security_epoch (
      singleton boolean PRIMARY KEY DEFAULT true CHECK (singleton),
      epoch bigint NOT NULL DEFAULT 1
    );
    INSERT INTO ${s}.security_epoch(singleton) VALUES (true) ON CONFLICT DO NOTHING;
    GRANT SELECT ON ${s}.security_epoch TO PUBLIC;
    CREATE OR REPLACE FUNCTION ${s}.bump_security_epoch() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog AS $sec$
    DECLARE next_epoch bigint;
    BEGIN
      UPDATE ${s}.security_epoch
        SET epoch = pg_catalog.nextval(${seqLiteral})
        WHERE singleton = true
        RETURNING epoch INTO next_epoch;
      IF next_epoch IS NULL THEN
        INSERT INTO ${s}.security_epoch(singleton, epoch)
          VALUES (true, pg_catalog.nextval(${seqLiteral}))
          ON CONFLICT (singleton) DO UPDATE
          SET epoch = pg_catalog.nextval(${seqLiteral})
          RETURNING epoch INTO next_epoch;
      END IF;
      PERFORM pg_catalog.pg_notify('eigos_security_epoch', ${rawSchemaLiteral} || ':' || next_epoch::text);
      RETURN NULL;
    END $sec$;`);
    for (const table of securityEpochTables)
        await attachSecurityEpochTrigger(db, table);
    await initializeModelEgress(db);
}
export function permits(expression, properties, context) {
    if (!expression)
        return true;
    const check = (item) => {
        const value = properties[item.property];
        if (item.op === 'equals')
            return digest(value ?? null) === digest(item.value);
        if (item.op === 'subject')
            return value === context.subject;
        return (Array.isArray(value) ? value : [value]).some(group => typeof group === 'string' && context.groups.includes(group));
    };
    return expression.all.every(check) && (!expression.any.length || expression.any.some(check));
}
export function markingsOf(policy, properties) {
    if (!policy?.markingsProperty)
        return [];
    return z.array(z.string()).parse(properties[policy.markingsProperty] ?? []);
}
export function policySql(expression, values, context, column = 'properties') {
    if (!expression)
        return 'TRUE';
    const bind = (value) => { values.push(value); return '$' + values.length; };
    const check = (item) => {
        const field = `${column}->${bind(item.property)}::text`;
        if (item.op === 'equals')
            return `COALESCE(${field},'null'::jsonb)=${bind(JSON.stringify(item.value))}::jsonb`;
        if (item.op === 'subject')
            return `${field}=${bind(JSON.stringify(context.subject))}::jsonb`;
        return `EXISTS (SELECT 1 FROM jsonb_array_elements(CASE WHEN jsonb_typeof(${field})='array' THEN ${field} ELSE jsonb_build_array(${field}) END) g WHERE jsonb_typeof(g)='string' AND g#>>'{}'=ANY(${bind(context.groups)}::text[]))`;
    };
    const all = expression.all.map(check), any = expression.any.map(check);
    return [...all, ...(any.length ? ['(' + any.join(' OR ') + ')'] : [])].join(' AND ') || 'TRUE';
}
