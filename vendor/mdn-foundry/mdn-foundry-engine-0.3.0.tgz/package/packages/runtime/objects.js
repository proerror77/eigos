import { scenarioInterfaceName } from '../ontology/scenario-definition.js';
import { HotEditBuffer } from './hot-edit-buffer.js';
import { scenarioMetadataRead, scenarioMetadataQuery, scenarioMetadataType } from './scenario-metadata.js';
import { capturingDecisionReads, observeDecisionRead, observedObject, observedObjects, observedPage } from './decision-evidence.js';
import { DerivedProperties } from './derived.js';
import { compareValues, matchesPredicate, nestedValue, orderSchema, predicateFields, predicateSchema, regexMatches, propertyPathSchema } from './query-filter.js';
import { journalLinks, recordObjectEdit, recordObjectEdits, resolveSourceEdits } from './edit-history.js';
import { z } from 'zod';
import { Conflict, NotFound, PermissionDenied, InvalidInput, digest } from '../core/identity.js';
import { objectRefSchema } from '../ontology/schema.js';
import { documentChunkType, documentType } from '../ontology/documents.js';
import { processLogTarget } from '../ontology/process-definition.js';
import { isSandboxResource } from '../ontology/sandbox.js';
import { checkScenario, lockEdits, viewTables, stageObject, stageLink } from './scenario-store.js';
import { isNumeric, storedPredicate, supportsStoredOrder, supportsStoredPredicate } from './stored-query.js';
import { followWithKernel, queryWithKernel } from './kernel/client.js';
import { compareWithKernel, defaultKernelUse, encodeKernelCursor, kernelAnswer, kernelCursor, referenceOffset } from './kernel/routing.js';
const maxCompleteRelationships = 1_000;
const instant = z.iso.datetime({ offset: true });
const intervalOverlapSchema = z.strictObject({
    start: propertyPathSchema, end: propertyPathSchema,
    from: instant, until: instant, includeUnknown: z.boolean().optional(),
}).refine(input => Date.parse(input.from) < Date.parse(input.until), 'Expected a nonempty time window');
export const querySchema = z.strictObject({
    type: z.string(), where: z.record(z.string(), z.union([z.string(), z.number(), z.boolean(), z.null()])).default({}),
    filter: predicateSchema.optional(), orderBy: orderSchema.optional(), intervalOverlap: intervalOverlapSchema.optional(),
    select: z.array(propertyPathSchema).max(30).optional(), limit: z.number().int().min(1).max(100).default(50), cursor: z.string().optional(),
    from: z.strictObject({ object: objectRefSchema, link: z.string(), as: z.string().optional() }).optional(),
});
function decodeQueryCursor(token) {
    try {
        return JSON.parse(Buffer.from(token, 'base64url').toString('utf8'));
    }
    catch {
        throw new InvalidInput('Invalid query cursor');
    }
}
export function queryFields(query) {
    return [...new Set([...Object.keys(query.where ?? {}), ...predicateFields(query.filter),
            ...(query.orderBy ?? []).map(item => item.property), ...(query.select ?? []),
            ...(query.intervalOverlap ? [query.intervalOverlap.start, query.intervalOverlap.end] : [])])];
}
export class Objects {
    db;
    model;
    access;
    client;
    change;
    /** How `query` uses the query kernel: by default from EIGOS_KERNEL and the process's kernels. Tests replace it. */
    static kernels = defaultKernelUse;
    constructor(db, model, access, client = db.pool, change) {
        this.db = db;
        this.model = model;
        this.access = access;
        this.client = client;
        this.change = change;
        if (!db.objectScoped(client))
            return;
        // In an object-scoped commit, this graph's Ontology data statements are the ones its object locks cover.
        for (let proto = Object.getPrototypeOf(this); proto && proto !== Object.prototype; proto = Object.getPrototypeOf(proto)) {
            for (const name of Object.getOwnPropertyNames(proto)) {
                const method = Object.getOwnPropertyDescriptor(proto, name)?.value;
                if (name === 'constructor' || typeof method !== 'function' || Object.hasOwn(this, name))
                    continue;
                Object.defineProperty(this, name, { configurable: true, writable: true,
                    value: (...args) => db.withObjectAccess(() => method.apply(this, args)) });
            }
        }
    }
    get owner() { return this.access.principal.owner; }
    /** Object-scoped commits lock each object before reading (shared) or writing it or its relationships (exclusive). */
    lockObjects(refs, mode) {
        return this.db.lockObjects(this.client, refs.map(ref => this.db.lockKey('object', this.model.projection, this.owner, ref.type, ref.id)), mode);
    }
    /** A read whose conflicts object locks cannot bound sends an object-scoped commit to its exclusive rerun. */
    requireExclusive(reason) { this.db.requireExclusive(this.client, reason); }
    /**
     * In an object-scoped commit, a read bounded by one source's relationship locks every target of it before
     * reading: the source's shared lock fixes the relationship, and the targets' locks fix what filters see.
     */
    async lockRelationshipTargets(source, link, view) {
        if (!this.db.objectScoped(this.client))
            return;
        const nav = this.model.navigation(source.type, link, view);
        if (processLogTarget(this.model, nav.target))
            this.requireExclusive('process log relationship');
        const [from, to] = nav.forward ? ['from', 'to'] : ['to', 'from'];
        const { rows } = await this.db.query(`SELECT l.${to}_type AS type,l.${to}_id AS id FROM ${this.db.schema}.links l
      WHERE l.projection=$1 AND l.owner=$2 AND l.type=$3 AND l.${from}_type=$4 AND l.${from}_id=$5 LIMIT $6`, [this.model.projection, this.owner, nav.link, source.type, source.id, this.db.objectLockBudget + 1], this.client);
        await this.lockObjects([source, ...rows.map(row => ({ type: String(row.type), id: String(row.id) }))], 'shared');
    }
    writeReady;
    async lockWrites() { await this.prepareWrite(); }
    prepareWrite() {
        if (HotEditBuffer.for(this.client, this.model, this.owner))
            return Promise.resolve();
        return this.writeReady ??= (async () => {
            await lockEdits(this.db, this.model, this.owner, this.client);
            await checkScenario(this.db, this.model, this.owner, this.client, true);
        })();
    }
    assertStoredFields(ref, properties) {
        if (Object.keys(properties).some(field => this.model.object(ref.type).properties[field]?.derived))
            throw new Conflict('Derived properties are read-only');
    }
    writeType(type, endpoint = false) {
        if (processLogTarget(this.model, type))
            throw new Conflict('Process logs and their relationships are read-only');
        if (type === scenarioMetadataType && !endpoint)
            throw new Conflict('Edit Scenario metadata through its lifecycle API');
        this.access.definition(this.model, 'object', type);
        for (const source of this.model.sources.values())
            if (source.objectType === type) {
                const provider = this.model.functions.get(source.function)?.source;
                if (provider)
                    this.access.source(this.model, provider);
            }
    }
    maskSnapshot(ref, properties) {
        this.access.read(this.model, ref.type);
        if (!this.access.rowAllowed(this.model, ref.type, properties))
            return null;
        this.access.readRow(this.model, ref.type, properties);
        return Object.fromEntries(Object.entries(properties).filter(([field]) => this.model.object(ref.type).properties[field]).map(([field, value]) => [field, this.access.cell(this.model, ref.type, field, properties) ? value : null]));
    }
    visible(object) {
        this.access.readRow(this.model, object.ref.type, object.properties);
        return { ...object, properties: this.maskSnapshot(object.ref, object.properties) };
    }
    row(row) {
        const ref = { type: String(row.type), id: String(row.id) };
        const properties = this.model.parseObject(ref, row.properties);
        return { ref, revision: Number(row.revision), properties };
    }
    async stored(input) {
        const ref = objectRefSchema.parse(input);
        const buffered = HotEditBuffer.for(this.client, this.model, this.owner, ref);
        if (buffered)
            return this.row({ ...ref, ...buffered.snapshot() });
        if (processLogTarget(this.model, ref.type))
            this.requireExclusive('process log read');
        await this.lockObjects([ref], 'shared');
        await checkScenario(this.db, this.model, this.owner, this.client);
        const values = [this.owner, ref.type, ref.id, this.model.projection];
        const policy = ref.type === documentChunkType || processLogTarget(this.model, ref.type) ? this.access.rowSql(this.model, ref.type, values, 'o.properties') : 'TRUE';
        const tables = viewTables(this.db, this.model, this.owner, values, [ref.type]);
        const rows = await this.db.readQuery(`${tables.prefix}SELECT type,id,revision,properties FROM ${tables.objects} o WHERE owner=$1 AND type=$2 AND id=$3 AND projection=$4 AND ${policy}`, values, this.client);
        if (!rows.rows[0])
            throw new NotFound('Object is unavailable');
        return this.row(rows.rows[0]);
    }
    async readStored(input) {
        return observeDecisionRead(this, { kind: 'stored', ref: objectRefSchema.parse(input) }, () => this.loadStored(input), observedObject);
    }
    /**
     * Batch live visibility and permission check for a list of object references, deduplicating
     * inputs and issuing a single SQL query for regular stored types instead of N+1 `read()` calls.
     * Returns a Set of `JSON.stringify([ref.type, ref.id])` keys for objects that currently exist
     * and are readable; throws PermissionDenied if an existing object is denied by policy.
     */
    async batchCheckLiveReadable(refs) {
        const accessible = new Set();
        const unique = new Map();
        for (const raw of refs) {
            const ref = objectRefSchema.parse(raw);
            unique.set(JSON.stringify([ref.type, ref.id]), ref);
        }
        if (!unique.size)
            return accessible;
        const regular = [];
        const special = [];
        for (const ref of unique.values()) {
            if (ref.type === scenarioMetadataType || ref.type === documentChunkType || processLogTarget(this.model, ref.type)) {
                special.push(ref);
            }
            else {
                regular.push(ref);
            }
        }
        for (const ref of special) {
            try {
                await this.readStored(ref);
                accessible.add(JSON.stringify([ref.type, ref.id]));
            }
            catch (error) {
                if (error instanceof NotFound)
                    continue;
                throw error;
            }
        }
        if (regular.length) {
            const types = [...new Set(regular.map(ref => ref.type))];
            for (const type of types)
                this.access.read(this.model, type);
            await this.lockObjects(regular, 'shared');
            await checkScenario(this.db, this.model, this.owner, this.client);
            const values = [this.owner, this.model.projection, JSON.stringify(regular.map(({ type, id }) => ({ type, id })))];
            const tables = viewTables(this.db, this.model, this.owner, values, types);
            const { rows } = await this.db.readQuery(`${tables.prefix}SELECT o.type,o.id,o.revision,o.properties FROM ${tables.objects} o
        JOIN jsonb_to_recordset($3::jsonb) AS k(type text,id text) ON o.type=k.type AND o.id=k.id
        WHERE o.owner=$1 AND o.projection=$2`, values, this.client);
            for (const row of rows) {
                const object = this.row(row);
                this.visible(object);
                accessible.add(JSON.stringify([object.ref.type, object.ref.id]));
            }
        }
        return accessible;
    }
    /** Hydrate raw stored rows returned by an already-authorized SQL query, running linked security checks and property masking. */
    async hydrateStoredRows(rows) {
        const records = rows.map(row => this.row(row));
        await this.linkedSecurityReads(records);
        return records.map(record => this.visible(record));
    }
    async loadStored(input) {
        if (input.type === scenarioMetadataType)
            return scenarioMetadataRead(this, input);
        this.access.read(this.model, input.type);
        const object = await this.stored(input);
        await this.linkedSecurityReads([object]);
        return this.visible(object);
    }
    async linkedSecurityReads(objects) {
        const seen = new Set();
        for (const object of objects) {
            const log = processLogTarget(this.model, object.ref.type);
            const target = log ? { type: log.objectType, id: String(object.properties.processId), field: log.property }
                : object.ref.type === documentChunkType
                    ? { type: documentType, id: String(object.properties.documentId), field: 'extractedText' }
                    : undefined;
            if (!target)
                continue;
            const { field, ...ref } = target, key = JSON.stringify(target);
            if (!seen.has(key)) {
                seen.add(key);
                const parent = await this.stored(ref);
                this.access.readRow(this.model, ref.type, parent.properties, true);
                if (!this.access.cell(this.model, ref.type, field, parent.properties))
                    throw new NotFound('Linked data is unavailable');
            }
            if (log && this.access.needsEgressRead(this.model, ref.type)) {
                const history = (await this.db.readQuery(`SELECT before_values,after_values FROM ${this.db.schema}.edit_history
          WHERE owner=$1 AND sequence=$2 AND release=$3`, [this.owner, object.properties.sequence, object.properties.release], this.client)).rows[0];
                for (const properties of [history?.before_values, history?.after_values]) {
                    if (properties)
                        this.access.observeRowClassification(this.model, ref.type, properties);
                }
            }
        }
    }
    /** Source fields must match their baseline; unrelated local notes may remain. */
    async matchesSource(ref, sourceName) {
        return (await observeDecisionRead(this, { kind: 'source', ref, source: sourceName }, () => this.sourceMatch(ref, sourceName))).matches;
    }
    async sourceMatch(ref, sourceName) {
        const mapping = this.model.sources.get(sourceName), provider = mapping && this.model.functions.get(mapping.function)?.source;
        if (!mapping || mapping.objectType !== ref.type || !provider)
            throw new Error('Source certification requires a matching datasource');
        this.access.source(this.model, provider);
        const object = await this.stored(ref);
        this.access.readRow(this.model, ref.type, object.properties);
        const baseline = (await this.db.readQuery(`SELECT properties,observed_at::text FROM ${this.db.schema}.source_values
        WHERE projection=$1 AND owner=$2 AND type=$3 AND id=$4 AND source=$5`, [this.model.projection, this.owner, ref.type, ref.id, sourceName], this.client)).rows[0];
        const matches = Boolean(baseline && Object.entries(baseline.properties).every(([field, value]) => Object.hasOwn(object.properties, field) && this.access.cell(this.model, ref.type, field, object.properties)
            && digest(object.properties[field]) === digest(value)));
        return { matches, version: baseline, revision: object.revision };
    }
    /**
     * For objects this graph has read, whether each named property is visible, as propertyVisible decides, from
     * one read. Objects whose rows need a row policy or cannot be read here are left to the per-object check.
     */
    async propertyVisibility(items) {
        const visibility = new Map();
        const plain = items.filter(({ ref }) => ref.type !== documentChunkType && !processLogTarget(this.model, ref.type));
        if (!plain.length)
            return visibility;
        await this.lockObjects(plain.map(item => item.ref), 'shared');
        await checkScenario(this.db, this.model, this.owner, this.client);
        const values = [this.owner, this.model.projection, JSON.stringify(plain.map(({ ref }) => ({ type: ref.type, id: ref.id })))];
        const tables = viewTables(this.db, this.model, this.owner, values, [...new Set(plain.map(({ ref }) => ref.type))]);
        const { rows } = await this.db.readQuery(`${tables.prefix}SELECT o.type,o.id,o.revision,o.properties FROM ${tables.objects} o
      JOIN jsonb_to_recordset($3::jsonb) AS k(type text,id text) ON o.type=k.type AND o.id=k.id
      WHERE o.owner=$1 AND o.projection=$2`, values, this.client);
        const names = new Map(plain.map(item => [digest({ type: item.ref.type, id: item.ref.id }), item.names]));
        for (const row of rows) {
            let object;
            try {
                object = this.row(row);
                this.access.readRow(this.model, object.ref.type, object.properties);
            }
            catch {
                continue;
            }
            for (const name of names.get(digest(object.ref)) ?? [])
                visibility.set(digest([object.ref, name]), this.access.cell(this.model, object.ref.type, name, object.properties));
        }
        return visibility;
    }
    /**
     * The objects linked from each source along one step, as queryStored with `from` returns them for that source,
     * from one read. Undefined when the target type needs the per-source path: it has derived properties, row
     * policies of its own kind, or the relationship is too large to hold at once.
     */
    async linkedTargets(sources, link, as) {
        const sourceType = sources[0]?.type;
        if (!sourceType || sources.some(source => source.type !== sourceType) || processLogTarget(this.model, sourceType))
            return undefined;
        const nav = this.model.navigation(sourceType, link, as), target = nav.target;
        if (!this.model.objects.has(target) || [scenarioMetadataType, documentChunkType].includes(target) || processLogTarget(this.model, target)
            || Object.values(this.model.object(target).properties).some(property => property.derived))
            return undefined;
        // The checks storedSelection makes for each source, made once for the batch.
        await checkScenario(this.db, this.model, this.owner, this.client);
        this.access.definition(this.model, 'object', target);
        if (as)
            this.access.definition(this.model, 'interface', as);
        this.access.read(this.model, target);
        this.access.definition(this.model, 'link', nav.link);
        const key = (id) => digest({ type: sourceType, id });
        const targets = new Map(sources.map(source => [key(source.id), []]));
        const label = this.model.links.get(nav.link)?.classification;
        if (!this.access.canSeeModelData(label))
            return targets;
        this.access.observeClassification(label);
        if (!this.access.canRead(this.model, target))
            return targets;
        const [from, to] = nav.forward ? ['from', 'to'] : ['to', 'from'], ids = sources.map(source => source.id), limit = 50000;
        if (this.db.objectScoped(this.client)) {
            const { rows } = await this.db.query(`SELECT l.${to}_type AS type,l.${to}_id AS id FROM ${this.db.schema}.links l
        WHERE l.projection=$1 AND l.owner=$2 AND l.type=$3 AND l.${from}_type=$4 AND l.${from}_id=ANY($5::text[]) LIMIT $6`, [this.model.projection, this.owner, nav.link, sourceType, ids, this.db.objectLockBudget + 1], this.client);
            await this.lockObjects([...sources, ...rows.map(row => ({ type: String(row.type), id: String(row.id) }))], 'shared');
        }
        const values = [this.owner, this.model.projection];
        const bind = (value) => { values.push(value); return '$' + values.length; };
        const tables = viewTables(this.db, this.model, this.owner, values, [target, sourceType]);
        const policy = this.access.rowSql(this.model, target, values, 'o.properties');
        const { rows } = await this.db.readQuery(`${tables.prefix}SELECT l.${from}_id AS source_id,o.type,o.id,o.revision,o.properties
      FROM ${tables.links} l JOIN ${tables.objects} o ON o.projection=l.projection AND o.owner=l.owner AND o.type=l.${to}_type AND o.id=l.${to}_id
      WHERE l.owner=$1 AND l.projection=$2 AND l.type=${bind(nav.link)} AND l.${from}_type=${bind(sourceType)}
        AND l.${from}_id=ANY(${bind(ids)}::text[]) AND o.type=${bind(target)} AND ${policy}
      ORDER BY l.${from}_id, o.type COLLATE "C", o.id COLLATE "C" LIMIT ${bind(limit + 1)}`, values, this.client);
        if (rows.length > limit)
            return undefined;
        const records = rows.map(row => ({ source: String(row.source_id), object: this.row(row) }));
        await this.linkedSecurityReads(records.map(record => record.object));
        const fields = Object.keys(this.model.object(target).properties);
        for (const { source, object } of records) {
            this.access.readRow(this.model, object.ref.type, object.properties);
            targets.get(key(source))?.push({ ...object, properties: Object.fromEntries(fields.map(field => [field,
                    this.visibleViewField(target, field) && this.access.cell(this.model, object.ref.type, field, object.properties) ? object.properties[field] : null])) });
        }
        return targets;
    }
    async propertyVisible(ref, field) {
        const object = await this.stored(ref);
        this.access.readRow(this.model, ref.type, object.properties);
        return this.access.cell(this.model, ref.type, field, object.properties);
    }
    /**
     * The objects `read` returns for these references, read together: one statement per type, each row checked and
     * masked as `read` does, and the derived values of the batch evaluated together. A reference whose object is missing
     * or unreadable is left out, where `read` would throw.
     */
    async readBatch(refs) {
        const byType = new Map();
        for (const ref of refs.map(ref => objectRefSchema.parse(ref))) {
            if (ref.type === scenarioMetadataType || !this.model.objects.has(ref.type))
                throw new InvalidInput('Batch reads cover published object types');
            let ids = byType.get(ref.type);
            if (!ids) {
                ids = [];
                byType.set(ref.type, ids);
            }
            ids.push(ref.id);
        }
        if (this.client === this.db.pool && [...byType.keys()].some(type => Object.values(this.model.object(type).properties).some(property => property.derived))) {
            // As `read`: derived values come from one snapshot, and their permissions must still hold when they are returned.
            const access = await this.access.fork();
            const result = await this.db.transaction(async (client) => {
                await this.db.query('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ', [], client);
                return new Objects(this.db, this.model, access, client).readBatch(refs);
            });
            if (!await access.canReturn(access.dataRequirements()))
                throw new Conflict('Derived result permissions changed');
            this.access.adoptReads(access);
            return result;
        }
        const visible = [];
        for (const [type, ids] of byType) {
            if (processLogTarget(this.model, type))
                this.requireExclusive('process log read');
            this.access.read(this.model, type);
            await this.lockObjects(ids.map(id => ({ type, id })), 'shared');
            await checkScenario(this.db, this.model, this.owner, this.client);
            const values = [this.owner, type, ids, this.model.projection];
            const policy = type === documentChunkType || processLogTarget(this.model, type) ? this.access.rowSql(this.model, type, values, 'o.properties') : 'TRUE';
            const tables = viewTables(this.db, this.model, this.owner, values, [type]);
            const { rows } = await this.db.readQuery(`${tables.prefix}SELECT type,id,revision,properties FROM ${tables.objects} o
        WHERE owner=$1 AND type=$2 AND id=ANY($3::text[]) AND projection=$4 AND ${policy}`, values, this.client);
            const records = rows.map(row => this.row(row));
            await this.linkedSecurityReads(records);
            for (const record of records) {
                try {
                    visible.push(this.visible(record));
                }
                catch (error) {
                    if (!(error instanceof PermissionDenied))
                        throw error;
                }
            }
        }
        const evaluator = new DerivedProperties(this);
        await evaluator.prefetch(visible);
        return Promise.all(visible.map(object => evaluator.enrich(object)));
    }
    async read(input) {
        return observeDecisionRead(this, { kind: 'object', ref: objectRefSchema.parse(input) }, () => this.readObject(input), observedObject);
    }
    async readObject(input) {
        if (this.client === this.db.pool && Object.values(this.model.object(input.type).properties).some(property => property.derived)) {
            const access = await this.access.fork();
            const result = await this.db.transaction(async (client) => {
                await this.db.query('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ', [], client);
                return new Objects(this.db, this.model, access, client).read(input);
            });
            if (!await access.canReturn(access.dataRequirements()))
                throw new Conflict('Derived result permissions changed');
            this.access.adoptReads(access);
            return result;
        }
        return new DerivedProperties(this).enrich(await this.readStored(input));
    }
    async query(input) {
        this.requireExclusive('set query');
        const args = querySchema.parse(input);
        return observeDecisionRead(this, { kind: 'query', input: args }, () => this.queryPage(args), observedPage);
    }
    /**
     * One page of a query. A query the reference evaluates completely (it filters, orders, or reads derived properties or
     * nested fields) goes through the query kernel as EIGOS_KERNEL says, like an Object Set: `route` answers it from the
     * kernel, in the reference's order, and `shadow` compares the kernel's answer with the reference's. Inside a caller's
     * transaction, while decision evidence records each read and outside the owner's row security context, the
     * reference answers. In a Scenario the kernel reads the Scenario's edits over the live data.
     */
    async queryPage(args) {
        const kernels = Objects.kernels();
        const cursor = args.cursor ? kernelCursor(args.cursor) : undefined;
        const allowed = kernels.mode !== 'off' && this.client === this.db.pool && !capturingDecisionReads()
            && this.db.readsAsOwner(this.owner) && this.completeQuery(args);
        // A kernel cursor continues only on the kernel, and a reference cursor only on the reference.
        if (!allowed && cursor)
            throw new InvalidInput('Query cursor expired; query again from the first page');
        if (allowed && kernels.mode === 'route' && (!args.cursor || cursor)) {
            const routed = await this.routedQuery(kernels, args, cursor);
            if (routed)
                return routed;
            if (cursor)
                throw new InvalidInput('Query cursor expired; query again from the first page');
        }
        const page = await this.queryObjects(args);
        if (allowed && kernels.mode === 'shadow')
            await this.shadowQuery(kernels, args);
        return page;
    }
    /** Whether the reference evaluates the query completely rather than reading it page by page from storage. */
    completeQuery(args) {
        try {
            return Boolean(args.filter || args.orderBy || queryFields(args).some(field => field.includes('.'))
                || this.model.concreteTypes(args.type).some(type => Object.values(this.model.object(type).properties).some(property => property.derived)));
        }
        catch {
            return false;
        }
    }
    async routedQuery(kernels, args, cursor) {
        const kernel = await kernels.registry.kernelFor(this.db, this.model, false);
        if (!kernel)
            return undefined;
        const identity = digest({ owner: this.owner, release: this.model.release, args: { ...args, cursor: undefined, limit: undefined } });
        if (cursor && cursor.identity !== identity)
            throw new InvalidInput('Query cursor belongs to another query');
        const offset = cursor?.offset ?? 0;
        const result = await kernelAnswer(this.db, kernels.registry, this.model, () => this.kernelQuery(kernel, args, offset));
        if (!result)
            return undefined;
        if (cursor && result.membership !== cursor.membership)
            throw new InvalidInput('Query results changed since the previous page; query again from the first page');
        const end = offset + args.limit;
        return { items: result.items, cursor: end < result.total ? encodeKernelCursor({ identity, offset: end, membership: result.membership }) : undefined };
    }
    /**
     * One page from the kernel. Like the reference's complete evaluation, it reads with a fork of the access, which must
     * still be able to return what it read; this access adopts the reads once the kernel answered.
     */
    async kernelQuery(kernel, args, offset) {
        const fork = await this.access.fork();
        const result = await queryWithKernel(kernel, this.model, fork, new Objects(this.db, this.model, fork), { query: args, offset });
        if (!result)
            return undefined;
        if (!await fork.canReturn(fork.dataRequirements()))
            throw new Conflict('Query permissions changed');
        this.access.adoptReads(fork);
        return result;
    }
    shadowQuery(kernels, args) {
        const offset = args.cursor ? referenceOffset(args.cursor) : 0;
        return compareWithKernel(this.db, kernels.registry, this.access, this.model, 'query', args, async (fork) => {
            const page = await new Objects(this.db, this.model, fork).queryObjects(args);
            return { items: page.items, more: Boolean(page.cursor) };
        }, async (client, fork) => {
            const result = await new Objects(this.db, this.model, fork).kernelQuery(client, args, offset);
            return result && { items: result.items, more: offset + args.limit < result.total };
        });
    }
    /**
     * Every match of a query for a caller that needs the whole set, such as Object Set evaluation. A query that
     * needs complete evaluation (derived properties, filters, ordering) is evaluated once rather than once per
     * page; other queries are read page by page from storage.
     */
    /**
     * The matches of a query among the given objects of its type, for a consumer that re-evaluates only the objects that
     * changed. It applies the visibility, filters and derived properties of `query`, and reads only those objects.
     */
    async queryAmong(input, ids) {
        this.requireExclusive('set query');
        const args = querySchema.parse({ ...input, limit: 100, cursor: undefined });
        const items = [];
        let cursor;
        do {
            const page = await this.queryObjects({ ...args, cursor }, true, ids);
            items.push(...page.items);
            cursor = page.cursor;
        } while (cursor);
        return items;
    }
    async queryAll(input) {
        this.requireExclusive('set query');
        const args = querySchema.parse({ ...input, limit: 100, cursor: undefined });
        const items = [];
        let cursor;
        do {
            const page = await this.queryObjects({ ...args, cursor }, true);
            items.push(...page.items);
            cursor = page.cursor;
        } while (cursor);
        return items;
    }
    /** `among` restricts the query to those object ids of its type. */
    async queryObjects(args, complete = false, among) {
        const fields = queryFields(args);
        this.access.definition(this.model, this.model.interfaces.has(args.type) ? 'interface' : 'object', args.type);
        const viewLabel = this.model.interfaces.get(args.type)?.classification;
        if (!this.access.canSeeModelData(viewLabel))
            return { items: [], cursor: undefined };
        this.access.observeClassification(viewLabel);
        const types = this.model.concreteTypes(args.type);
        for (const field of fields)
            this.model.propertyPath(args.type, field);
        const derived = types.some(type => Object.values(this.model.object(type).properties).some(property => property.derived));
        if (!args.filter && !args.orderBy && !derived && !fields.some(field => field.includes('.')))
            return this.queryStored(args, among);
        if (this.client === this.db.pool) {
            const access = await this.access.fork();
            const result = await this.db.transaction(async (client) => {
                await this.db.query('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ', [], client);
                return new Objects(this.db, this.model, access, client).queryObjects(args, complete, among);
            });
            if (!await access.canReturn(access.dataRequirements()))
                throw new Conflict('Query permissions changed');
            this.access.adoptReads(access);
            return result;
        }
        const evaluator = new DerivedProperties(this);
        const definitions = this.model.interfaces.get(args.type)?.properties ?? this.model.object(args.type).properties;
        const project = async (raw) => {
            const enriched = await evaluator.enrich(raw);
            const properties = Object.fromEntries(Object.keys(definitions).map(field => {
                const local = this.model.propertyName(raw.ref.type, args.type, field);
                return [field, local && this.visibleViewField(args.type, field) ? enriched.properties[local] ?? null : null];
            }));
            return { ...enriched, properties };
        };
        const pushed = await this.scalarCandidates(args, among);
        let matching;
        if (pushed) {
            matching = [];
            await evaluator.prefetch(pushed.objects);
            for (const item of pushed.objects)
                matching.push(await project(item));
        }
        else {
            const candidates = [], all = [];
            let cursor;
            do {
                const page = await this.queryStored({ type: args.type, from: args.from, intervalOverlap: args.intervalOverlap, limit: 100, cursor }, among);
                for (const item of page.items) {
                    candidates.push(args.type === item.ref.type ? item : await this.readStored(item.ref));
                    if (candidates.length > 10000)
                        throw new Conflict('Extended query exceeds 10000 complete candidate objects');
                }
                cursor = page.cursor;
            } while (cursor);
            // Derived properties of every candidate read their visibility and relationships together.
            await evaluator.prefetch(candidates);
            for (const item of candidates)
                all.push(await project(item));
            const regex = await regexMatches(args.filter, all);
            matching = all.filter(object => Object.entries(args.where).every(([field, value]) => digest(nestedValue(object.properties, field)) === digest(value)) &&
                (!args.filter || matchesPredicate(args.filter, object.properties, regex)));
        }
        if (!pushed?.ordered)
            matching.sort((left, right) => {
                for (const order of args.orderBy ?? []) {
                    const a = nestedValue(left.properties, order.property);
                    const b = nestedValue(right.properties, order.property);
                    const comparison = compareValues(a, b);
                    if (comparison)
                        return a === null || b === null ? comparison : order.direction === 'desc' ? -comparison : comparison;
                }
                return Buffer.compare(Buffer.from(JSON.stringify(left.ref)), Buffer.from(JSON.stringify(right.ref)));
            });
        const identity = digest({ owner: this.owner, release: this.model.release, scenario: this.model.scenario, args: { ...args, cursor: undefined, limit: undefined }, objects: matching });
        const offset = args.cursor ? z.strictObject({ query: z.literal(identity), offset: z.number().int().min(0).max(matching.length) }).parse(decodeQueryCursor(args.cursor)).offset : 0;
        const end = complete ? matching.length : offset + args.limit;
        const items = matching.slice(offset, end).map(object => args.select ? { ...object, properties: Object.fromEntries(args.select.map(field => [field, nestedValue(object.properties, field)])) } : object);
        return { items, cursor: end < matching.length ? Buffer.from(JSON.stringify({ query: identity, offset: end })).toString('base64url') : undefined };
    }
    visibleViewField(view, field) {
        const label = this.model.interfaces.get(view)?.properties[field]?.classification;
        if (!this.access.canSeeModelData(label))
            return false;
        this.access.observeClassification(label);
        return true;
    }
    mayUseStoredFields(view, types, fields) {
        return types.every(type => type !== scenarioMetadataType && !processLogTarget(this.model, type)
            && fields.every(field => {
                const [root, ...nested] = field.split('.');
                if (nested.some(part => /^0[0-9]+$|^[0-9]{10,}$/.test(part)))
                    return false;
                const local = this.model.propertyName(type, view, root);
                return !local || !this.model.object(type).properties[local]?.derived;
            }));
    }
    async storedSelection(args, inlineView = false, among) {
        await checkScenario(this.db, this.model, this.owner, this.client);
        this.access.definition(this.model, this.model.interfaces.has(args.type) ? 'interface' : 'object', args.type);
        const viewLabel = this.model.interfaces.get(args.type)?.classification;
        if (!this.access.canSeeModelData(viewLabel))
            return undefined;
        this.access.observeClassification(viewLabel);
        const navigation = args.from && this.model.navigation(args.from.object.type, args.from.link, args.from.as);
        if (args.from && navigation) {
            if (args.from.as)
                this.access.definition(this.model, 'interface', args.from.as);
            await this.readStored(args.from.object);
            this.access.read(this.model, navigation.target);
            this.access.definition(this.model, 'link', navigation.link);
            const label = this.model.links.get(navigation.link)?.classification;
            if (!this.access.canSeeModelData(label))
                return undefined;
            this.access.observeClassification(label);
        }
        const types = this.model.concreteTypes(args.type).filter(type => (!navigation || type === navigation.target) && this.access.canRead(this.model, type));
        if (!types.length)
            return undefined;
        const values = [this.owner, types, this.model.projection];
        const bind = (value) => { values.push(value); return '$' + values.length; };
        const tables = viewTables(this.db, this.model, this.owner, values, [...types, ...(args.from ? [args.from.object.type] : [])], inlineView);
        const policies = types.map(type => {
            this.access.read(this.model, type);
            return `(o.type=${bind(type)} AND ${this.access.rowSql(this.model, type, values, 'o.properties')})`;
        });
        const clauses = ['o.owner=$1', 'o.type=ANY($2::text[])', 'o.projection=$3', '(' + policies.join(' OR ') + ')'];
        if (among)
            clauses.push(`o.id=ANY(${bind([...among])}::text[])`);
        if (args.from && navigation) {
            const source = navigation.forward ? 'from' : 'to', target = navigation.forward ? 'to' : 'from';
            clauses.push(`EXISTS(SELECT 1 FROM ${tables.links} l WHERE l.projection=o.projection AND l.owner=o.owner
        AND l.type=${bind(navigation.link)} AND l.${source}_type=${bind(args.from.object.type)} AND l.${source}_id=${bind(args.from.object.id)}
        AND l.${target}_type=o.type AND l.${target}_id=o.id)`);
        }
        const property = this.storedFields(types, values, args.type);
        // Add an indexable necessary condition only for readable, unmarked scalar cells.
        if (types.length === 1 && types[0] === args.type && !processLogTarget(this.model, args.type)
            && !this.access.hasObjectPolicy(this.model, args.type)) {
            const exact = Object.entries(args.where).filter(([field, value]) => value !== null && !field.includes('.')
                && this.access.canSeeModelData(this.model.object(args.type).properties[field]?.classification)
                && this.access.property(this.model, args.type, field));
            if (exact.length)
                clauses.push(`o.properties @> ${bind(JSON.stringify(Object.fromEntries(exact)))}::jsonb`);
        }
        if (args.intervalOverlap) {
            const window = args.intervalOverlap;
            const fields = [window.start, window.end];
            if (fields.some(field => this.model.propertyPath(args.type, field).format !== 'date-time')
                || !this.mayUseStoredFields(args.type, types, fields))
                throw new Conflict('Time windows require stored date-time properties');
            const timestamp = (field) => {
                const raw = `(${property(field)}#>>'{}')`;
                // Date.parse uses millisecond precision, including on offsets in legacy values.
                const millis = `regexp_replace(${raw}, '([.][0-9]{3})[0-9]+', '\\1')`;
                return `(CASE WHEN pg_input_is_valid(${millis},'timestamptz') THEN ${millis}::timestamptz END)`;
            };
            const start = timestamp(window.start), end = timestamp(window.end);
            const overlap = `(${start}<${bind(new Date(window.until).toISOString())}::timestamptz AND ${end}>${bind(new Date(window.from).toISOString())}::timestamptz)`;
            const known = `${start}<${end}`;
            clauses.push(window.includeUnknown ? `((${known}) IS NOT TRUE OR ${overlap})` : `(${known} AND ${overlap})`);
        }
        for (const [field, value] of Object.entries(args.where))
            clauses.push(`${property(field)}=${bind(JSON.stringify(value))}::jsonb`);
        return { values, bind, clauses, property, tables, types };
    }
    storedFields(types, values, defaultView) {
        const fields = new Map();
        const bind = (value) => { values.push(value); return '$' + values.length; };
        return (path, view = defaultView) => {
            const key = JSON.stringify([view, path]), cached = fields.get(key);
            if (cached)
                return cached;
            const [root, ...nested] = path.split('.');
            if (!this.visibleViewField(view, root))
                return "'null'::jsonb";
            const cases = types.flatMap(type => {
                const local = this.model.propertyName(type, view, root);
                if (!local)
                    return [];
                const kind = bind(type), allowed = this.access.cellSql(this.model, type, local, values, 'o.properties');
                return [`WHEN o.type=${kind} AND ${allowed} THEN o.properties#>${bind([local, ...nested])}::text[]`];
            });
            const expression = cases.length ? `COALESCE((CASE ${cases.join(' ')} END),'null'::jsonb)` : "'null'::jsonb";
            fields.set(key, expression);
            return expression;
        };
    }
    supportsScalarFilter(args, types) {
        return supportsStoredPredicate(args.filter)
            && this.mayUseStoredFields(args.type, types, [...Object.keys(args.where), ...predicateFields(args.filter)]);
    }
    supportsScalarOrder(args, types) {
        return !args.orderBy || this.mayUseStoredFields(args.type, types, args.orderBy.map(item => item.property))
            && args.orderBy.every(item => supportsStoredOrder(this.model.propertyPath(args.type, item.property)));
    }
    /** PostgreSQL checks each stored ORDER BY cell before it reads any rows, including for an empty result. */
    recordsStoredOrderFields(args) {
        const types = this.model.concreteTypes(args.type);
        return this.supportsScalarFilter(args, types) && this.supportsScalarOrder(args, types);
    }
    async scalarCandidates(args, among) {
        const types = this.model.concreteTypes(args.type);
        if (!this.supportsScalarFilter(args, types))
            return undefined;
        const selection = await this.storedSelection(args, false, among);
        if (!selection)
            return { objects: [], ordered: true };
        const { values, bind, clauses, property, tables } = selection;
        if (args.filter)
            clauses.push(storedPredicate(args.filter, property, bind));
        const ordered = this.supportsScalarOrder(args, types);
        const order = ordered ? (args.orderBy ?? []).map(item => `NULLIF(${property(item.property)},'null'::jsonb) ${item.direction.toUpperCase()} NULLS LAST`) : [];
        order.push('to_json(o.type)::text COLLATE "C"', 'to_json(o.id)::text COLLATE "C"');
        const result = await this.db.readQuery(`${tables.prefix}SELECT o.type,o.id,o.revision,o.properties FROM ${tables.objects} o
      WHERE ${clauses.join(' AND ')} ORDER BY ${order.join(', ')} LIMIT 10001`, values, this.client);
        if (result.rows.length > 10000)
            throw new Conflict('Extended query exceeds 10000 matching objects');
        const records = result.rows.map(row => this.row(row));
        await this.linkedSecurityReads(records);
        return { objects: records.map(record => this.visible(record)), ordered };
    }
    /** `among` restricts the query to those object ids of its type. */
    async queryStored(input, among) {
        if (input.type === scenarioMetadataType || input.type === scenarioInterfaceName && this.model.interfaces.has(scenarioInterfaceName)) {
            this.requireExclusive('set query');
            if (input.intervalOverlap)
                throw new Conflict('Time windows require stored date-time properties');
            if (input.type === scenarioInterfaceName)
                this.access.definition(this.model, 'interface', input.type);
            return scenarioMetadataQuery(this, input, among);
        }
        const args = querySchema.parse(input);
        // A read of one source's relationship is bounded by object locks; any other set query is not.
        if (!args.from)
            this.requireExclusive('set query');
        const selection = await this.storedSelection(args, false, among);
        if (!selection)
            return { items: [], cursor: undefined };
        if (args.from)
            await this.lockRelationshipTargets(args.from.object, args.from.link, args.from.as);
        const { values, bind, clauses, tables, types } = selection;
        const queryDigest = digest({ ...args, cursor: undefined, owner: this.owner, release: this.model.release, scenario: this.model.scenario });
        if (args.cursor) {
            const cursor = z.strictObject({ query: z.literal(queryDigest), type: z.string(), id: z.string() }).parse(decodeQueryCursor(args.cursor));
            clauses.push(`(o.type COLLATE "C",o.id COLLATE "C")>(${bind(cursor.type)},${bind(cursor.id)})`);
        }
        const result = await this.db.readQuery(`${tables.prefix}SELECT o.type,o.id,o.revision,o.properties FROM ${tables.objects} o
      WHERE ${clauses.join(' AND ')} ORDER BY o.type COLLATE "C",o.id COLLATE "C" LIMIT ${bind(args.limit + 1)}`, values, this.client);
        const records = result.rows.slice(0, args.limit).map(row => this.row(row));
        await this.linkedSecurityReads(records);
        const fields = args.select ?? Object.keys(this.model.interfaces.get(args.type)?.properties ?? this.model.object(args.type).properties).filter(field => types.some(type => { const local = this.model.propertyName(type, args.type, field); return local && !this.model.object(type).properties[local]?.derived; }));
        const items = records.map(object => {
            this.access.readRow(this.model, object.ref.type, object.properties);
            return { ...object, properties: Object.fromEntries(fields.flatMap(field => {
                    const local = this.model.propertyName(object.ref.type, args.type, field);
                    return local === undefined ? [] : [[field, this.visibleViewField(args.type, field) && this.access.cell(this.model, object.ref.type, local, object.properties) ? object.properties[local] : null]];
                })) };
        });
        const last = records.at(-1)?.ref;
        return { items, cursor: result.rows.length > args.limit && last ? Buffer.from(JSON.stringify({ query: queryDigest, ...last })).toString('base64url') : undefined };
    }
    /** Compile membership when this read needs no per-row authorization evidence. */
    async storedSetSelection(input, path) {
        this.requireExclusive('set query');
        const args = querySchema.parse(input), start = args.type;
        const eligible = (type) => this.model.objects.has(type) && this.access.canRead(this.model, type)
            && type !== scenarioMetadataType && !processLogTarget(this.model, type) && !this.access.hasObjectPolicy(this.model, type);
        if (args.orderBy || !eligible(start) || !supportsStoredPredicate(args.filter))
            return undefined;
        let type = start;
        const hops = [];
        for (const step of path) {
            let navigation;
            try {
                navigation = this.model.navigation(type, step.link, step.as);
            }
            catch {
                return undefined;
            } // Preserve the interpreter's handling of empty or invalid frontiers.
            if (!eligible(navigation.target)
                || !this.access.canDefine(this.model, 'link', navigation.link)
                || !this.access.canSeeModelData(this.model.links.get(navigation.link)?.classification)
                || step.as && !this.access.canDefine(this.model, 'interface', step.as))
                return undefined;
            hops.push({ navigation, as: step.as });
            type = navigation.target;
        }
        const fields = queryFields(args);
        if (!this.mayUseStoredFields(start, [start], fields))
            return undefined;
        for (const field of fields)
            this.model.propertyPath(start, field);
        const selection = await this.storedSelection(args, hops.length > 0);
        if (!selection)
            return undefined;
        const { values, bind, clauses, tables } = selection;
        if (this.access.canSeeModelData(this.model.document.classification)) {
            this.access.observeClassification(this.model.document.classification);
        }
        if (args.filter)
            clauses.push(storedPredicate(args.filter, selection.property, bind));
        let prefix = tables.prefix;
        let relation = tables.objects;
        let filter = 'WHERE ' + clauses.join(' AND ');
        if (hops.length) {
            const columns = 'o.type,o.id,o.revision,o.properties';
            relation = 'object_set_seed';
            const steps = [`${relation} AS (SELECT o.id FROM ${tables.objects} o ${filter})`];
            let sourceType = start;
            for (const [index, { navigation: nav, as }] of hops.entries()) {
                if (as)
                    this.access.definition(this.model, 'interface', as, true);
                this.access.definition(this.model, 'link', nav.link, true);
                this.access.read(this.model, nav.target);
                const source = bind(sourceType), target = bind(nav.target), relationship = bind(nav.link);
                const policy = this.access.rowSql(this.model, nav.target, values, 'o.properties');
                const from = nav.forward ? 'from' : 'to', to = nav.forward ? 'to' : 'from';
                const name = 'object_set_hop_' + index, keys = 'object_set_targets_' + index;
                // Reduce to distinct target identities before the next hop so fan-in never multiplies the frontier.
                steps.push(`${keys} AS MATERIALIZED (
          SELECT DISTINCT l.${to}_id AS id FROM ${tables.links} l JOIN ${relation} frontier ON frontier.id=l.${from}_id
          WHERE l.owner=$1 AND l.projection=$3 AND l.type=${relationship} AND l.${from}_type=${source} AND l.${to}_type=${target}
        )`, `${name} AS (
          SELECT ${columns} FROM ${tables.objects} o JOIN ${keys} target ON target.id=o.id
          WHERE o.owner=$1 AND o.projection=$3 AND o.type=${target} AND ${policy}
        )`);
                relation = name;
                sourceType = nav.target;
            }
            prefix = (prefix ? prefix.trimEnd() + ', ' : 'WITH ') + steps.join(', ') + ' ';
            filter = '';
        }
        const property = hops.length ? this.storedFields([type], values, type) : selection.property;
        return { type, prefix, relation, filter, values, bind, property };
    }
    recordSetRead() {
        if (this.model.scenario)
            this.access.recordScenarioRead(this.model, this.model.scenario, this.model.release);
    }
    async readSetQuery(statement, values, traversal) {
        if (traversal) {
            // Fresh projections can drastically underestimate frontier size. Prefer set joins within this Object Set transaction.
            await this.db.query('SET LOCAL enable_nestloop=off', [], this.client);
        }
        return this.db.readQuery(statement, values, this.client);
    }
    async readStoredSet(input, path, limit) {
        this.requireExclusive('set query');
        const selection = await this.storedSetSelection(input, path);
        if (!selection || Object.values(this.model.object(selection.type).properties).some(property => property.derived))
            return undefined;
        const { prefix, relation, filter, values, bind } = selection;
        const result = await this.readSetQuery(`${prefix}SELECT o.type,o.id,o.revision,o.properties FROM ${relation} o
      ${filter} LIMIT ${bind(limit + 1)}`, values, path.length > 0);
        if (result.rows.length > limit)
            throw new Conflict('Object set exceeds the complete evaluation limit');
        this.recordSetRead();
        return result.rows.map(row => this.visible(this.row(row)));
    }
    /** Keep eligible set membership and reduction inside PostgreSQL. */
    async aggregateStored(input, view, groupBy, metrics, groupLimit, path) {
        this.requireExclusive('set query');
        const selection = await this.storedSetSelection(input, path);
        if (!selection)
            return undefined;
        const { type, prefix, relation, filter, values, bind, property } = selection;
        const outputView = view ?? type;
        if (!this.model.implements(type, outputView))
            return undefined;
        const metricEntries = Object.entries(metrics);
        const groupFields = [...groupBy, ...metricEntries.flatMap(([, metric]) => metric.property ? [metric.property] : [])];
        if (!this.mayUseStoredFields(outputView, [type], groupFields))
            return undefined;
        for (const field of groupFields)
            this.model.propertyPath(outputView, field);
        if (metricEntries.some(([, metric]) => metric.op !== 'count' && !isNumeric(this.model.propertyPath(outputView, metric.property))))
            return undefined;
        const groups = groupBy.map((field, index) => `NULLIF(${property(field, outputView)},'null'::jsonb) AS g${index}`);
        const aggregates = metricEntries.map(([, metric], index) => {
            const field = metric.property ? `NULLIF(${property(metric.property, outputView)},'null'::jsonb)` : '*';
            const operand = metric.op === 'count' ? field : `(${field})::double precision`;
            return `${metric.op.toUpperCase()}(${operand}) AS m${index}`;
        });
        const group = groups.length ? 'GROUP BY ' + groupBy.map((_, index) => 'g' + index).join(', ') : '';
        const statement = `${prefix}SELECT COUNT(*) AS count,${[...groups, ...aggregates].join(', ')}
      FROM ${relation} o ${filter} ${group}
      ORDER BY MIN(to_json(o.id)::text COLLATE "C") LIMIT ${bind(groupLimit + 1)}`;
        const rows = await this.readSetQuery(statement, values, path.length > 0)
            .catch(error => {
            if (error?.code === '22003')
                throw new Conflict('Numeric aggregation overflow');
            throw error;
        });
        if (rows.rows.length > groupLimit)
            throw new Conflict('Object set exceeds the aggregate group limit');
        this.recordSetRead();
        return {
            count: rows.rows.reduce((total, row) => total + Number(row.count), 0),
            items: rows.rows.map(row => ({
                group: Object.fromEntries(groupBy.map((field, index) => [field, row['g' + index]])),
                metrics: Object.fromEntries(metricEntries.map(([name], index) => {
                    const value = row['m' + index] === null ? null : Number(row['m' + index]);
                    if (value !== null && !Number.isFinite(value))
                        throw new Conflict('Numeric aggregation overflow');
                    return [name, value];
                })),
            })),
        };
    }
    /** Object Set frontiers have already been read within this transaction. Recheck both endpoints in the join. */
    async followSet(sourceType, ids, link, as, maximum, explicitFrontier = false) {
        this.requireExclusive('set query');
        const nav = this.model.navigation(sourceType, link, as);
        if ([sourceType, nav.target].some(type => type === scenarioMetadataType || processLogTarget(this.model, type))
            || Object.values(this.model.object(nav.target).properties).some(property => property.derived))
            return undefined;
        if (as)
            this.access.definition(this.model, 'interface', as);
        this.access.read(this.model, sourceType);
        this.access.read(this.model, nav.target);
        this.access.definition(this.model, 'link', nav.link);
        const label = this.model.links.get(nav.link)?.classification;
        if (!this.access.canSeeModelData(label))
            return [];
        this.access.observeClassification(label);
        await checkScenario(this.db, this.model, this.owner, this.client);
        const from = nav.forward ? 'from' : 'to', to = nav.forward ? 'to' : 'from';
        const values = [this.owner, this.model.projection, sourceType, ids, nav.link, nav.target, maximum + 1];
        const tables = viewTables(this.db, this.model, this.owner, values, [sourceType, nav.target]);
        const sourcePolicy = this.access.rowSql(this.model, sourceType, values, 's.properties');
        const targetPolicy = this.access.rowSql(this.model, nav.target, values, 'o.properties');
        // Start from the sources' relationship rows, which the endpoint indexes find, instead of testing every target.
        const result = await this.db.readQuery(`${tables.prefix}SELECT DISTINCT ON (o.type,o.id) o.type,o.id,o.revision,o.properties
      FROM ${tables.links} l
      JOIN ${tables.objects} s ON s.projection=l.projection AND s.owner=l.owner AND (s.type,s.id)=(l.${from}_type,l.${from}_id)
      JOIN ${tables.objects} o ON o.projection=l.projection AND o.owner=l.owner AND (o.type,o.id)=(l.${to}_type,l.${to}_id)
      WHERE l.owner=$1 AND l.projection=$2 AND l.type=$5 AND l.${from}_type=$3 AND l.${from}_id=ANY($4::text[])
        AND s.type=$3 AND ${sourcePolicy} AND o.type=$6 AND ${targetPolicy}
      ORDER BY o.type,o.id LIMIT $7`, values, this.client);
        if (result.rows.length > maximum)
            throw new Conflict(explicitFrontier ? 'Traversal exceeds the selected frontier limit' : 'Object set exceeds the complete evaluation limit');
        const records = result.rows.map(row => this.row(row));
        await this.linkedSecurityReads(records);
        return records.map(record => this.visible(record));
    }
    async follow(ref, link, view = ref.type, maximum) {
        if (maximum !== undefined && (!Number.isInteger(maximum) || maximum < 1 || maximum > maxCompleteRelationships))
            throw new InvalidInput('Relationship read limit is out of range');
        return observeDecisionRead(this, { kind: 'follow', ref, link, as: view, ...(maximum === undefined ? {} : { maximum }) }, () => this.followTargets(ref, link, view, maximum ?? maxCompleteRelationships), observedObjects);
    }
    /**
     * An object's relationship, through the query kernel as EIGOS_KERNEL says, on the same conditions as `query`: `route`
     * answers from the kernel and `shadow` compares the kernel's answer with the reference's.
     */
    async followTargets(ref, link, view, maximum) {
        const kernels = Objects.kernels();
        const allowed = kernels.mode !== 'off' && this.client === this.db.pool && !capturingDecisionReads() && this.db.readsAsOwner(this.owner);
        if (allowed && kernels.mode === 'route') {
            const kernel = await kernels.registry.kernelFor(this.db, this.model, false);
            const routed = kernel && await kernelAnswer(this.db, kernels.registry, this.model, () => this.kernelFollow(kernel, ref, link, view, maximum));
            if (routed)
                return routed;
        }
        const targets = await this.followObjects(ref, link, view, maximum);
        if (allowed && kernels.mode === 'shadow')
            await compareWithKernel(this.db, kernels.registry, this.access, this.model, 'follow', { follow: { ref, link, view, maximum } }, fork => new Objects(this.db, this.model, fork).followObjects(ref, link, view, maximum), (client, fork) => new Objects(this.db, this.model, fork).kernelFollow(client, ref, link, view, maximum));
        return targets;
    }
    /** The targets from the kernel, read with a fork of the access as `kernelQuery` reads a page. */
    async kernelFollow(kernel, ref, link, view, maximum) {
        const fork = await this.access.fork();
        const targets = await followWithKernel(kernel, this.model, fork, new Objects(this.db, this.model, fork), { ref, link, view, maximum });
        if (!targets)
            return undefined;
        if (!await fork.canReturn(fork.dataRequirements()))
            throw new Conflict('Derived result permissions changed');
        this.access.adoptReads(fork);
        return targets;
    }
    /** A mandatory relationship guard needs to distinguish a complete empty result from filtered targets. */
    async readCompleteRelationship(ref, link) {
        if (this.client === this.db.pool)
            return this.db.transaction(async (client) => {
                await this.db.query('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY', [], client);
                return new Objects(this.db, this.model, this.access, client).readCompleteRelationship(ref, link);
            });
        this.requireExclusive('complete relationship guard');
        const nav = this.model.navigation(ref.type, link);
        const items = await this.follow(ref, link);
        const label = this.model.links.get(nav.link)?.classification;
        if (!this.access.canSeeModelData(label))
            return { items, complete: false };
        const from = nav.forward ? 'from' : 'to';
        const values = [this.owner, nav.link, ref.type, ref.id, this.model.projection];
        const tables = viewTables(this.db, this.model, this.owner, values, [ref.type, nav.target]);
        const count = await this.db.readQuery(`${tables.prefix}SELECT count(*)::text AS count
      FROM ${tables.links} l WHERE l.owner=$1 AND l.type=$2 AND l.${from}_type=$3 AND l.${from}_id=$4 AND l.projection=$5`, values, this.client);
        return { items, complete: Number(count.rows[0]?.count) === items.length };
    }
    async followObjects(ref, link, view, maximum) {
        if (view !== ref.type)
            this.access.definition(this.model, 'interface', view);
        const nav = this.model.navigation(ref.type, link, view);
        if (this.client === this.db.pool && [ref.type, nav.target].some(type => Object.values(this.model.object(type).properties).some(property => property.derived))) {
            const access = await this.access.fork();
            const result = await this.db.transaction(async (client) => {
                await this.db.query('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ', [], client);
                return new Objects(this.db, this.model, access, client).follow(ref, link, view, maximum);
            });
            if (!await access.canReturn(access.dataRequirements()))
                throw new Conflict('Derived result permissions changed');
            this.access.adoptReads(access);
            return result;
        }
        await this.read(ref);
        this.access.read(this.model, nav.target);
        this.access.definition(this.model, 'link', nav.link);
        await this.lockRelationshipTargets(ref, link, view);
        const label = this.model.links.get(nav.link)?.classification;
        if (!this.access.canSeeModelData(label))
            return [];
        this.access.observeClassification(label);
        const from = nav.forward ? 'from' : 'to', to = nav.forward ? 'to' : 'from';
        await checkScenario(this.db, this.model, this.owner, this.client);
        const values = [this.owner, nav.link, ref.type, ref.id, this.model.projection];
        const policy = this.access.rowSql(this.model, nav.target, values, 'o.properties');
        const tables = viewTables(this.db, this.model, this.owner, values, [ref.type, nav.target]);
        const limit = values.push(maximum + 1);
        const result = await this.db.readQuery(`${tables.prefix}SELECT o.type,o.id,o.revision,o.properties FROM ${tables.links} l
      JOIN ${tables.objects} o ON o.projection=l.projection AND o.owner=l.owner AND o.type=l.${to}_type AND o.id=l.${to}_id
      WHERE l.owner=$1 AND l.type=$2 AND l.${from}_type=$3 AND l.${from}_id=$4 AND l.projection=$5 AND ${policy} ORDER BY o.id COLLATE "C" LIMIT $${limit}`, values, this.client);
        if (result.rows.length > maximum)
            throw new Conflict('Relationship exceeds the complete read limit. Use a paginated query through the Link.');
        await this.linkedSecurityReads(result.rows.map(row => this.row(row)));
        if (nav.target === scenarioMetadataType) {
            const items = [];
            for (const row of result.rows)
                try {
                    items.push(await scenarioMetadataRead(this, { type: scenarioMetadataType, id: String(row.id) }));
                }
                catch (error) {
                    if (!(error instanceof NotFound))
                        throw error;
                }
            return items;
        }
        const evaluator = new DerivedProperties(this), targets = result.rows.map(row => this.visible(this.row(row)));
        await evaluator.prefetch(targets);
        return Promise.all(targets.map(object => evaluator.enrich(object)));
    }
    async create(ref, input) {
        if (this.client === this.db.pool)
            return this.db.transaction(client => new Objects(this.db, this.model, this.access, client, this.change).create(ref, input));
        this.writeType(ref.type);
        await this.prepareWrite();
        await this.lockObjects([ref], 'exclusive');
        this.assertStoredFields(ref, input);
        const properties = this.model.parseObject(ref, input);
        this.access.writeRow(this.model, ref.type, properties);
        if (this.model.scenario) {
            const old = await this.stored(ref).catch(error => { if (error instanceof NotFound)
                return undefined; throw error; });
            if (old) {
                if (digest(old.properties) !== digest(properties))
                    throw new Conflict('Object identity already contains different data');
                return;
            }
            await stageObject(this.db, this.model, this.owner, ref, 1, properties, this.client, Object.keys(input), { op: 'create', journal: this.change?.scenarioEdits });
            return;
        }
        const result = await this.db.query(`INSERT INTO ${this.db.schema}.objects(owner,type,id,properties,projection) VALUES($1,$2,$3,$4,$5) ON CONFLICT DO NOTHING RETURNING id`, [this.owner, ref.type, ref.id, properties, this.model.projection], this.client);
        if (!result.rowCount) {
            if (digest((await this.stored(ref)).properties) !== digest(properties))
                throw new Conflict('Object identity already contains different data');
        }
        else
            await recordObjectEdit(this, ref, null, properties, properties, 'create');
    }
    /** Raw live snapshots for batch writes and the Action undo journal. */
    async liveSnapshots(refs) {
        if (!refs.length)
            return new Map();
        const { rows } = await this.db.query(`
      SELECT o.type,o.id,o.revision,o.properties FROM ${this.db.schema}.objects o
      JOIN jsonb_to_recordset($3::jsonb) AS r(type text,id text) ON o.type=r.type AND o.id=r.id
      WHERE o.projection=$1 AND o.owner=$2`, [this.model.projection, this.owner, JSON.stringify(refs)], this.client);
        return new Map(rows.map(row => [digest({ type: row.type, id: row.id }), { revision: Number(row.revision), properties: row.properties }]));
    }
    /** Commit independent live objects from a Scenario under its existing exclusive Action lock. */
    async writeScenarioObjects(edits) {
        if (!edits.length)
            return;
        if (this.client === this.db.pool || this.model.scenario)
            throw new Conflict('Scenario batch writes require a live Action transaction');
        this.requireExclusive('Scenario batch write');
        await this.prepareWrite();
        const references = edits.map(edit => objectRefSchema.parse(edit.ref));
        const keys = references.map(ref => digest(ref));
        if (new Set(keys).size !== keys.length)
            throw new Conflict('Scenario batch repeats an object');
        const snapshots = await this.liveSnapshots(references);
        const inserted = [];
        const updated = [];
        const journal = [];
        for (const [index, { ref, fields, revision }] of edits.entries()) {
            this.writeType(ref.type);
            if (ref.type === documentChunkType)
                throw new Conflict('Document chunks require their individual row read');
            this.assertStoredFields(ref, fields);
            const row = snapshots.get(keys[index]);
            const before = row ? this.model.parseObject(ref, row.properties) : null;
            if (revision === undefined) {
                const after = this.model.parseObject(ref, fields);
                this.access.writeRow(this.model, ref.type, after);
                if (before) {
                    if (digest(before) !== digest(after))
                        throw new Conflict('Object identity already contains different data');
                    continue;
                }
                inserted.push({ ...ref, properties: after });
                journal.push({ ref, before, after, kind: 'create' });
            }
            else {
                if (!row || !before)
                    throw new NotFound('Object is unavailable');
                const after = this.model.parseObject(ref, { ...before, ...fields });
                this.access.readRow(this.model, ref.type, before);
                for (const field of Object.keys(fields))
                    if (!this.access.cell(this.model, ref.type, field, before))
                        throw new PermissionDenied('Cannot edit a hidden property');
                this.access.writeRow(this.model, ref.type, after);
                if (row.revision !== revision)
                    throw new Conflict('Object revision changed');
                updated.push({ ...ref, revision, properties: after });
                journal.push({ ref, before, after, changedFields: fields, kind: 'edit' });
            }
        }
        const scope = [this.model.projection, this.owner];
        if (inserted.length) {
            const result = await this.db.query(`INSERT INTO ${this.db.schema}.objects(projection,owner,type,id,properties)
        SELECT $1,$2,type,id,properties FROM jsonb_to_recordset($3::jsonb) AS r(type text,id text,properties jsonb)
        ON CONFLICT DO NOTHING`, [...scope, JSON.stringify(inserted)], this.client);
            if (result.rowCount !== inserted.length)
                throw new Conflict('Object identity already contains different data');
        }
        if (updated.length) {
            const result = await this.db.query(`UPDATE ${this.db.schema}.objects o SET properties=r.properties,revision=o.revision+1
        FROM jsonb_to_recordset($3::jsonb) AS r(type text,id text,properties jsonb,revision bigint)
        WHERE o.projection=$1 AND o.owner=$2 AND o.type=r.type AND o.id=r.id AND o.revision=r.revision`, [...scope, JSON.stringify(updated)], this.client);
            if (result.rowCount !== updated.length)
                throw new Conflict('Object revision changed');
        }
        await recordObjectEdits(this, journal);
    }
    async ingestBatch(input, source = 'default', observedAt) {
        if (this.client === this.db.pool)
            return this.db.transaction(client => new Objects(this.db, this.model, this.access, client, this.change).ingestBatch(input, source, observedAt));
        await this.prepareWrite();
        if (this.model.scenario)
            throw new Conflict('Source ingestion is unavailable inside a scenario');
        const unique = new Map();
        for (const item of input) {
            this.writeType(item.ref.type);
            if (item.properties)
                this.assertStoredFields(item.ref, item.properties);
            const properties = item.properties === null ? null : this.model.parseObject(item.ref, item.properties);
            const key = JSON.stringify(item.ref), prior = unique.get(key);
            if (prior && digest(prior.properties) !== digest(properties))
                throw new Conflict('Source rows disagree about one object');
            unique.set(key, { ref: item.ref, properties });
        }
        await this.lockObjects([...unique.values()].map(entry => entry.ref), 'exclusive');
        const entries = [...unique.values()], stored = await this.storedSources(entries.map(entry => entry.ref));
        const observations = entries.map(({ ref, properties }) => {
            if (properties)
                this.access.sourceRow(this.model, ref.type, properties);
            const old = stored.get(JSON.stringify([ref.type, ref.id]));
            if (old?.visible)
                this.access.sourceRow(this.model, ref.type, old.visible.properties);
            return { ref, incoming: properties, before: old?.raw ?? null };
        });
        const removed = [], written = [];
        (await resolveSourceEdits(this, observations, source, observedAt)).forEach(({ value, current }, index) => {
            const { ref } = entries[index];
            if (value)
                this.access.sourceRow(this.model, ref.type, value);
            if (!current)
                return;
            if (value === null)
                removed.push(ref);
            else
                written.push({ type: ref.type, id: ref.id, properties: value });
        });
        const scope = [this.model.projection, this.owner], rows = (refs) => JSON.stringify(refs.map(({ type, id }) => ({ type, id })));
        // Deleting an object deletes its relationships with objects this commit has not locked.
        if (removed.length)
            this.requireExclusive('source deletion');
        if (removed.length) {
            const values = [...scope, rows(removed)];
            await this.db.query(`WITH removed AS (DELETE FROM ${this.db.schema}.links l USING jsonb_to_recordset($3::jsonb) AS k(type text,id text)
        WHERE l.projection=$1 AND l.owner=$2 AND ((l.from_type=k.type AND l.from_id=k.id) OR (l.to_type=k.type AND l.to_id=k.id))
        RETURNING l.type,l.from_type,l.from_id,l.to_type,l.to_id) ${journalLinks(this, 'unlink', 'removed', '$1', '$2', values, source)}`, values, this.client);
            await this.db.query(`DELETE FROM ${this.db.schema}.objects o USING jsonb_to_recordset($3::jsonb) AS k(type text,id text)
        WHERE o.projection=$1 AND o.owner=$2 AND o.type=k.type AND o.id=k.id`, [...scope, rows(removed)], this.client);
        }
        if (written.length)
            await this.db.query(`INSERT INTO ${this.db.schema}.objects AS o(projection,owner,type,id,properties)
      SELECT $1,$2,r.type,r.id,r.properties FROM jsonb_to_recordset($3::jsonb) AS r(type text,id text,properties jsonb)
      ON CONFLICT(projection,owner,type,id) DO UPDATE SET properties=excluded.properties,revision=o.revision+1
      WHERE o.properties IS DISTINCT FROM excluded.properties`, [...scope, JSON.stringify(written)], this.client);
    }
    /** Stored rows for source ingestion: the raw value it replaces, and the parsed value when the caller may see it. */
    async storedSources(refs) {
        const found = new Map();
        if (!refs.length)
            return found;
        const { rows } = await this.db.query(`SELECT o.type,o.id,o.revision,o.properties FROM ${this.db.schema}.objects o
      JOIN jsonb_to_recordset($3::jsonb) AS k(type text,id text) ON o.type=k.type AND o.id=k.id
      WHERE o.projection=$1 AND o.owner=$2`, [this.model.projection, this.owner, JSON.stringify(refs.map(({ type, id }) => ({ type, id })))], this.client);
        for (const row of rows) {
            const ref = { type: String(row.type), id: String(row.id) };
            // Row policies decide whether a document chunk counts as an existing visible row, as for a single read.
            const visible = ref.type === documentChunkType || processLogTarget(this.model, ref.type)
                ? await this.stored(ref).catch(error => { if (error instanceof NotFound)
                    return undefined; throw error; })
                : this.row(row);
            found.set(JSON.stringify([ref.type, ref.id]), { raw: row.properties, visible });
        }
        return found;
    }
    async edit(ref, revision, fields, expected) {
        if (this.client === this.db.pool)
            return this.db.transaction(client => new Objects(this.db, this.model, this.access, client, this.change).edit(ref, revision, fields, expected));
        this.writeType(ref.type);
        await this.prepareWrite();
        await this.lockObjects([ref], 'exclusive');
        this.assertStoredFields(ref, fields);
        const old = await this.stored(ref), properties = this.model.parseObject(ref, { ...old.properties, ...fields });
        this.access.readRow(this.model, ref.type, old.properties);
        for (const field of Object.keys(fields))
            if (!this.access.cell(this.model, ref.type, field, old.properties))
                throw new PermissionDenied('Cannot edit a hidden property');
        this.access.writeRow(this.model, ref.type, properties);
        if (expected) {
            const fieldsMatch = Object.keys(fields).every(name => Object.hasOwn(expected, name) &&
                digest({ value: old.properties[name] }) === digest({ value: expected[name] }));
            if (!Number.isSafeInteger(revision) || revision < 1 || revision > old.revision || !fieldsMatch)
                throw new Conflict('Compared object properties changed');
            revision = old.revision;
        }
        else if (old.revision !== revision)
            throw new Conflict('Object revision changed');
        if (this.model.scenario) {
            await stageObject(this.db, this.model, this.owner, ref, revision + 1, properties, this.client, Object.keys(fields), { op: 'edit', journal: this.change?.scenarioEdits });
            return;
        }
        const buffered = HotEditBuffer.for(this.client, this.model, this.owner, ref);
        if (buffered) {
            buffered.edit(revision, properties, fields);
            return;
        }
        const result = await this.db.query(`UPDATE ${this.db.schema}.objects SET properties=$4,revision=revision+1 WHERE owner=$1 AND type=$2 AND id=$3 AND revision=$5 AND projection=$6`, [this.owner, ref.type, ref.id, properties, revision, this.model.projection], this.client);
        if (!result.rowCount)
            throw new Conflict('Object revision changed');
        await recordObjectEdit(this, ref, old.properties, properties, fields, 'edit');
    }
    async link(edge) {
        return this.linkBatch([edge]);
    }
    async readScenarioLinkEndpoints(edges) {
        const refs = [...new Map(edges.flatMap(edge => [edge.from, edge.to]).map(ref => [digest(ref), ref])).values()];
        if (capturingDecisionReads()) {
            for (const ref of refs)
                await this.read(ref);
            return;
        }
        const regular = refs.filter(ref => ref.type !== scenarioMetadataType);
        const visible = new Set((await this.readBatch(regular)).map(object => digest(object.ref)));
        // Use the individual read's exact missing-row or permission response.
        for (const ref of refs)
            if (!visible.has(digest(ref)))
                await this.read(ref);
    }
    async linkBatch(edges, scenarioMerge = false) {
        if (this.client === this.db.pool) {
            if (scenarioMerge)
                throw new Conflict('Scenario link writes require a live Action transaction');
            return this.db.transaction(client => new Objects(this.db, this.model, this.access, client, this.change).linkBatch(edges));
        }
        await this.prepareWrite();
        if (!edges.length)
            return;
        await this.lockObjects(edges.flatMap(edge => [edge.from, edge.to]), 'exclusive');
        if (scenarioMerge) {
            if (this.model.scenario)
                throw new Conflict('Scenario link writes require the live Ontology');
            this.requireExclusive('Scenario link writes');
            await this.readScenarioLinkEndpoints(edges);
        }
        else {
            for (const edge of edges) {
                await this.read(edge.from);
                await this.read(edge.to);
            }
        }
        const rows = edges.map(edge => {
            this.access.definition(this.model, 'link', edge.type);
            this.writeType(edge.from.type, true);
            this.writeType(edge.to.type, true);
            const definition = this.model.links.get(edge.type);
            if (!definition || edge.from.type !== definition.from.type || edge.to.type !== definition.to.type)
                throw new InvalidInput('Invalid link endpoints');
            return { type: edge.type, from_type: edge.from.type, from_id: edge.from.id, to_type: edge.to.type, to_id: edge.to.id, single_from: definition.from.cardinality === 'one', single_to: definition.to.cardinality === 'one' };
        });
        if (this.model.scenario) {
            for (const edge of edges) {
                await this.stored(edge.from);
                await this.stored(edge.to);
                const definition = this.model.links.get(edge.type);
                const singleFrom = definition.from.cardinality === 'one', singleTo = definition.to.cardinality === 'one';
                if (singleFrom || singleTo) {
                    const values = [this.model.projection, this.owner, edge.type, edge.from.type, edge.from.id,
                        edge.to.type, edge.to.id, singleFrom, singleTo];
                    const tables = viewTables(this.db, this.model, this.owner, values, [], true);
                    const { rows: [row] } = await this.db.query(`${tables.prefix}SELECT EXISTS(
            SELECT 1 FROM ${tables.links} WHERE projection=$1 AND owner=$2 AND type=$3
            AND (($8 AND (from_type,from_id)=($4,$5) AND (to_type,to_id)<>($6,$7))
              OR ($9 AND (to_type,to_id)=($6,$7) AND (from_type,from_id)<>($4,$5)))
          ) AS conflicting`, values, this.client);
                    if (row?.conflicting)
                        throw new Conflict('Link cardinality exceeded');
                }
                await stageLink(this.db, this.model, this.owner, edge, false, this.client, this.change?.scenarioEdits);
            }
            return;
        }
        try {
            // Only relationships this commit adds are journaled; an existing one is left as it is.
            const values = [this.owner, JSON.stringify(rows), this.model.projection];
            await this.db.query(`WITH added AS (INSERT INTO ${this.db.schema}.links(owner,type,from_type,from_id,to_type,to_id,single_from,single_to,projection)
        SELECT $1,type,from_type,from_id,to_type,to_id,single_from,single_to,$3 FROM jsonb_to_recordset($2::jsonb)
        AS input(type text,from_type text,from_id text,to_type text,to_id text,single_from boolean,single_to boolean)
        ON CONFLICT(projection,owner,type,from_type,from_id,to_type,to_id) DO NOTHING
        RETURNING type,from_type,from_id,to_type,to_id) ${journalLinks(this, 'link', 'added', '$3', '$1', values)}`, values, this.client);
        }
        catch (error) {
            const databaseError = error;
            if (databaseError?.code === '23505' &&
                (databaseError.constraint === 'links_single_from' || databaseError.constraint === 'links_single_to'))
                throw new Conflict('Link cardinality exceeded');
            throw error;
        }
    }
    async unlinkScenarioLinks(edges) {
        if (!edges.length)
            return;
        if (this.client === this.db.pool || this.model.scenario)
            throw new Conflict('Scenario link writes require a live Action transaction');
        this.requireExclusive('Scenario link writes');
        await this.prepareWrite();
        for (const edge of edges)
            this.access.definition(this.model, 'link', edge.type);
        await this.readScenarioLinkEndpoints(edges);
        const rows = edges.map(edge => {
            this.writeType(edge.from.type, true);
            this.writeType(edge.to.type, true);
            const definition = this.model.links.get(edge.type);
            if (!definition || edge.from.type !== definition.from.type || edge.to.type !== definition.to.type)
                throw new InvalidInput('Invalid link endpoints');
            return { type: edge.type, from_type: edge.from.type, from_id: edge.from.id, to_type: edge.to.type, to_id: edge.to.id };
        });
        const values = [this.model.projection, this.owner, JSON.stringify(rows)];
        await this.db.query(`WITH removed AS (DELETE FROM ${this.db.schema}.links l
      USING jsonb_to_recordset($3::jsonb) AS r(type text,from_type text,from_id text,to_type text,to_id text)
      WHERE l.projection=$1 AND l.owner=$2 AND (l.type,l.from_type,l.from_id,l.to_type,l.to_id)=(r.type,r.from_type,r.from_id,r.to_type,r.to_id)
      RETURNING l.type,l.from_type,l.from_id,l.to_type,l.to_id) ${journalLinks(this, 'unlink', 'removed', '$1', '$2', values)}`, values, this.client);
    }
    async unlink(edge) {
        if (this.client === this.db.pool)
            return this.db.transaction(client => new Objects(this.db, this.model, this.access, client, this.change).unlink(edge));
        await this.prepareWrite();
        this.access.definition(this.model, 'link', edge.type);
        await this.lockObjects([edge.from, edge.to], 'exclusive');
        await this.read(edge.from);
        await this.read(edge.to);
        this.writeType(edge.from.type, true);
        this.writeType(edge.to.type, true);
        const definition = this.model.links.get(edge.type);
        if (!definition || definition.from.type !== edge.from.type || definition.to.type !== edge.to.type)
            throw new InvalidInput('Invalid link endpoints');
        if (this.model.scenario)
            return stageLink(this.db, this.model, this.owner, edge, true, this.client, this.change?.scenarioEdits);
        const values = [this.model.projection, this.owner, edge.type, edge.from.type, edge.from.id, edge.to.type, edge.to.id];
        await this.db.query(`WITH removed AS (DELETE FROM ${this.db.schema}.links WHERE projection=$1 AND owner=$2 AND type=$3 AND from_type=$4 AND from_id=$5 AND to_type=$6 AND to_id=$7
      RETURNING type,from_type,from_id,to_type,to_id) ${journalLinks(this, 'unlink', 'removed', '$1', '$2', values)}`, values, this.client);
    }
    async remove(ref, revision) {
        if (this.client === this.db.pool)
            return this.db.transaction(client => new Objects(this.db, this.model, this.access, client, this.change).remove(ref, revision));
        await this.prepareWrite();
        this.writeType(ref.type);
        await this.lockObjects([ref], 'exclusive');
        const old = await this.stored(ref);
        this.access.readRow(this.model, ref.type, old.properties);
        for (const field of Object.keys(old.properties))
            if (!this.access.cell(this.model, ref.type, field, old.properties))
                throw new PermissionDenied('Cannot delete an object with hidden properties');
        if (old.revision !== revision)
            throw new Conflict('Object revision changed');
        const edges = new Map();
        for (const link of this.model.links.values()) {
            if (processLogTarget(this.model, link.from.type) || processLogTarget(this.model, link.to.type))
                continue;
            // Unavailable sandbox relationships are still counted by the physical-edge check below.
            if (!this.db.sandboxEnabled && [link.from.type, link.to.type].some(type => isSandboxResource(this.model, 'object', type)))
                continue;
            for (const side of ['from', 'to'])
                if (link[side].type === ref.type) {
                    for (const other of await this.follow(ref, link[side].name)) {
                        const edge = { type: link.apiName, from: side === 'from' ? ref : other.ref, to: side === 'to' ? ref : other.ref };
                        edges.set(digest(edge), edge);
                        if (edges.size > maxCompleteRelationships)
                            throw new Conflict('Unlink relationships in smaller groups before deleting this object');
                    }
                }
        }
        // Compare authorized edges with physical edges without returning hidden endpoints or counts.
        const values = [this.model.projection, this.owner, ref.type, ref.id, edges.size];
        const tables = viewTables(this.db, this.model, this.owner, values, [], true);
        const { rows: [incident] } = await this.db.query(`${tables.prefix}SELECT EXISTS(
      SELECT 1 FROM ${tables.links} WHERE projection=$1 AND owner=$2
      AND ((from_type=$3 AND from_id=$4) OR (to_type=$3 AND to_id=$4))
      LIMIT 1 OFFSET $5
    ) AS hidden`, values, this.client);
        if (incident?.hidden)
            throw new PermissionDenied('Cannot delete an object with inaccessible relationships');
        for (const edge of edges.values())
            await this.unlink(edge);
        if (this.model.scenario)
            return stageObject(this.db, this.model, this.owner, ref, revision + 1, null, this.client, [], { op: 'delete', journal: this.change?.scenarioEdits });
        await this.db.query(`DELETE FROM ${this.db.schema}.objects WHERE projection=$1 AND owner=$2 AND type=$3 AND id=$4 AND revision=$5`, [this.model.projection, this.owner, ref.type, ref.id, revision], this.client);
        await recordObjectEdit(this, ref, old.properties, null, undefined, 'delete');
    }
}
