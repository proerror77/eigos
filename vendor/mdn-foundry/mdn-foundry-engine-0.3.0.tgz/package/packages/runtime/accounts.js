import { randomBytes } from 'node:crypto';
import { digest, InvalidInput } from '../core/identity.js';
import { attachSecurityEpochTrigger, notifySecurityCacheInvalidated } from './security.js';
export const accountGroup = 'eigos-accounts';
export const accountActionsGroup = 'eigos-account-actions';
/** Group that held the same grants before member accounts became self-service accounts. */
const legacyMemberGroup = 'eigos-member-queries';
export const accountTaskScopes = ['tasks:read', 'tasks:write'];
export const agentTokenPattern = /^eigos_agent_[A-Za-z0-9_-]{43}$/;
export const newAccountSecret = () => randomBytes(32).toString('base64url');
export const emailDigest = (email) => digest(email.trim().toLowerCase());
const emailApprovalId = (emailHash) => digest(['verified-email-beta-approval', emailHash]);
const accountColumns = 'owner,status,activated_at,approved_at,revoked_at,suspended_at,suspended_reason,email_hash,(agent_token_hash IS NOT NULL) AS has_agent_token';
const denied = (reason) => ({ kind: 'denied', reason });
export async function initializeAccounts(db) {
    const s = db.schema;
    await db.query(`
    DO $$ BEGIN
      IF to_regclass('${s}.member_accounts') IS NOT NULL AND to_regclass('${s}.accounts') IS NULL THEN
        ALTER TABLE ${s}.member_accounts RENAME TO accounts;
      END IF;
    END $$;
    CREATE TABLE IF NOT EXISTS ${s}.accounts (
      owner text PRIMARY KEY, activated_at timestamptz NOT NULL DEFAULT now(), approved_at timestamptz, revoked_at timestamptz);
    ALTER TABLE ${s}.accounts ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'active',
      ADD COLUMN IF NOT EXISTS suspended_at timestamptz, ADD COLUMN IF NOT EXISTS suspended_reason text,
      ADD COLUMN IF NOT EXISTS email_hash text, ADD COLUMN IF NOT EXISTS agent_token_hash text;
    CREATE UNIQUE INDEX IF NOT EXISTS accounts_agent_token ON ${s}.accounts(agent_token_hash) WHERE agent_token_hash IS NOT NULL;
    DO $$ BEGIN
      IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='accounts_status_check' AND conrelid='${s}.accounts'::regclass) THEN
        ALTER TABLE ${s}.accounts ADD CONSTRAINT accounts_status_check CHECK (status IN ('active','suspended'));
      END IF;
    END $$;
    CREATE INDEX IF NOT EXISTS accounts_email ON ${s}.accounts(email_hash) WHERE email_hash IS NOT NULL;
    CREATE TABLE IF NOT EXISTS ${s}.member_invitations (
      code_hash text PRIMARY KEY, email_hash text NOT NULL, expires_at timestamptz NOT NULL,
      redeemed_by text REFERENCES ${s}.accounts(owner));
    ALTER TABLE ${s}.member_invitations ADD COLUMN IF NOT EXISTS applicant_owner text;
    ALTER TABLE ${s}.member_invitations ADD COLUMN IF NOT EXISTS automatic boolean NOT NULL DEFAULT false;
    CREATE INDEX IF NOT EXISTS invitations_applicant ON ${s}.member_invitations(applicant_owner,email_hash) WHERE redeemed_by IS NULL;
    CREATE TABLE IF NOT EXISTS ${s}.account_applications (
      owner text PRIMARY KEY, email_hash text NOT NULL, email text NOT NULL, purpose text NOT NULL,
      applied_at timestamptz NOT NULL DEFAULT now());
    CREATE INDEX IF NOT EXISTS applications_email ON ${s}.account_applications(email_hash);
    CREATE TABLE IF NOT EXISTS ${s}.member_sessions (
      token_hash text PRIMARY KEY, owner text NOT NULL, email_hash text NOT NULL,
      expires_at timestamptz NOT NULL);
    CREATE INDEX IF NOT EXISTS member_sessions_expiry ON ${s}.member_sessions(expires_at);
    INSERT INTO ${s}.resource_grants(subject,resource,permission)
      SELECT 'group:${accountGroup}',resource,permission FROM ${s}.resource_grants WHERE subject='group:${legacyMemberGroup}'
      ON CONFLICT DO NOTHING;
    DELETE FROM ${s}.resource_grants WHERE subject='group:${legacyMemberGroup}';
  `);
    await attachSecurityEpochTrigger(db, 'accounts');
}
/** Default supplier reads are available to verified, currently authorized invite recipients. */
export async function hasBetaReadAccess(db, owner) {
    const result = await db.query(`SELECT 1 FROM ${db.schema}.accounts a
    WHERE a.owner=$1 AND a.status='active' AND a.email_hash IS NOT NULL
      AND a.approved_at IS NOT NULL AND a.revoked_at IS NULL
      AND EXISTS (SELECT 1 FROM ${db.schema}.member_invitations i WHERE i.redeemed_by=a.owner)`, [owner]);
    return Boolean(result.rowCount);
}
export class Accounts {
    db;
    signup;
    constructor(db, signup) {
        this.db = db;
        this.signup = signup;
    }
    async apply(session, email, purpose) {
        const emailHash = emailDigest(email), s = this.db.schema;
        if (this.signup !== 'invite' || emailHash !== session.email_hash)
            return false;
        return this.db.transaction(async (client) => {
            await this.lockApplication(session.owner, client);
            if (await this.account(session.owner, client) || await this.isOperator(session.owner, client))
                return false;
            await this.db.query(`INSERT INTO ${s}.account_applications(owner,email_hash,email,purpose)
        VALUES($1,$2,$3,$4) ON CONFLICT(owner) DO UPDATE SET
        email_hash=excluded.email_hash,email=excluded.email,purpose=excluded.purpose,applied_at=now()
        WHERE account_applications.email_hash<>excluded.email_hash`, [session.owner, emailHash, email, purpose], client);
            return true;
        });
    }
    async applicationStatus(session) {
        const s = this.db.schema;
        return (await this.db.query(`SELECT CASE WHEN EXISTS (
      SELECT 1 FROM ${s}.member_invitations i WHERE i.email_hash=a.email_hash
        AND (i.applicant_owner=a.owner OR i.applicant_owner IS NULL)
        AND NOT i.automatic AND i.redeemed_by IS NULL AND i.expires_at>now()
      ) THEN 'invited' ELSE 'pending' END AS status
      FROM ${s}.account_applications a WHERE a.owner=$1 AND a.email_hash=$2`, [session.owner, session.email_hash])).rows[0]?.status;
    }
    async applications(offset = 0) {
        const s = this.db.schema;
        return (await this.db.query(`SELECT a.owner,a.email,a.purpose,a.applied_at,
      (SELECT max(i.expires_at) FROM ${s}.member_invitations i WHERE i.applicant_owner=a.owner AND i.email_hash=a.email_hash
        AND i.redeemed_by IS NULL AND i.expires_at>now()) AS invited_until
      FROM ${s}.account_applications a WHERE NOT EXISTS (SELECT 1 FROM ${s}.accounts b WHERE b.owner=a.owner)
      ORDER BY a.applied_at,a.owner LIMIT 100 OFFSET $1`, [offset])).rows;
    }
    async invitationOwner(target) {
        const byOwner = /^[a-f0-9]{64}$/.test(target), column = byOwner ? 'owner' : 'email_hash', s = this.db.schema;
        const { rows } = await this.db.query(`SELECT owner FROM ${s}.accounts WHERE ${column}=$1
      UNION SELECT owner FROM ${s}.account_applications WHERE ${column}=$1 AND NOT EXISTS (
        SELECT 1 FROM ${s}.accounts a WHERE a.owner=account_applications.owner)
      LIMIT 2`, [byOwner ? target : emailDigest(target)]);
        if (rows.length > 1)
            throw new InvalidInput('Multiple identities match this email. Use the applicant or account owner.');
        return rows[0]?.owner;
    }
    async invite(target, hours) {
        if (this.signup !== 'invite')
            throw new InvalidInput('Invitations require invite sign-up mode');
        const owner = await this.invitationOwner(target), s = this.db.schema;
        if (!owner)
            throw new InvalidInput('No pending application for this email or owner');
        return this.db.transaction(async (client) => {
            await this.lockApplication(owner, client);
            const application = (await this.db.query(`SELECT email_hash FROM ${s}.account_applications
        WHERE owner=$1`, [owner], client)).rows[0];
            if (!application || (!/^[a-f0-9]{64}$/.test(target) && application.email_hash !== emailDigest(target)) ||
                await this.account(owner, client) || await this.isOperator(owner, client)) {
                throw new InvalidInput('No pending application for this email or owner');
            }
            await this.db.query(`UPDATE ${s}.member_invitations SET expires_at=now()
        WHERE applicant_owner=$1 AND redeemed_by IS NULL AND expires_at>now()`, [owner], client);
            const code = newAccountSecret();
            await this.db.query(`INSERT INTO ${s}.member_invitations(code_hash,email_hash,expires_at,applicant_owner)
        VALUES($1,$2,now()+$3::int*interval '1 hour',$4)`, [digest(code), application.email_hash, hours, owner], client);
            return code;
        });
    }
    /** Open the exact verified account an operator reviewed. The receipt enables the existing Beta grants. */
    async approveApplication(owner, email) {
        if (this.signup !== 'invite')
            throw new InvalidInput('Waitlist approval requires invite sign-up mode');
        const hash = emailDigest(email), s = this.db.schema, table = `${s}.member_invitations`;
        return this.db.transaction(async (client) => {
            await this.lockApplication(owner, client);
            const application = await this.db.query(`SELECT 1 FROM ${s}.account_applications WHERE owner=$1 AND email_hash=$2`, [owner, hash], client);
            if (!application.rowCount || await this.isOperator(owner, client))
                return false;
            const existing = await this.account(owner, client);
            if (existing)
                return existing.status === 'active' && existing.email_hash === hash;
            await this.db.query(`INSERT INTO ${s}.accounts(owner,email_hash) VALUES($1,$2)`, [owner, hash], client);
            notifySecurityCacheInvalidated(this.db);
            const approved = await this.db.query(`INSERT INTO ${table}(code_hash,email_hash,expires_at,automatic,applicant_owner,redeemed_by)
        VALUES($1,$2,now(),true,$3,$3)
        ON CONFLICT(code_hash) DO UPDATE SET applicant_owner=$3,redeemed_by=$3
        WHERE ${table}.automatic AND ${table}.redeemed_by IS NULL`, [emailApprovalId(hash), hash, owner], client);
            if (!approved.rowCount)
                throw new InvalidInput('This email was already approved for a different account');
            return true;
        });
    }
    async lockApplication(owner, client) {
        await this.db.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))', [this.db.lockKey('account-application', owner)], client);
    }
    async startSession(owner, email, previousToken) {
        const token = newAccountSecret();
        await this.db.transaction(async (client) => {
            await this.db.query(`DELETE FROM ${this.db.schema}.member_sessions
        WHERE expires_at<=now() OR token_hash=$1`, [digest(previousToken)], client);
            await this.db.query(`INSERT INTO ${this.db.schema}.member_sessions(token_hash,owner,email_hash,expires_at)
        VALUES($1,$2,$3,now()+interval '8 hours')`, [digest(token), owner, emailDigest(email)], client);
        });
        return token;
    }
    async session(token) {
        if (!token)
            return;
        return (await this.db.query(`SELECT owner,email_hash
      FROM ${this.db.schema}.member_sessions WHERE token_hash=$1 AND expires_at>now()`, [digest(token)])).rows[0];
    }
    async endSession(token) {
        await this.db.query(`DELETE FROM ${this.db.schema}.member_sessions WHERE token_hash=$1`, [digest(token)]);
    }
    async account(owner, client) {
        return (await this.db.query(`SELECT ${accountColumns}
      FROM ${this.db.schema}.accounts WHERE owner=$1`, [owner], client)).rows[0];
    }
    /** Looks an account up by owner digest, or by e-mail address (newest account first when several share it). */
    async find(ownerOrEmail) {
        const byOwner = /^[a-f0-9]{64}$/.test(ownerOrEmail);
        return (await this.db.query(`SELECT ${accountColumns} FROM ${this.db.schema}.accounts
      WHERE ${byOwner ? 'owner' : 'email_hash'}=$1 ORDER BY activated_at DESC, owner LIMIT 1`, [byOwner ? ownerOrEmail : emailDigest(ownerOrEmail)])).rows[0];
    }
    /** Subjects with Eigos definition grants are operators. They keep their own grants and never become accounts. */
    async isOperator(owner, client) {
        const legacy = await this.db.query(`SELECT 1 FROM ${this.db.schema}.resource_grants
      WHERE (subject=$1 OR subject IN (SELECT 'group:'||name FROM ${this.db.schema}.security_memberships WHERE subject=$1 AND kind='group'))
      AND resource='Eigos' AND permission IN ('view_definition','edit_definition','manage_definition') LIMIT 1`, [owner], client);
        return Boolean(legacy.rowCount);
    }
    /** Returns the existing account in any status, or opens one when the sign-up mode allows it. */
    async provision(owner, emailHash, client) {
        const s = this.db.schema, existing = await this.account(owner, client);
        if (existing) {
            if (!emailHash || emailHash === existing.email_hash)
                return existing;
            return (await this.db.query(`UPDATE ${s}.accounts SET email_hash=$2 WHERE owner=$1
        RETURNING ${accountColumns}`, [owner, emailHash], client)).rows[0] ?? existing;
        }
        if (await this.isOperator(owner, client))
            return 'operator_account';
        if (this.signup === 'invite')
            return 'invite_required';
        if (this.signup === 'closed')
            return 'signup_closed';
        // A concurrent first login or first request for the same owner converges on the same row.
        const account = (await this.db.query(`INSERT INTO ${s}.accounts(owner,email_hash) VALUES($1,$2)
      ON CONFLICT(owner) DO UPDATE SET email_hash=COALESCE(excluded.email_hash,accounts.email_hash)
      RETURNING ${accountColumns}`, [owner, emailHash ?? null], client)).rows[0];
        notifySecurityCacheInvalidated(this.db);
        return account;
    }
    async activate(session, code) {
        if (this.signup === 'closed')
            return 'invalid';
        const { owner, email_hash } = session, s = this.db.schema;
        return this.db.transaction(async (client) => {
            if (await this.isOperator(owner, client))
                return 'operator_account';
            await this.lockApplication(owner, client);
            if (await this.account(owner, client))
                return 'activated';
            // Legacy invitations had no applicant owner.
            const invite = (await this.db.query(`SELECT redeemed_by FROM ${s}.member_invitations
        WHERE code_hash=$1 AND email_hash=$2 AND NOT automatic AND expires_at>now()
          AND (applicant_owner IS NULL OR (applicant_owner=$3 AND EXISTS (
            SELECT 1 FROM ${s}.account_applications a WHERE a.owner=$3 AND a.email_hash=$2))) FOR UPDATE`, [digest(code), email_hash, owner], client)).rows[0];
            if (!invite || invite.redeemed_by && invite.redeemed_by !== owner)
                return 'invalid';
            const inserted = await this.db.query(`INSERT INTO ${s}.accounts(owner,email_hash) VALUES($1,$2) ON CONFLICT DO NOTHING`, [owner, email_hash], client);
            if (!inserted.rowCount)
                return 'activated';
            notifySecurityCacheInvalidated(this.db);
            await this.db.query(`UPDATE ${s}.member_invitations SET redeemed_by=$2 WHERE code_hash=$1`, [digest(code), owner], client);
            return 'activated';
        });
    }
    /** Grants agent access. Approving again after a revocation starts a new grant, and `authorize` only accepts tokens issued in or after the second it started. */
    async approve(owner) {
        const approved = Boolean((await this.db.query(`UPDATE ${this.db.schema}.accounts
      SET approved_at=CASE WHEN approved_at IS NOT NULL AND revoked_at IS NULL THEN approved_at ELSE now() END, revoked_at=NULL
      WHERE owner=$1 AND status='active'`, [owner])).rowCount);
        if (approved)
            notifySecurityCacheInvalidated(this.db);
        return approved;
    }
    /** Creates or replaces the private Agent credential after the account holder consents in the portal. */
    async issueAgentToken(owner) {
        const token = 'eigos_agent_' + newAccountSecret();
        const issued = await this.db.query(`UPDATE ${this.db.schema}.accounts
      SET agent_token_hash=$2, approved_at=CASE WHEN approved_at IS NOT NULL AND revoked_at IS NULL THEN approved_at ELSE now() END,
        revoked_at=NULL WHERE owner=$1 AND status='active'`, [owner, digest(token)]);
        if (issued.rowCount)
            notifySecurityCacheInvalidated(this.db);
        return issued.rowCount ? token : undefined;
    }
    async agentTokenOwner(tokenHash) {
        const result = await this.db.query(`SELECT owner FROM ${this.db.schema}.accounts
      WHERE agent_token_hash=$1 AND status='active' AND approved_at IS NOT NULL AND revoked_at IS NULL`, [tokenHash]);
        return result.rows[0]?.owner;
    }
    async active(owner, client, tokenHash) {
        return Boolean((await this.db.query(`SELECT 1 FROM ${this.db.schema}.accounts
      WHERE owner=$1 AND status='active' AND approved_at IS NOT NULL AND revoked_at IS NULL
        AND ($2::text IS NULL OR agent_token_hash=$2) FOR SHARE`, [owner, tokenHash ?? null], client)).rowCount);
    }
    async revoke(owner) {
        const revoked = await this.db.query(`UPDATE ${this.db.schema}.accounts SET revoked_at=COALESCE(revoked_at,now()), agent_token_hash=NULL
      WHERE owner=$1 AND approved_at IS NOT NULL`, [owner]);
        if (revoked.rowCount)
            notifySecurityCacheInvalidated(this.db);
    }
    async suspend(owner, reason) {
        const text = reason.trim();
        if (!text || text.length > 200)
            throw new InvalidInput('Suspension reason must be 1 to 200 characters');
        const suspended = Boolean((await this.db.query(`UPDATE ${this.db.schema}.accounts
      SET status='suspended', suspended_at=now(), suspended_reason=$2 WHERE owner=$1 AND status='active'`, [owner, text])).rowCount);
        if (suspended)
            notifySecurityCacheInvalidated(this.db);
        return suspended;
    }
    async restore(owner) {
        const restored = Boolean((await this.db.query(`UPDATE ${this.db.schema}.accounts
      SET status='active', suspended_at=NULL, suspended_reason=NULL WHERE owner=$1 AND status='suspended'`, [owner])).rowCount);
        if (restored)
            notifySecurityCacheInvalidated(this.db);
        return restored;
    }
    async authorize(principal, clientId, legacyClientIds) {
        const forAccounts = Boolean(principal.memberAudience) && principal.clientId === clientId;
        let account = await this.account(principal.owner);
        if (!account && forAccounts) {
            const provisioned = await this.provision(principal.owner);
            if (typeof provisioned === 'string')
                return denied(provisioned);
            account = provisioned;
        }
        if (account || principal.memberAudience || principal.clientId === clientId) {
            if (account?.status === 'suspended')
                return denied('account_suspended');
            if (!forAccounts)
                return denied('client_not_allowed');
            if (!account?.approved_at || account.revoked_at || principal.issuedAt === undefined ||
                principal.issuedAt < Math.floor(account.approved_at.getTime() / 1000))
                return denied('client_not_authorized');
            if (!accountTaskScopes.every(scope => principal.scopes.includes(scope)))
                return denied('insufficient_scope');
            return { kind: 'account' };
        }
        // Existing operator identities retain their grants. Unprovisioned subjects cannot use a legacy client to bypass onboarding.
        if (principal.clientId && legacyClientIds.includes(principal.clientId) && await this.isOperator(principal.owner))
            return { kind: 'existing' };
        return denied('client_not_allowed');
    }
}
