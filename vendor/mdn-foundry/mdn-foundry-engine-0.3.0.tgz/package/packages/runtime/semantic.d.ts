import { z } from 'zod';
import { type ObjectData } from '../ontology/schema.js';
import { Access } from './access.js';
import type { Database } from './database.js';
import type { PublishedOntology } from './metadata.js';
import { Functions } from './functions.js';
export declare const semanticConfigureSchema: z.ZodObject<{
    name: z.ZodString;
    type: z.ZodString;
    property: z.ZodString;
    embeddingFunction: z.ZodString;
    dimensions: z.ZodNumber;
}, z.core.$strict>;
export declare const semanticIndexSchema: z.ZodObject<{
    name: z.ZodString;
    objects: z.ZodArray<z.ZodObject<{
        type: z.ZodString;
        id: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const semanticSearchSchema: z.ZodObject<{
    name: z.ZodString;
    text: z.ZodString;
    from: z.ZodOptional<z.ZodObject<{
        object: z.ZodObject<{
            type: z.ZodString;
            id: z.ZodString;
        }, z.core.$strict>;
        link: z.ZodString;
        as: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    limit: z.ZodDefault<z.ZodNumber>;
}, z.core.$strict>;
export declare const semanticSearchViewSchema: z.ZodObject<{
    name: z.ZodString;
    text: z.ZodString;
    from: z.ZodOptional<z.ZodObject<{
        object: z.ZodObject<{
            type: z.ZodString;
            id: z.ZodString;
        }, z.core.$strict>;
        link: z.ZodString;
        as: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    limit: z.ZodDefault<z.ZodNumber>;
    scenarioId: z.ZodOptional<z.ZodUUID>;
}, z.core.$strict>;
export declare const semanticStatusSchema: z.ZodObject<{
    name: z.ZodString;
}, z.core.$strict>;
export declare function initializeSemantic(db: Database): Promise<void>;
declare function chunkCitation(object: ObjectData): {
    version: {
        type: string;
        id: string;
    };
    chunk: {
        type: string;
        id: string;
    };
    index: number;
    startOffset: number;
    endOffset: number;
    page?: number | undefined;
    paragraph?: number | undefined;
} | undefined;
type Backend = 'jsonb' | 'pgvector';
export declare class SemanticSearch {
    private readonly db;
    private readonly functions;
    constructor(db: Database, functions: Functions);
    configure(access: Access, model: PublishedOntology, raw: unknown): Promise<{
        name: string;
        type: string;
        property: string;
        embeddingFunction: string;
        dimensions: number;
        release: string;
        binding: string;
        modelVersion: string;
    }>;
    private configuration;
    private embed;
    index(access: Access, model: PublishedOntology, raw: unknown): Promise<{
        name: string;
        indexed: number;
        release: string;
        dimensions: number;
        binding: string;
        modelVersion: string;
    }>;
    private documentChunks;
    private withCandidates;
    private rank;
    private canPushSql;
    private buildSqlScope;
    search(access: Access, model: PublishedOntology, raw: unknown): Promise<{
        name: string;
        items: {
            object: ObjectData;
            citation?: ReturnType<typeof chunkCitation>;
            score: number;
        }[];
        dimensions: number;
        binding: string;
        modelVersion: string;
        search: string;
        backend: Backend;
    }>;
    status(access: Access, model: PublishedOntology, name: string): Promise<{
        name: string;
        type: string;
        property: string;
        embeddingFunction: string;
        dimensions: number;
        release: string;
        binding: string;
        modelVersion: string;
        currentAuthorizedObjects: number;
        search: string;
        backend: Backend;
    }>;
}
export {};
