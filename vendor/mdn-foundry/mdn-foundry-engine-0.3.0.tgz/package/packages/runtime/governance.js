import { analyzeProposal, visibleProposalEvidence } from './machinery-proposal.js';
import { resourceGroups } from '../ontology/resource-mapping.js';
import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import { InvalidInput, Conflict, NotFound, PermissionDenied, digest } from '../core/identity.js';
import { Ontology } from '../ontology/model.js';
import { ontologySchema } from '../ontology/schema.js';
import { resource } from './access.js';
import { attachSecurityEpochTrigger, notifySecurityCacheInvalidated } from './security.js';
const identifier = z.string().regex(/^[A-Za-z][A-Za-z0-9]*$/).max(80);
export const projectSchema = z.strictObject({ ontology: identifier, id: identifier, name: z.string().min(1).max(200) });
export const assignProjectSchema = z.strictObject({ ontology: identifier, project: identifier, resources: z.array(z.string().min(1).max(300)).min(1).max(200) });
export const branchCreateSchema = z.strictObject({ ontology: identifier, project: identifier.optional(), name: z.string().min(1).max(200), body: ontologySchema.optional(), baseRelease: z.string().regex(/^[0-9a-f]{64}$/).optional() });
export const branchRevisionSchema = z.strictObject({ id: z.uuid(), revision: z.number().int().positive() });
export const branchUpdateSchema = branchRevisionSchema.extend({ body: ontologySchema });
export const branchReviewSchema = branchRevisionSchema.extend({ release: z.string().regex(/^[a-f0-9]{64}$/) });
export async function initializeGovernance(db) {
    await db.query(`CREATE TABLE IF NOT EXISTS ${db.schema}.ontology_projects (
    ontology text NOT NULL, id text NOT NULL, name text NOT NULL, PRIMARY KEY(ontology,id));
    CREATE TABLE IF NOT EXISTS ${db.schema}.ontology_resource_projects (
      ontology text NOT NULL, resource text NOT NULL, project text NOT NULL, PRIMARY KEY(ontology,resource),
      FOREIGN KEY(ontology,project) REFERENCES ${db.schema}.ontology_projects(ontology,id));
    CREATE TABLE IF NOT EXISTS ${db.schema}.ontology_branches (
      id uuid PRIMARY KEY, ontology text NOT NULL, project text, name text NOT NULL, author text NOT NULL,
      base_release text NOT NULL REFERENCES ${db.schema}.releases(digest), body jsonb NOT NULL,
      revision integer NOT NULL DEFAULT 1, state text NOT NULL DEFAULT 'draft', candidate text REFERENCES ${db.schema}.releases(digest),
      reviewer text, reviewed_digest text, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now());
    ALTER TABLE ${db.schema}.ontology_branches ADD COLUMN IF NOT EXISTS machinery_evidence jsonb;`);
    await attachSecurityEpochTrigger(db, 'ontology_resource_projects');
}
function recordContributor(evidence, owner) {
    return evidence && { ...evidence, contributors: [...new Set([...(evidence.contributors ?? [evidence.owner]), owner])] };
}
const resources = (document) => {
    const expanded = new Ontology(document).resourceDocument;
    const entries = Object.entries(resourceGroups).flatMap(([kind, field]) => (expanded[field] ?? []).map(entry => [resource(document.id, kind, entry.apiName + (kind === 'valueType' && 'version' in entry ? '@' + entry.version : '')), digest(entry)]));
    for (const imported of document.imports ?? [])
        entries.push([resource(document.id, 'import', imported.namespace), digest(imported)]);
    return new Map(entries);
};
const sameValue = (a, b) => digest(a ?? null) === digest(b ?? null);
function mergeRecord3Way(base, live, draft, conflictPrefix, nestedMerge) {
    const b = base ?? {}, l = live ?? {}, d = draft ?? {};
    const result = {};
    for (const key of new Set([...Object.keys(b), ...Object.keys(l), ...Object.keys(d)])) {
        const hasB = Object.hasOwn(b, key), hasL = Object.hasOwn(l, key), hasD = Object.hasOwn(d, key);
        const bv = hasB ? b[key] : undefined, lv = hasL ? l[key] : undefined, dv = hasD ? d[key] : undefined;
        if (sameValue(bv, dv)) {
            if (hasL)
                result[key] = structuredClone(lv);
        }
        else if (sameValue(bv, lv)) {
            if (hasD)
                result[key] = structuredClone(dv);
        }
        else if (sameValue(lv, dv)) {
            if (hasL)
                result[key] = structuredClone(lv);
        }
        else if (nestedMerge && hasB && hasL && hasD) {
            result[key] = nestedMerge(key, bv, lv, dv);
        }
        else {
            throw new Conflict(`Ontology rebase conflict: ${conflictPrefix}.${key}`);
        }
    }
    return result;
}
function mergeStringSet3Way(base, live, draft) {
    const result = new Set(live);
    const baseSet = new Set(base), draftSet = new Set(draft);
    for (const item of baseSet)
        if (!draftSet.has(item))
            result.delete(item);
    for (const item of draftSet)
        if (!baseSet.has(item))
            result.add(item);
    return [...result];
}
function mergeScalarFields3Way(base, live, draft, skip, conflictPrefix) {
    const result = {};
    for (const key of new Set([...Object.keys(base), ...Object.keys(live), ...Object.keys(draft)])) {
        if (skip.has(key))
            continue;
        const bv = Object.hasOwn(base, key) ? base[key] : undefined;
        const lv = Object.hasOwn(live, key) ? live[key] : undefined;
        const dv = Object.hasOwn(draft, key) ? draft[key] : undefined;
        let chosen;
        if (sameValue(bv, dv))
            chosen = lv;
        else if (sameValue(bv, lv))
            chosen = dv;
        else if (sameValue(lv, dv))
            chosen = lv;
        else
            throw new Conflict(`Ontology rebase conflict: ${conflictPrefix}.${key}`);
        if (chosen !== undefined)
            result[key] = structuredClone(chosen);
    }
    return result;
}
function mergeObjectType3Way(base, live, draft, conflictPrefix) {
    const merged = mergeScalarFields3Way(base, live, draft, new Set(['properties', 'interfaces']), conflictPrefix);
    merged.properties = mergeRecord3Way(base.properties, live.properties, draft.properties, `${conflictPrefix}.properties`);
    merged.interfaces = mergeRecord3Way(base.interfaces, live.interfaces, draft.interfaces, `${conflictPrefix}.interfaces`, (ifaceName, bMap, lMap, dMap) => ({
        properties: mergeRecord3Way(bMap.properties, lMap.properties, dMap.properties, `${conflictPrefix}.interfaces.${ifaceName}.properties`),
        links: mergeRecord3Way(bMap.links, lMap.links, dMap.links, `${conflictPrefix}.interfaces.${ifaceName}.links`),
        actions: mergeRecord3Way(bMap.actions, lMap.actions, dMap.actions, `${conflictPrefix}.interfaces.${ifaceName}.actions`),
    }));
    return merged;
}
function mergeInterfaceType3Way(base, live, draft, conflictPrefix) {
    const merged = mergeScalarFields3Way(base, live, draft, new Set(['properties', 'links', 'actions', 'optionalProperties']), conflictPrefix);
    merged.properties = mergeRecord3Way(base.properties, live.properties, draft.properties, `${conflictPrefix}.properties`);
    merged.links = mergeRecord3Way(base.links, live.links, draft.links, `${conflictPrefix}.links`);
    merged.actions = mergeRecord3Way(base.actions, live.actions, draft.actions, `${conflictPrefix}.actions`);
    merged.optionalProperties = mergeStringSet3Way(base.optionalProperties, live.optionalProperties, draft.optionalProperties);
    return merged;
}
export class Governance {
    db;
    metadata;
    bindings;
    constructor(db, metadata, bindings) {
        this.db = db;
        this.metadata = metadata;
        this.bindings = bindings;
    }
    authorize(access, branch, permission) {
        access.require(branch.ontology, permission, branch.project ? resource(branch.ontology, 'project', branch.project) : branch.ontology);
    }
    async row(id, client = this.db.pool, lock = false) {
        z.uuid().parse(id);
        const row = (await this.db.query(`SELECT * FROM ${this.db.schema}.ontology_branches WHERE id=$1${lock ? ' FOR UPDATE' : ''}`, [id], client)).rows[0];
        if (!row)
            throw new NotFound('Ontology branch is unavailable');
        return row;
    }
    async project(access, raw) {
        const input = projectSchema.parse(raw);
        access.require(input.ontology, 'manage_definition', input.ontology);
        await this.metadata.active(input.ontology);
        return this.db.transaction(async (client) => {
            await access.refresh(client);
            await this.db.query(`INSERT INTO ${this.db.schema}.ontology_projects(ontology,id,name) VALUES($1,$2,$3)
        ON CONFLICT(ontology,id) DO UPDATE SET name=excluded.name`, [input.ontology, input.id, input.name], client);
            return input;
        });
    }
    async assign(access, raw) {
        const input = assignProjectSchema.parse(raw);
        access.require(input.ontology, 'manage_definition', input.ontology);
        const known = resources((await this.metadata.active(input.ontology)).document);
        if (input.resources.some(name => !known.has(name)))
            throw new InvalidInput('Project assignment requires published Ontology resources');
        return this.db.transaction(async (client) => {
            await access.refresh(client);
            for (const name of input.resources)
                await this.db.query(`INSERT INTO ${this.db.schema}.ontology_resource_projects(ontology,resource,project) VALUES($1,$2,$3)
        ON CONFLICT(ontology,resource) DO UPDATE SET project=excluded.project`, [input.ontology, name, input.project], client);
            notifySecurityCacheInvalidated(this.db);
            return input;
        });
    }
    async validateChanges(access, branch, base, body, client = this.db.pool) {
        new Ontology(body);
        if (body.id !== branch.ontology)
            throw new Conflict('A branch cannot change its Ontology identity');
        this.authorize(access, branch, 'edit_definition');
        if (!branch.project)
            return;
        const before = resources(base), after = resources(body);
        const assigned = new Set((await this.db.query(`SELECT resource FROM ${this.db.schema}.ontology_resource_projects WHERE ontology=$1 AND project=$2`, [branch.ontology, branch.project], client)).rows.map(row => row.resource));
        for (const name of new Set([...before.keys(), ...after.keys()])) {
            if (before.get(name) !== after.get(name) && before.has(name) && !assigned.has(name))
                throw new Conflict('Branch edits exceed the selected project');
        }
    }
    async create(access, raw, evidence) {
        const input = branchCreateSchema.parse(raw), base = await this.metadata.active(input.ontology);
        if (input.baseRelease && input.baseRelease !== base.release)
            throw new Conflict('Ontology changed; refresh the proposed definition');
        access.require(input.ontology, 'view_definition', input.ontology);
        const branch = { ontology: input.ontology, project: input.project ?? null };
        const body = input.body ?? base.document;
        await this.validateChanges(access, branch, base.document, body);
        const id = randomUUID();
        await this.db.transaction(async (client) => {
            await access.refresh(client);
            if (branch.project && !(await this.db.query(`SELECT 1 FROM ${this.db.schema}.ontology_projects WHERE ontology=$1 AND id=$2`, [branch.ontology, branch.project], client)).rowCount)
                throw new NotFound('Ontology project is unavailable');
            if (evidence) {
                const active = await this.metadata.active(input.ontology, client, true);
                if (active.release !== evidence.release || base.release !== evidence.release || !await access.canReturn(evidence.requirements, client))
                    throw new Conflict('Machinery evidence changed before the proposal was saved');
            }
            await this.db.query(`INSERT INTO ${this.db.schema}.ontology_branches(id,ontology,project,name,author,base_release,body,machinery_evidence)
        VALUES($1,$2,$3,$4,$5,$6,$7,$8)`, [id, input.ontology, branch.project, input.name, access.principal.owner, base.release, body, evidence ?? null], client);
        });
        return this.read(access, id);
    }
    async read(access, id) {
        const row = await this.row(id);
        // Branch bodies include unchanged resources from the whole Ontology.
        access.require(row.ontology, 'view_definition', row.ontology);
        this.authorize(access, row, 'edit_definition');
        await access.refresh();
        const { machinery_evidence: evidence, ...branch } = row;
        const proposalEvidence = evidence && await visibleProposalEvidence(this.db, access, await this.metadata.get(evidence.release), evidence, branch.base_release === evidence.release ? branch.body.objectTypes.find(type => type.apiName === evidence.process)?.machinery : undefined);
        return { ...branch, ...(proposalEvidence ? { proposalEvidence } : {}) };
    }
    async list(access, ontology) {
        identifier.parse(ontology);
        access.require(ontology, 'view_definition', ontology);
        if (access.workbenchRole(ontology) === 'member')
            throw new PermissionDenied('Ontology management requires service team access');
        const rows = (await this.db.query(`SELECT id,ontology,project,name,author,revision,state,candidate,updated_at FROM ${this.db.schema}.ontology_branches WHERE ontology=$1 ORDER BY updated_at DESC LIMIT 100`, [ontology])).rows;
        const visible = rows.filter(row => access.allows({ ontology, permission: 'edit_definition', resource: row.project ? resource(ontology, 'project', row.project) : ontology }));
        await access.refresh();
        return visible;
    }
    async update(access, raw) {
        const input = branchUpdateSchema.parse(raw);
        return this.db.transaction(async (client) => {
            const row = await this.row(input.id, client, true);
            if (row.state === 'merged' || row.revision !== input.revision)
                throw new Conflict('Branch is merged or its revision changed');
            if (this.bindings.independentDefinitionReview && row.author !== access.principal.owner)
                throw new PermissionDenied('Edit or rebase your own proposal to preserve independent review');
            const base = await this.metadata.get(row.base_release, client);
            await this.validateChanges(access, row, base.document, input.body, client);
            await access.refresh(client);
            await this.db.query(`UPDATE ${this.db.schema}.ontology_branches SET body=$2,machinery_evidence=$3,revision=revision+1,state='draft',candidate=NULL,reviewer=NULL,reviewed_digest=NULL,updated_at=now() WHERE id=$1`, [input.id, input.body, recordContributor(row.machinery_evidence, access.principal.owner)], client);
            return { id: input.id, revision: input.revision + 1, state: 'draft' };
        });
    }
    async prepare(access, raw) {
        const input = branchRevisionSchema.parse(raw), row = await this.read(access, input.id);
        if (row.state === 'merged' || row.revision !== input.revision)
            throw new Conflict('Branch is merged or its revision changed');
        const active = await this.metadata.active(row.ontology);
        if (active.release !== row.base_release)
            throw new Conflict('Ontology changed; rebase the branch before preparing');
        await this.validateChanges(access, row, active.document, row.body);
        const target = row.project ? resource(row.ontology, 'project', row.project) : undefined;
        const candidate = await this.metadata.prepare(row.body, this.bindings, access, undefined, target);
        return this.db.transaction(async (client) => {
            const current = await this.row(row.id, client, true);
            if (current.revision !== row.revision || current.state === 'merged')
                throw new Conflict('Branch changed while preparing');
            await access.refresh(client);
            await this.db.query(`UPDATE ${this.db.schema}.ontology_branches SET candidate=$2,revision=revision+1,state='submitted',reviewer=NULL,reviewed_digest=NULL,updated_at=now() WHERE id=$1`, [row.id, candidate.release], client);
            return { id: row.id, revision: row.revision + 1, state: 'submitted', release: candidate.release };
        });
    }
    /** Catch-up retains the projection identity and invalidates the prior review. */
    async catchUp(access, raw) {
        const input = branchRevisionSchema.parse(raw);
        return this.db.transaction(async (client) => {
            const row = await this.row(input.id, client, true);
            if (row.state === 'merged' || row.revision !== input.revision || !row.candidate)
                throw new Conflict('Catch-up requires the current prepared branch revision');
            const base = await this.metadata.get(row.base_release, client);
            await this.validateChanges(access, row, base.document, row.body, client);
            const progress = await this.metadata.catchUp(row.candidate, this.bindings, access, row.project ? resource(row.ontology, 'project', row.project) : undefined, client);
            await this.db.query(`UPDATE ${this.db.schema}.ontology_branches SET state='submitted',reviewer=NULL,reviewed_digest=NULL,revision=revision+1,updated_at=now() WHERE id=$1`, [row.id], client);
            return { ...progress, id: row.id, revision: row.revision + 1, state: 'submitted' };
        });
    }
    async rebase(access, raw) {
        const input = branchRevisionSchema.parse(raw);
        return this.db.transaction(async (client) => {
            const row = await this.row(input.id, client, true);
            if (row.state === 'merged' || row.revision !== input.revision)
                throw new Conflict('Branch is merged or its revision changed');
            if (this.bindings.independentDefinitionReview && row.author !== access.principal.owner)
                throw new PermissionDenied('Edit or rebase your own proposal to preserve independent review');
            const old = await this.metadata.get(row.base_release, client), current = await this.metadata.active(row.ontology, client);
            const oldResources = resources(old.document), liveResources = resources(current.document), draftResources = resources(row.body);
            const oldObjects = new Map(old.document.objectTypes.map(item => [item.apiName, item]));
            const liveObjects = new Map(current.document.objectTypes.map(item => [item.apiName, item]));
            const draftObjects = new Map(row.body.objectTypes.map(item => [item.apiName, item]));
            const oldInterfaces = new Map(old.document.interfaceTypes.map(item => [item.apiName, item]));
            const liveInterfaces = new Map(current.document.interfaceTypes.map(item => [item.apiName, item]));
            const draftInterfaces = new Map(row.body.interfaceTypes.map(item => [item.apiName, item]));
            const mergedObjects = new Map();
            const mergedInterfaces = new Map();
            const objectPrefix = resource(row.ontology, 'object', '');
            const interfacePrefix = resource(row.ontology, 'interface', '');
            for (const name of new Set([...oldResources.keys(), ...liveResources.keys(), ...draftResources.keys()])) {
                if (oldResources.get(name) !== draftResources.get(name) && oldResources.get(name) !== liveResources.get(name) && draftResources.get(name) !== liveResources.get(name)) {
                    if (name.startsWith(objectPrefix)) {
                        const apiName = name.slice(objectPrefix.length);
                        const b = oldObjects.get(apiName), l = liveObjects.get(apiName), d = draftObjects.get(apiName);
                        if (b && l && d) {
                            mergedObjects.set(apiName, mergeObjectType3Way(b, l, d, name));
                            continue;
                        }
                    }
                    else if (name.startsWith(interfacePrefix)) {
                        const apiName = name.slice(interfacePrefix.length);
                        const b = oldInterfaces.get(apiName), l = liveInterfaces.get(apiName), d = draftInterfaces.get(apiName);
                        if (b && l && d) {
                            mergedInterfaces.set(apiName, mergeInterfaceType3Way(b, l, d, name));
                            continue;
                        }
                    }
                    throw new Conflict(`Ontology rebase conflict: ${name}`);
                }
            }
            const body = structuredClone(current.document);
            for (const field of Object.values(resourceGroups)) {
                const oldEntries = new Map((old.document[field] ?? []).map(item => [item.apiName + ('version' in item ? '@' + item.version : ''), digest(item)]));
                const drafts = new Map((row.body[field] ?? []).map(item => [item.apiName + ('version' in item ? '@' + item.version : ''), item]));
                const merged = new Map((body[field] ?? []).map(item => [item.apiName + ('version' in item ? '@' + item.version : ''), item]));
                for (const name of new Set([...oldEntries.keys(), ...drafts.keys()]))
                    if (oldEntries.get(name) !== (drafts.has(name) ? digest(drafts.get(name)) : undefined)) {
                        if (field === 'objectTypes' && mergedObjects.has(name)) {
                            merged.set(name, mergedObjects.get(name));
                        }
                        else if (field === 'interfaceTypes' && mergedInterfaces.has(name)) {
                            merged.set(name, mergedInterfaces.get(name));
                        }
                        else {
                            const draft = drafts.get(name);
                            if (draft)
                                merged.set(name, draft);
                            else
                                merged.delete(name);
                        }
                    }
                body[field] = [...merged.values()];
            }
            const imports = new Map((current.document.imports ?? []).map(item => [item.namespace, item]));
            const oldImports = new Map((old.document.imports ?? []).map(item => [item.namespace, item]));
            const draftImports = new Map((row.body.imports ?? []).map(item => [item.namespace, item]));
            for (const name of new Set([...oldImports.keys(), ...draftImports.keys()]))
                if (digest(oldImports.get(name) ?? null) !== digest(draftImports.get(name) ?? null)) {
                    const value = draftImports.get(name);
                    if (value)
                        imports.set(name, value);
                    else
                        imports.delete(name);
                }
            if (imports.size || row.body.imports || current.document.imports)
                body.imports = [...imports.values()];
            body.version = row.body.version;
            await this.validateChanges(access, row, current.document, body, client);
            await access.refresh(client);
            await this.db.query(`UPDATE ${this.db.schema}.ontology_branches SET body=$2,base_release=$3,machinery_evidence=$4,revision=revision+1,state='draft',candidate=NULL,reviewer=NULL,reviewed_digest=NULL,updated_at=now() WHERE id=$1`, [row.id, body, current.release, recordContributor(row.machinery_evidence, access.principal.owner)], client);
            return { id: row.id, revision: row.revision + 1, state: 'draft', baseRelease: current.release };
        });
    }
    async refreshMachineryEvidence(access, id, revision, query) {
        const row = await this.row(id);
        this.authorize(access, row, 'edit_definition');
        access.require(row.ontology, 'view_definition', row.ontology);
        const type = row.machinery_evidence?.process;
        const proposed = row.body.objectTypes.find(object => object.apiName === type)?.machinery;
        if (!type || !proposed || row.revision !== revision || row.state === 'merged')
            throw new Conflict('Select the current Machinery proposal');
        const base = await this.metadata.get(row.base_release);
        const measured = await analyzeProposal(this.db, access, base, query, type, proposed);
        const evidence = { ...measured, contributors: recordContributor(row.machinery_evidence, access.principal.owner).contributors };
        return this.db.transaction(async (client) => {
            await access.refresh(client);
            this.authorize(access, row, 'edit_definition');
            if (!await access.canReturn(evidence.requirements, client))
                throw new PermissionDenied('Machinery evidence permissions changed');
            const result = await this.db.query(`UPDATE ${this.db.schema}.ontology_branches SET machinery_evidence=$3,
        revision=revision+1,state='draft',candidate=NULL,reviewer=NULL,reviewed_digest=NULL,updated_at=now()
        WHERE id=$1 AND revision=$2 AND state<>'merged' RETURNING revision`, [id, revision, evidence], client);
            if (!result.rowCount)
                throw new Conflict('The Machinery proposal changed during analysis');
            return { id, revision: result.rows[0].revision, state: 'draft' };
        });
    }
    async reviewDigest(row, client) {
        const candidate = (await this.db.query(`SELECT source_fingerprint,projection_fingerprint FROM ${this.db.schema}.releases WHERE digest=$1`, [row.candidate], client)).rows[0];
        return digest({ body: row.body, release: row.candidate, base: row.base_release, projection: candidate, ...(row.machinery_evidence ? { evidence: digest(row.machinery_evidence) } : {}) });
    }
    async review(access, raw) {
        const input = branchReviewSchema.parse(raw);
        return this.db.transaction(async (client) => {
            const row = await this.row(input.id, client, true);
            this.authorize(access, row, 'manage_definition');
            if (this.bindings.independentDefinitionReview && row.author === access.principal.owner)
                throw new PermissionDenied('A separate reviewer must approve this proposal');
            if (row.machinery_evidence && (row.base_release !== row.machinery_evidence.release ||
                digest(row.body.objectTypes.find(object => object.apiName === row.machinery_evidence.process)?.machinery ?? null) !== row.machinery_evidence.modelDigest))
                throw new Conflict('Refresh the Machinery evidence for this revision before review');
            if (row.machinery_evidence && [row.author, row.machinery_evidence.owner, ...(row.machinery_evidence.contributors ?? [])].includes(access.principal.owner))
                throw new Conflict('Machinery proposals require independent review');
            if (row.state !== 'submitted' || row.revision !== input.revision || row.candidate !== input.release)
                throw new Conflict('Review requires the exact submitted candidate');
            const candidate = await this.metadata.get(input.release, client);
            if (candidate.digest !== new Ontology(row.body).digest)
                throw new Conflict('Candidate definition differs');
            await access.refresh(client);
            const reviewed = await this.reviewDigest(row, client);
            await this.db.query(`UPDATE ${this.db.schema}.ontology_branches SET state='approved',reviewer=$2,reviewed_digest=$3,revision=revision+1,updated_at=now() WHERE id=$1`, [row.id, access.principal.owner, reviewed], client);
            return { id: row.id, revision: row.revision + 1, state: 'approved', release: row.candidate };
        });
    }
    async merge(access, raw) {
        const input = branchReviewSchema.parse(raw);
        return this.db.transaction(async (client) => {
            const row = await this.row(input.id, client, true);
            this.authorize(access, row, 'manage_definition');
            await this.db.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))', [this.db.lockKey('publication', row.ontology)], client);
            await this.validateChanges(access, row, (await this.metadata.get(row.base_release, client)).document, row.body, client);
            if (row.state !== 'approved' || row.revision !== input.revision || row.candidate !== input.release || row.reviewed_digest !== await this.reviewDigest(row, client))
                throw new Conflict('Merge requires the exact approved candidate');
            await this.metadata.activate(input.release, this.bindings, access, client);
            if (row.project) {
                const base = resources((await this.metadata.get(row.base_release, client)).document);
                let assigned = false;
                for (const name of resources(row.body).keys())
                    if (!base.has(name)) {
                        await this.db.query(`INSERT INTO ${this.db.schema}.ontology_resource_projects(ontology,resource,project) VALUES($1,$2,$3)`, [row.ontology, name, row.project], client);
                        assigned = true;
                    }
                if (assigned)
                    notifySecurityCacheInvalidated(this.db);
            }
            await access.refresh(client);
            await this.db.query(`UPDATE ${this.db.schema}.ontology_branches SET state='merged',revision=revision+1,updated_at=now() WHERE id=$1`, [row.id], client);
            return { id: row.id, revision: row.revision + 1, state: 'merged', release: input.release };
        });
    }
}
