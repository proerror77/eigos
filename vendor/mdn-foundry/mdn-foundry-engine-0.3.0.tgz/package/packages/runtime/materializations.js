import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import { Conflict, NotFound, digest } from '../core/identity.js';
import { Objects } from './objects.js';
import { viewTables } from './scenario-store.js';
export const materializationInputSchema = z.strictObject({ requestId: z.string().min(1).max(128), name: z.string().min(1).max(200), types: z.array(z.string().min(1)).min(1).max(100) });
export async function initializeMaterializations(db) {
    await db.query(`CREATE TABLE IF NOT EXISTS ${db.schema}.materializations (
    id uuid PRIMARY KEY, owner text NOT NULL, request_id text NOT NULL, digest text NOT NULL,
    release text NOT NULL REFERENCES ${db.schema}.releases(digest), name text NOT NULL,
    types jsonb NOT NULL, captured_at timestamptz NOT NULL DEFAULT now(), UNIQUE(owner,request_id));
    CREATE TABLE IF NOT EXISTS ${db.schema}.materialized_objects (
      materialization_id uuid NOT NULL REFERENCES ${db.schema}.materializations(id),
      type text NOT NULL,id text NOT NULL,revision bigint NOT NULL,properties jsonb NOT NULL,
      PRIMARY KEY(materialization_id,type,id));
    ALTER TABLE ${db.schema}.materialized_objects ADD COLUMN IF NOT EXISTS provenance jsonb;
    CREATE TABLE IF NOT EXISTS ${db.schema}.materialized_links (
      materialization_id uuid NOT NULL REFERENCES ${db.schema}.materializations(id),
      type text NOT NULL,from_type text NOT NULL,from_id text NOT NULL,to_type text NOT NULL,to_id text NOT NULL,
      PRIMARY KEY(materialization_id,type,from_type,from_id,to_type,to_id));`);
}
const referenceKey = (ref) => JSON.stringify([ref.type, ref.id]);
export class Materializations {
    db;
    constructor(db) {
        this.db = db;
    }
    async header(access, model, id) {
        z.uuid().parse(id);
        await access.refresh(undefined, [model.document.id]);
        const header = (await this.db.query(`SELECT id,release,name,types,captured_at FROM ${this.db.schema}.materializations WHERE id=$1 AND owner=$2`, [id, access.principal.owner])).rows[0];
        if (!header)
            throw new NotFound('Materialization is unavailable');
        if (header.release !== model.release)
            throw new Conflict('Materialization belongs to another publication');
        return header;
    }
    async capture(access, model, raw) {
        const input = materializationInputSchema.parse(raw);
        if (model.scenario)
            throw new Conflict('Materialization requires live resolved objects');
        const types = [...new Set(input.types)].sort(), fingerprint = digest({ name: input.name, types, release: model.release });
        types.forEach(type => { model.object(type); access.read(model, type); });
        return this.db.transaction(async (client) => {
            await this.db.query('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ', [], client);
            await access.refresh(client, [model.document.id]);
            const graph = new Objects(this.db, model, access, client), id = randomUUID();
            const inserted = await this.db.query(`INSERT INTO ${this.db.schema}.materializations(id,owner,request_id,digest,release,name,types)
        VALUES($1,$2,$3,$4,$5,$6,$7) ON CONFLICT(owner,request_id) DO NOTHING RETURNING id`, [id, access.principal.owner, input.requestId, fingerprint, model.release, input.name, JSON.stringify(types)], client);
            if (!inserted.rowCount) {
                const previous = (await this.db.query(`SELECT id,digest FROM ${this.db.schema}.materializations WHERE owner=$1 AND request_id=$2`, [access.principal.owner, input.requestId], client)).rows[0];
                if (previous.digest !== fingerprint)
                    throw new Conflict('Materialization request ID has different input');
                return { id: String(previous.id) };
            }
            const included = new Set();
            for (const type of types) {
                let cursor;
                do {
                    const page = await graph.query({ type, limit: 100, cursor });
                    for (const object of page.items) {
                        if (included.size >= 10000)
                            throw new Conflict('Materialization exceeds 10000 objects; narrow the selected types');
                        included.add(referenceKey(object.ref));
                    }
                    // Retain original policy fields even when hidden. Exports evaluate the complete historical row.
                    const args = [id, model.projection, access.principal.owner, JSON.stringify(page.items.map(item => item.ref)), model.document.id];
                    const tables = viewTables(this.db, model, access.principal.owner, args, [type]);
                    await this.db.query(`${tables.prefix}INSERT INTO ${this.db.schema}.materialized_objects(materialization_id,type,id,revision,properties,provenance)
            SELECT $1,o.type,o.id,o.revision,o.properties,
              COALESCE(prov.provenance, jsonb_build_object('revision', o.revision))
            FROM ${tables.objects} o
            JOIN jsonb_to_recordset($4::jsonb) AS selected(type text,id text) ON selected.type=o.type AND selected.id=o.id
            LEFT JOIN LATERAL (
              SELECT jsonb_strip_nulls(jsonb_build_object(
                'revision', o.revision,
                'historySequence', h.sequence::text,
                'operation', h.operation,
                'source', h.source,
                'requestId', h.request_id,
                'taskId', h.task_id,
                'indexTx', COALESCE(h.index_tx, CASE WHEN h.executor_kind = 'indexer' THEN h.request_id ELSE NULL END),
                'observedAt', h.observed_at,
                'release', h.release
              )) AS provenance
              FROM ${this.db.schema}.edit_history h
              JOIN ${this.db.schema}.releases r ON r.digest=h.release
              WHERE r.body->>'id'=$5 AND h.owner=o.owner AND h.type=o.type AND h.id=o.id
              ORDER BY h.sequence DESC LIMIT 1
            ) prov ON true
            WHERE o.projection=$2 AND o.owner=$3`, args, client);
                    cursor = page.cursor;
                } while (cursor);
            }
            // Filter candidate links by included endpoints directly in SQL.
            const args = [model.projection, access.principal.owner, types, id], tables = viewTables(this.db, model, access.principal.owner, args, types);
            const links = (await this.db.query(`${tables.prefix}SELECT l.type,l.from_type,l.from_id,l.to_type,l.to_id
        FROM ${tables.links} l
        JOIN ${this.db.schema}.materialized_objects mf ON mf.materialization_id=$4 AND mf.type=l.from_type AND mf.id=l.from_id
        JOIN ${this.db.schema}.materialized_objects mt ON mt.materialization_id=$4 AND mt.type=l.to_type AND mt.id=l.to_id
        WHERE l.projection=$1 AND l.owner=$2 AND l.from_type=ANY($3::text[]) AND l.to_type=ANY($3::text[])
        LIMIT 100001`, args, client)).rows;
            if (links.length > 100000)
                throw new Conflict('Materialization exceeds 100000 relationships; narrow the selected types');
            const checkedLinkTypes = new Set();
            for (const link of links) {
                if (!checkedLinkTypes.has(link.type)) {
                    access.definition(model, 'link', link.type);
                    checkedLinkTypes.add(link.type);
                }
            }
            for (let start = 0; start < links.length; start += 1000) {
                await this.db.query(`INSERT INTO ${this.db.schema}.materialized_links(materialization_id,type,from_type,from_id,to_type,to_id)
          SELECT $1,type,from_type,from_id,to_type,to_id FROM jsonb_to_recordset($2::jsonb) AS input(type text,from_type text,from_id text,to_type text,to_id text)`, [id, JSON.stringify(links.slice(start, start + 1000))], client);
            }
            await access.refresh(client, [model.document.id]);
            return { id };
        });
    }
    async read(access, model, id, cursor) {
        const header = await this.header(access, model, id);
        const token = cursor ? z.strictObject({ id: z.literal(id), type: z.string(), key: z.string() }).parse(JSON.parse(Buffer.from(cursor, 'base64url').toString())) : undefined;
        const args = [id];
        let clause = '';
        if (token) {
            args.push(token.type, token.key);
            clause = ' AND (type COLLATE "C",id COLLATE "C")>($2,$3)';
        }
        const rows = (await this.db.query(`SELECT type,id,revision,properties,provenance FROM ${this.db.schema}.materialized_objects WHERE materialization_id=$1${clause} ORDER BY type COLLATE "C",id COLLATE "C" LIMIT 101`, args)).rows;
        const pageRows = rows.slice(0, 100);
        const graph = new Objects(this.db, model, access), items = [];
        const refs = pageRows.map(row => ({ type: String(row.type), id: String(row.id) }));
        const accessible = await graph.batchCheckLiveReadable(refs);
        for (const row of pageRows) {
            const ref = { type: String(row.type), id: String(row.id) };
            if (!accessible.has(referenceKey(ref)))
                continue;
            const properties = graph.maskSnapshot(ref, row.properties);
            if (!properties)
                continue;
            const provenance = row.provenance;
            items.push({ ref, revision: Number(row.revision), properties, ...(provenance ? { provenance } : {}) });
        }
        await access.refresh(undefined, [model.document.id]);
        const last = rows[Math.min(rows.length, 100) - 1];
        return { id, name: header.name, release: header.release, capturedAt: header.captured_at, items, cursor: rows.length > 100 ? Buffer.from(JSON.stringify({ id, type: last.type, key: last.id })).toString('base64url') : undefined };
    }
    async links(access, model, id, after = 0) {
        z.number().int().min(0).parse(after);
        await this.header(access, model, id);
        const rows = (await this.db.query(`SELECT l.type,l.from_type,l.from_id,l.to_type,l.to_id,f.properties AS from_properties,t.properties AS to_properties
      FROM ${this.db.schema}.materialized_links l
      JOIN ${this.db.schema}.materialized_objects f ON f.materialization_id=l.materialization_id AND f.type=l.from_type AND f.id=l.from_id
      JOIN ${this.db.schema}.materialized_objects t ON t.materialization_id=l.materialization_id AND t.type=l.to_type AND t.id=l.to_id
      WHERE l.materialization_id=$1 ORDER BY l.type,l.from_type,l.from_id,l.to_type,l.to_id OFFSET $2 LIMIT 101`, [id, after])).rows;
        const pageRows = rows.slice(0, 100);
        const graph = new Objects(this.db, model, access), items = [];
        const checkedLinkTypes = new Set();
        const endpoints = [];
        for (const row of pageRows) {
            if (!checkedLinkTypes.has(row.type)) {
                access.definition(model, 'link', row.type);
                checkedLinkTypes.add(row.type);
            }
            endpoints.push({ type: String(row.from_type), id: String(row.from_id) }, { type: String(row.to_type), id: String(row.to_id) });
        }
        const accessible = await graph.batchCheckLiveReadable(endpoints);
        for (const row of pageRows) {
            const from = { type: row.from_type, id: row.from_id }, to = { type: row.to_type, id: row.to_id };
            if (!accessible.has(referenceKey(from)) || !accessible.has(referenceKey(to)))
                continue;
            if (!graph.maskSnapshot(from, row.from_properties) || !graph.maskSnapshot(to, row.to_properties))
                continue;
            items.push({ type: String(row.type), from, to });
        }
        await access.refresh(undefined, [model.document.id]);
        return { items, cursor: rows.length > 100 ? after + 100 : undefined };
    }
}
