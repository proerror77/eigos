import { checkPendingReservationContracts } from './resource-reservations.js';
import { requireReleaseEvaluation } from './release-evaluation.js';
import { versionProblem } from '../ontology/function-versions.js';
import { copyEditState } from './edit-history.js';
import { copySemanticIndexes, semanticFingerprint } from './semantic-publication.js';
import { migrateProjectionState } from './projection-migration.js';
import { checkSavedObjectSets } from './object-set-compatibility.js';
import { createHash, randomUUID } from 'node:crypto';
import { digest, Conflict, NotFound } from '../core/identity.js';
import { Ontology, validator } from '../ontology/model.js';
import { machineryStateContract } from './machinery-state.js';
const compiledReleases = new WeakMap();
export class PublishedOntology extends Ontology {
    release;
    projection;
    runtimeId;
    bindings;
    scenario;
    evaluation;
    constructor(body, release, projection, runtimeId, bindings, scenario, evaluation) {
        super(body, { published: true });
        this.release = release;
        this.projection = projection;
        this.runtimeId = runtimeId;
        this.bindings = bindings;
        this.scenario = scenario;
        this.evaluation = evaluation;
    }
    /** The same compiled release seen through a Scenario or a candidate evaluation, without compiling it again. */
    scoped(scenario, evaluation) {
        const compiled = compiledReleases.get(this) ?? this;
        const view = Object.create(compiled, {
            scenario: { value: scenario, enumerable: true }, evaluation: { value: evaluation, enumerable: true },
        });
        compiledReleases.set(view, compiled);
        return view;
    }
}
const DEFAULT_FINGERPRINT_PAGE_SIZE = 1000;
const DEFAULT_PROJECTION_COPY_PAGE_SIZE = 500;
async function hashOrderedTable(db, client, table, filterColumn, filterValue, keyColumns, rowExpression, pageSize = DEFAULT_FINGERPRINT_PAGE_SIZE) {
    const hash = createHash('sha256');
    if (filterValue === null)
        return hash.digest('hex');
    const limit = Math.max(1, Math.trunc(pageSize));
    const keyList = keyColumns.join(',');
    const cursorParams = keyColumns.map((_, i) => `$${i + 3}`).join(',');
    let cursor = null;
    for (;;) {
        const query = cursor
            ? `SELECT ${keyList}, encode(sha256(convert_to(${rowExpression}, 'UTF8')), 'hex') AS row_hash
         FROM ${db.schema}.${table}
         WHERE ${filterColumn}=$1 AND (${keyList}) > (${cursorParams})
         ORDER BY ${keyList} LIMIT $2`
            : `SELECT ${keyList}, encode(sha256(convert_to(${rowExpression}, 'UTF8')), 'hex') AS row_hash
         FROM ${db.schema}.${table}
         WHERE ${filterColumn}=$1
         ORDER BY ${keyList} LIMIT $2`;
        const params = cursor ? [filterValue, limit, ...cursor] : [filterValue, limit];
        const rows = (await db.query(query, params, client)).rows;
        if (!rows.length)
            break;
        for (const row of rows) {
            hash.update(row.row_hash);
            hash.update('\n');
        }
        if (rows.length < limit)
            break;
        const last = rows.at(-1);
        cursor = keyColumns.map((col) => String(last[col]));
    }
    return hash.digest('hex');
}
export class Metadata {
    db;
    ontologyId;
    models = new Map();
    transforms = new Map();
    constructor(db, ontologyId = 'Eigos') {
        this.db = db;
        this.ontologyId = ontologyId;
    }
    async fingerprint(projection, client = this.db.pool, ontology, pageSize = DEFAULT_FINGERPRINT_PAGE_SIZE) {
        const objects = await hashOrderedTable(this.db, client, 'objects', 'projection', projection, ['owner', 'type', 'id'], 'row(owner,type,id,revision,properties)::text', pageSize);
        const links = await hashOrderedTable(this.db, client, 'links', 'projection', projection, ['owner', 'type', 'from_type', 'from_id', 'to_type', 'to_id'], 'row(owner,type,from_type,from_id,to_type,to_id,single_from,single_to)::text', pageSize);
        const sources = await hashOrderedTable(this.db, client, 'source_values', 'projection', projection, ['owner', 'type', 'id', 'source'], 'row(owner,type,id,source,properties,observed_at)::text', pageSize);
        const edits = await hashOrderedTable(this.db, client, 'object_edits', 'projection', projection, ['owner', 'type', 'id'], 'row(owner,type,id,overrides,deleted,created)::text', pageSize);
        const policies = await hashOrderedTable(this.db, client, 'edit_policies', 'ontology', ontology ?? null, ['ontology', 'type'], 'row(ontology,type,policy,property_policies,source_priorities)::text', pageSize);
        return digest({
            row: { objects, links },
            edits: { sources, edits, policies },
            semantic: await semanticFingerprint(this.db, projection, client),
        });
    }
    async validateEditState(model, projection, client, pageSize = DEFAULT_PROJECTION_COPY_PAGE_SIZE) {
        const limit = Math.max(1, Math.trunc(pageSize));
        const propertyValidators = new Map();
        const validate = (type, values) => {
            const definition = model.object(type);
            for (const [name, value] of Object.entries(values)) {
                const property = definition.properties[name];
                if (!property)
                    continue;
                const key = `${type}\0${name}`;
                let check = propertyValidators.get(key);
                if (!check) {
                    check = validator(property.schema);
                    propertyValidators.set(key, check);
                }
                try {
                    check.parse(value);
                }
                catch {
                    throw new Conflict('Candidate edit or source state needs migration for ' + type + '.' + name);
                }
            }
        };
        let sourceCursor = null;
        for (;;) {
            const rows = (await this.db.query(sourceCursor
                ? `SELECT owner,type,id,source,properties FROM ${this.db.schema}.source_values
             WHERE projection=$1 AND properties IS NOT NULL AND (owner,type,id,source)>($3,$4,$5,$6)
             ORDER BY owner,type,id,source LIMIT $2`
                : `SELECT owner,type,id,source,properties FROM ${this.db.schema}.source_values
             WHERE projection=$1 AND properties IS NOT NULL
             ORDER BY owner,type,id,source LIMIT $2`, sourceCursor ? [projection, limit, ...sourceCursor] : [projection, limit], client)).rows;
            if (!rows.length)
                break;
            for (const row of rows)
                validate(row.type, row.properties);
            if (rows.length < limit)
                break;
            const last = rows.at(-1);
            sourceCursor = [last.owner, last.type, last.id, last.source];
        }
        let editCursor = null;
        for (;;) {
            const rows = (await this.db.query(editCursor
                ? `SELECT owner,type,id,overrides FROM ${this.db.schema}.object_edits
             WHERE projection=$1 AND (owner,type,id)>($3,$4,$5)
             ORDER BY owner,type,id LIMIT $2`
                : `SELECT owner,type,id,overrides FROM ${this.db.schema}.object_edits
             WHERE projection=$1
             ORDER BY owner,type,id LIMIT $2`, editCursor ? [projection, limit, ...editCursor] : [projection, limit], client)).rows;
            if (!rows.length)
                break;
            for (const row of rows) {
                const values = {};
                for (const [name, edit] of Object.entries(row.overrides))
                    values[name] = edit.value;
                validate(row.type, values);
            }
            if (rows.length < limit)
                break;
            const last = rows.at(-1);
            editCursor = [last.owner, last.type, last.id];
        }
    }
    async prepare(input, bindings, access, transform, permissionTarget) {
        const model = new Ontology(input);
        await access.refresh();
        access.require(model.document.id, 'edit_definition', permissionTarget ?? model.document.id);
        const manifest = bindings.describe(model), projection = randomUUID();
        await bindings.checkRelease?.(model);
        const transformId = transform ? randomUUID() : null;
        const release = digest({ definition: model.digest, runtime: this.db.runtimeId, manifest, projection });
        await this.db.transaction(async (client) => {
            await this.db.query('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ', [], client);
            const current = (await this.db.query(`SELECT r.digest,r.projection FROM ${this.db.schema}.ontology o JOIN ${this.db.schema}.releases r ON r.digest=o.release WHERE o.id=$1`, [model.document.id], client)).rows[0];
            if (current) {
                const history = (await this.db.query(`SELECT body FROM ${this.db.schema}.releases WHERE body->>'id'=$1 AND state IN ('active','retired')`, [model.document.id], client)).rows;
                const released = new Set();
                for (const record of history) {
                    const previous = new Ontology(record.body, { published: true });
                    for (const fn of previous.resolvedDocument.functionTypes)
                        released.add(JSON.stringify([fn.apiName, fn.version ?? null]));
                    for (const value of model.resourceDocument.valueTypes ?? []) {
                        const old = previous.resourceDocument.valueTypes?.find(item => item.apiName === value.apiName && item.version === value.version);
                        if (old && digest(old.schema) !== digest(value.schema))
                            throw new Conflict('Value Type constraints require a new version');
                    }
                    // Palantir: versions of a Function are immutable once released, so a changed component Function needs a new version.
                    for (const fn of model.resolvedDocument.functionTypes) {
                        const old = previous.resolvedDocument.functionTypes.find(item => item.apiName === fn.apiName && item.version === fn.version);
                        if (old && (old.implementation || fn.implementation) && digest(old) !== digest(fn))
                            throw new Conflict(`Function versions are immutable: release ${fn.apiName} as a new version`);
                    }
                }
                // A version released before may come back unchanged. A new one follows the active release's: above it, and a new
                // major version for a breaking change, as Palantir's function versioning asks.
                const baseline = await this.get(current.digest, client);
                for (const fn of model.resolvedDocument.functionTypes) {
                    const old = baseline.resolvedDocument.functionTypes.find(item => item.apiName === fn.apiName);
                    if (!old || !old.implementation && !fn.implementation || released.has(JSON.stringify([fn.apiName, fn.version ?? null])))
                        continue;
                    const problem = versionProblem(old, fn);
                    if (problem)
                        throw new Conflict(problem);
                }
            }
            if (current?.projection)
                await checkSavedObjectSets(this.db, client, await this.get(current.digest, client), model);
            if (current && !current.projection)
                throw new Conflict('Upgrade the existing data before preparing a release');
            const fingerprint = current ? await this.fingerprint(current.projection, client, model.document.id) : null;
            // Bind the candidate contract before copying rows. Readers see the complete release only at commit.
            await this.db.query(`INSERT INTO ${this.db.schema}.releases(digest,body,definition_digest,projection,runtime_id,bindings,state,prepared_from,source_fingerprint,transform_id,machinery_states)
        VALUES($1,$2,$3,$4,$5,$6,'prepared',$7,$8,$9,$10)`, [release, model.document, model.digest, projection, this.db.runtimeId, manifest,
                current?.digest ?? null, fingerprint, transformId, machineryStateContract(model)], client);
            if (current) {
                const pageSize = DEFAULT_PROJECTION_COPY_PAGE_SIZE;
                const objectTypes = [...model.objects.keys()].filter(type => type !== 'OntologyScenario');
                if (objectTypes.length) {
                    let objectCursor = null;
                    for (;;) {
                        const batch = (await this.db.query(objectCursor
                            ? `SELECT owner,type,id,revision,properties FROM ${this.db.schema}.objects
                   WHERE projection=$1 AND type=ANY($2::text[]) AND (owner,type,id)>($4,$5,$6)
                   ORDER BY owner,type,id LIMIT $3`
                            : `SELECT owner,type,id,revision,properties FROM ${this.db.schema}.objects
                   WHERE projection=$1 AND type=ANY($2::text[])
                   ORDER BY owner,type,id LIMIT $3`, objectCursor ? [current.projection, objectTypes, pageSize, ...objectCursor] : [current.projection, objectTypes, pageSize], client)).rows;
                        if (!batch.length)
                            break;
                        const projected = batch.map(row => {
                            const allowed = model.object(row.type).properties;
                            const fields = Object.fromEntries(Object.entries(row.properties).filter(([name]) => allowed[name]));
                            return {
                                ...row,
                                properties: model.parseObject({ type: row.type, id: row.id }, transform ? transform({ type: row.type, id: row.id }, structuredClone(row.properties)) : fields),
                            };
                        });
                        await this.db.query(`INSERT INTO ${this.db.schema}.objects(projection,owner,type,id,revision,properties)
               SELECT $1,owner,type,id,revision,properties FROM jsonb_to_recordset($2::jsonb) AS r(owner text,type text,id text,revision bigint,properties jsonb)`, [projection, JSON.stringify(projected)], client);
                        if (batch.length < pageSize)
                            break;
                        const last = batch.at(-1);
                        objectCursor = [last.owner, last.type, last.id];
                    }
                }
                const linkTypes = [...model.links.keys()];
                if (linkTypes.length) {
                    let linkCursor = null;
                    for (;;) {
                        const batch = (await this.db.query(linkCursor
                            ? `SELECT owner,type,from_type,from_id,to_type,to_id FROM ${this.db.schema}.links
                   WHERE projection=$1 AND type=ANY($2::text[]) AND from_type<>'OntologyScenario' AND to_type<>'OntologyScenario'
                     AND (owner,type,from_type,from_id,to_type,to_id)>($4,$5,$6,$7,$8,$9)
                   ORDER BY owner,type,from_type,from_id,to_type,to_id LIMIT $3`
                            : `SELECT owner,type,from_type,from_id,to_type,to_id FROM ${this.db.schema}.links
                   WHERE projection=$1 AND type=ANY($2::text[]) AND from_type<>'OntologyScenario' AND to_type<>'OntologyScenario'
                   ORDER BY owner,type,from_type,from_id,to_type,to_id LIMIT $3`, linkCursor ? [current.projection, linkTypes, pageSize, ...linkCursor] : [current.projection, linkTypes, pageSize], client)).rows;
                        if (!batch.length)
                            break;
                        const mapped = batch.map(row => {
                            const link = model.links.get(row.type);
                            if (link.from.type !== row.from_type || link.to.type !== row.to_type)
                                throw new Conflict('Link endpoints need a compatible source projection');
                            return { ...row, single_from: link.from.cardinality === 'one', single_to: link.to.cardinality === 'one' };
                        });
                        await this.db.query(`INSERT INTO ${this.db.schema}.links(projection,owner,type,from_type,from_id,to_type,to_id,single_from,single_to)
               SELECT $1,owner,type,from_type,from_id,to_type,to_id,single_from,single_to FROM jsonb_to_recordset($2::jsonb) AS r(owner text,type text,from_type text,from_id text,to_type text,to_id text,single_from boolean,single_to boolean)`, [projection, JSON.stringify(mapped)], client);
                        if (batch.length < pageSize)
                            break;
                        const last = batch.at(-1);
                        linkCursor = [last.owner, last.type, last.from_type, last.from_id, last.to_type, last.to_id];
                    }
                }
            }
            if (current) {
                await copyEditState(this.db, current.projection, projection, client, [...model.objects.keys()]);
                if (transform)
                    await migrateProjectionState(this.db, current.projection, projection, model, transform, client);
                await this.validateEditState(model, projection, client);
                await copySemanticIndexes(this.db, current.digest, model, { release, bindings: manifest }, client);
            }
            await access.refresh(client);
            await this.db.query(`UPDATE ${this.db.schema}.releases SET projection_fingerprint=$2 WHERE digest=$1`, [release, await this.fingerprint(projection, client)], client);
        });
        if (transformId && transform)
            this.transforms.set(transformId, transform);
        return this.get(release);
    }
    async activate(release, bindings, access, transaction) {
        const model = await this.get(release);
        await access.refresh();
        access.require(model.document.id, 'manage_definition', model.document.id);
        this.checkBindings(model, bindings);
        const activate = async (client) => {
            await this.db.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))', [this.db.lockKey('publication', model.document.id)], client);
            const current = (await this.db.query(`SELECT release FROM ${this.db.schema}.ontology WHERE id=$1 FOR UPDATE`, [model.document.id], client)).rows[0]?.release;
            const prepared = (await this.db.query(`SELECT * FROM ${this.db.schema}.releases WHERE digest=$1`, [release], client)).rows[0];
            if (current === release)
                return;
            await checkPendingReservationContracts(this.db, model, client);
            if (prepared.state !== 'prepared' || (prepared.prepared_from ?? null) !== (current ?? null))
                throw new Conflict('Prepare against the current live release before activation');
            const candidate = new Ontology(model.document);
            const running = await this.db.query(`SELECT 1 FROM ${this.db.schema}.tasks t JOIN ${this.db.schema}.releases r ON r.digest=t.release WHERE r.body->>'id'=$1 AND t.state IN('submitted','working','input-required') LIMIT 1`, [model.document.id], client);
            if (running.rowCount)
                throw new Conflict('Complete or cancel unfinished tasks before changing their publication');
            const indexing = await this.db.query(`SELECT 1 FROM ${this.db.schema}.index_transactions WHERE ontology=$1 AND state IN ('pending','failed') LIMIT 1`, [model.document.id], client);
            if (indexing.rowCount)
                throw new Conflict('Resolve pending or failed source transactions before activation');
            const workflows = await this.db.query(`SELECT 1 FROM ${this.db.schema}.workflow_runs WHERE ontology=$1 AND state IN ('pending','working','failed','waiting-proposal','waiting-approval') LIMIT 1`, [model.document.id], client);
            if (workflows.rowCount)
                throw new Conflict('Complete or cancel unfinished workflows before changing their publication');
            if (current) {
                const live = await this.get(current, client);
                if (await this.fingerprint(live.projection, client, model.document.id) !== prepared.source_fingerprint)
                    throw new Conflict('Source data changed; rebuild the candidate projection');
                if (live.digest !== model.digest) {
                    await this.db.query(`LOCK TABLE ${this.db.schema}.object_sets IN SHARE MODE`, [], client);
                    await checkSavedObjectSets(this.db, client, live, candidate);
                }
            }
            if (await this.fingerprint(model.projection, client) !== prepared.projection_fingerprint)
                throw new Conflict('Prepared projection changed');
            await requireReleaseEvaluation(this.db, client, model, bindings, current ?? null, prepared.projection_fingerprint);
            await access.refresh(client);
            if (current)
                await this.db.query(`UPDATE ${this.db.schema}.releases SET state='retired' WHERE digest=$1`, [current], client);
            await this.db.query(`INSERT INTO ${this.db.schema}.ontology(id,release) VALUES($1,$2) ON CONFLICT(id) DO UPDATE SET release=excluded.release`, [model.document.id, release], client);
            await this.db.query(`UPDATE ${this.db.schema}.releases SET state='active' WHERE digest=$1`, [release], client);
        };
        if (transaction)
            await activate(transaction);
        else
            await this.db.transaction(activate);
        return model;
    }
    async catchUp(release, bindings, access, permissionTarget, transaction) {
        const candidate = await this.get(release);
        this.checkBindings(candidate, bindings);
        await access.refresh();
        access.require(candidate.document.id, 'edit_definition', permissionTarget ?? candidate.document.id);
        const synchronize = async (client) => {
            await this.db.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))', [this.db.lockKey('publication', candidate.document.id)], client);
            const stored = (await this.db.query(`SELECT * FROM ${this.db.schema}.releases WHERE digest=$1 FOR UPDATE`, [release], client)).rows[0];
            const transform = stored.transform_id ? this.transforms.get(stored.transform_id) : undefined;
            if (stored.transform_id && !transform)
                throw new Conflict('Candidate transformation is unavailable; prepare it again with the original migration implementation');
            const live = await this.active(candidate.document.id, client);
            if (stored.state !== 'prepared' || stored.prepared_from !== live.release)
                throw new Conflict('Candidate base changed; rebase before catching up');
            if (await this.fingerprint(candidate.projection, client) !== stored.projection_fingerprint)
                throw new Conflict('Prepared projection changed');
            const types = [...candidate.objects.keys()].filter(type => type !== 'OntologyScenario'), links = [...candidate.links.keys()];
            // Remove outdated edges before objects, preserving foreign-key validity throughout catch-up.
            await this.db.query(`DELETE FROM ${this.db.schema}.links target WHERE target.projection=$1 AND NOT EXISTS(
        SELECT 1 FROM ${this.db.schema}.links source WHERE source.projection=$2 AND source.owner=target.owner AND source.type=target.type
        AND source.from_type=target.from_type AND source.from_id=target.from_id AND source.to_type=target.to_type AND source.to_id=target.to_id)`, [candidate.projection, live.projection], client);
            await this.db.query(`DELETE FROM ${this.db.schema}.objects target WHERE target.projection=$1 AND NOT EXISTS(
        SELECT 1 FROM ${this.db.schema}.objects source WHERE source.projection=$2 AND source.owner=target.owner AND source.type=target.type AND source.id=target.id)`, [candidate.projection, live.projection], client);
            let cursor = null;
            let updated = 0;
            for (;;) {
                const rows = (await this.db.query(`SELECT source.owner,source.type,source.id,source.revision,source.properties FROM ${this.db.schema}.objects source
          LEFT JOIN ${this.db.schema}.objects target ON target.projection=$1 AND target.owner=source.owner AND target.type=source.type AND target.id=source.id
          WHERE source.projection=$2 AND source.type=ANY($3::text[]) AND (target.id IS NULL OR source.revision IS DISTINCT FROM target.revision OR source.properties IS DISTINCT FROM target.properties)
          AND ($4::text[] IS NULL OR (source.owner,source.type,source.id)>($4[1],$4[2],$4[3])) ORDER BY source.owner,source.type,source.id LIMIT 500`, [candidate.projection, live.projection, types, cursor], client)).rows;
                if (!rows.length)
                    break;
                const projected = rows.map(row => ({ ...row, properties: candidate.parseObject({ type: row.type, id: row.id }, transform ? transform({ type: row.type, id: row.id }, structuredClone(row.properties)) : Object.fromEntries(Object.entries(row.properties).filter(([name]) => candidate.object(row.type).properties[name]))) }));
                await this.db.query(`INSERT INTO ${this.db.schema}.objects(projection,owner,type,id,revision,properties)
          SELECT $1,owner,type,id,revision,properties FROM jsonb_to_recordset($2::jsonb) AS r(owner text,type text,id text,revision bigint,properties jsonb)
          ON CONFLICT(projection,owner,type,id) DO UPDATE SET revision=excluded.revision,properties=excluded.properties`, [candidate.projection, JSON.stringify(projected)], client);
                updated += rows.length;
                const last = rows.at(-1);
                cursor = [last.owner, last.type, last.id];
            }
            let linksAdded = 0;
            if (links.length) {
                const pageSize = DEFAULT_PROJECTION_COPY_PAGE_SIZE;
                let edgeCursor = null;
                for (;;) {
                    const edges = (await this.db.query(edgeCursor
                        ? `SELECT source.owner,source.type,source.from_type,source.from_id,source.to_type,source.to_id
                 FROM ${this.db.schema}.links source
                 WHERE source.projection=$1 AND source.type=ANY($2::text[]) AND source.from_type<>'OntologyScenario' AND source.to_type<>'OntologyScenario'
                   AND (source.owner,source.type,source.from_type,source.from_id,source.to_type,source.to_id)>($5,$6,$7,$8,$9,$10)
                   AND NOT EXISTS(
                     SELECT 1 FROM ${this.db.schema}.links target WHERE target.projection=$3 AND target.owner=source.owner AND target.type=source.type
                     AND target.from_type=source.from_type AND target.from_id=source.from_id AND target.to_type=source.to_type AND target.to_id=source.to_id)
                 ORDER BY source.owner,source.type,source.from_type,source.from_id,source.to_type,source.to_id LIMIT $4`
                        : `SELECT source.owner,source.type,source.from_type,source.from_id,source.to_type,source.to_id
                 FROM ${this.db.schema}.links source
                 WHERE source.projection=$1 AND source.type=ANY($2::text[]) AND source.from_type<>'OntologyScenario' AND source.to_type<>'OntologyScenario'
                   AND NOT EXISTS(
                     SELECT 1 FROM ${this.db.schema}.links target WHERE target.projection=$3 AND target.owner=source.owner AND target.type=source.type
                     AND target.from_type=source.from_type AND target.from_id=source.from_id AND target.to_type=source.to_type AND target.to_id=source.to_id)
                 ORDER BY source.owner,source.type,source.from_type,source.from_id,source.to_type,source.to_id LIMIT $4`, edgeCursor ? [live.projection, links, candidate.projection, pageSize, ...edgeCursor] : [live.projection, links, candidate.projection, pageSize], client)).rows;
                    if (!edges.length)
                        break;
                    const mapped = edges.map(row => {
                        const link = candidate.links.get(row.type);
                        if (link.from.type !== row.from_type || link.to.type !== row.to_type)
                            throw new Conflict('Link endpoints need a compatible source projection');
                        return { ...row, single_from: link.from.cardinality === 'one', single_to: link.to.cardinality === 'one' };
                    });
                    await this.db.query(`INSERT INTO ${this.db.schema}.links(projection,owner,type,from_type,from_id,to_type,to_id,single_from,single_to)
             SELECT $1,owner,type,from_type,from_id,to_type,to_id,single_from,single_to FROM jsonb_to_recordset($2::jsonb)
             AS r(owner text,type text,from_type text,from_id text,to_type text,to_id text,single_from boolean,single_to boolean)`, [candidate.projection, JSON.stringify(mapped)], client);
                    linksAdded += edges.length;
                    if (edges.length < pageSize)
                        break;
                    const last = edges.at(-1);
                    edgeCursor = [last.owner, last.type, last.from_type, last.from_id, last.to_type, last.to_id];
                }
            }
            await copyEditState(this.db, live.projection, candidate.projection, client, types);
            if (transform)
                await migrateProjectionState(this.db, live.projection, candidate.projection, candidate, transform, client);
            await this.validateEditState(candidate, candidate.projection, client);
            await copySemanticIndexes(this.db, live.release, candidate, candidate, client);
            await access.refresh(client);
            await this.db.query(`UPDATE ${this.db.schema}.releases SET source_fingerprint=$2,projection_fingerprint=$3 WHERE digest=$1`, [release, await this.fingerprint(live.projection, client, candidate.document.id), await this.fingerprint(candidate.projection, client)], client);
            return { release, projection: candidate.projection, objectsUpdated: updated, linksAdded };
        };
        return transaction ? synchronize(transaction) : this.db.transaction(synchronize);
    }
    async publish(input, bindings, access, transform) { return this.activate((await this.prepare(input, bindings, access, transform)).release, bindings, access); }
    async prepareRollback(targetRelease, bindings, access, transform, permissionTarget) {
        const row = (await this.db.query(`SELECT digest,state FROM ${this.db.schema}.releases WHERE digest=$1`, [targetRelease])).rows[0];
        if (!row)
            throw new NotFound('Ontology release is unavailable');
        if (row.state === 'active')
            throw new Conflict('Target release is already active');
        if (row.state !== 'retired')
            throw new Conflict('Rollback requires a previously active retired release');
        const target = await this.get(targetRelease);
        const current = await this.active(target.document.id);
        if (current.release === targetRelease)
            throw new Conflict('Target release is already active');
        return this.prepare(target.document, bindings, access, transform, permissionTarget);
    }
    async rollback(targetRelease, bindings, access, options) {
        const prepared = await this.prepareRollback(targetRelease, bindings, access, options?.transform, options?.permissionTarget);
        return this.activate(prepared.release, bindings, access);
    }
    compatibilityDigest(model, bindings) {
        return digest({ definition: model.digest, bindings: bindings ? bindings.describe(model) : model.bindings });
    }
    isContractCompatible(model, bindings) {
        return this.compatibilityDigest(model) === this.compatibilityDigest(model, bindings);
    }
    checkBindings(model, bindings, options) {
        const runtimeMismatch = !options?.allowCompatibleRuntime && model.runtimeId !== this.db.runtimeId;
        if (runtimeMismatch || !this.isContractCompatible(model, bindings))
            throw new Conflict('The publication does not match this runtime implementation');
    }
    async active(id = this.ontologyId, client, lock = false) {
        if (lock)
            await this.db.query('SELECT pg_advisory_xact_lock_shared(hashtextextended($1,0))', [this.db.lockKey('publication', id)], client);
        const result = await this.db.query(`SELECT release FROM ${this.db.schema}.ontology WHERE id=$1`, [id], client);
        if (!result.rows[0])
            throw new NotFound('Published Ontology is unavailable');
        return this.get(String(result.rows[0].release), client);
    }
    /** Permit restart from the pinned definition only through independently reviewed branch activations. */
    async reviewedFrom(model, baseline) {
        const { rows } = await this.db.query(`WITH RECURSIVE lineage(digest) AS (
      SELECT $1::text
      UNION
      SELECT b.base_release FROM lineage l
      JOIN ${this.db.schema}.ontology_branches b ON b.candidate=l.digest
      JOIN ${this.db.schema}.releases r ON r.digest=b.candidate AND r.prepared_from=b.base_release
      WHERE b.ontology=$2 AND b.state='merged' AND b.reviewed_digest IS NOT NULL AND b.reviewer<>b.author
    ) SELECT 1 FROM lineage JOIN ${this.db.schema}.releases r USING(digest)
      WHERE r.definition_digest=$3 AND r.body->>'id'=$2 LIMIT 1`, [model.release, model.document.id, baseline]);
        return rows.length > 0;
    }
    async findAncestor(model, identity, client, match = 'definition') {
        const field = match === 'release' ? 'digest' : 'definition_digest';
        const { rows } = await this.db.query(`WITH RECURSIVE ancestors AS (
      SELECT digest,prepared_from,definition_digest FROM ${this.db.schema}.releases WHERE digest=$1
      UNION ALL
      SELECT r.digest,r.prepared_from,r.definition_digest FROM ${this.db.schema}.releases r
      JOIN ancestors a ON r.digest=a.prepared_from WHERE a.${field}<>$2
    ) SELECT digest FROM ancestors WHERE ${field}=$2`, [model.release, identity], client);
        if (rows[0])
            return this.get(rows[0].digest, client);
    }
    async get(release, client) {
        const cached = this.models.get(release);
        if (cached)
            return cached;
        const row = (await this.db.query(`SELECT * FROM ${this.db.schema}.releases WHERE digest=$1`, [release], client)).rows[0];
        if (!row)
            throw new NotFound('Ontology release is unavailable');
        if (!row.projection)
            throw new Error('Published projection is unavailable');
        const model = new PublishedOntology(row.body, release, row.projection, row.runtime_id, row.bindings);
        if (model.digest !== row.definition_digest)
            throw new Error('Ontology release content differs');
        if (this.models.size >= 16)
            this.models.delete(this.models.keys().next().value);
        this.models.set(release, model);
        return model;
    }
}
