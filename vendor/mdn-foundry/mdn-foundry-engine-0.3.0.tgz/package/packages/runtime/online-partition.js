import { createHash } from 'node:crypto';
import pg from 'pg';
const IDENT_RE = /^[a-z_][a-z0-9_]{0,62}$/;
function assertIdent(name, label) {
    if (!IDENT_RE.test(name))
        throw new Error(`Invalid PostgreSQL identifier for ${label}: ${name}`);
    return name;
}
function derivedIdent(prefix, suffix, maxLen = 63) {
    const raw = `${prefix}_${suffix}`;
    if (raw.length <= maxLen && IDENT_RE.test(raw))
        return raw;
    const hash = createHash('sha256').update(raw).digest('hex').slice(0, 8);
    const safeBase = raw.toLowerCase().replace(/[^a-z0-9_]/g, '_').replace(/^[^a-z_]+/, 'p_');
    const trimmed = safeBase.slice(0, maxLen - hash.length - 1);
    return `${trimmed}_${hash}`;
}
function q(ident) {
    return pg.escapeIdentifier(ident);
}
export function resolvePartitionPlan(db, options) {
    if (!Number.isInteger(options.partitions) || options.partitions < 1 || options.partitions > 1024) {
        throw new Error(`Invalid hash partition count: ${options.partitions} (expected integer 1..1024)`);
    }
    const schemaName = db.schema.slice(1, -1);
    const table = assertIdent(options.table ?? 'objects', 'table');
    const partitionKey = assertIdent(options.partitionKey ?? 'owner', 'partitionKey');
    const shadowTable = assertIdent(options.shadowTable ?? derivedIdent(table, 'shadow'), 'shadowTable');
    const changeLogTable = assertIdent(options.changeLogTable ?? derivedIdent(table, 'part_changes'), 'changeLogTable');
    const reverseChangeLogTable = assertIdent(options.reverseChangeLogTable ?? derivedIdent(table, 'rev_changes'), 'reverseChangeLogTable');
    const stateTable = assertIdent(options.stateTable ?? derivedIdent(table, 'part_state'), 'stateTable');
    const legacyTable = assertIdent(options.legacyTable ?? derivedIdent(table, 'legacy'), 'legacyTable');
    const distinctNames = new Set([table, shadowTable, changeLogTable, reverseChangeLogTable, stateTable, legacyTable]);
    if (distinctNames.size !== 6) {
        throw new Error('Partition plan table names must all be distinct');
    }
    return {
        schemaName,
        schemaSql: db.schema,
        table,
        partitionKey,
        partitions: options.partitions,
        shadowTable,
        changeLogTable,
        reverseChangeLogTable,
        stateTable,
        legacyTable,
        captureFunction: derivedIdent(table, 'part_capture_fn'),
        captureTrigger: derivedIdent(table, 'part_capture_trg'),
        reverseCaptureFunction: derivedIdent(table, 'rev_capture_fn'),
        reverseCaptureTrigger: derivedIdent(table, 'rev_capture_trg'),
    };
}
async function inspectTable(client, schemaName, tableName, excludedTriggers = new Set()) {
    const relRes = await client.query(`SELECT c.oid, c.relkind, c.relrowsecurity, c.relforcerowsecurity
     FROM pg_catalog.pg_class c
     JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
     WHERE n.nspname = $1 AND c.relname = $2`, [schemaName, tableName]);
    const rel = relRes.rows[0];
    if (!rel)
        throw new Error(`Table ${schemaName}.${tableName} does not exist`);
    const columnsRes = await client.query(`SELECT a.attnum, a.attname, pg_catalog.format_type(a.atttypid, a.atttypmod) AS data_type,
            a.attnotnull, a.attgenerated, a.attidentity,
            pg_catalog.pg_get_expr(d.adbin, d.adrelid) AS default_expr
     FROM pg_catalog.pg_attribute a
     LEFT JOIN pg_catalog.pg_attrdef d ON d.adrelid = a.attrelid AND d.adnum = a.attnum
     WHERE a.attrelid = $1 AND a.attnum > 0 AND NOT a.attisdropped
     ORDER BY a.attnum`, [rel.oid]);
    const constraintsRes = await client.query(`SELECT c.oid, c.conname, c.contype,
            pg_catalog.pg_get_constraintdef(c.oid, true) AS condef,
            ARRAY(
              SELECT a.attname::text
              FROM unnest(c.conkey) WITH ORDINALITY AS k(attnum, ord)
              JOIN pg_catalog.pg_attribute a ON a.attrelid = c.conrelid AND a.attnum = k.attnum
              ORDER BY k.ord
            ) AS columns
     FROM pg_catalog.pg_constraint c
     WHERE c.conrelid = $1 AND c.conparentid = 0
     ORDER BY c.contype, c.conname`, [rel.oid]);
    const indexesRes = await client.query(`SELECT ci.oid, ci.relname AS index_name, i.indisprimary, i.indisunique,
            pg_catalog.pg_get_indexdef(ci.oid) AS indexdef,
            ARRAY(
              SELECT a.attname::text
              FROM unnest(i.indkey::smallint[]) WITH ORDINALITY AS k(attnum, ord)
              LEFT JOIN pg_catalog.pg_attribute a ON a.attrelid = i.indrelid AND a.attnum = k.attnum
              WHERE k.ord <= i.indnkeyatts
              ORDER BY k.ord
            ) AS key_columns,
            EXISTS (SELECT 1 FROM pg_catalog.pg_constraint con WHERE con.conindid = ci.oid) AS backs_constraint
     FROM pg_catalog.pg_index i
     JOIN pg_catalog.pg_class ci ON ci.oid = i.indexrelid
     WHERE i.indrelid = $1
     ORDER BY ci.relname`, [rel.oid]);
    const incomingRes = await client.query(`SELECT c.conname, n.nspname AS ref_schema, r.relname AS ref_table,
            pg_catalog.pg_get_constraintdef(c.oid, true) AS condef
     FROM pg_catalog.pg_constraint c
     JOIN pg_catalog.pg_class r ON r.oid = c.conrelid
     JOIN pg_catalog.pg_namespace n ON n.oid = r.relnamespace
     WHERE c.confrelid = $1 AND c.contype = 'f' AND c.conparentid = 0
     ORDER BY n.nspname, r.relname, c.conname`, [rel.oid]);
    const policiesRes = await client.query(`SELECT p.polname, p.polcmd, p.polpermissive,
            ARRAY(SELECT r.rolname::text FROM pg_catalog.pg_roles r WHERE r.oid = ANY(p.polroles)) AS roles,
            pg_catalog.pg_get_expr(p.polqual, p.polrelid) AS using_expr,
            pg_catalog.pg_get_expr(p.polwithcheck, p.polrelid) AS check_expr
     FROM pg_catalog.pg_policy p
     WHERE p.polrelid = $1
     ORDER BY p.polname`, [rel.oid]);
    const grantsRes = await client.query(`SELECT grantee, privilege_type, is_grantable
     FROM information_schema.role_table_grants
     WHERE table_schema = $1 AND table_name = $2
     ORDER BY grantee, privilege_type`, [schemaName, tableName]);
    const triggersRes = await client.query(`SELECT t.tgname, pg_catalog.pg_get_triggerdef(t.oid) AS tgdef, t.tgfoid, pn.nspname AS fn_schema
     FROM pg_catalog.pg_trigger t
     JOIN pg_catalog.pg_proc p ON p.oid = t.tgfoid
     JOIN pg_catalog.pg_namespace pn ON pn.oid = p.pronamespace
     WHERE t.tgrelid = $1 AND NOT t.tgisinternal AND t.tgparentid = 0
     ORDER BY t.tgname`, [rel.oid]);
    const pkConstraint = constraintsRes.rows.find(c => c.contype === 'p');
    if (!pkConstraint || !pkConstraint.columns.length) {
        throw new Error(`Table ${schemaName}.${tableName} requires a PRIMARY KEY for online partitioning`);
    }
    const colByName = new Map(columnsRes.rows.map(col => [col.attname, col]));
    const primaryKeyColumns = pkConstraint.columns.map(name => {
        const col = colByName.get(name);
        if (!col)
            throw new Error(`Primary key column ${name} missing on ${schemaName}.${tableName}`);
        return col;
    });
    return {
        oid: rel.oid,
        relkind: rel.relkind,
        relrowsecurity: rel.relrowsecurity,
        relforcerowsecurity: rel.relforcerowsecurity,
        columns: columnsRes.rows,
        writableColumns: columnsRes.rows.filter(c => c.attgenerated === ''),
        primaryKeyColumns,
        constraints: constraintsRes.rows,
        indexes: indexesRes.rows,
        incomingForeignKeys: incomingRes.rows.map(row => ({
            constraintName: row.conname,
            referencingSchema: row.ref_schema,
            referencingTable: row.ref_table,
            definition: row.condef,
        })),
        policies: policiesRes.rows,
        grants: grantsRes.rows,
        userTriggers: triggersRes.rows
            .filter(t => !excludedTriggers.has(t.tgname))
            .map(t => ({ name: t.tgname, definition: t.tgdef, functionOid: t.tgfoid, functionSchema: t.fn_schema })),
    };
}
function rewriteIndexForShadow(indexDef, schemaSql, shadowTable, newIndexName) {
    const match = /^CREATE\s+(UNIQUE\s+)?INDEX\s+\S+\s+ON\s+(?:ONLY\s+)?\S+\s+(USING\s+[\s\S]+)$/i.exec(indexDef.trim());
    if (!match)
        throw new Error(`Cannot rewrite index definition for shadow table: ${indexDef}`);
    const uniqueSql = match[1] ? 'UNIQUE ' : '';
    return `CREATE ${uniqueSql}INDEX ${q(newIndexName)} ON ${schemaSql}.${q(shadowTable)} ${match[2]}`;
}
function policyCommandSql(polcmd) {
    switch (polcmd) {
        case 'r': return 'SELECT';
        case 'a': return 'INSERT';
        case 'w': return 'UPDATE';
        case 'd': return 'DELETE';
        default: return 'ALL';
    }
}
async function lockMigrationAdvisory(client, plan) {
    await client.query(`SELECT pg_catalog.pg_advisory_xact_lock(pg_catalog.hashtextextended($1, 0))`, [
        `online_partition:${plan.schemaName}.${plan.table}`,
    ]);
}
function pkRowExpr(alias, cols) {
    const prefix = alias ? `${alias}.` : '';
    return `(${cols.map(c => `${prefix}${q(c.attname)}`).join(', ')})`;
}
function pkJsonObjectExpr(recordAlias, cols) {
    const pairs = cols.map(c => `${pg.escapeLiteral(c.attname)}, ${recordAlias}.${q(c.attname)}`).join(', ');
    return `pg_catalog.jsonb_build_object(${pairs})`;
}
function canonicalRowJsonExpr(alias, cols) {
    const pairs = cols.map(c => `${pg.escapeLiteral(c.attname)}, ${alias}.${q(c.attname)}`).join(', ');
    return `pg_catalog.jsonb_build_object(${pairs})`;
}
/**
 * Creates a HASH-partitioned shadow table by `partitionKey` (default `owner`) with N child partitions,
 * copies columns, defaults, constraints, indexes, RLS policies and grants, and validates that every
 * unique constraint/index contains the partition key (docs/scaling.md 09.1 step 1).
 */
export async function createShadowHashPartitions(db, options) {
    const plan = resolvePartitionPlan(db, options);
    const s = plan.schemaSql;
    return db.transaction(async (client) => {
        await lockMigrationAdvisory(client, plan);
        const meta = await inspectTable(client, plan.schemaName, plan.table, new Set([plan.captureTrigger, plan.reverseCaptureTrigger]));
        if (meta.relkind === 'p') {
            throw new Error(`Table ${plan.schemaName}.${plan.table} is already partitioned`);
        }
        const partCol = meta.columns.find(c => c.attname === plan.partitionKey);
        if (!partCol) {
            throw new Error(`Partition key column "${plan.partitionKey}" does not exist on ${plan.schemaName}.${plan.table}`);
        }
        // PostgreSQL requires every PRIMARY KEY, UNIQUE constraint, and UNIQUE index on a partitioned table
        // to include all partition key columns. Fail loudly before creating any shadow objects.
        for (const con of meta.constraints) {
            if ((con.contype === 'p' || con.contype === 'u') && !con.columns.includes(plan.partitionKey)) {
                throw new Error(`Unique constraint "${con.conname}" on ${plan.schemaName}.${plan.table} (${con.columns.join(', ')}) does not include partition key "${plan.partitionKey}"`);
            }
        }
        for (const idx of meta.indexes) {
            if (idx.indisunique && !idx.key_columns.includes(plan.partitionKey)) {
                throw new Error(`Unique index "${idx.index_name}" on ${plan.schemaName}.${plan.table} does not include partition key "${plan.partitionKey}"`);
            }
        }
        const existsRes = await client.query(`SELECT c.oid FROM pg_catalog.pg_class c JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
       WHERE n.nspname = $1 AND c.relname = $2`, [plan.schemaName, plan.shadowTable]);
        if (existsRes.rowCount) {
            throw new Error(`Shadow table ${plan.schemaName}.${plan.shadowTable} already exists`);
        }
        await client.query(`CREATE TABLE ${s}.${q(plan.shadowTable)} (
        LIKE ${s}.${q(plan.table)}
        INCLUDING DEFAULTS
        INCLUDING GENERATED
        INCLUDING IDENTITY
        INCLUDING STORAGE
        INCLUDING COMMENTS
      ) PARTITION BY HASH (${q(plan.partitionKey)})`);
        // Create child hash partitions p0 .. p(N-1).
        const partitions = [];
        for (let i = 0; i < plan.partitions; i++) {
            const partName = derivedIdent(plan.shadowTable, `p${i}`);
            await client.query(`CREATE TABLE ${s}.${q(partName)} PARTITION OF ${s}.${q(plan.shadowTable)}
         FOR VALUES WITH (MODULUS ${plan.partitions}, REMAINDER ${i})`);
            partitions.push(partName);
        }
        // Copy PRIMARY KEY, UNIQUE, CHECK, and outgoing FOREIGN KEY constraints.
        const copiedConstraints = [];
        for (const con of meta.constraints) {
            if (con.contype !== 'p' && con.contype !== 'u' && con.contype !== 'c' && con.contype !== 'f')
                continue;
            const shadowConName = derivedIdent(plan.shadowTable, con.conname);
            await client.query(`ALTER TABLE ${s}.${q(plan.shadowTable)} ADD CONSTRAINT ${q(shadowConName)} ${con.condef}`);
            copiedConstraints.push(shadowConName);
        }
        // Copy all non-constraint indexes (GIN, partial, B-tree, unique indexes).
        const copiedIndexes = [];
        for (const idx of meta.indexes) {
            if (idx.backs_constraint)
                continue;
            const shadowIdxName = derivedIdent(plan.shadowTable, idx.index_name);
            const sql = rewriteIndexForShadow(idx.indexdef, s, plan.shadowTable, shadowIdxName);
            await client.query(sql);
            copiedIndexes.push(shadowIdxName);
        }
        // Copy RLS settings and policies.
        const copiedPolicies = [];
        if (meta.relrowsecurity) {
            await client.query(`ALTER TABLE ${s}.${q(plan.shadowTable)} ENABLE ROW LEVEL SECURITY`);
        }
        if (meta.relforcerowsecurity) {
            await client.query(`ALTER TABLE ${s}.${q(plan.shadowTable)} FORCE ROW LEVEL SECURITY`);
        }
        for (const pol of meta.policies) {
            const kind = pol.polpermissive ? 'PERMISSIVE' : 'RESTRICTIVE';
            const cmd = policyCommandSql(pol.polcmd);
            const roles = pol.roles.length ? pol.roles.map(q).join(', ') : 'PUBLIC';
            const usingSql = pol.using_expr ? ` USING (${pol.using_expr})` : '';
            const checkSql = pol.check_expr ? ` WITH CHECK (${pol.check_expr})` : '';
            await client.query(`CREATE POLICY ${q(pol.polname)} ON ${s}.${q(plan.shadowTable)} AS ${kind} FOR ${cmd} TO ${roles}${usingSql}${checkSql}`);
            copiedPolicies.push(pol.polname);
        }
        // Copy table privileges onto shadow parent (and child partitions for visibility parity).
        const currentUser = (await client.query('SELECT current_user')).rows[0]?.current_user;
        for (const grant of meta.grants) {
            if (grant.grantee === currentUser)
                continue;
            const granteeSql = grant.grantee === 'PUBLIC' ? 'PUBLIC' : q(grant.grantee);
            const optionSql = grant.is_grantable === 'YES' ? ' WITH GRANT OPTION' : '';
            await client.query(`GRANT ${grant.privilege_type} ON ${s}.${q(plan.shadowTable)} TO ${granteeSql}${optionSql}`);
            for (const part of partitions) {
                await client.query(`GRANT ${grant.privilege_type} ON ${s}.${q(part)} TO ${granteeSql}${optionSql}`);
            }
        }
        // Persist migration metadata and progress tracking table.
        await client.query(`CREATE TABLE IF NOT EXISTS ${s}.${q(plan.stateTable)} (
        table_name text PRIMARY KEY,
        shadow_table text NOT NULL,
        partition_key text NOT NULL,
        partition_count integer NOT NULL,
        primary_key_columns text[] NOT NULL,
        backfill_cursor jsonb,
        backfill_rows bigint NOT NULL DEFAULT 0,
        backfill_done boolean NOT NULL DEFAULT false,
        replay_cursor bigint NOT NULL DEFAULT 0,
        replayed_changes bigint NOT NULL DEFAULT 0,
        reverse_replay_cursor bigint NOT NULL DEFAULT 0,
        state text NOT NULL DEFAULT 'shadow_created',
        updated_at timestamptz NOT NULL DEFAULT now()
      )`);
        const pkNames = meta.primaryKeyColumns.map(c => c.attname);
        await client.query(`INSERT INTO ${s}.${q(plan.stateTable)}(table_name, shadow_table, partition_key, partition_count, primary_key_columns, state)
       VALUES ($1, $2, $3, $4, $5, 'shadow_created')
       ON CONFLICT (table_name) DO UPDATE SET
         shadow_table = EXCLUDED.shadow_table,
         partition_key = EXCLUDED.partition_key,
         partition_count = EXCLUDED.partition_count,
         primary_key_columns = EXCLUDED.primary_key_columns,
         backfill_cursor = NULL,
         backfill_rows = 0,
         backfill_done = false,
         replay_cursor = 0,
         replayed_changes = 0,
         reverse_replay_cursor = 0,
         state = 'shadow_created',
         updated_at = now()`, [plan.table, plan.shadowTable, plan.partitionKey, plan.partitions, pkNames]);
        return {
            table: plan.table,
            shadowTable: plan.shadowTable,
            partitionKey: plan.partitionKey,
            partitions,
            primaryKeyColumns: pkNames,
            copiedConstraints,
            copiedIndexes,
            copiedPolicies,
            incomingForeignKeys: meta.incomingForeignKeys,
            userTriggers: meta.userTriggers,
        };
    });
}
// --- 2. installChangeCapture ---
async function installCaptureTriggerOnTable(client, schemaSql, targetTable, changeLogTable, fnName, triggerName, pkColumns) {
    await client.query(`CREATE TABLE IF NOT EXISTS ${schemaSql}.${q(changeLogTable)} (
      seq bigserial PRIMARY KEY,
      op text NOT NULL CHECK (op IN ('I', 'U', 'D')),
      pk jsonb NOT NULL,
      xid xid8 NOT NULL DEFAULT pg_catalog.pg_current_xact_id(),
      applied boolean NOT NULL DEFAULT false,
      recorded_at timestamptz NOT NULL DEFAULT pg_catalog.clock_timestamp()
    )`);
    const pendingIdx = derivedIdent(changeLogTable, 'pending');
    await client.query(`CREATE INDEX IF NOT EXISTS ${q(pendingIdx)} ON ${schemaSql}.${q(changeLogTable)}(seq) WHERE NOT applied`);
    const oldPk = pkJsonObjectExpr('OLD', pkColumns);
    const newPk = pkJsonObjectExpr('NEW', pkColumns);
    const pkChanged = pkColumns.map(c => `OLD.${q(c.attname)} IS DISTINCT FROM NEW.${q(c.attname)}`).join(' OR ');
    await client.query(`CREATE OR REPLACE FUNCTION ${schemaSql}.${q(fnName)}()
     RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = pg_catalog AS $$
     BEGIN
       IF TG_OP = 'INSERT' THEN
         INSERT INTO ${schemaSql}.${q(changeLogTable)}(op, pk) VALUES ('I', ${newPk});
         RETURN NEW;
       ELSIF TG_OP = 'UPDATE' THEN
         IF ${pkChanged} THEN
           INSERT INTO ${schemaSql}.${q(changeLogTable)}(op, pk) VALUES ('D', ${oldPk}), ('U', ${newPk});
         ELSE
           INSERT INTO ${schemaSql}.${q(changeLogTable)}(op, pk) VALUES ('U', ${newPk});
         END IF;
         RETURN NEW;
       ELSIF TG_OP = 'DELETE' THEN
         INSERT INTO ${schemaSql}.${q(changeLogTable)}(op, pk) VALUES ('D', ${oldPk});
         RETURN OLD;
       END IF;
       RETURN NULL;
     END;
     $$`);
    await client.query(`DROP TRIGGER IF EXISTS ${q(triggerName)} ON ${schemaSql}.${q(targetTable)}`);
    await client.query(`CREATE TRIGGER ${q(triggerName)}
     AFTER INSERT OR UPDATE OR DELETE ON ${schemaSql}.${q(targetTable)}
     FOR EACH ROW EXECUTE FUNCTION ${schemaSql}.${q(fnName)}()`);
}
/**
 * Installs same-transaction change capture (INSERT, UPDATE, DELETE, and primary-key moves)
 * on the authoritative table before historical chunked backfill begins (docs/scaling.md 09.1 step 2).
 */
export async function installChangeCapture(db, options) {
    const plan = resolvePartitionPlan(db, options);
    const s = plan.schemaSql;
    return db.transaction(async (client) => {
        await lockMigrationAdvisory(client, plan);
        const meta = await inspectTable(client, plan.schemaName, plan.table, new Set([plan.captureTrigger, plan.reverseCaptureTrigger]));
        await installCaptureTriggerOnTable(client, s, plan.table, plan.changeLogTable, plan.captureFunction, plan.captureTrigger, meta.primaryKeyColumns);
        const stateExists = await client.query(`SELECT 1 FROM pg_catalog.pg_class c JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
       WHERE n.nspname = $1 AND c.relname = $2`, [plan.schemaName, plan.stateTable]);
        if (stateExists.rowCount) {
            await client.query(`UPDATE ${s}.${q(plan.stateTable)} SET state = 'capture_installed', updated_at = now() WHERE table_name = $1`, [plan.table]);
        }
        return {
            table: plan.table,
            changeLogTable: plan.changeLogTable,
            triggerName: plan.captureTrigger,
            functionName: plan.captureFunction,
            primaryKeyColumns: meta.primaryKeyColumns.map(c => c.attname),
        };
    });
}
/**
 * Opens a `REPEATABLE READ READ ONLY` transaction, exports its PostgreSQL consistent snapshot ID,
 * and passes it to `run` so multiple `backfillChunk` calls can read from one exact consistent snapshot.
 */
export async function withConsistentSnapshot(db, run) {
    const client = await db.pool.connect();
    try {
        await client.query('BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY');
        const { rows: [row] } = await client.query('SELECT pg_catalog.pg_export_snapshot() AS snapshot_id');
        if (!row?.snapshot_id)
            throw new Error('Failed to export PostgreSQL consistent snapshot');
        const result = await run(row.snapshot_id);
        await client.query('COMMIT');
        return result;
    }
    catch (error) {
        await client.query('ROLLBACK').catch(() => { });
        throw error;
    }
    finally {
        client.release();
    }
}
/**
 * Copies one primary-key-ordered chunk of historical rows from the authoritative table into the
 * partitioned shadow table and persists the PK cursor atomically (docs/scaling.md 09.1 step 2).
 */
export async function backfillChunk(db, options) {
    const plan = resolvePartitionPlan(db, options);
    const chunkSize = Math.max(1, Math.min(100_000, Math.floor(options.chunkSize ?? 1000)));
    const s = plan.schemaSql;
    if (options.snapshotId) {
        // Two-connection path: read chunk from the exported consistent snapshot, then write & persist cursor atomically.
        const metaAndState = await db.transaction(async (client) => {
            await lockMigrationAdvisory(client, plan);
            const meta = await inspectTable(client, plan.schemaName, plan.table, new Set([plan.captureTrigger, plan.reverseCaptureTrigger]));
            const stateRow = (await client.query(`SELECT backfill_cursor, backfill_rows::text, backfill_done FROM ${s}.${q(plan.stateTable)} WHERE table_name = $1`, [plan.table])).rows[0];
            if (!stateRow)
                throw new Error(`Migration state missing for ${plan.schemaName}.${plan.table}; call createShadowHashPartitions first`);
            return { meta, stateRow };
        });
        const { meta, stateRow } = metaAndState;
        if (stateRow.backfill_done) {
            return {
                scanned: 0,
                copied: 0,
                totalCopied: Number(stateRow.backfill_rows),
                done: true,
                cursor: stateRow.backfill_cursor,
            };
        }
        const pkCols = meta.primaryKeyColumns;
        const writeCols = meta.writableColumns;
        const writeColList = writeCols.map(c => q(c.attname)).join(', ');
        const pkColList = pkCols.map(c => q(c.attname)).join(', ');
        const pkOrderAsc = pkCols.map(c => `${q(c.attname)} ASC`).join(', ');
        const pkOrderDesc = pkCols.map(c => `${q(c.attname)} DESC`).join(', ');
        const cursorValues = [];
        let whereSql = '';
        if (stateRow.backfill_cursor) {
            const placeholders = pkCols.map((c, idx) => {
                cursorValues.push(stateRow.backfill_cursor[c.attname]);
                return `$${idx + 1}::${c.data_type}`;
            }).join(', ');
            whereSql = `WHERE ${pkRowExpr('', pkCols)} > (${placeholders})`;
        }
        const limitParam = `$${cursorValues.length + 1}`;
        const reader = await db.pool.connect();
        let payloadJson;
        let scanned;
        let lastCursor;
        try {
            await reader.query('BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY');
            await reader.query(`SET TRANSACTION SNAPSHOT ${pg.escapeLiteral(options.snapshotId)}`);
            const readRes = await reader.query(`WITH chunk AS (
           SELECT ${writeColList} FROM ${s}.${q(plan.table)}
           ${whereSql}
           ORDER BY ${pkOrderAsc}
           LIMIT ${limitParam}
         )
         SELECT
           (SELECT count(*)::int FROM chunk) AS scanned,
           COALESCE((SELECT pg_catalog.jsonb_agg(pg_catalog.to_jsonb(chunk)) FROM chunk), '[]'::jsonb) AS rows_json,
           (SELECT pg_catalog.row_to_json(k) FROM (SELECT ${pkColList} FROM chunk ORDER BY ${pkOrderDesc} LIMIT 1) k) AS last_cursor`, [...cursorValues, chunkSize]);
            await reader.query('COMMIT');
            scanned = readRes.rows[0]?.scanned ?? 0;
            payloadJson = JSON.stringify(readRes.rows[0]?.rows_json ?? []);
            lastCursor = readRes.rows[0]?.last_cursor ?? stateRow.backfill_cursor;
        }
        catch (error) {
            await reader.query('ROLLBACK').catch(() => { });
            throw error;
        }
        finally {
            reader.release();
        }
        return db.transaction(async (client) => {
            await lockMigrationAdvisory(client, plan);
            let copied = 0;
            if (scanned > 0) {
                const ins = await client.query(`WITH inserted AS (
             INSERT INTO ${s}.${q(plan.shadowTable)} (${writeColList})
             SELECT ${writeColList}
             FROM pg_catalog.jsonb_populate_recordset(NULL::${s}.${q(plan.shadowTable)}, $1::jsonb)
             ON CONFLICT (${pkColList}) DO NOTHING
             RETURNING 1
           )
           SELECT count(*)::int AS copied FROM inserted`, [payloadJson]);
                copied = ins.rows[0]?.copied ?? 0;
            }
            const done = scanned < chunkSize;
            const updated = await client.query(`UPDATE ${s}.${q(plan.stateTable)}
         SET backfill_cursor = COALESCE($2::jsonb, backfill_cursor),
             backfill_rows = backfill_rows + $3,
             backfill_done = $4,
             state = CASE WHEN $4 THEN 'backfilled' ELSE 'backfilling' END,
             updated_at = now()
         WHERE table_name = $1
         RETURNING backfill_rows::text`, [plan.table, lastCursor ? JSON.stringify(lastCursor) : null, copied, done]);
            return {
                scanned,
                copied,
                totalCopied: Number(updated.rows[0]?.backfill_rows ?? 0),
                done,
                cursor: lastCursor,
            };
        });
    }
    // Single-transaction repeatable-read chunk path.
    const client = await db.pool.connect();
    try {
        await client.query('BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ');
        await lockMigrationAdvisory(client, plan);
        const meta = await inspectTable(client, plan.schemaName, plan.table, new Set([plan.captureTrigger, plan.reverseCaptureTrigger]));
        const stateRow = (await client.query(`SELECT backfill_cursor, backfill_rows::text, backfill_done FROM ${s}.${q(plan.stateTable)} WHERE table_name = $1`, [plan.table])).rows[0];
        if (!stateRow) {
            throw new Error(`Migration state missing for ${plan.schemaName}.${plan.table}; call createShadowHashPartitions first`);
        }
        if (stateRow.backfill_done) {
            await client.query('COMMIT');
            return {
                scanned: 0,
                copied: 0,
                totalCopied: Number(stateRow.backfill_rows),
                done: true,
                cursor: stateRow.backfill_cursor,
            };
        }
        const pkCols = meta.primaryKeyColumns;
        const writeCols = meta.writableColumns;
        const writeColList = writeCols.map(c => q(c.attname)).join(', ');
        const pkColList = pkCols.map(c => q(c.attname)).join(', ');
        const pkOrderAsc = pkCols.map(c => `${q(c.attname)} ASC`).join(', ');
        const pkOrderDesc = pkCols.map(c => `${q(c.attname)} DESC`).join(', ');
        const params = [];
        let whereSql = '';
        if (stateRow.backfill_cursor) {
            const placeholders = pkCols.map((c, idx) => {
                params.push(stateRow.backfill_cursor[c.attname]);
                return `$${idx + 1}::${c.data_type}`;
            }).join(', ');
            whereSql = `WHERE ${pkRowExpr('', pkCols)} > (${placeholders})`;
        }
        params.push(chunkSize);
        const limitParam = `$${params.length}`;
        const chunkRes = await client.query(`WITH chunk AS (
         SELECT ${writeColList} FROM ${s}.${q(plan.table)}
         ${whereSql}
         ORDER BY ${pkOrderAsc}
         LIMIT ${limitParam}
       ),
       inserted AS (
         INSERT INTO ${s}.${q(plan.shadowTable)} (${writeColList})
         SELECT ${writeColList} FROM chunk
         ON CONFLICT (${pkColList}) DO NOTHING
         RETURNING 1
       )
       SELECT
         (SELECT count(*)::int FROM chunk) AS scanned,
         (SELECT count(*)::int FROM inserted) AS copied,
         (SELECT pg_catalog.row_to_json(k) FROM (SELECT ${pkColList} FROM chunk ORDER BY ${pkOrderDesc} LIMIT 1) k) AS last_cursor`, params);
        const scanned = chunkRes.rows[0]?.scanned ?? 0;
        const copied = chunkRes.rows[0]?.copied ?? 0;
        const nextCursor = chunkRes.rows[0]?.last_cursor ?? stateRow.backfill_cursor;
        const done = scanned < chunkSize;
        const updated = await client.query(`UPDATE ${s}.${q(plan.stateTable)}
       SET backfill_cursor = COALESCE($2::jsonb, backfill_cursor),
           backfill_rows = backfill_rows + $3,
           backfill_done = $4,
           state = CASE WHEN $4 THEN 'backfilled' ELSE 'backfilling' END,
           updated_at = now()
       WHERE table_name = $1
       RETURNING backfill_rows::text`, [plan.table, nextCursor ? JSON.stringify(nextCursor) : null, copied, done]);
        await client.query('COMMIT');
        return {
            scanned,
            copied,
            totalCopied: Number(updated.rows[0]?.backfill_rows ?? 0),
            done,
            cursor: nextCursor,
        };
    }
    catch (error) {
        await client.query('ROLLBACK').catch(() => { });
        throw error;
    }
    finally {
        client.release();
    }
}
// --- 4. replayChanges (shared CTE engine for forward & reverse replay) ---
async function replayBatchInTransaction(client, schemaSql, sourceTable, targetTable, changeLogTable, meta, batchSize) {
    const eventsRes = await client.query(`SELECT seq::text, op, pk
     FROM ${schemaSql}.${q(changeLogTable)}
     WHERE NOT applied
     ORDER BY seq ASC
     LIMIT $1`, [batchSize]);
    if (!eventsRes.rows.length) {
        return { processedEvents: 0, distinctKeys: 0, upserted: 0, deleted: 0, maxSeq: 0, remaining: 0 };
    }
    const pkCols = meta.primaryKeyColumns;
    const writeCols = meta.writableColumns;
    const pkNameSet = new Set(pkCols.map(c => c.attname));
    const nonPkWriteCols = writeCols.filter(c => !pkNameSet.has(c.attname));
    const seqs = [];
    const uniqueMap = new Map();
    let maxSeq = 0;
    for (const row of eventsRes.rows) {
        seqs.push(row.seq);
        const numSeq = Number(row.seq);
        if (numSeq > maxSeq)
            maxSeq = numSeq;
        const keyTuple = JSON.stringify(pkCols.map(c => row.pk[c.attname]));
        if (!uniqueMap.has(keyTuple))
            uniqueMap.set(keyTuple, row.pk);
    }
    const uniquePks = [...uniqueMap.values()];
    const writeColList = writeCols.map(c => q(c.attname)).join(', ');
    const selectLiveCols = writeCols.map(c => `s.${q(c.attname)}`).join(', ');
    const pkColList = pkCols.map(c => q(c.attname)).join(', ');
    const joinSource = pkCols.map(c => `s.${q(c.attname)} = k.${q(c.attname)}`).join(' AND ');
    const joinTarget = pkCols.map(c => `t.${q(c.attname)} = k.${q(c.attname)}`).join(' AND ');
    const joinLive = pkCols.map(c => `l.${q(c.attname)} = k.${q(c.attname)}`).join(' AND ');
    const conflictClause = nonPkWriteCols.length
        ? `ON CONFLICT (${pkColList}) DO UPDATE SET ${nonPkWriteCols.map(c => `${q(c.attname)} = EXCLUDED.${q(c.attname)}`).join(', ')}`
        : `ON CONFLICT (${pkColList}) DO NOTHING`;
    // Single-statement CTE guarantees `live`, `upserted`, and `deleted` share one atomic MVCC snapshot.
    const applyRes = await client.query(`WITH batch_keys AS (
       SELECT DISTINCT ${pkColList}
       FROM pg_catalog.jsonb_populate_recordset(NULL::${schemaSql}.${q(sourceTable)}, $1::jsonb)
     ),
     live AS (
       SELECT ${selectLiveCols}
       FROM ${schemaSql}.${q(sourceTable)} s
       JOIN batch_keys k ON ${joinSource}
     ),
     upserted AS (
       INSERT INTO ${schemaSql}.${q(targetTable)} (${writeColList})
       SELECT ${writeColList} FROM live
       ${conflictClause}
       RETURNING 1
     ),
     deleted AS (
       DELETE FROM ${schemaSql}.${q(targetTable)} t
       USING batch_keys k
       WHERE ${joinTarget}
         AND NOT EXISTS (SELECT 1 FROM live l WHERE ${joinLive})
       RETURNING 1
     )
     SELECT
       (SELECT count(*)::int FROM upserted) AS upserted,
       (SELECT count(*)::int FROM deleted) AS deleted`, [JSON.stringify(uniquePks)]);
    await client.query(`UPDATE ${schemaSql}.${q(changeLogTable)} SET applied = true WHERE seq = ANY($1::bigint[])`, [seqs]);
    const remRes = await client.query(`SELECT count(*)::int AS remaining FROM ${schemaSql}.${q(changeLogTable)} WHERE NOT applied`);
    return {
        processedEvents: eventsRes.rows.length,
        distinctKeys: uniquePks.length,
        upserted: applyRes.rows[0]?.upserted ?? 0,
        deleted: applyRes.rows[0]?.deleted ?? 0,
        maxSeq,
        remaining: remRes.rows[0]?.remaining ?? 0,
    };
}
/**
 * Deduplicates captured change keys, re-reads latest values from the authoritative table
 * (deleting removed keys from the shadow table), and persists the replay cursor in the same
 * transaction (docs/scaling.md 09.1 step 3).
 */
export async function replayChanges(db, options) {
    const plan = resolvePartitionPlan(db, options);
    const batchSize = Math.max(1, Math.min(50_000, Math.floor(options.batchSize ?? 500)));
    const s = plan.schemaSql;
    return db.transaction(async (client) => {
        await lockMigrationAdvisory(client, plan);
        const meta = await inspectTable(client, plan.schemaName, plan.table, new Set([plan.captureTrigger, plan.reverseCaptureTrigger]));
        const stateRow = (await client.query(`SELECT backfill_done, replay_cursor::text FROM ${s}.${q(plan.stateTable)} WHERE table_name = $1`, [plan.table])).rows[0];
        if (!stateRow) {
            throw new Error(`Migration state missing for ${plan.schemaName}.${plan.table}; call createShadowHashPartitions first`);
        }
        if (!stateRow.backfill_done && !options.allowBeforeBackfillDone) {
            throw new Error('Complete historical backfill before replaying changes to prevent backfill from overwriting newer rows');
        }
        const batch = await replayBatchInTransaction(client, s, plan.table, plan.shadowTable, plan.changeLogTable, meta, batchSize);
        if (batch.processedEvents === 0) {
            return {
                ...batch,
                replayCursor: Number(stateRow.replay_cursor),
            };
        }
        const updated = await client.query(`UPDATE ${s}.${q(plan.stateTable)}
       SET replay_cursor = GREATEST(replay_cursor, $2::bigint),
           replayed_changes = replayed_changes + $3,
           state = 'replaying',
           updated_at = now()
       WHERE table_name = $1
       RETURNING replay_cursor::text`, [plan.table, batch.maxSeq, batch.processedEvents]);
        return {
            processedEvents: batch.processedEvents,
            distinctKeys: batch.distinctKeys,
            upserted: batch.upserted,
            deleted: batch.deleted,
            replayCursor: Number(updated.rows[0]?.replay_cursor ?? batch.maxSeq),
            remaining: batch.remaining,
        };
    });
}
/**
 * Reconciles authoritative and shadow tables chunk-by-chunk across `(owner, projection)` slices
 * in a single repeatable-read snapshot: row counts, SHA-256 content fingerprints, forward diff,
 * reverse diff (extra rows in shadow), and content mismatches (docs/scaling.md 09.1 step 4).
 */
export async function reconcileShadow(db, options) {
    const plan = resolvePartitionPlan(db, options);
    const sourceTable = assertIdent(options.sourceTable ?? plan.table, 'sourceTable');
    const targetTable = assertIdent(options.targetTable ?? plan.shadowTable, 'targetTable');
    const sliceChunkSize = Math.max(1, Math.min(1000, Math.floor(options.sliceChunkSize ?? 100)));
    const maxSamples = Math.max(1, Math.min(500, Math.floor(options.maxSampleMismatches ?? 20)));
    const s = plan.schemaSql;
    const client = await db.pool.connect();
    let result;
    try {
        await client.query('BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY');
        const meta = await inspectTable(client, plan.schemaName, sourceTable, new Set([plan.captureTrigger, plan.reverseCaptureTrigger]));
        const colByName = new Map(meta.columns.map(c => [c.attname, c]));
        const groupNames = options.groupByColumns
            ? [...options.groupByColumns]
            : colByName.has('owner') && colByName.has('projection')
                ? ['owner', 'projection']
                : [plan.partitionKey];
        const groupCols = groupNames.map(name => {
            const col = colByName.get(name);
            if (!col)
                throw new Error(`Reconcile group column "${name}" does not exist on ${plan.schemaName}.${sourceTable}`);
            return col;
        });
        const pkCols = meta.primaryKeyColumns;
        const allCols = meta.columns;
        const groupSelect = groupCols.map(c => q(c.attname)).join(', ');
        const groupOrder = groupCols.map(c => `${q(c.attname)} ASC NULLS FIRST`).join(', ');
        const groupsRes = await client.query(`SELECT pg_catalog.row_to_json(g) AS grp
       FROM (
         SELECT ${groupSelect} FROM ${s}.${q(sourceTable)}
         UNION
         SELECT ${groupSelect} FROM ${s}.${q(targetTable)}
       ) g
       ORDER BY ${groupOrder}`);
        const groupKeyOf = (row) => JSON.stringify(groupCols.map(c => row[c.attname] ?? null));
        const groupJoin = (alias) => groupCols.map(c => c.attnotnull
            ? `${alias}.${q(c.attname)} = g.${q(c.attname)}`
            : `${alias}.${q(c.attname)} IS NOT DISTINCT FROM g.${q(c.attname)}`).join(' AND ');
        const groupAliasSelect = (alias) => groupCols.map(c => `${alias}.${q(c.attname)}`).join(', ');
        const pkJoin = (a, b) => pkCols.map(c => `${a}.${q(c.attname)} = ${b}.${q(c.attname)}`).join(' AND ');
        const pkOrder = (alias) => pkCols.map(c => `${alias}.${q(c.attname)} ASC`).join(', ');
        const pkJson = (alias) => pkJsonObjectExpr(alias, pkCols);
        const rowHash = (alias) => `pg_catalog.encode(pg_catalog.sha256(pg_catalog.convert_to(${canonicalRowJsonExpr(alias, allCols)}::text, 'UTF8')), 'hex')`;
        const groupJson = (alias) => pkJsonObjectExpr(alias, groupCols);
        const slices = [];
        const sampleMissingInShadow = [];
        const sampleExtraInShadow = [];
        const sampleContentMismatch = [];
        let sourceRows = 0;
        let shadowRows = 0;
        let missingInShadowTotal = 0;
        let extraInShadowTotal = 0;
        let contentMismatchTotal = 0;
        const allGroups = groupsRes.rows.map(r => r.grp);
        for (let offset = 0; offset < allGroups.length; offset += sliceChunkSize) {
            const chunkGroups = allGroups.slice(offset, offset + sliceChunkSize);
            const chunkParam = JSON.stringify(chunkGroups);
            const aggSql = (table) => `
        WITH slice_groups AS (
          SELECT DISTINCT ${groupSelect}
          FROM pg_catalog.jsonb_populate_recordset(NULL::${s}.${q(sourceTable)}, $1::jsonb)
        )
        SELECT ${groupJson('g')} AS grp,
               count(*)::bigint AS cnt,
               pg_catalog.encode(
                 pg_catalog.sha256(
                   pg_catalog.convert_to(pg_catalog.string_agg(${rowHash('t')}, ',' ORDER BY ${pkOrder('t')}), 'UTF8')
                 ),
                 'hex'
               ) AS fp
        FROM ${s}.${q(table)} t
        JOIN slice_groups g ON ${groupJoin('t')}
        GROUP BY ${groupAliasSelect('g')}`;
            const srcAgg = await client.query(aggSql(sourceTable), [chunkParam]);
            const shdAgg = await client.query(aggSql(targetTable), [chunkParam]);
            const srcMap = new Map(srcAgg.rows.map(r => [groupKeyOf(r.grp), { count: Number(r.cnt), fp: r.fp ?? '' }]));
            const shdMap = new Map(shdAgg.rows.map(r => [groupKeyOf(r.grp), { count: Number(r.cnt), fp: r.fp ?? '' }]));
            // Compute explicit forward diff (source \ shadow), reverse diff (shadow \ source), and content diff per group.
            const diffRes = await client.query(`WITH slice_groups AS (
           SELECT DISTINCT ${groupSelect}
           FROM pg_catalog.jsonb_populate_recordset(NULL::${s}.${q(sourceTable)}, $1::jsonb)
         ),
         src AS (
           SELECT t.*, ${groupJson('g')} AS _grp
           FROM ${s}.${q(sourceTable)} t
           JOIN slice_groups g ON ${groupJoin('t')}
         ),
         shd AS (
           SELECT t.*, ${groupJson('g')} AS _grp
           FROM ${s}.${q(targetTable)} t
           JOIN slice_groups g ON ${groupJoin('t')}
         ),
         missing AS (
           SELECT s._grp AS grp, count(*)::bigint AS cnt
           FROM src s
           LEFT JOIN shd d ON ${pkJoin('s', 'd')}
           WHERE d.${q(pkCols[0].attname)} IS NULL
           GROUP BY s._grp
         ),
         extra AS (
           SELECT d._grp AS grp, count(*)::bigint AS cnt
           FROM shd d
           LEFT JOIN src s ON ${pkJoin('d', 's')}
           WHERE s.${q(pkCols[0].attname)} IS NULL
           GROUP BY d._grp
         ),
         content AS (
           SELECT s._grp AS grp, count(*)::bigint AS cnt
           FROM src s
           JOIN shd d ON ${pkJoin('s', 'd')}
           WHERE ${canonicalRowJsonExpr('s', allCols)} IS DISTINCT FROM ${canonicalRowJsonExpr('d', allCols)}
           GROUP BY s._grp
         )
         SELECT ${groupJson('g')} AS grp,
                COALESCE(m.cnt, 0)::text AS missing_in_shadow,
                COALESCE(e.cnt, 0)::text AS extra_in_shadow,
                COALESCE(c.cnt, 0)::text AS content_mismatch
         FROM slice_groups g
         LEFT JOIN missing m ON m.grp = ${groupJson('g')}
         LEFT JOIN extra e ON e.grp = ${groupJson('g')}
         LEFT JOIN content c ON c.grp = ${groupJson('g')}`, [chunkParam]);
            const diffMap = new Map(diffRes.rows.map(r => [
                groupKeyOf(r.grp),
                {
                    missing: Number(r.missing_in_shadow),
                    extra: Number(r.extra_in_shadow),
                    content: Number(r.content_mismatch),
                },
            ]));
            let chunkHasMissing = false;
            let chunkHasExtra = false;
            let chunkHasContent = false;
            for (const grp of chunkGroups) {
                const key = groupKeyOf(grp);
                const sStat = srcMap.get(key) ?? { count: 0, fp: '' };
                const dStat = shdMap.get(key) ?? { count: 0, fp: '' };
                const diff = diffMap.get(key) ?? { missing: 0, extra: 0, content: 0 };
                sourceRows += sStat.count;
                shadowRows += dStat.count;
                missingInShadowTotal += diff.missing;
                extraInShadowTotal += diff.extra;
                contentMismatchTotal += diff.content;
                if (diff.missing > 0)
                    chunkHasMissing = true;
                if (diff.extra > 0)
                    chunkHasExtra = true;
                if (diff.content > 0)
                    chunkHasContent = true;
                const matched = sStat.count === dStat.count &&
                    sStat.fp === dStat.fp &&
                    diff.missing === 0 &&
                    diff.extra === 0 &&
                    diff.content === 0;
                slices.push({
                    group: grp,
                    sourceCount: sStat.count,
                    shadowCount: dStat.count,
                    sourceFingerprint: sStat.fp,
                    shadowFingerprint: dStat.fp,
                    missingInShadow: diff.missing,
                    extraInShadow: diff.extra,
                    contentMismatches: diff.content,
                    matched,
                });
            }
            // Collect bounded mismatch PK samples for diagnostics.
            if (chunkHasMissing && sampleMissingInShadow.length < maxSamples) {
                const need = maxSamples - sampleMissingInShadow.length;
                const rows = (await client.query(`WITH slice_groups AS (
             SELECT DISTINCT ${groupSelect}
             FROM pg_catalog.jsonb_populate_recordset(NULL::${s}.${q(sourceTable)}, $1::jsonb)
           )
           SELECT ${pkJson('s')} AS pk
           FROM ${s}.${q(sourceTable)} s
           JOIN slice_groups g ON ${groupJoin('s')}
           LEFT JOIN ${s}.${q(targetTable)} d ON ${pkJoin('s', 'd')}
           WHERE d.${q(pkCols[0].attname)} IS NULL
           ORDER BY ${pkOrder('s')}
           LIMIT $2`, [chunkParam, need])).rows;
                for (const r of rows)
                    sampleMissingInShadow.push(r.pk);
            }
            if (chunkHasExtra && sampleExtraInShadow.length < maxSamples) {
                const need = maxSamples - sampleExtraInShadow.length;
                const rows = (await client.query(`WITH slice_groups AS (
             SELECT DISTINCT ${groupSelect}
             FROM pg_catalog.jsonb_populate_recordset(NULL::${s}.${q(sourceTable)}, $1::jsonb)
           )
           SELECT ${pkJson('d')} AS pk
           FROM ${s}.${q(targetTable)} d
           JOIN slice_groups g ON ${groupJoin('d')}
           LEFT JOIN ${s}.${q(sourceTable)} s ON ${pkJoin('d', 's')}
           WHERE s.${q(pkCols[0].attname)} IS NULL
           ORDER BY ${pkOrder('d')}
           LIMIT $2`, [chunkParam, need])).rows;
                for (const r of rows)
                    sampleExtraInShadow.push(r.pk);
            }
            if (chunkHasContent && sampleContentMismatch.length < maxSamples) {
                const need = maxSamples - sampleContentMismatch.length;
                const rows = (await client.query(`WITH slice_groups AS (
             SELECT DISTINCT ${groupSelect}
             FROM pg_catalog.jsonb_populate_recordset(NULL::${s}.${q(sourceTable)}, $1::jsonb)
           )
           SELECT ${pkJson('s')} AS pk
           FROM ${s}.${q(sourceTable)} s
           JOIN slice_groups g ON ${groupJoin('s')}
           JOIN ${s}.${q(targetTable)} d ON ${pkJoin('s', 'd')}
           WHERE ${canonicalRowJsonExpr('s', allCols)} IS DISTINCT FROM ${canonicalRowJsonExpr('d', allCols)}
           ORDER BY ${pkOrder('s')}
           LIMIT $2`, [chunkParam, need])).rows;
                for (const r of rows)
                    sampleContentMismatch.push(r.pk);
            }
        }
        await client.query('COMMIT');
        const mismatchedSlices = slices.filter(slice => !slice.matched).length;
        result = {
            matched: mismatchedSlices === 0 && missingInShadowTotal === 0 && extraInShadowTotal === 0 && contentMismatchTotal === 0,
            groupByColumns: groupNames,
            totalSlices: slices.length,
            mismatchedSlices,
            sourceRows,
            shadowRows,
            missingInShadowTotal,
            extraInShadowTotal,
            contentMismatchTotal,
            slices,
            sampleMissingInShadow,
            sampleExtraInShadow,
            sampleContentMismatch,
        };
    }
    catch (error) {
        await client.query('ROLLBACK').catch(() => { });
        throw error;
    }
    finally {
        client.release();
    }
    if (result.matched && !options.sourceTable && !options.targetTable) {
        await db.query(`UPDATE ${s}.${q(plan.stateTable)} SET state = 'reconciled', updated_at = now()
       WHERE table_name = $1 AND state IN ('backfilled', 'replaying', 'reconciled')`, [plan.table]).catch(() => { });
    }
    return result;
}
// --- 6. cutoverShadow, syncReverseChanges & rollbackCutover ---
/**
 * In PostgreSQL 17, row triggers attached to a partitioned parent table execute on the routed child
 * partition, so `TG_TABLE_NAME` is the child partition name rather than the parent table name.
 * If a schema-local trigger function compares `TG_TABLE_NAME = '<table>'`, widen that predicate to
 * also match child partitions whose same-schema parent is `<table>` (which remains valid on rollback).
 */
async function ensurePartitionAwareTriggerFunction(client, schemaName, tableName, trigger) {
    if (trigger.functionSchema !== schemaName)
        return;
    const fnRes = await client.query(`SELECT pg_catalog.pg_get_functiondef($1::oid) AS fn_def`, [trigger.functionOid]);
    const fnDef = fnRes.rows[0]?.fn_def;
    if (!fnDef || fnDef.includes('pg_catalog.pg_inherits'))
        return;
    const escaped = tableName.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const pattern = new RegExp(`\\bTG_TABLE_NAME\\s*=\\s*'${escaped}'`, 'gi');
    if (!pattern.test(fnDef))
        return;
    const literalTable = pg.escapeLiteral(tableName);
    const replacement = `(TG_TABLE_NAME = ${literalTable} OR EXISTS (` +
        `SELECT 1 FROM pg_catalog.pg_inherits _i ` +
        `JOIN pg_catalog.pg_class _p ON _p.oid = _i.inhparent ` +
        `JOIN pg_catalog.pg_class _c ON _c.oid = _i.inhrelid ` +
        `WHERE _i.inhrelid = TG_RELID AND _p.relnamespace = _c.relnamespace AND _p.relname = ${literalTable}))`;
    const updatedDef = fnDef.replace(pattern, replacement);
    if (updatedDef !== fnDef) {
        await client.query(updatedDef);
    }
}
/**
 * Performs a bounded-lock cutover: sets `SET LOCAL lock_timeout`, acquires exclusive locks, drains all
 * remaining change-log events, swaps table names (`table -> legacyTable`, `shadowTable -> table`),
 * rebinds OID-pinned incoming foreign keys and user triggers, and installs reverse change capture so
 * the legacy table can be synced and restored safely if rollback is needed (docs/scaling.md 09.1 steps 5-6).
 *
 * On lock contention (`55P03`), aborts cleanly and rolls back without affecting the live table.
 */
export async function cutoverShadow(db, options) {
    const plan = resolvePartitionPlan(db, options);
    const lockTimeoutMs = Math.max(10, Math.min(60_000, Math.floor(options.lockTimeoutMs ?? 1000)));
    const statementTimeoutMs = Math.max(100, Math.min(120_000, Math.floor(options.statementTimeoutMs ?? 15_000)));
    const drainBatchSize = Math.max(1, Math.min(50_000, Math.floor(options.drainBatchSize ?? 1000)));
    const installReverse = options.installReverseCapture ?? true;
    const s = plan.schemaSql;
    const client = await db.pool.connect();
    const reboundForeignKeys = [];
    const fksToValidate = [];
    const migratedTriggers = [];
    let drainedEvents = 0;
    try {
        await client.query('BEGIN');
        await client.query(`SET LOCAL lock_timeout = '${lockTimeoutMs}ms'`);
        await client.query(`SET LOCAL statement_timeout = '${statementTimeoutMs}ms'`);
        await lockMigrationAdvisory(client, plan);
        const stateRow = (await client.query(`SELECT backfill_done FROM ${s}.${q(plan.stateTable)} WHERE table_name = $1`, [plan.table])).rows[0];
        if (!stateRow?.backfill_done) {
            throw new Error(`Backfill must complete before cutover of ${plan.schemaName}.${plan.table}`);
        }
        // Discover incoming foreign keys before locking so we lock referencing tables deterministically.
        const preMeta = await inspectTable(client, plan.schemaName, plan.table, new Set([plan.captureTrigger, plan.reverseCaptureTrigger]));
        if (preMeta.relkind === 'p') {
            throw new Error(`Table ${plan.schemaName}.${plan.table} is already partitioned`);
        }
        const lockTargets = new Set([`${s}.${q(plan.table)}`, `${s}.${q(plan.shadowTable)}`]);
        for (const fk of preMeta.incomingForeignKeys) {
            lockTargets.add(`${q(fk.referencingSchema)}.${q(fk.referencingTable)}`);
        }
        const orderedLocks = [...lockTargets].sort();
        await client.query(`LOCK TABLE ${orderedLocks.join(', ')} IN ACCESS EXCLUSIVE MODE`);
        // Re-inspect under exclusive lock in case DDL changed just before lock acquisition.
        const meta = await inspectTable(client, plan.schemaName, plan.table, new Set([plan.captureTrigger, plan.reverseCaptureTrigger]));
        // Drain every remaining change-log event into the shadow table while writes are quiesced.
        const changeLogExists = await client.query(`SELECT 1 FROM pg_catalog.pg_class c JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
       WHERE n.nspname = $1 AND c.relname = $2`, [plan.schemaName, plan.changeLogTable]);
        if (changeLogExists.rowCount) {
            let maxSeq = 0;
            for (;;) {
                const batch = await replayBatchInTransaction(client, s, plan.table, plan.shadowTable, plan.changeLogTable, meta, drainBatchSize);
                drainedEvents += batch.processedEvents;
                if (batch.maxSeq > maxSeq)
                    maxSeq = batch.maxSeq;
                if (batch.processedEvents === 0 || batch.remaining === 0)
                    break;
            }
            if (drainedEvents > 0) {
                await client.query(`UPDATE ${s}.${q(plan.stateTable)}
           SET replay_cursor = GREATEST(replay_cursor, $2::bigint),
               replayed_changes = replayed_changes + $3,
               updated_at = now()
           WHERE table_name = $1`, [plan.table, maxSeq, drainedEvents]);
            }
        }
        // Remove forward change-capture trigger from the outgoing table.
        await client.query(`DROP TRIGGER IF EXISTS ${q(plan.captureTrigger)} ON ${s}.${q(plan.table)}`);
        // Drop OID-bound incoming foreign keys and user triggers before swapping table names.
        for (const fk of meta.incomingForeignKeys) {
            await client.query(`ALTER TABLE ${q(fk.referencingSchema)}.${q(fk.referencingTable)} DROP CONSTRAINT ${q(fk.constraintName)}`);
        }
        for (const trg of meta.userTriggers) {
            await client.query(`DROP TRIGGER ${q(trg.name)} ON ${s}.${q(plan.table)}`);
        }
        // Atomically swap names: authoritative -> legacy, partitioned shadow -> authoritative.
        await client.query(`ALTER TABLE ${s}.${q(plan.table)} RENAME TO ${q(plan.legacyTable)}`);
        await client.query(`ALTER TABLE ${s}.${q(plan.shadowTable)} RENAME TO ${q(plan.table)}`);
        // Rebind incoming foreign keys to the newly active partitioned table (NOT VALID inside lock window).
        for (const fk of meta.incomingForeignKeys) {
            const alreadyNotValid = /\bNOT\s+VALID\s*$/i.test(fk.definition);
            await client.query(`ALTER TABLE ${q(fk.referencingSchema)}.${q(fk.referencingTable)}
         ADD CONSTRAINT ${q(fk.constraintName)} ${fk.definition}${alreadyNotValid ? '' : ' NOT VALID'}`);
            reboundForeignKeys.push(`${fk.referencingTable}.${fk.constraintName}`);
            if (!alreadyNotValid)
                fksToValidate.push(fk);
        }
        // Recreate user triggers (such as bind_machinery_states) on the newly active partitioned table.
        for (const trg of meta.userTriggers) {
            await ensurePartitionAwareTriggerFunction(client, plan.schemaName, plan.table, trg);
            await client.query(trg.definition);
            migratedTriggers.push(trg.name);
        }
        // Install reverse change capture on the new partitioned table so post-cutover writes (incl. deletes)
        // can be synced back into the retained legacy table before any rollback.
        if (installReverse) {
            await installCaptureTriggerOnTable(client, s, plan.table, plan.reverseChangeLogTable, plan.reverseCaptureFunction, plan.reverseCaptureTrigger, meta.primaryKeyColumns);
        }
        await client.query(`UPDATE ${s}.${q(plan.stateTable)} SET state = 'cutover', updated_at = now() WHERE table_name = $1`, [plan.table]);
        await client.query('COMMIT');
    }
    catch (error) {
        await client.query('ROLLBACK').catch(() => { });
        const code = error?.code;
        if (code === '55P03') {
            return {
                status: 'lock_timeout',
                table: plan.table,
                legacyTable: plan.legacyTable,
                drainedEvents: 0,
                reboundForeignKeys: [],
                migratedTriggers: [],
                reverseCaptureInstalled: false,
                errorCode: '55P03',
            };
        }
        throw error;
    }
    finally {
        client.release();
    }
    // Validate rebound foreign keys outside the exclusive cutover lock (SHARE UPDATE EXCLUSIVE only).
    for (const fk of fksToValidate) {
        await db.query(`ALTER TABLE ${q(fk.referencingSchema)}.${q(fk.referencingTable)} VALIDATE CONSTRAINT ${q(fk.constraintName)}`);
    }
    return {
        status: 'cutover',
        table: plan.table,
        legacyTable: plan.legacyTable,
        drainedEvents,
        reboundForeignKeys,
        migratedTriggers,
        reverseCaptureInstalled: installReverse,
    };
}
/**
 * Replays post-cutover writes (INSERT, UPDATE, DELETE, PK moves) from the active partitioned table
 * back into the retained legacy table so rollback preserves every write made after cutover.
 */
export async function syncReverseChanges(db, options) {
    const plan = resolvePartitionPlan(db, options);
    const batchSize = Math.max(1, Math.min(50_000, Math.floor(options.batchSize ?? 500)));
    const s = plan.schemaSql;
    return db.transaction(async (client) => {
        await lockMigrationAdvisory(client, plan);
        const meta = await inspectTable(client, plan.schemaName, plan.table, new Set([plan.captureTrigger, plan.reverseCaptureTrigger]));
        const batch = await replayBatchInTransaction(client, s, plan.table, plan.legacyTable, plan.reverseChangeLogTable, meta, batchSize);
        const updated = await client.query(`UPDATE ${s}.${q(plan.stateTable)}
       SET reverse_replay_cursor = GREATEST(reverse_replay_cursor, $2::bigint),
           updated_at = now()
       WHERE table_name = $1
       RETURNING reverse_replay_cursor::text`, [plan.table, batch.maxSeq]);
        return {
            processedEvents: batch.processedEvents,
            distinctKeys: batch.distinctKeys,
            upserted: batch.upserted,
            deleted: batch.deleted,
            replayCursor: Number(updated.rows[0]?.reverse_replay_cursor ?? batch.maxSeq),
            remaining: batch.remaining,
        };
    });
}
/**
 * Drains reverse changes back into the legacy table under a bounded `lock_timeout` and swaps
 * the legacy table back into place as the authoritative table (docs/scaling.md 09.1 step 6).
 */
export async function rollbackCutover(db, options) {
    const plan = resolvePartitionPlan(db, options);
    const lockTimeoutMs = Math.max(10, Math.min(60_000, Math.floor(options.lockTimeoutMs ?? 1000)));
    const statementTimeoutMs = Math.max(100, Math.min(120_000, Math.floor(options.statementTimeoutMs ?? 15_000)));
    const drainBatchSize = Math.max(1, Math.min(50_000, Math.floor(options.drainBatchSize ?? 1000)));
    const s = plan.schemaSql;
    const client = await db.pool.connect();
    const reboundForeignKeys = [];
    const fksToValidate = [];
    const migratedTriggers = [];
    let drainedReverseEvents = 0;
    try {
        await client.query('BEGIN');
        await client.query(`SET LOCAL lock_timeout = '${lockTimeoutMs}ms'`);
        await client.query(`SET LOCAL statement_timeout = '${statementTimeoutMs}ms'`);
        await lockMigrationAdvisory(client, plan);
        const preMeta = await inspectTable(client, plan.schemaName, plan.table, new Set([plan.captureTrigger, plan.reverseCaptureTrigger]));
        if (preMeta.relkind !== 'p') {
            throw new Error(`Table ${plan.schemaName}.${plan.table} is not currently partitioned`);
        }
        const lockTargets = new Set([`${s}.${q(plan.table)}`, `${s}.${q(plan.legacyTable)}`]);
        for (const fk of preMeta.incomingForeignKeys) {
            lockTargets.add(`${q(fk.referencingSchema)}.${q(fk.referencingTable)}`);
        }
        await client.query(`LOCK TABLE ${[...lockTargets].sort().join(', ')} IN ACCESS EXCLUSIVE MODE`);
        const meta = await inspectTable(client, plan.schemaName, plan.table, new Set([plan.captureTrigger, plan.reverseCaptureTrigger]));
        // Drain any remaining reverse changes into the legacy table before restoring it.
        const revExists = await client.query(`SELECT 1 FROM pg_catalog.pg_class c JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
       WHERE n.nspname = $1 AND c.relname = $2`, [plan.schemaName, plan.reverseChangeLogTable]);
        if (revExists.rowCount) {
            let maxSeq = 0;
            for (;;) {
                const batch = await replayBatchInTransaction(client, s, plan.table, plan.legacyTable, plan.reverseChangeLogTable, meta, drainBatchSize);
                drainedReverseEvents += batch.processedEvents;
                if (batch.maxSeq > maxSeq)
                    maxSeq = batch.maxSeq;
                if (batch.processedEvents === 0 || batch.remaining === 0)
                    break;
            }
            if (maxSeq > 0) {
                await client.query(`UPDATE ${s}.${q(plan.stateTable)} SET reverse_replay_cursor = GREATEST(reverse_replay_cursor, $2::bigint), updated_at = now() WHERE table_name = $1`, [plan.table, maxSeq]);
            }
        }
        await client.query(`DROP TRIGGER IF EXISTS ${q(plan.reverseCaptureTrigger)} ON ${s}.${q(plan.table)}`);
        for (const fk of meta.incomingForeignKeys) {
            await client.query(`ALTER TABLE ${q(fk.referencingSchema)}.${q(fk.referencingTable)} DROP CONSTRAINT ${q(fk.constraintName)}`);
        }
        for (const trg of meta.userTriggers) {
            await client.query(`DROP TRIGGER ${q(trg.name)} ON ${s}.${q(plan.table)}`);
        }
        await client.query(`ALTER TABLE ${s}.${q(plan.table)} RENAME TO ${q(plan.shadowTable)}`);
        await client.query(`ALTER TABLE ${s}.${q(plan.legacyTable)} RENAME TO ${q(plan.table)}`);
        for (const fk of meta.incomingForeignKeys) {
            const alreadyNotValid = /\bNOT\s+VALID\s*$/i.test(fk.definition);
            await client.query(`ALTER TABLE ${q(fk.referencingSchema)}.${q(fk.referencingTable)}
         ADD CONSTRAINT ${q(fk.constraintName)} ${fk.definition}${alreadyNotValid ? '' : ' NOT VALID'}`);
            reboundForeignKeys.push(`${fk.referencingTable}.${fk.constraintName}`);
            if (!alreadyNotValid)
                fksToValidate.push(fk);
        }
        for (const trg of meta.userTriggers) {
            await client.query(trg.definition);
            migratedTriggers.push(trg.name);
        }
        await client.query(`UPDATE ${s}.${q(plan.stateTable)} SET state = 'rolled_back', updated_at = now() WHERE table_name = $1`, [plan.table]);
        await client.query('COMMIT');
    }
    catch (error) {
        await client.query('ROLLBACK').catch(() => { });
        const code = error?.code;
        if (code === '55P03') {
            return {
                status: 'lock_timeout',
                table: plan.table,
                shadowTable: plan.shadowTable,
                drainedReverseEvents: 0,
                reboundForeignKeys: [],
                migratedTriggers: [],
                errorCode: '55P03',
            };
        }
        throw error;
    }
    finally {
        client.release();
    }
    for (const fk of fksToValidate) {
        await db.query(`ALTER TABLE ${q(fk.referencingSchema)}.${q(fk.referencingTable)} VALIDATE CONSTRAINT ${q(fk.constraintName)}`);
    }
    return {
        status: 'rolled_back',
        table: plan.table,
        shadowTable: plan.shadowTable,
        drainedReverseEvents,
        reboundForeignKeys,
        migratedTriggers,
    };
}
