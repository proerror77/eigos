import { ResourceReservations } from './resource-reservations.js';
import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import { Conflict, InvalidInput, NotFound, digest } from '../core/identity.js';
import { Access, PermissionDenied } from './access.js';
import { Metadata } from './metadata.js';
import { isWebhookHandler } from './action-webhooks.js';
import { ActionWriteBudgets, ProviderBudgetExceeded } from './provider-budgets.js';
const TRANSIENT_PG_CODES = new Set([
    '40001', '40P01', '55P03', '57014', '53300', '57P01', '57P02', '57P03',
    '08000', '08001', '08003', '08004', '08006',
]);
const TRANSIENT_NET_CODES = new Set([
    'ECONNRESET', 'ECONNREFUSED', 'ETIMEDOUT', 'EPIPE', 'EAI_AGAIN', 'ENOTFOUND',
    'EHOSTUNREACH', 'ENETUNREACH', 'UND_ERR_CONNECT_TIMEOUT', 'UND_ERR_HEADERS_TIMEOUT',
    'UND_ERR_BODY_TIMEOUT', 'UND_ERR_SOCKET',
]);
const TRANSIENT_HTTP_STATUSES = new Set([408, 429, 500, 502, 503, 504]);
export function isTransientError(error) {
    if (error instanceof Conflict ||
        error instanceof PermissionDenied ||
        error instanceof NotFound ||
        error instanceof InvalidInput ||
        error instanceof z.ZodError)
        return false;
    const candidates = [error, error?.cause];
    for (const candidate of candidates) {
        if (!candidate || typeof candidate !== 'object')
            continue;
        const record = candidate;
        if (record.retryable === true)
            return true;
        if (typeof record.code === 'string' && (TRANSIENT_PG_CODES.has(record.code) || TRANSIENT_NET_CODES.has(record.code)))
            return true;
        const status = typeof record.status === 'number' ? record.status : typeof record.statusCode === 'number' ? record.statusCode : undefined;
        if (status !== undefined && TRANSIENT_HTTP_STATUSES.has(status))
            return true;
        if (record.name === 'TimeoutError')
            return true;
    }
    return false;
}
export function sanitizeErrorMessage(error) {
    const raw = error instanceof Error ? error.message : typeof error === 'string' ? error : 'Unknown error';
    return raw
        .replace(/\bBearer\s+[A-Za-z0-9._~+/=-]+/gi, 'Bearer [REDACTED]')
        .replace(/\b(postgres(?:ql)?|https?):\/\/[^\s'"]+@[^\s'"]+/gi, '$1://[REDACTED]')
        .replace(/\b(password|passwd|secret|token|api[_-]?key|authorization)\s*[:=]\s*[^\s,;'"&]+/gi, '$1=[REDACTED]')
        .replace(/[\r\n\t]+/g, ' ')
        .slice(0, 240);
}
export function errorDiagnostic(error) {
    const name = error instanceof Error ? error.name : 'Error';
    const rawCode = error?.code ?? (error?.cause?.code);
    const code = typeof rawCode === 'string' && /^[A-Za-z0-9_:-]{1,48}$/.test(rawCode) ? rawCode : undefined;
    const summary = code ? `${name}:${code}` : name;
    return { name, code, summary, message: sanitizeErrorMessage(error) };
}
export function retryBackoffSeconds(attempts) {
    return Math.min(300, 2 * (2 ** Math.max(0, attempts - 1)));
}
export async function initializeEffects(db) {
    await db.query(`CREATE TABLE IF NOT EXISTS ${db.schema}.action_effects (
    id text PRIMARY KEY, owner text NOT NULL, request_id text NOT NULL, release text NOT NULL REFERENCES ${db.schema}.releases(digest),
    ontology text NOT NULL, action text NOT NULL, name text NOT NULL, handler text NOT NULL, payload jsonb NOT NULL,
    requirements jsonb NOT NULL, scopes jsonb NOT NULL, state text NOT NULL DEFAULT 'pending', attempts integer NOT NULL DEFAULT 0,
    token uuid, lease_until timestamptz, available_at timestamptz NOT NULL DEFAULT now(), error text,
    created_at timestamptz NOT NULL DEFAULT now(), completed_at timestamptz,
    UNIQUE(owner,request_id,name));
    ALTER TABLE ${db.schema}.action_effects ADD COLUMN IF NOT EXISTS confirms_reservation boolean NOT NULL DEFAULT false;
    ALTER TABLE ${db.schema}.action_effects ADD COLUMN IF NOT EXISTS max_attempts integer NOT NULL DEFAULT 3;
    ALTER TABLE ${db.schema}.action_effects ADD COLUMN IF NOT EXISTS last_claimed_at timestamptz;
    CREATE INDEX IF NOT EXISTS action_effects_queue ON ${db.schema}.action_effects(state,available_at);
    CREATE INDEX IF NOT EXISTS action_effects_owner_fairness ON ${db.schema}.action_effects(owner,last_claimed_at DESC) WHERE last_claimed_at IS NOT NULL;
    DO $$ BEGIN
      IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conrelid='${db.schema}.action_effects'::regclass
        AND conname='action_effects_committed_action_fkey') THEN
        ALTER TABLE ${db.schema}.action_effects ADD CONSTRAINT action_effects_committed_action_fkey
          FOREIGN KEY(owner,request_id) REFERENCES ${db.schema}.actions(owner,request_id) NOT VALID;
      END IF;
    END $$;`);
}
export class Effects {
    db;
    handlers;
    webhooks;
    writeBudgets;
    metadata;
    constructor(db, handlers, webhooks) {
        this.db = db;
        this.handlers = handlers;
        this.webhooks = webhooks;
        if ([...handlers.keys()].some(isWebhookHandler))
            throw new Error('The Source webhook handler name is reserved');
        this.metadata = new Metadata(db);
        this.writeBudgets = new ActionWriteBudgets(db);
    }
    check(names) {
        for (const name of names)
            if (!(isWebhookHandler(name) ? this.webhooks : this.handlers.has(name)))
                throw new Error(`Action effect handler is unavailable: ${name}`);
    }
    async enqueue(client, access, model, action, requestId, effects) {
        if (model.scenario || !effects.length)
            return;
        this.check(effects.map(effect => effect.handler));
        const prepared = effects.map(effect => ({
            ...effect,
            payload: isWebhookHandler(effect.handler) ? this.webhooks.prepare(model, action, effect.name, effect.payload, access) : effect.payload,
        }));
        const requirements = await access.finalRequirements(client);
        for (const effect of prepared) {
            const id = digest([access.principal.owner, requestId, effect.name]);
            await this.db.query(`INSERT INTO ${this.db.schema}.action_effects(id,owner,request_id,release,ontology,action,name,handler,payload,requirements,scopes,confirms_reservation)
        VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`, [id, access.principal.owner, requestId, model.release, model.document.id, action, effect.name, effect.handler, effect.payload, JSON.stringify(requirements),
                JSON.stringify(access.principal.memberAccess ? { scopes: access.principal.scopes, memberAccess: true } : access.principal.scopes), model.action(action).reservation?.confirmationEffect === effect.name], client);
        }
        await this.db.query("SELECT pg_notify('eigos_automation','effect')", [], client);
    }
    async status(access, requestId) {
        z.string().min(1).max(128).parse(requestId);
        const rows = (await this.db.query(`SELECT id,ontology,action,name,handler,state,attempts,error,created_at,completed_at FROM ${this.db.schema}.action_effects WHERE owner=$1 AND request_id=$2 ORDER BY name`, [access.principal.owner, requestId])).rows;
        for (const row of rows)
            access.require(row.ontology, 'apply_action', `${row.ontology}/action/${row.action}`);
        await access.refresh();
        return rows;
    }
    async retry(access, id) {
        z.string().regex(/^[a-f0-9]{64}$/).parse(id);
        return this.db.transaction(async (client) => {
            const row = (await this.db.query(`SELECT * FROM ${this.db.schema}.action_effects WHERE id=$1 AND owner=$2 FOR UPDATE`, [id, access.principal.owner], client)).rows[0];
            if (!row || row.state !== 'failed')
                throw new Conflict('Only a failed owned effect can be retried');
            access.require(row.ontology, 'apply_action', `${row.ontology}/action/${row.action}`);
            if (!await access.canReturn(row.requirements, client))
                throw new Error('Effect data permissions changed');
            for (const requirement of row.requirements)
                access.require(requirement.ontology, requirement.permission, requirement.resource);
            await access.refresh(client);
            await this.db.query(`UPDATE ${this.db.schema}.action_effects SET state='pending',attempts=0,available_at=now(),error=NULL WHERE id=$1`, [id], client);
            await this.db.query("SELECT pg_notify('eigos_automation','effect')", [], client);
            return { id, state: 'pending' };
        });
    }
    async runOne(signal = AbortSignal.timeout(30000)) {
        signal.throwIfAborted();
        const token = randomUUID();
        const claim = await this.db.transaction(async (client) => {
            const deadLettered = await this.db.query(`WITH dead AS (
          SELECT id,owner FROM ${this.db.schema}.action_effects
          WHERE state='working' AND lease_until<now() AND attempts>=max_attempts
          FOR UPDATE SKIP LOCKED LIMIT 100
        )
        UPDATE ${this.db.schema}.action_effects e
        SET state='failed',
            error='Effect delivery exceeded max attempts after lease expiration (dead-lettered)',
            token=NULL,lease_until=NULL
        FROM dead WHERE e.id=dead.id AND e.owner=dead.owner
        RETURNING e.id,e.owner,e.ontology,e.action,e.handler`, [], client);
            for (const dead of deadLettered.rows) {
                console.error(JSON.stringify({
                    event: 'effect_dead_letter', effectId: dead.id, owner: dead.owner, ontology: dead.ontology,
                    action: dead.action, handler: dead.handler, reason: 'max_attempts_exceeded_after_lease_expiration',
                }));
            }
            const selected = (await this.db.query(`SELECT e.id,e.owner FROM ${this.db.schema}.action_effects e
        WHERE (e.state='pending' AND e.available_at<=now()) OR (e.state='working' AND e.lease_until<now() AND e.attempts<e.max_attempts)
        ORDER BY
          (SELECT count(*) FROM ${this.db.schema}.action_effects active WHERE active.owner=e.owner AND active.state='working' AND active.lease_until>=now()),
          COALESCE((SELECT max(recent.last_claimed_at) FROM ${this.db.schema}.action_effects recent WHERE recent.owner=e.owner), '-infinity'::timestamptz),
          e.available_at,e.id
        FOR UPDATE OF e SKIP LOCKED LIMIT 1`, [], client)).rows[0];
            if (!selected)
                return undefined;
            const updated = (await this.db.query(`UPDATE ${this.db.schema}.action_effects SET state='working',token=$3,lease_until=now()+interval '60 seconds',attempts=attempts+1,last_claimed_at=clock_timestamp()
        WHERE id=$1 AND owner=$2 RETURNING id,owner,ontology,action,handler,attempts,max_attempts`, [selected.id, selected.owner, token], client)).rows[0];
            return updated;
        });
        if (!claim)
            return false;
        const lease = [claim.id, claim.owner, token];
        const controller = new AbortController();
        const executionSignal = AbortSignal.any([signal, controller.signal, AbortSignal.timeout(45000)]);
        let renew;
        const timer = setInterval(() => {
            if (renew)
                return;
            renew = this.db.query(`UPDATE ${this.db.schema}.action_effects SET lease_until=now()+interval '60 seconds'
        WHERE id=$1 AND owner=$2 AND token=$3 AND state='working' RETURNING id`, lease)
                .then(result => { if (!result.rowCount)
                controller.abort(); }).catch(() => controller.abort()).finally(() => { renew = undefined; });
        }, 15000);
        timer.unref();
        try {
            await this.db.withOwner(claim.owner, async () => {
                const row = (await this.db.query(`SELECT effect.scopes,effect.requirements,effect.handler,effect.payload,effect.name,effect.action,effect.release,effect.ontology,effect.request_id,effect.confirms_reservation
          FROM ${this.db.schema}.action_effects effect
          JOIN ${this.db.schema}.actions committed
            ON committed.owner=effect.owner AND committed.request_id=effect.request_id
            AND committed.action=effect.action AND committed.release=effect.release
          WHERE effect.id=$1 AND effect.owner=$2 AND effect.token=$3 AND effect.state='working' AND effect.lease_until>now()`, lease)).rows[0];
                if (!row)
                    throw new Conflict('Effect lease is unavailable');
                const identity = z.object({ scopes: z.array(z.string()), memberAccess: z.literal(true).optional() })
                    .parse(Array.isArray(row.scopes) ? { scopes: row.scopes } : row.scopes);
                const principal = { owner: claim.owner, ...identity };
                const access = await Access.load(this.db, principal);
                if (!await access.canReturn(row.requirements))
                    throw new Error('Effect data permissions changed');
                for (const requirement of row.requirements)
                    access.require(requirement.ontology, requirement.permission, requirement.resource);
                this.check([row.handler]);
                executionSignal.throwIfAborted();
                try {
                    await this.writeBudgets.take(claim.owner, undefined, `${row.ontology}/${row.action}`);
                }
                catch (error) {
                    if (!(error instanceof ProviderBudgetExceeded))
                        throw error;
                    await this.db.query(`UPDATE ${this.db.schema}.action_effects SET state='pending',lease_until=NULL,token=NULL,
            available_at=$4,attempts=attempts-1 WHERE id=$1 AND owner=$2 AND token=$3`, [...lease, error.until]);
                    return;
                }
                executionSignal.throwIfAborted();
                let outcome;
                if (isWebhookHandler(row.handler)) {
                    const model = await this.metadata.get(row.release);
                    const authorize = async () => {
                        const current = await this.db.query(`SELECT 1 FROM ${this.db.schema}.action_effects
              WHERE id=$1 AND owner=$2 AND token=$3 AND state='working' AND lease_until>clock_timestamp()`, lease);
                        if (!current.rowCount || !await access.canReturn(row.requirements))
                            throw new Conflict('Action webhook authority changed');
                    };
                    const persistBody = async (body) => {
                        const changed = await this.db.query(`UPDATE ${this.db.schema}.action_effects SET payload=jsonb_set(payload,'{body}',to_jsonb($4::text))
              WHERE id=$1 AND owner=$2 AND token=$3 AND state='working' AND lease_until>clock_timestamp()`, [...lease, body]);
                        if (!changed.rowCount)
                            throw new Conflict('Action effect lease is unavailable');
                    };
                    outcome = await this.webhooks.deliver(model, row.action, row.name, row.payload, access, claim.id, executionSignal, authorize, persistBody);
                }
                else {
                    outcome = await this.handlers.get(row.handler)(row.payload, { idempotencyKey: claim.id, principal, signal: executionSignal });
                }
                executionSignal.throwIfAborted();
                const completed = outcome !== 'canceled';
                const mark = (client) => this.db.query(`UPDATE ${this.db.schema}.action_effects SET state=$4,completed_at=now(),lease_until=NULL,token=NULL,error=NULL
          WHERE id=$1 AND owner=$2 AND token=$3`, [...lease, completed ? 'completed' : 'canceled'], client);
                if (row.confirms_reservation) {
                    await this.db.transaction(async (client) => {
                        if ((await mark(client)).rowCount)
                            await new ResourceReservations(this.db)
                                .finishEffect(claim.owner, row.ontology, row.action, row.request_id, row.name, completed, client);
                    });
                }
                else
                    await mark(this.db.pool);
            });
        }
        catch (error) {
            // A handler can have completed remotely before a local failure. Retries always retain its idempotency key.
            const diag = errorDiagnostic(error);
            const transient = !signal.aborted && isTransientError(error);
            const willRetry = transient && Number(claim.attempts) < Number(claim.max_attempts);
            console.error(JSON.stringify({
                event: 'effect_delivery_error', effectId: claim.id, attemptId: token, owner: claim.owner,
                ontology: claim.ontology, action: claim.action, handler: claim.handler,
                attempts: Number(claim.attempts), maxAttempts: Number(claim.max_attempts),
                transient, willRetry, errorName: diag.name, errorCode: diag.code, message: diag.message,
            }));
            const storedError = `Effect delivery failed; inspect the configured handler before retrying [${diag.summary}]`;
            if (willRetry) {
                const backoffSeconds = retryBackoffSeconds(Number(claim.attempts));
                await this.db.query(`UPDATE ${this.db.schema}.action_effects SET state='pending',available_at=now()+$4::int*interval '1 second',lease_until=NULL,token=NULL,error=$5
          WHERE id=$1 AND owner=$2 AND token=$3`, [...lease, backoffSeconds, storedError]);
            }
            else {
                await this.db.query(`UPDATE ${this.db.schema}.action_effects SET state='failed',lease_until=NULL,token=NULL,error=$4
          WHERE id=$1 AND owner=$2 AND token=$3`, [...lease, storedError]);
            }
        }
        finally {
            clearInterval(timer);
            await renew;
        }
        return true;
    }
}
