import { AsyncLocalStorage } from 'node:async_hooks';
import { z } from 'zod';
import { type Principal } from '../core/identity.js';
import type { Sql } from './database.js';
import { Database } from './database.js';
import { Metadata, type PublishedOntology } from './metadata.js';
import { type Requirement } from './access.js';
import type { ScheduledCall } from './scheduled-actions.js';
import type { CognitiveContext } from './cognitive-workflow.js';
import { type ActionContinuation } from './clarification.js';
export { placeAmendmentSchema, placeSelectionSchema, taskInputAnswerSchema, taskPlaceAmendmentSchema } from './clarification.js';
import { storedInputSchema, taskActionSchema } from './task-input.js';
export { routeInputSchema, submitSchema, type RouteInput } from './task-input.js';
export interface Task {
    id: string;
    owner: string;
    request_id: string;
    input: z.infer<typeof storedInputSchema> & {
        scheduledAction?: ScheduledCall;
    };
    release: string;
    scopes: string[];
    state: string;
    token: string | null;
    result: unknown;
    result_permissions?: Requirement[] | null;
    error: string | null;
    created_at: Date;
    available_at?: Date;
    updated_at: Date;
    execution_step?: number;
    conversation_id?: string | null;
    cognitive_context?: CognitiveContext | null;
}
export declare const taskPrincipal: (task: Task) => Principal;
export declare const currentTaskExecution: AsyncLocalStorage<{
    task: Task;
    tasks: Tasks;
}>;
export type TaskResultProjection = (result: unknown) => unknown;
export declare const publicTask: (task: Task, project: TaskResultProjection) => {
    id: string;
    conversationId?: string | undefined;
    state: string;
    result: unknown;
    error: string | null;
    createdAt: Date;
    updatedAt: Date;
    inputRequest?: {
        requestId: string;
        purpose: "authorization" | "execution-result" | "input" | "observation";
        responseSchema?: z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
            kind: z.ZodLiteral<"city">;
            city: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            kind: z.ZodLiteral<"origin">;
            place: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            kind: z.ZodLiteral<"destination">;
            place: z.ZodString;
        }, z.core.$strict> | z.ZodObject<{
            kind: z.ZodLiteral<"retry-source">;
        }, z.core.$strict> | z.ZodUnion<readonly [z.ZodObject<{
            kind: z.ZodLiteral<"select">;
            places: z.ZodObject<{
                origin: z.ZodObject<{
                    type: z.ZodString;
                    id: z.ZodString;
                }, z.core.$strict>;
                destination: z.ZodObject<{
                    type: z.ZodString;
                    id: z.ZodString;
                }, z.core.$strict>;
            }, z.core.$strict>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"amend">;
            amendment: z.ZodObject<{
                address: z.ZodOptional<z.ZodString>;
                landmark: z.ZodOptional<z.ZodString>;
                name: z.ZodOptional<z.ZodString>;
                side: z.ZodEnum<{
                    destination: "destination";
                    origin: "origin";
                }>;
                keep: z.ZodOptional<z.ZodObject<{
                    type: z.ZodString;
                    id: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
        }, z.core.$strict>]>> | undefined;
    } | undefined;
};
export declare class Tasks {
    readonly db: Database;
    private readonly metadata;
    private readonly ownerSlots;
    private readonly deadLetterReapIntervalMs;
    private lastDeadLetterReapAt;
    private backgroundReapers;
    private activeReap?;
    /**
     * `ownerSlots` is how many interactive tasks of one owner may run at once across all Workers (runtime budget 06.1), from
     * EIGOS_TASK_OWNER_SLOTS, 2 by default.
     */
    constructor(db: Database, metadata: Metadata, ownerSlots?: number, deadLetterReapIntervalMs?: number);
    /** Marks an active background dead-letter reaper (e.g. Worker.run()) so claim() skips fallback reaping. */
    registerBackgroundReaper(): () => void;
    /** Transitions expired working tasks that exhausted max_attempts into failed (dead-lettered). */
    reapDeadLetters(lane?: 'scheduled' | 'interactive'): Promise<number>;
    submit(principal: Principal, raw: unknown, { assignConversation, authorize, actionInvocation, expectedRelease, ontologyId, admit, transaction }?: {
        assignConversation?: boolean;
        authorize?: (client: Sql) => Promise<void>;
        actionInvocation?: z.infer<typeof taskActionSchema>;
        transaction?: Sql;
        expectedRelease?: string;
        ontologyId?: string;
        admit?: (client: Sql, model: PublishedOntology) => Promise<void>;
    }): Promise<Task>;
    private lockInboxKey;
    visible(principal: Principal, task: Task): Promise<Task>;
    get(principal: Principal, id: string): Promise<Task>;
    cancel(principal: Principal, id: string): Promise<Task>;
    selectPlaces(principal: Principal, id: string, input: unknown): Promise<Task>;
    amendPlace(principal: Principal, id: string, input: unknown): Promise<Task>;
    answerInput(principal: Principal, id: string, input: unknown): Promise<Task>;
    resumeInput(principal: Principal, task: Task, response: unknown, client: Sql): Promise<Task>;
    private continueTaskInput;
    claim(lane?: 'scheduled' | 'interactive'): Promise<Task | undefined>;
    private claimOnce;
    nextInboxDelay(): Promise<number>;
    current(task: Task, client?: Sql, lock?: boolean): Promise<void>;
    renew(task: Task): Promise<void>;
    defer(task: Task, until: string): Promise<void>;
    /**
     * Puts a task back in the queue until `until`, as when its owner's budget for a provider is used up. It then runs again
     * from the start, as a task whose lease expired does; its Actions are idempotent by request.
     */
    postpone(task: Task, until: string): Promise<void>;
    finish(task: Task, state: 'completed' | 'failed' | 'input-required', result: unknown, error?: string, permissions?: Requirement[], pending?: ActionContinuation): Promise<void>;
    readSource<T>(task: Task, name: string, input: unknown, invoke: () => Promise<T>): Promise<T>;
}
