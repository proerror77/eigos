import { type TaskResultProjection } from './tasks.js';
import type { Actions } from './actions.js';
import { z } from 'zod';
import type { Principal } from '../core/identity.js';
import { Access } from './access.js';
import { Database } from './database.js';
import { Metadata } from './metadata.js';
import { type ScenarioDecisionSupport } from './scenarios.js';
import { Effects } from './effects.js';
import type { Functions } from './functions.js';
import type { Bindings } from './metadata.js';
export type ServiceRegistration = <S extends z.ZodType>(name: string, description: string, schema: S, write: boolean, run: (access: Access, input: z.output<S>) => Promise<unknown>) => void;
export type RegisterServices = (register: ServiceRegistration, db: Database, metadata: Metadata, actions: Actions) => void;
declare function buildMcpServiceSchema(schema: z.ZodType): z.ZodObject<{
    [x: string]: any;
    _ontology: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export type McpServiceInputSchema = ReturnType<typeof buildMcpServiceSchema>;
export type OntologyService = {
    schema: z.ZodType;
    mcpInputSchema: McpServiceInputSchema;
    description: string;
    invoke: (principal: Principal, input: unknown) => Promise<unknown>;
    invokeForMcpOperator?: (principal: Principal, input: unknown) => Promise<unknown>;
};
export type OntologyServiceMap = Map<string, OntologyService>;
export declare const DEFAULT_ONTOLOGY_SERVICE_CACHE_SIZE = 32;
/** Bounded LRU cache for non-default Ontology service maps; the default ontology stays pinned. */
export declare class OntologyServiceCache {
    readonly defaultOntologyId: string;
    private readonly build;
    readonly defaultServices: OntologyServiceMap;
    readonly maxEntries: number;
    private readonly entries;
    private hitCount;
    private missCount;
    constructor(defaultOntologyId: string, build: (ontologyId: string) => OntologyServiceMap, maxEntries?: number);
    get(ontologyId?: string): OntologyServiceMap;
    get size(): number;
    stats(): {
        hits: number;
        misses: number;
        size: number;
        maxEntries: number;
    };
}
export declare function ontologyServices(db: Database, metadata: Metadata, bindings: Bindings & {
    registerServices?: RegisterServices;
    projectTaskResult: TaskResultProjection;
    scenarioDecisions?: ScenarioDecisionSupport<Record<string, unknown>, unknown>;
}, functions: Functions, effects: Effects, actions: Actions, ontologyId?: string): OntologyServiceMap;
export {};
