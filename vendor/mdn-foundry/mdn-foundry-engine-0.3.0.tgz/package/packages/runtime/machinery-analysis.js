import { z } from 'zod';
import { Conflict, PermissionDenied, digest } from '../core/identity.js';
import { processLogTarget, validateMachineryModel } from '../ontology/process-definition.js';
import { machineryEdgeSchema, machineryModelSchema, objectRefSchema, ontologyName } from '../ontology/schema.js';
import { ObjectSets } from './object-sets.js';
import { Objects } from './objects.js';
import { processLogTables } from './process-logs.js';
const state = z.string().min(1).max(200);
const milliseconds = z.number().int().min(0).max(Number.MAX_SAFE_INTEGER);
export const machineryAnalysisSchema = z.strictObject({
    type: ontologyName,
    from: z.iso.datetime({ offset: true }),
    to: z.iso.datetime({ offset: true }),
    object: objectRefSchema.optional(),
    setId: z.uuid().optional(),
    externalSource: ontologyName.optional(),
    eventLimit: z.number().int().min(1).max(100000).default(20000),
    focus: z.strictObject({ parent: objectRefSchema, type: ontologyName, link: ontologyName }).optional(),
    reference: machineryModelSchema.optional(),
    candidate: machineryModelSchema.optional(),
    includeIdle: z.boolean().default(true),
    durationClock: z.enum(['recordedAt', 'observedAt']).default('recordedAt'),
    mining: z.strictObject({
        minCases: z.number().int().positive().max(20000).default(1),
        coveragePercent: z.number().int().min(1).max(100).default(100),
        exclude: z.array(machineryEdgeSchema).max(500).default([]),
    }).optional(),
    // One of Palantir's four views: ever or current counts, and historical or current durations, per node and edge.
    view: z.strictObject({ kind: z.enum(['count', 'duration']), scope: z.enum(['historical', 'current']) }).optional(),
    filter: z.strictObject({
        state: state.optional(),
        current: z.boolean().default(false),
        edge: machineryEdgeSchema.optional(),
        // Processes currently in one of these states with `current`, otherwise ever in one of them.
        states: z.array(state).min(1).max(200).optional(),
        // Processes that ever went through one of these transitions, or whose last transition is one of them.
        edges: z.array(machineryEdgeSchema).min(1).max(500).optional(),
        edgeMode: z.enum(['through', 'last']).default('through'),
        path: z.string().regex(/^[0-9a-f]{64}$/).optional(),
        conformance: z.enum(['conforming', 'deviation', 'unknown']).optional(),
        duration: z.strictObject({ state, minMs: milliseconds.default(0), maxExclusiveMs: milliseconds.optional() }).optional(),
    }).optional(),
    offset: z.number().int().min(0).max(100000).default(0),
    limit: z.number().int().min(1).max(100).default(25),
});
const edgeKey = (from, to) => JSON.stringify([from, to]);
const maxWindowMs = 366 * 86400000;
function targetFor(model, type) {
    const target = processLogTarget(model, type);
    if (!target)
        throw new Conflict('Select a published concrete ProcessLog type');
    return target;
}
function linkVisible(access, model, target, link) {
    const nav = model.navigation(target.objectType, link);
    return access.canDefine(model, 'link', nav.link)
        && access.canSeeModelData(model.links.get(nav.link)?.classification)
        && access.canRead(model, nav.target);
}
function readableModel(access, model, target, reference) {
    if (!reference)
        return null;
    return {
        states: reference.states,
        transitions: reference.transitions.map(({ action, ...edge }) => ({
            ...edge,
            ...(action && access.canDefine(model, 'action', action) && access.canSeeModelData(model.actions.get(action)?.classification) ? { action } : {}),
        })),
        subprocesses: (reference.subprocesses ?? []).filter(child => access.canRead(model, child.process) && linkVisible(access, model, target, child.link)),
    };
}
export function listMachineryProcesses(access, model) {
    access.require(model.document.id, 'view_definition', model.document.id);
    return { release: model.release, items: [...model.objects.values()].flatMap(definition => {
            const target = processLogTarget(model, definition.apiName);
            if (!target || !access.canRead(model, target.type) || !access.canRead(model, target.objectType)
                || !access.canSeeModelData(definition.classification)
                || !access.canSeeModelData(model.object(target.objectType).classification)
                || !access.property(model, target.objectType, target.property)
                || !access.canSeeModelData(model.object(target.objectType).properties[target.property]?.classification))
                return [];
            access.read(model, target.type);
            access.read(model, target.objectType);
            return [{ type: target.type, objectType: target.objectType, property: target.property,
                    name: model.object(target.objectType).displayName, states: model.object(target.objectType).properties[target.property].schema.enum,
                    reference: readableModel(access, model, target, definition.machinery) }];
        }) };
}
async function readEvents(db, client, access, model, target, input, ids) {
    const values = [input.from, input.to, ids ?? null, input.includeIdle];
    const base = { prefix: '', objects: db.schema + '.objects', links: db.schema + '.links' };
    const view = processLogTables(db, model, access.principal.owner, values, base, [target.type], {
        before: '$2', ids: '$3',
    });
    const row = access.rowSql(model, target.type, values, 'o.properties');
    const cell = (field) => access.cellSql(model, target.type, field, values, 'o.properties');
    const required = ['id', 'processId', 'oldState', 'newState', 'sequence', 'recordedAt'].map(cell).join(' AND ');
    const optional = (field) => `CASE WHEN ${cell(field)} THEN o.properties->>'${field}' END AS "${field}"`;
    const result = await db.query(`${view.prefix.trimEnd()}, window_events AS (
      SELECT * FROM process_log_rows WHERE recorded_at >= $1::timestamptz
    ), baseline AS (
      SELECT DISTINCT ON (process_id) * FROM process_log_rows
        WHERE recorded_at < $1::timestamptz
        AND ($4::boolean OR EXISTS (SELECT 1 FROM window_events w WHERE w.process_id=process_log_rows.process_id))
      ORDER BY process_id, sequence DESC
    ), history AS (
      SELECT *, false AS prior FROM window_events UNION ALL SELECT *, true FROM baseline
    ), checked AS MATERIALIZED (
      SELECT o.*, (${row} AND ${required}) AS readable,
        ${optional('timestamp')}, ${optional('action')}, ${optional('source')},
        ${access.principal.scopes.includes('tasks:read') ? optional('taskId') : 'NULL AS "taskId"'},
        ${optional('requestId')}
      FROM history o
    ), complete AS (
      SELECT process_id FROM checked GROUP BY process_id HAVING bool_and(COALESCE(readable, false))
    )
    SELECT o.process_id AS "caseId",o.id,o.properties->>'oldState' AS "from",o.properties->>'newState' AS "to",
      o.properties->>'recordedAt' AS "recordedAt",o.timestamp,o.action,o.source,o."taskId",o."requestId",o.prior
    FROM checked o JOIN complete USING (process_id)
    ORDER BY o.process_id,o.sequence LIMIT ${input.eventLimit + 1}`, values, client);
    if (result.rows.length > input.eventLimit)
        throw new Conflict('Process analysis exceeds the event limit. Narrow the date range or focus on a process object.');
    return result.rows;
}
async function readExternalEvents(db, client, access, model, target, input, ids) {
    const owner = access.principal.owner;
    access.source(model, input.externalSource);
    const values = [model.document.id, owner, target.type, input.externalSource, target.objectType, target.property,
        model.projection, input.from, input.to, ids ?? null, input.includeIdle];
    const visible = (column) => access.rowSql(model, target.objectType, values, column) + ' AND ' + access.cellSql(model, target.objectType, target.property, values, column);
    const current = visible('o.properties');
    const before = visible("jsonb_set(o.properties, ARRAY[h.property], COALESCE(to_jsonb(h.previous_state),'null'::jsonb))");
    const after = visible("jsonb_set(o.properties, ARRAY[h.property], COALESCE(to_jsonb(h.next_state),'null'::jsonb))");
    const fields = ['id', 'processId', 'oldState', 'newState', 'sequence', 'recordedAt', 'source', 'timestamp'];
    // Imported rows have their own source grants and object snapshot checks. No synthetic ProcessLog
    // row receives contextual access rules written for committed history.
    if (access.hasObjectPolicy(model, target.type) || fields.some(field => !access.property(model, target.type, field) || !access.canSeeModelData(model.object(target.type).properties[field]?.classification)))
        throw new Conflict('External process history requires readable log fields without a log-specific row policy');
    const checked = await db.query(`WITH events AS (
     SELECT h.*,h.observed_at<$8::timestamptz AS prior,(${before}) AND (${after}) AS visible
     FROM ${db.schema}.machinery_history h
     JOIN ${db.schema}.objects o ON o.projection=$7 AND o.owner=h.owner AND o.type=h.object_type AND o.id=h.object_id
     WHERE h.ontology=$1 AND h.owner=$2 AND h.type=$3 AND h.source=$4 AND h.object_type=$5 AND h.property=$6
       AND h.observed_at<$9::timestamptz AND ($10::text[] IS NULL OR h.object_id=ANY($10)) AND (${current})
   ), history AS (
     SELECT * FROM events WHERE NOT prior
     UNION ALL (SELECT DISTINCT ON(object_id) * FROM events e WHERE prior
       AND ($11::boolean OR EXISTS(SELECT 1 FROM events observed WHERE observed.object_id=e.object_id AND NOT observed.prior))
       ORDER BY object_id,observed_at DESC)
   ), complete AS (SELECT object_id FROM history GROUP BY object_id HAVING bool_and(COALESCE(visible,false)))
   SELECT h.object_id AS "caseId",h.id,h.previous_state AS "from",h.next_state AS "to",
     h.observed_at::text AS "recordedAt",h.observed_at::text AS timestamp,NULL AS action,h.source,NULL AS "taskId",NULL AS "requestId",h.prior
   FROM history h JOIN complete USING(object_id) ORDER BY h.object_id,h.observed_at LIMIT ${input.eventLimit + 1}`, values, client);
    if (checked.rows.length > input.eventLimit)
        throw new Conflict('Narrow the external history window before analyzing');
    return checked.rows;
}
function trace(target, history, from, to, reference, clock) {
    const allowed = new Set(reference?.transitions.map(edge => edgeKey(edge.from, edge.to)));
    const [first] = history;
    const episodes = [], states = [];
    let partial = Boolean(first.prior || first.from !== null);
    let incomplete = !first.prior && first.from !== null;
    let current = null, openAt = null;
    const completedDuration = (end) => end !== null && openAt !== null && end >= openAt ? end - openAt : null;
    let deviates = false;
    for (const event of history) {
        const clockValue = clock === 'observedAt' ? event.timestamp : event.recordedAt;
        const timestamp = clockValue === null ? null : Date.parse(clockValue);
        if (!event.prior && reference && !allowed.has(edgeKey(event.from, event.to)))
            deviates = true;
        if (!event.prior && current !== event.from) {
            // Historical imports or renamed state contracts can leave an unknown interval.
            partial = true;
            incomplete = true;
            if (event.from !== null) {
                if (states.at(-1) !== event.from)
                    states.push(event.from);
                episodes.push({ state: event.from, durationMs: null, open: false, clipped: true });
            }
        }
        else if (current !== null) {
            episodes.push({ state: current, durationMs: completedDuration(timestamp),
                open: false, clipped: openAt !== null && openAt < from });
        }
        current = event.to;
        openAt = timestamp;
        if (current !== null)
            states.push(current);
    }
    if (current !== null)
        episodes.push({
            state: current, durationMs: completedDuration(to), open: true, clipped: openAt !== null && openAt < from,
        });
    const events = history.filter(event => !event.prior);
    const conformance = deviates ? 'deviation' : !reference || incomplete || !events.length ? 'unknown' : 'conforming';
    return { object: { type: target.objectType, id: first.caseId }, states, path: digest([partial, states]),
        partial, current, conformance, episodes, events };
}
function matches(item, filter) {
    if (!filter)
        return true;
    if (filter.state && (filter.current ? item.current !== filter.state : !item.states.includes(filter.state)))
        return false;
    if (filter.edge && !item.events.some(event => event.from === filter.edge.from && event.to === filter.edge.to))
        return false;
    if (filter.states && !(filter.current ? item.current !== null && filter.states.includes(item.current)
        : item.states.some(name => filter.states.includes(name))))
        return false;
    if (filter.edges) {
        const selected = new Set(filter.edges.map(edge => edgeKey(edge.from, edge.to))), last = item.events.at(-1);
        if (filter.edgeMode === 'last' ? !last || !selected.has(edgeKey(last.from, last.to))
            : !item.events.some(event => selected.has(edgeKey(event.from, event.to))))
            return false;
    }
    if (filter.path && item.path !== filter.path)
        return false;
    if (filter.conformance && item.conformance !== filter.conformance)
        return false;
    const duration = filter.duration;
    return !duration || item.episodes.some(episode => episode.state === duration.state && episode.durationMs !== null
        && episode.durationMs >= duration.minMs && episode.durationMs < (duration.maxExclusiveMs ?? Infinity));
}
function distribution(values) {
    values.sort((a, b) => a - b);
    const p = (rank) => values[Math.ceil(values.length * rank) - 1] ?? null;
    const ranges = [60000, 300000, 1800000, 3600000, 86400000];
    const buckets = Array(ranges.length + 1).fill(0);
    for (const value of values) {
        const range = ranges.findIndex(upper => value < upper);
        const index = range < 0 ? ranges.length : range;
        buckets[index] = buckets[index] + 1;
    }
    return { count: values.length, totalMs: values.reduce((sum, value) => sum + value, 0),
        p50Ms: p(.5), p95Ms: p(.95), maxMs: values.at(-1) ?? null,
        distribution: buckets.map((count, index) => ({ fromMs: ranges[index - 1] ?? 0, toMs: ranges[index] ?? null, count })) };
}
function summarize(cases, reference) {
    const states = new Map();
    const transitions = new Map();
    const paths = new Map();
    const stateFor = (name) => {
        const existing = states.get(name);
        if (existing)
            return existing;
        const definition = reference?.states.find(state => state.name === name);
        const item = { ever: 0, current: 0, closed: [], open: [], unknown: 0, clipped: 0,
            breaches: 0, target: definition?.dwellSeconds, terminal: definition?.terminal ?? false };
        states.set(name, item);
        return item;
    };
    for (const state of reference?.states ?? [])
        stateFor(state.name);
    for (const edge of reference?.transitions ?? [])
        transitions.set(edgeKey(edge.from, edge.to), {
            ...edge, count: 0, cases: 0, last: 0, expected: true, observedActions: Object.create(null), observedSources: Object.create(null),
        });
    for (const item of cases) {
        if (item.events.length) {
            if (!paths.has(item.path))
                paths.set(item.path, { id: item.path, states: item.states, partial: item.partial, count: 0 });
            paths.get(item.path).count++;
        }
        for (const state of new Set(item.states))
            stateFor(state).ever++;
        if (item.current !== null)
            stateFor(item.current).current++;
        for (const episode of item.episodes) {
            const stats = stateFor(episode.state);
            if (episode.durationMs === null) {
                stats.unknown++;
                continue;
            }
            if (episode.clipped)
                stats.clipped++;
            (episode.open ? stats.open : stats.closed).push(episode.durationMs);
            if (stats.target !== undefined && episode.durationMs > 1000 * stats.target)
                stats.breaches++;
        }
        const distinctEdges = new Set();
        for (const event of item.events) {
            const key = edgeKey(event.from, event.to);
            if (!transitions.has(key))
                transitions.set(key, {
                    from: event.from, to: event.to, count: 0, cases: 0, last: 0, expected: reference ? false : null,
                    observedActions: Object.create(null), observedSources: Object.create(null),
                });
            const row = transitions.get(key);
            row.count++;
            if (event.source)
                row.observedSources[event.source] = (row.observedSources[event.source] ?? 0) + 1;
            if (event.action)
                row.observedActions[event.action] = (row.observedActions[event.action] ?? 0) + 1;
            distinctEdges.add(key);
        }
        for (const key of distinctEdges)
            transitions.get(key).cases++;
        const last = item.events.at(-1);
        if (last)
            transitions.get(edgeKey(last.from, last.to)).last++;
    }
    const stateRows = [...states].map(([name, item]) => ({
        name, ever: item.ever, current: item.current, historical: distribution(item.closed), currentDuration: distribution(item.open),
        unknownDuration: item.unknown, priorToWindow: item.clipped, dwellSeconds: item.target ?? null, breaches: item.breaches, terminal: item.terminal,
    }));
    const edgeRows = [...transitions.values()].sort((a, b) => b.count - a.count);
    return {
        states: stateRows,
        transitions: edgeRows,
        paths: [...paths.values()].sort((a, b) => b.count - a.count || a.id.localeCompare(b.id)).slice(0, 100),
        pathsTotal: paths.size,
        conformance: {
            conforming: cases.filter(item => item.conformance === 'conforming').length,
            deviation: cases.filter(item => item.conformance === 'deviation').length,
            unknown: cases.filter(item => item.conformance === 'unknown').length,
        },
        findings: {
            bottlenecks: stateRows.filter(row => !row.terminal && (row.historical.count || row.currentDuration.count))
                .sort((a, b) => b.historical.totalMs + b.currentDuration.totalMs - a.historical.totalMs - a.currentDuration.totalMs)
                .map(row => ({ state: row.name, totalMs: row.historical.totalMs + row.currentDuration.totalMs,
                completedP95Ms: row.historical.p95Ms, currentMaxMs: row.currentDuration.maxMs, breaches: row.breaches })),
            observedOnly: edgeRows.filter(edge => edge.expected === false),
            expectedOnly: edgeRows.filter(edge => edge.expected === true && !edge.count),
        },
    };
}
/**
 * One of Palantir's four Machinery views. Counts: processes ever in each state and through each transition (historical),
 * or now in each state and whose last transition each edge is (current). Durations: the P50 of finished stays
 * (historical) or of ongoing ones (current), colored against the state's dwell target by the P95 or the longest.
 */
function view(summary, input) {
    if (!input)
        return undefined;
    const current = input.scope === 'current';
    const nodes = summary.states.map(row => {
        if (input.kind === 'count')
            return { state: row.name, value: current ? row.current : row.ever };
        const stats = current ? row.currentDuration : row.historical, worst = current ? stats.maxMs : stats.p95Ms;
        const color = row.dwellSeconds === null || worst === null ? undefined : worst > row.dwellSeconds * 1000 ? 'red' : 'green';
        return { state: row.name, value: stats.p50Ms, p95Ms: stats.p95Ms, maxMs: stats.maxMs, cases: stats.count, ...(color ? { color } : {}) };
    });
    return { kind: input.kind, scope: input.scope, nodes,
        edges: summary.transitions.map(edge => ({ from: edge.from, to: edge.to, value: current ? edge.last : edge.cases })) };
}
/**
 * The model's node and edge metrics, over the tracked objects of conforming processes as in Palantir: a node aggregates
 * the processes now in its state, an edge those that went through it. The aggregation is an Object Set aggregation, so
 * the query kernel answers it when routing allows; a selection over 10,000 objects is not aggregated.
 */
async function customMetrics(db, access, model, metrics, cases, summary) {
    if (!metrics?.node && !metrics?.edge)
        return undefined;
    const conforming = cases.filter(item => item.conformance === 'conforming'), sets = new ObjectSets(db);
    const measure = async (metric, objects) => {
        if (!objects.length)
            return { value: null, cases: 0 };
        if (objects.length > 10000)
            return { value: null, cases: objects.length, truncated: true };
        let value;
        try {
            const result = await sets.aggregate(access, model, { set: { op: 'refs', objects }, metrics: { value: metric.aggregation } });
            value = (result.items[0]?.metrics.value ?? null);
        }
        catch (error) {
            // A caller who may not read the aggregated property still gets the rest of the analysis.
            if (error instanceof PermissionDenied)
                return { value: null, cases: objects.length, denied: true };
            throw error;
        }
        const color = value === null ? undefined : [...metric.colors ?? []].sort((a, b) => b.min - a.min).find(rule => value >= rule.min)?.color;
        return { value, cases: objects.length, ...(color ? { color } : {}) };
    };
    const describe = ({ colors: _colors, ...metric }) => metric;
    const output = {};
    // One aggregation at a time, so that a model with many states does not take many connections.
    if (metrics.node) {
        const values = [];
        for (const row of summary.states)
            values.push({ state: row.name, ...await measure(metrics.node, conforming.filter(item => item.current === row.name).map(item => item.object)) });
        output.node = { ...describe(metrics.node), values };
    }
    if (metrics.edge) {
        const values = [];
        for (const row of summary.transitions)
            values.push({ from: row.from, to: row.to, ...await measure(metrics.edge, conforming.filter(item => item.events.some(event => event.from === row.from && event.to === row.to)).map(item => item.object)) });
        output.edge = { ...describe(metrics.edge), values };
    }
    return output;
}
function crosstab(pairs) {
    const rows = new Map();
    for (const [state, other] of pairs) {
        const row = rows.get(state) ?? new Map();
        row.set(other, (row.get(other) ?? 0) + 1);
        rows.set(state, row);
    }
    return [...rows].map(([state, row]) => ({ state, with: [...row].map(([other, count]) => ({ state: other, count }))
            .sort((a, b) => b.count - a.count || String(a.state).localeCompare(String(b.state))) }));
}
const stateOf = (properties, property) => typeof properties[property] === 'string' ? properties[property] : null;
/**
 * One process container: where the same objects now stand in the model's parallel processes, the other tracked state
 * properties of their type, against their current state in this one.
 */
function parallelStates(access, model, target, baseline, cases, current) {
    const result = [];
    for (const process of baseline?.parallel ?? []) {
        const other = processLogTarget(model, process);
        if (!other || !access.canRead(model, process))
            continue;
        const pairs = [];
        for (const item of cases) {
            const properties = current.get(item.object.id);
            if (item.current === null || !properties || !access.cell(model, target.objectType, other.property, properties))
                continue;
            pairs.push([item.current, stateOf(properties, other.property)]);
        }
        result.push({ process, property: other.property, states: crosstab(pairs) });
    }
    return result;
}
/**
 * Nested containers: for each readable subprocess, the current states of the children its link reaches, against the
 * current state of their parent. Children are read under the caller's row policies.
 */
async function alignSubprocesses(db, client, access, model, target, reference, cases) {
    const result = [];
    const parents = new Map(cases.filter(item => item.current !== null).map(item => [item.object.id, item.current]));
    if (!parents.size)
        return result;
    for (const child of reference?.subprocesses ?? []) {
        const childTarget = processLogTarget(model, child.process);
        if (!childTarget)
            continue;
        const nav = model.navigation(target.objectType, child.link);
        const [from, to] = nav.forward ? ['from', 'to'] : ['to', 'from'];
        const values = [access.principal.owner, model.projection, target.objectType, [...parents.keys()], nav.link, childTarget.objectType];
        const policy = access.rowSql(model, childTarget.objectType, values, 'o.properties');
        const rows = (await db.query(`SELECT l.${from}_id AS parent,o.properties
      FROM ${db.schema}.links l JOIN ${db.schema}.objects o ON o.projection=l.projection AND o.owner=l.owner AND (o.type,o.id)=(l.${to}_type,l.${to}_id)
      WHERE l.owner=$1 AND l.projection=$2 AND l.type=$5 AND l.${from}_type=$3 AND l.${from}_id=ANY($4::text[]) AND o.type=$6 AND ${policy}`, values, client)).rows;
        const pairs = [];
        for (const row of rows) {
            if (!access.cell(model, childTarget.objectType, childTarget.property, row.properties))
                continue;
            pairs.push([parents.get(row.parent), stateOf(row.properties, childTarget.property)]);
        }
        result.push({ link: child.link, process: child.process, property: childTarget.property, states: crosstab(pairs) });
    }
    return result;
}
function mine(summary, reference, input) {
    const excluded = new Set(input?.exclude.map(edge => edgeKey(edge.from, edge.to)));
    const observed = summary.transitions.filter(edge => edge.cases >= (input?.minCases ?? 1) &&
        !excluded.has(edgeKey(edge.from, edge.to)));
    const threshold = observed.reduce((count, edge) => count + edge.count, 0) * (input?.coveragePercent ?? 100) / 100;
    let covered = 0;
    const observedOnly = observed.filter(edge => {
        if (covered >= threshold)
            return false;
        covered += edge.count;
        return edge.expected !== true;
    });
    const states = new Set(reference?.states.map(state => state.name));
    const observedStates = summary.states.filter(state => state.ever >= (input?.minCases ?? 1) && !states.has(state.name));
    return { states: observedStates.map(state => ({ name: state.name, cases: state.ever })), transitions: observedOnly };
}
const durationRanges = [60000, 300000, 1800000, 3600000, 86400000];
const toNum = (v) => (v === null || v === undefined ? null : Number(v));
function buildDistribution(count, totalMs, p50Ms, p95Ms, maxMs, buckets) {
    return {
        count,
        totalMs: Number(totalMs),
        p50Ms: toNum(p50Ms),
        p95Ms: toNum(p95Ms),
        maxMs: toNum(maxMs),
        distribution: buckets.map((c, index) => ({
            fromMs: durationRanges[index - 1] ?? 0,
            toMs: durationRanges[index] ?? null,
            count: c,
        })),
    };
}
function emptyDistribution() {
    return buildDistribution(0, 0, null, null, null, [0, 0, 0, 0, 0, 0]);
}
async function aggregateInSql(db, client, access, model, target, input, ids, fromMs, endMs, baseline, reference) {
    const endIso = new Date(endMs).toISOString();
    let prefixSql;
    let values;
    if (input.externalSource) {
        const owner = access.principal.owner;
        access.source(model, input.externalSource);
        values = [model.document.id, owner, target.type, input.externalSource, target.objectType, target.property,
            model.projection, input.from, endIso, ids ?? null, input.includeIdle];
        const visible = (column) => access.rowSql(model, target.objectType, values, column) + ' AND ' + access.cellSql(model, target.objectType, target.property, values, column);
        const current = visible('o.properties');
        const before = visible("jsonb_set(o.properties, ARRAY[h.property], COALESCE(to_jsonb(h.previous_state),'null'::jsonb))");
        const after = visible("jsonb_set(o.properties, ARRAY[h.property], COALESCE(to_jsonb(h.next_state),'null'::jsonb))");
        const fields = ['id', 'processId', 'oldState', 'newState', 'sequence', 'recordedAt', 'source', 'timestamp'];
        if (access.hasObjectPolicy(model, target.type) || fields.some(field => !access.property(model, target.type, field) || !access.canSeeModelData(model.object(target.type).properties[field]?.classification)))
            throw new Conflict('External process history requires readable log fields without a log-specific row policy');
        prefixSql = `WITH events AS (
        SELECT h.*, h.observed_at < $8::timestamptz AS prior, (${before}) AND (${after}) AS visible
        FROM ${db.schema}.machinery_history h
        JOIN ${db.schema}.objects o ON o.projection=$7 AND o.owner=h.owner AND o.type=h.object_type AND o.id=h.object_id
        WHERE h.ontology=$1 AND h.owner=$2 AND h.type=$3 AND h.source=$4 AND h.object_type=$5 AND h.property=$6
          AND h.observed_at < $9::timestamptz AND ($10::text[] IS NULL OR h.object_id=ANY($10)) AND (${current})
      ), history AS (
        SELECT * FROM events WHERE NOT prior
        UNION ALL (SELECT DISTINCT ON(object_id) * FROM events e WHERE prior
          AND ($11::boolean OR EXISTS(SELECT 1 FROM events observed WHERE observed.object_id=e.object_id AND NOT observed.prior))
          ORDER BY object_id, observed_at DESC)
      ), complete AS (SELECT object_id FROM history GROUP BY object_id HAVING bool_and(COALESCE(visible, false))),
      scoped_events AS (
        SELECT h.object_id AS case_id, h.previous_state AS from_state, h.next_state AS to_state,
          h.observed_at::text AS recorded_at, h.observed_at::text AS observed_at,
          NULL::text AS action, h.source, h.prior,
          ROW_NUMBER() OVER (PARTITION BY h.object_id ORDER BY h.observed_at, h.id) AS rn,
          COUNT(*) OVER (PARTITION BY h.object_id) AS case_len
        FROM history h JOIN complete USING (object_id)
      )`;
    }
    else {
        values = [input.from, endIso, ids ?? null, input.includeIdle];
        const base = { prefix: '', objects: db.schema + '.objects', links: db.schema + '.links' };
        const view = processLogTables(db, model, access.principal.owner, values, base, [target.type], {
            before: '$2', ids: '$3',
        });
        const row = access.rowSql(model, target.type, values, 'o.properties');
        const cell = (field) => access.cellSql(model, target.type, field, values, 'o.properties');
        const required = ['id', 'processId', 'oldState', 'newState', 'sequence', 'recordedAt'].map(cell).join(' AND ');
        const optional = (field) => `CASE WHEN ${cell(field)} THEN o.properties->>'${field}' END AS "${field}"`;
        prefixSql = `${view.prefix.trimEnd()}, window_events AS (
        SELECT * FROM process_log_rows WHERE recorded_at >= $1::timestamptz
      ), baseline AS (
        SELECT DISTINCT ON (process_id) * FROM process_log_rows
          WHERE recorded_at < $1::timestamptz
          AND ($4::boolean OR EXISTS (SELECT 1 FROM window_events w WHERE w.process_id=process_log_rows.process_id))
        ORDER BY process_id, sequence DESC
      ), history AS (
        SELECT *, false AS prior FROM window_events UNION ALL SELECT *, true FROM baseline
      ), checked AS MATERIALIZED (
        SELECT o.*, (${row} AND ${required}) AS readable,
          ${optional('timestamp')}, ${optional('action')}, ${optional('source')}
        FROM history o
      ), complete AS (
        SELECT process_id FROM checked GROUP BY process_id HAVING bool_and(COALESCE(readable, false))
      ), scoped_events AS (
        SELECT o.process_id AS case_id, o.properties->>'oldState' AS from_state, o.properties->>'newState' AS to_state,
          o.properties->>'recordedAt' AS recorded_at, o.timestamp AS observed_at,
          o.action, o.source, o.prior,
          ROW_NUMBER() OVER (PARTITION BY o.process_id ORDER BY o.sequence) AS rn,
          COUNT(*) OVER (PARTITION BY o.process_id) AS case_len
        FROM checked o JOIN complete USING (process_id)
      )`;
    }
    const bind = (val) => { values.push(val); return '$' + values.length; };
    const fromMsParam = bind(fromMs);
    const endMsParam = bind(endMs);
    const dwellTargets = (reference?.states ?? [])
        .filter(s => s.dwellSeconds !== undefined)
        .map(s => ({ state: s.name, dwell_ms: 1000 * s.dwellSeconds }));
    const dwellParam = bind(JSON.stringify(dwellTargets));
    const baselineEdgesParam = bind(baseline ? JSON.stringify(baseline.transitions.map(e => ({ f: e.from, t: e.to }))) : null);
    const candidateEdgesParam = bind(input.candidate ? JSON.stringify(input.candidate.transitions.map(e => ({ f: e.from, t: e.to }))) : null);
    const clockExpr = input.durationClock === 'observedAt' ? 'observed_at' : 'recorded_at';
    const sql = `${prefixSql},
    event_count AS (
      SELECT COUNT(*)::int AS total FROM scoped_events
    ),
    ordered AS (
      SELECT
        case_id, from_state, to_state, action, source, prior, rn, case_len,
        CASE WHEN ${clockExpr} IS NOT NULL THEN FLOOR(EXTRACT(EPOCH FROM (${clockExpr})::timestamptz) * 1000)::bigint END AS clock_ms,
        LAG(to_state) OVER (PARTITION BY case_id ORDER BY rn) AS prev_to,
        LAG(CASE WHEN ${clockExpr} IS NOT NULL THEN FLOOR(EXTRACT(EPOCH FROM (${clockExpr})::timestamptz) * 1000)::bigint END)
          OVER (PARTITION BY case_id ORDER BY rn) AS prev_ms
      FROM scoped_events
    ),
    episodes AS (
      SELECT from_state AS state, NULL::bigint AS duration_ms, false AS is_open, true AS clipped
      FROM ordered
      WHERE NOT prior AND prev_to IS DISTINCT FROM from_state AND from_state IS NOT NULL
      UNION ALL
      SELECT prev_to AS state,
        CASE WHEN clock_ms IS NOT NULL AND prev_ms IS NOT NULL AND clock_ms >= prev_ms THEN clock_ms - prev_ms END AS duration_ms,
        false AS is_open,
        (prev_ms IS NOT NULL AND prev_ms < ${fromMsParam}::bigint) AS clipped
      FROM ordered
      WHERE NOT (NOT prior AND prev_to IS DISTINCT FROM from_state) AND prev_to IS NOT NULL
      UNION ALL
      SELECT to_state AS state,
        CASE WHEN clock_ms IS NOT NULL AND ${endMsParam}::bigint >= clock_ms THEN ${endMsParam}::bigint - clock_ms END AS duration_ms,
        true AS is_open,
        (clock_ms IS NOT NULL AND clock_ms < ${fromMsParam}::bigint) AS clipped
      FROM ordered
      WHERE rn = case_len AND to_state IS NOT NULL
    ),
    dwell_targets AS (
      SELECT state, dwell_ms FROM jsonb_to_recordset(${dwellParam}::jsonb) AS t(state text, dwell_ms bigint)
    ),
    state_durations AS (
      SELECT
        e.state,
        COUNT(*) FILTER (WHERE NOT e.is_open AND e.duration_ms IS NOT NULL)::int AS closed_count,
        COALESCE(SUM(e.duration_ms) FILTER (WHERE NOT e.is_open AND e.duration_ms IS NOT NULL), 0)::bigint AS closed_total_ms,
        (percentile_disc(0.5) WITHIN GROUP (ORDER BY e.duration_ms) FILTER (WHERE NOT e.is_open AND e.duration_ms IS NOT NULL))::bigint AS closed_p50_ms,
        (percentile_disc(0.95) WITHIN GROUP (ORDER BY e.duration_ms) FILTER (WHERE NOT e.is_open AND e.duration_ms IS NOT NULL))::bigint AS closed_p95_ms,
        MAX(e.duration_ms) FILTER (WHERE NOT e.is_open AND e.duration_ms IS NOT NULL)::bigint AS closed_max_ms,
        COUNT(*) FILTER (WHERE NOT e.is_open AND e.duration_ms IS NOT NULL AND e.duration_ms < 60000)::int AS closed_b0,
        COUNT(*) FILTER (WHERE NOT e.is_open AND e.duration_ms IS NOT NULL AND e.duration_ms >= 60000 AND e.duration_ms < 300000)::int AS closed_b1,
        COUNT(*) FILTER (WHERE NOT e.is_open AND e.duration_ms IS NOT NULL AND e.duration_ms >= 300000 AND e.duration_ms < 1800000)::int AS closed_b2,
        COUNT(*) FILTER (WHERE NOT e.is_open AND e.duration_ms IS NOT NULL AND e.duration_ms >= 1800000 AND e.duration_ms < 3600000)::int AS closed_b3,
        COUNT(*) FILTER (WHERE NOT e.is_open AND e.duration_ms IS NOT NULL AND e.duration_ms >= 3600000 AND e.duration_ms < 86400000)::int AS closed_b4,
        COUNT(*) FILTER (WHERE NOT e.is_open AND e.duration_ms IS NOT NULL AND e.duration_ms >= 86400000)::int AS closed_b5,
        COUNT(*) FILTER (WHERE e.is_open AND e.duration_ms IS NOT NULL)::int AS open_count,
        COALESCE(SUM(e.duration_ms) FILTER (WHERE e.is_open AND e.duration_ms IS NOT NULL), 0)::bigint AS open_total_ms,
        (percentile_disc(0.5) WITHIN GROUP (ORDER BY e.duration_ms) FILTER (WHERE e.is_open AND e.duration_ms IS NOT NULL))::bigint AS open_p50_ms,
        (percentile_disc(0.95) WITHIN GROUP (ORDER BY e.duration_ms) FILTER (WHERE e.is_open AND e.duration_ms IS NOT NULL))::bigint AS open_p95_ms,
        MAX(e.duration_ms) FILTER (WHERE e.is_open AND e.duration_ms IS NOT NULL)::bigint AS open_max_ms,
        COUNT(*) FILTER (WHERE e.is_open AND e.duration_ms IS NOT NULL AND e.duration_ms < 60000)::int AS open_b0,
        COUNT(*) FILTER (WHERE e.is_open AND e.duration_ms IS NOT NULL AND e.duration_ms >= 60000 AND e.duration_ms < 300000)::int AS open_b1,
        COUNT(*) FILTER (WHERE e.is_open AND e.duration_ms IS NOT NULL AND e.duration_ms >= 300000 AND e.duration_ms < 1800000)::int AS open_b2,
        COUNT(*) FILTER (WHERE e.is_open AND e.duration_ms IS NOT NULL AND e.duration_ms >= 1800000 AND e.duration_ms < 3600000)::int AS open_b3,
        COUNT(*) FILTER (WHERE e.is_open AND e.duration_ms IS NOT NULL AND e.duration_ms >= 3600000 AND e.duration_ms < 86400000)::int AS open_b4,
        COUNT(*) FILTER (WHERE e.is_open AND e.duration_ms IS NOT NULL AND e.duration_ms >= 86400000)::int AS open_b5,
        COUNT(*) FILTER (WHERE e.duration_ms IS NULL)::int AS unknown_duration,
        COUNT(*) FILTER (WHERE e.duration_ms IS NOT NULL AND e.clipped)::int AS prior_to_window,
        COUNT(*) FILTER (WHERE e.duration_ms IS NOT NULL AND dt.dwell_ms IS NOT NULL AND e.duration_ms > dt.dwell_ms)::int AS breaches
      FROM episodes e
      LEFT JOIN dwell_targets dt ON dt.state = e.state
      GROUP BY e.state
    ),
    transition_base AS (
      SELECT from_state, to_state, COUNT(*)::int AS count, COUNT(DISTINCT case_id)::int AS cases,
        COUNT(*) FILTER (WHERE rn = case_len)::int AS last,
        MIN(case_id) AS first_case, MIN(rn) AS first_rn
      FROM ordered WHERE NOT prior
      GROUP BY from_state, to_state
    ),
    transition_actions AS (
      SELECT from_state, to_state, jsonb_object_agg(action, cnt) AS observed_actions
      FROM (
        SELECT from_state, to_state, action, COUNT(*)::int AS cnt
        FROM ordered WHERE NOT prior AND action IS NOT NULL
        GROUP BY from_state, to_state, action
      ) a GROUP BY from_state, to_state
    ),
    transition_sources AS (
      SELECT from_state, to_state, jsonb_object_agg(source, cnt) AS observed_sources
      FROM (
        SELECT from_state, to_state, source, COUNT(*)::int AS cnt
        FROM ordered WHERE NOT prior AND source IS NOT NULL
        GROUP BY from_state, to_state, source
      ) s GROUP BY from_state, to_state
    ),
    transition_aggs AS (
      SELECT b.from_state AS "from", b.to_state AS "to", b.count, b.cases, b.last, b.first_case, b.first_rn,
        COALESCE(a.observed_actions, '{}'::jsonb) AS "observedActions",
        COALESCE(s.observed_sources, '{}'::jsonb) AS "observedSources"
      FROM transition_base b
      LEFT JOIN transition_actions a ON a.from_state IS NOT DISTINCT FROM b.from_state AND a.to_state IS NOT DISTINCT FROM b.to_state
      LEFT JOIN transition_sources s ON s.from_state IS NOT DISTINCT FROM b.from_state AND s.to_state IS NOT DISTINCT FROM b.to_state
    ),
    baseline_edges AS (
      SELECT f, t FROM jsonb_to_recordset(COALESCE(${baselineEdgesParam}::jsonb, '[]'::jsonb)) AS e(f text, t text)
    ),
    candidate_edges AS (
      SELECT f, t FROM jsonb_to_recordset(COALESCE(${candidateEdgesParam}::jsonb, '[]'::jsonb)) AS e(f text, t text)
    ),
    state_tokens AS (
      SELECT o.case_id, o.rn, tok.ord, tok.state_name, tok.is_gap_state
      FROM ordered o
      CROSS JOIN LATERAL (
        VALUES
          (1, CASE WHEN NOT o.prior AND o.prev_to IS DISTINCT FROM o.from_state THEN o.from_state END, true),
          (2, o.to_state, false)
      ) AS tok(ord, state_name, is_gap_state)
      WHERE tok.state_name IS NOT NULL
    ),
    state_tokens_dedup AS (
      SELECT case_id, rn, ord, state_name, is_gap_state,
        LAG(state_name) OVER (PARTITION BY case_id ORDER BY rn, ord) AS prev_emitted
      FROM state_tokens
    ),
    case_states AS (
      SELECT case_id, array_agg(state_name ORDER BY rn, ord) AS states
      FROM state_tokens_dedup
      WHERE NOT (is_gap_state AND prev_emitted IS NOT DISTINCT FROM state_name)
      GROUP BY case_id
    ),
    case_summaries AS (
      SELECT
        o.case_id AS "caseId",
        COALESCE(cs.states, ARRAY[]::text[]) AS states,
        bool_or((o.rn = 1 AND (o.prior OR o.from_state IS NOT NULL)) OR (NOT o.prior AND o.prev_to IS DISTINCT FROM o.from_state)) AS partial,
        bool_or((o.rn = 1 AND NOT o.prior AND o.from_state IS NOT NULL) OR (NOT o.prior AND o.prev_to IS DISTINCT FROM o.from_state)) AS incomplete,
        MAX(CASE WHEN o.rn = o.case_len THEN o.to_state END) AS current,
        COUNT(*) FILTER (WHERE NOT o.prior)::int AS transitions,
        CASE WHEN ${baselineEdgesParam}::jsonb IS NULL THEN false
          ELSE bool_or(NOT o.prior AND NOT EXISTS (
            SELECT 1 FROM baseline_edges be WHERE be.f IS NOT DISTINCT FROM o.from_state AND be.t IS NOT DISTINCT FROM o.to_state
          ))
        END AS deviates,
        CASE WHEN ${candidateEdgesParam}::jsonb IS NULL THEN false
          ELSE bool_or(NOT o.prior AND NOT EXISTS (
            SELECT 1 FROM candidate_edges ce WHERE ce.f IS NOT DISTINCT FROM o.from_state AND ce.t IS NOT DISTINCT FROM o.to_state
          ))
        END AS "candidateDeviates"
      FROM ordered o
      LEFT JOIN case_states cs ON cs.case_id = o.case_id
      GROUP BY o.case_id, cs.states
    )
    SELECT
      (SELECT total FROM event_count) AS "totalEvents",
      COALESCE((SELECT jsonb_agg(jsonb_build_object('from', t."from", 'to', t."to", 'count', t.count, 'cases', t.cases, 'last', t.last, 'observedActions', t."observedActions", 'observedSources', t."observedSources") ORDER BY t.count DESC, t.first_case, t.first_rn) FROM transition_aggs t), '[]'::jsonb) AS transitions,
      COALESCE((SELECT jsonb_agg(to_jsonb(s)) FROM state_durations s), '[]'::jsonb) AS "stateDurations",
      COALESCE((SELECT jsonb_agg(to_jsonb(c) ORDER BY c."caseId") FROM case_summaries c), '[]'::jsonb) AS cases`;
    const row = (await db.query(sql, values, client)).rows[0];
    if (row.totalEvents > input.eventLimit) {
        throw new Conflict(input.externalSource
            ? 'Narrow the external history window before analyzing'
            : 'Process analysis exceeds the event limit. Narrow the date range or focus on a process object.');
    }
    return row;
}
function summarizeFromSql(sqlResult, target, baseline, reference, candidate) {
    const durationsByState = new Map(sqlResult.stateDurations.map(row => [row.state, row]));
    const stateEver = new Map();
    const stateCurrent = new Map();
    const stateOrder = new Set((reference?.states ?? []).map(s => s.name));
    const paths = new Map();
    const conformance = { conforming: 0, deviation: 0, unknown: 0 };
    const candidateConformance = { conforming: 0, deviation: 0, unknown: 0 };
    const caseItems = sqlResult.cases.map(item => {
        const path = digest([item.partial, item.states]);
        const conf = item.deviates ? 'deviation' : !baseline || item.incomplete || !item.transitions ? 'unknown' : 'conforming';
        conformance[conf]++;
        if (candidate) {
            const candConf = item.candidateDeviates ? 'deviation' : item.incomplete || !item.transitions ? 'unknown' : 'conforming';
            candidateConformance[candConf]++;
        }
        if (item.transitions) {
            if (!paths.has(path))
                paths.set(path, { id: path, states: item.states, partial: item.partial, count: 0 });
            paths.get(path).count++;
        }
        for (const s of new Set(item.states)) {
            stateOrder.add(s);
            stateEver.set(s, (stateEver.get(s) ?? 0) + 1);
        }
        if (item.current !== null) {
            stateOrder.add(item.current);
            stateCurrent.set(item.current, (stateCurrent.get(item.current) ?? 0) + 1);
        }
        return {
            object: { type: target.objectType, id: item.caseId },
            states: item.states,
            path,
            partial: item.partial,
            current: item.current,
            conformance: conf,
            transitions: item.transitions,
        };
    });
    for (const s of durationsByState.keys())
        stateOrder.add(s);
    const stateRows = [...stateOrder].map(name => {
        const def = reference?.states.find(s => s.name === name);
        const dur = durationsByState.get(name);
        return {
            name,
            ever: stateEver.get(name) ?? 0,
            current: stateCurrent.get(name) ?? 0,
            historical: dur
                ? buildDistribution(dur.closed_count, dur.closed_total_ms, dur.closed_p50_ms, dur.closed_p95_ms, dur.closed_max_ms, [dur.closed_b0, dur.closed_b1, dur.closed_b2, dur.closed_b3, dur.closed_b4, dur.closed_b5])
                : emptyDistribution(),
            currentDuration: dur
                ? buildDistribution(dur.open_count, dur.open_total_ms, dur.open_p50_ms, dur.open_p95_ms, dur.open_max_ms, [dur.open_b0, dur.open_b1, dur.open_b2, dur.open_b3, dur.open_b4, dur.open_b5])
                : emptyDistribution(),
            unknownDuration: dur?.unknown_duration ?? 0,
            priorToWindow: dur?.prior_to_window ?? 0,
            dwellSeconds: def?.dwellSeconds ?? null,
            breaches: dur?.breaches ?? 0,
            terminal: def?.terminal ?? false,
        };
    });
    const transitions = new Map();
    for (const edge of reference?.transitions ?? []) {
        transitions.set(edgeKey(edge.from, edge.to), {
            ...edge, count: 0, cases: 0, last: 0, expected: true, observedActions: Object.create(null), observedSources: Object.create(null),
        });
    }
    for (const observed of sqlResult.transitions) {
        const key = edgeKey(observed.from, observed.to);
        const existing = transitions.get(key);
        const observedActions = Object.assign(Object.create(null), observed.observedActions);
        const observedSources = Object.assign(Object.create(null), observed.observedSources);
        if (existing) {
            existing.count = observed.count;
            existing.cases = observed.cases;
            existing.last = observed.last;
            existing.observedActions = observedActions;
            existing.observedSources = observedSources;
        }
        else {
            transitions.set(key, {
                from: observed.from, to: observed.to, count: observed.count, cases: observed.cases, last: observed.last,
                expected: reference ? false : null, observedActions, observedSources,
            });
        }
    }
    const edgeRows = [...transitions.values()].sort((a, b) => b.count - a.count);
    const summary = {
        states: stateRows,
        transitions: edgeRows,
        paths: [...paths.values()].sort((a, b) => b.count - a.count || a.id.localeCompare(b.id)).slice(0, 100),
        pathsTotal: paths.size,
        conformance,
        findings: {
            bottlenecks: stateRows.filter(row => !row.terminal && (row.historical.count || row.currentDuration.count))
                .sort((a, b) => b.historical.totalMs + b.currentDuration.totalMs - a.historical.totalMs - a.currentDuration.totalMs)
                .map(row => ({
                state: row.name, totalMs: row.historical.totalMs + row.currentDuration.totalMs,
                completedP95Ms: row.historical.p95Ms, currentMaxMs: row.currentDuration.maxMs, breaches: row.breaches,
            })),
            observedOnly: edgeRows.filter(edge => edge.expected === false),
            expectedOnly: edgeRows.filter(edge => edge.expected === true && !edge.count),
        },
    };
    return { summary, caseItems, candidateConformance };
}
export async function analyzeMachinery(db, access, model, input, collectMembers = false) {
    const from = Date.parse(input.from), to = Date.parse(input.to);
    if (to <= from || to - from > maxWindowMs)
        throw new Conflict('Select a positive process analysis window of at most 366 days');
    if ([input.object, input.setId, input.focus].filter(Boolean).length > 1)
        throw new Conflict('Select one object, Object Set or subprocess focus');
    const target = targetFor(model, input.type);
    if (input.object && input.object.type !== target.objectType)
        throw new Conflict('Object type differs from the process type');
    const analysis = await db.transaction(async (client) => {
        await db.query('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY', [], client);
        await db.setOwner(client, access.principal.owner);
        await access.refresh(client);
        const head = await db.query(`SELECT 1 FROM ${db.schema}.ontology WHERE id=$1 AND release=$2`, [model.document.id, model.release], client);
        if (!head.rowCount)
            throw new Conflict('The process publication changed. Refresh and retry.');
        const now = (await db.query('SELECT transaction_timestamp() AS at', [], client)).rows[0].at.getTime();
        if (from >= now)
            throw new Conflict('Process analysis starts in the future');
        const end = Math.min(to, now);
        const graph = new Objects(db, model, access, client);
        access.read(model, target.type);
        access.read(model, target.objectType);
        for (const specification of [input.reference, input.candidate]) {
            if (!specification)
                continue;
            if (specification.transitions.some(({ action }) => action &&
                (!model.actions.has(action) || !access.canDefine(model, 'action', action)
                    || !access.canSeeModelData(model.actions.get(action)?.classification))))
                throw new Conflict('The process model references an unavailable Action');
            try {
                validateMachineryModel(model, target.type, specification);
            }
            catch (error) {
                throw new Conflict(error instanceof Error ? error.message : 'Invalid Machinery model');
            }
        }
        let ids = input.object ? [input.object.id] : undefined;
        if (input.object)
            await graph.read(input.object);
        if (input.setId) {
            const members = await new ObjectSets(db).members(access, model, { op: 'saved', id: input.setId }, client);
            ids = members.filter(object => object.type === target.objectType).map(object => object.id);
        }
        if (input.focus) {
            const parent = targetFor(model, input.focus.type);
            if (input.focus.parent.type !== parent.objectType || !model.object(parent.type).machinery?.subprocesses?.some(child => child.process === input.type && child.link === input.focus.link))
                throw new Conflict('Select a subprocess configured on the parent process');
            access.read(model, parent.type);
            const objects = await graph.follow(input.focus.parent, input.focus.link);
            ids = objects.filter(object => object.ref.type === target.objectType).map(object => object.ref.id);
        }
        const baseline = input.reference ?? model.object(target.type).machinery;
        const reference = readableModel(access, model, target, baseline);
        const { offset, limit } = input;
        const useSqlFastPath = !input.filter && !baseline?.parallel?.length && !baseline?.subprocesses?.length
            && !baseline?.metrics?.node && !baseline?.metrics?.edge && input.view?.scope !== 'current';
        if (useSqlFastPath) {
            const sqlAgg = await aggregateInSql(db, client, access, model, target, input, ids, from, end, baseline, reference);
            const idsInHistory = sqlAgg.cases.map(item => item.caseId);
            if (idsInHistory.length) {
                const snapshots = await db.query(`SELECT properties FROM ${db.schema}.objects WHERE owner=$1 AND projection=$2 AND type=$3 AND id=ANY($4::text[])`, [access.principal.owner, model.projection, target.objectType, idsInHistory], client);
                for (const { properties } of snapshots.rows) {
                    access.readRow(model, target.objectType, properties, true);
                    access.cell(model, target.objectType, target.property, properties);
                }
            }
            const { summary, caseItems, candidateConformance } = summarizeFromSql(sqlAgg, target, baseline, reference, input.candidate);
            let singleDetail;
            if (input.object && caseItems.length) {
                const singleEvents = await (input.externalSource ? readExternalEvents : readEvents)(db, client, access, model, target, { ...input, to: new Date(end).toISOString() }, [input.object.id]);
                if (singleEvents.length) {
                    const singleTrace = trace(target, singleEvents, from, end, baseline, input.durationClock);
                    singleDetail = { timeline: singleTrace.events, episodes: singleTrace.episodes };
                }
            }
            const comparison = input.candidate ? {
                baseline: summary.conformance,
                candidate: candidateConformance,
                evidence: 'observed-transitions',
            } : undefined;
            const result = {
                release: model.release, type: target.type, objectType: target.objectType,
                from: new Date(from).toISOString(), to: new Date(end).toISOString(),
                windowClock: input.externalSource ? 'observedAt' : 'recordedAt', durationClock: input.durationClock,
                ...(collectMembers ? { members: caseItems.map(item => item.object) } : {}),
                reference, ...summary, mined: mine(summary, baseline, input.mining), comparison,
                casesTotal: caseItems.length, nextOffset: offset + limit < caseItems.length ? offset + limit : null,
                cases: caseItems.slice(offset, offset + limit).map(item => ({
                    ...item,
                    ...(singleDetail ? singleDetail : {}),
                })),
            };
            return { result: { ...result, ...(input.view ? { view: view(summary, input.view) } : {}) }, cases: [], summary, metrics: undefined };
        }
        const events = await (input.externalSource ? readExternalEvents : readEvents)(db, client, access, model, target, { ...input, to: new Date(end).toISOString() }, ids);
        const idsInHistory = [...new Set(events.map(event => event.caseId))];
        const current = new Map();
        if (idsInHistory.length) {
            const snapshots = await db.query(`SELECT id,properties FROM ${db.schema}.objects WHERE owner=$1 AND projection=$2 AND type=$3 AND id=ANY($4::text[])`, [access.principal.owner, model.projection, target.objectType, idsInHistory], client);
            for (const { id, properties } of snapshots.rows) {
                access.readRow(model, target.objectType, properties, true);
                access.cell(model, target.objectType, target.property, properties);
                current.set(id, properties);
            }
        }
        const groups = new Map();
        for (const event of events) {
            const group = groups.get(event.caseId) ?? [];
            group.push(event);
            groups.set(event.caseId, group);
        }
        const traces = [...groups.values()].map(history => ({ history, item: trace(target, history, from, end, baseline, input.durationClock) }))
            .filter(({ item }) => matches(item, input.filter));
        const cases = traces.map(({ item }) => item);
        const summary = summarize(cases, reference);
        const parallel = parallelStates(access, model, target, baseline, cases, current);
        const alignment = await alignSubprocesses(db, client, access, model, target, reference, cases);
        const comparison = input.candidate ? {
            baseline: summary.conformance,
            candidate: summarize(traces.map(({ history }) => trace(target, history, from, end, input.candidate, input.durationClock)), readableModel(access, model, target, input.candidate)).conformance,
            evidence: 'observed-transitions',
        } : undefined;
        const result = { release: model.release, type: target.type, objectType: target.objectType,
            from: new Date(from).toISOString(), to: new Date(end).toISOString(), windowClock: input.externalSource ? 'observedAt' : 'recordedAt', durationClock: input.durationClock,
            ...(collectMembers ? { members: cases.map(item => item.object) } : {}),
            reference, ...summary, mined: mine(summary, baseline, input.mining), comparison,
            ...(parallel.length ? { parallel } : {}), ...(alignment.length ? { alignment } : {}),
            casesTotal: cases.length, nextOffset: offset + limit < cases.length ? offset + limit : null,
            cases: cases.slice(offset, offset + limit).map(({ events: history, episodes, ...item }) => ({
                ...item, transitions: history.length,
                ...(input.object ? { timeline: history, episodes } : {}),
            })),
        };
        return { result: { ...result, ...(input.view ? { view: view(summary, input.view) } : {}) }, cases, summary, metrics: baseline?.metrics };
    });
    // After the snapshot, so that the aggregations can go through the query kernel.
    const metrics = await customMetrics(db, access, model, analysis.metrics, analysis.cases, analysis.summary);
    return { ...analysis.result, ...(metrics ? { metrics } : {}) };
}
