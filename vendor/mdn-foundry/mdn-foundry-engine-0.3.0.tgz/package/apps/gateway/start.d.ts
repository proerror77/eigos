import type { Database } from '../../packages/runtime/database.js';
import type { InstalledRuntime } from '../../packages/runtime/installation.js';
import { readConfig, type Config } from '../../packages/core/config.js';
import type { Installation } from '../../packages/runtime/installation.js';
import { createHostApp, type HostAppOptions } from './host.js';
export declare function gatewayMetricsOptions(config: Pick<Config, 'EIGOS_METRICS_ENABLED' | 'EIGOS_METRICS_REQUIRE_AUTH' | 'EIGOS_METRICS_PATH'>): HostAppOptions | undefined;
export declare function startGateway(installation: Installation, adapter?: (config: ReturnType<typeof readConfig>, db: Database, capabilities: InstalledRuntime, options?: HostAppOptions) => ReturnType<typeof createHostApp>): Promise<void>;
