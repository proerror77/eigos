import { readConfig } from '../../packages/core/config.js';
import { createMetricsHandler } from '../../packages/core/metrics.js';
import { assertOwnerIsolation } from '../../packages/runtime/owner-isolation.js';
import { checkInstallation, openInstallation } from '../../packages/runtime/open-installation.js';
import { createHostApp } from './host.js';
export function gatewayMetricsOptions(config) {
    if (config.EIGOS_METRICS_ENABLED !== 'true')
        return undefined;
    const handler = createMetricsHandler();
    return {
        metricsHandler: (req, res) => { handler(req, res); },
        metricsRequireAuth: config.EIGOS_METRICS_REQUIRE_AUTH === 'true',
        ...(config.EIGOS_METRICS_PATH ? { metricsPath: config.EIGOS_METRICS_PATH } : {}),
    };
}
export async function startGateway(installation, adapter) {
    const config = readConfig();
    const { db } = openInstallation(installation);
    await assertOwnerIsolation(db);
    const capabilities = installation.assemble(db);
    const options = gatewayMetricsOptions(config);
    const gateway = adapter
        ? adapter(config, db, capabilities, options)
        : createHostApp(config, db, capabilities, installation.model.document.id, undefined, undefined, options);
    await checkInstallation(installation, gateway.metadata, capabilities);
    const server = gateway.app.listen(config.PORT, config.HOST, () => {
        console.log(`EIGOS listening on ${config.HOST}:${config.PORT}`);
        if (config.OAUTH_MEMBER_MCP_CLIENT_ID)
            console.log(`EIGOS account sign-up mode: ${config.EIGOS_SIGNUP}`);
    });
    const close = () => server.close(() => { void db.close(); });
    process.on('SIGTERM', close);
    process.on('SIGINT', close);
}
