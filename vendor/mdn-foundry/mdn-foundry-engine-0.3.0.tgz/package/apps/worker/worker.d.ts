import { Tasks, type Task } from '../../packages/runtime/tasks.js';
type TaskLane = 'scheduled' | 'interactive';
export declare class Worker {
    private readonly tasks;
    private readonly agent;
    private readonly schedules?;
    private readonly scheduledRunner?;
    private readonly controller;
    private readonly waiters;
    private notifications;
    private readonly deadLetterReapIntervalMs;
    constructor(tasks: Tasks, agent: {
        run(task: Task, signal: AbortSignal): Promise<unknown>;
    }, schedules?: {
        promoteOne(): Promise<boolean>;
    } | undefined, scheduledRunner?: {
        run(task: Task, signal: AbortSignal): Promise<unknown>;
    } | undefined, deadLetterReapIntervalMs?: number);
    runOne(lane?: TaskLane): Promise<boolean>;
    private execute;
    run(): Promise<void>;
    private reapDeadLettersLoop;
    private consume;
    private wake;
    stop(): void;
}
export {};
