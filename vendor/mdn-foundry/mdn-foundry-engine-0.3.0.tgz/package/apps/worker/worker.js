import { randomUUID } from 'node:crypto';
import { TaskResult, PermissionDenied } from '../../packages/runtime/access.js';
import { Conflict } from '../../packages/core/identity.js';
import { withOperationTiming } from '../../packages/core/operation-timing.js';
import { profileDatabase, profileSummary } from '../../packages/core/database-profile.js';
import { Clarification } from '../../packages/runtime/agent.js';
import { DeferredExecution } from '../../packages/runtime/scheduled-actions.js';
import { ProviderBudgetExceeded } from '../../packages/runtime/provider-budgets.js';
export class Worker {
    tasks;
    agent;
    schedules;
    scheduledRunner;
    controller = new AbortController();
    waiters = new Set();
    notifications = 0;
    deadLetterReapIntervalMs;
    constructor(tasks, agent, schedules, scheduledRunner, deadLetterReapIntervalMs = Math.max(100, Number(process.env.EIGOS_TASK_REAP_INTERVAL_MS ?? 5000) || 5000)) {
        this.tasks = tasks;
        this.agent = agent;
        this.schedules = schedules;
        this.scheduledRunner = scheduledRunner;
        this.deadLetterReapIntervalMs = deadLetterReapIntervalMs;
    }
    async runOne(lane) {
        if (lane !== 'interactive')
            await this.schedules?.promoteOne();
        const task = await this.tasks.claim(lane);
        if (!task)
            return false;
        const correlation = { taskId: task.id, workerRunId: randomUUID() };
        const startedAt = new Date().toISOString(), started = performance.now();
        console.info(JSON.stringify({
            event: 'worker_claim', ...correlation, startedAt, taskCreatedAt: task.created_at.toISOString(),
            taskAvailableAt: task.available_at?.toISOString(), taskClaimedAt: task.updated_at.toISOString(),
            queuedMs: task.available_at ? task.updated_at.getTime() - task.available_at.getTime() : undefined,
        }));
        let taskState = 'uncommitted', profile;
        try {
            taskState = await this.tasks.db.withOwner(task.owner, () => withOperationTiming(correlation, () => profileDatabase(measured => { profile = measured; return this.execute(task); })));
        }
        finally {
            console.info(JSON.stringify({
                event: 'worker_finish', ...correlation, taskState, finishedAt: new Date().toISOString(),
                durationMs: Math.round(performance.now() - started), db: profile && profileSummary(profile),
            }));
        }
        return true;
    }
    async execute(task) {
        const controller = new AbortController(), signal = AbortSignal.any([controller.signal, this.controller.signal]);
        let renewing;
        const timer = setInterval(() => {
            if (!renewing)
                renewing = this.tasks.renew(task).catch(() => controller.abort()).finally(() => { renewing = undefined; });
        }, 10000);
        timer.unref();
        try {
            if (task.input.scheduledAction && !this.scheduledRunner)
                throw new Error('Scheduled Action runner is unavailable');
            const result = await (task.input.scheduledAction ? this.scheduledRunner : this.agent).run(task, signal);
            signal.throwIfAborted();
            await this.tasks.finish(task, 'completed', result instanceof TaskResult ? result.value : result, undefined, result instanceof TaskResult ? result.permissions : []);
            return 'completed';
        }
        catch (error) {
            if (error instanceof DeferredExecution)
                return await this.tasks.defer(task, error.until).then(() => 'deferred', () => 'uncommitted');
            // A provider call over its owner's budget waits for the budget instead of failing the task (runtime budget 06.3).
            if (error instanceof ProviderBudgetExceeded)
                return await this.tasks.postpone(task, error.until).then(() => 'deferred', () => 'uncommitted');
            const clarification = error instanceof Clarification;
            const state = clarification ? 'input-required' : 'failed';
            if (!clarification)
                console.error('Inquiry execution failed', error instanceof Error ? error.message : 'Unknown error');
            const safeError = error instanceof Conflict || error instanceof PermissionDenied ? error.message : 'Execution failed. Check the original operation and configured source before retrying.';
            return await this.tasks.finish(task, state, clarification ? error.choices ?? null : null, clarification ? error.message : safeError, clarification ? error.permissions : [], clarification ? error.continuation : undefined).then(() => state, () => 'uncommitted');
        }
        finally {
            clearInterval(timer);
            await renewing;
        }
    }
    async run() {
        const listener = await this.tasks.db.pool.connect();
        listener.on('notification', () => this.wake());
        listener.on('error', () => this.stop());
        const consumers = [];
        const releaseReaper = this.tasks.registerBackgroundReaper();
        try {
            await listener.query('LISTEN eigos_tasks');
            // Each Worker runs EIGOS_WORKER_SLOTS tasks at once, 4 by default (runtime budget 06.1).
            const slots = Math.max(1, Number(process.env.EIGOS_WORKER_SLOTS ?? 4) || 4);
            if (this.schedules && this.scheduledRunner) {
                // Provider-backed scheduled Actions have a slot even when every interactive slot is busy.
                consumers.push(this.consume('scheduled'), ...Array.from({ length: slots }, () => this.consume('interactive')));
            }
            else
                consumers.push(...Array.from({ length: slots }, () => this.consume()));
            consumers.push(this.reapDeadLettersLoop());
            await Promise.all(consumers);
        }
        finally {
            this.stop();
            await Promise.allSettled(consumers);
            releaseReaper();
            await listener.query('UNLISTEN eigos_tasks').catch(() => { });
            listener.release();
        }
    }
    async reapDeadLettersLoop() {
        while (!this.controller.signal.aborted) {
            try {
                await this.tasks.reapDeadLetters();
            }
            catch (error) {
                if (this.controller.signal.aborted)
                    break;
                console.error('Task dead-letter reaper failed', error instanceof Error ? error.message : 'Unknown error');
            }
            if (this.controller.signal.aborted)
                break;
            await new Promise(resolve => {
                const done = () => {
                    clearTimeout(timer);
                    this.controller.signal.removeEventListener('abort', done);
                    resolve();
                };
                const timer = setTimeout(done, this.deadLetterReapIntervalMs);
                timer.unref();
                this.controller.signal.addEventListener('abort', done, { once: true });
            });
        }
    }
    async consume(lane) {
        while (!this.controller.signal.aborted) {
            const seen = this.notifications;
            if (await this.runOne(lane))
                continue;
            const delay = lane === 'scheduled' ? 1000 : await this.tasks.nextInboxDelay();
            if (seen !== this.notifications || this.controller.signal.aborted)
                continue;
            await new Promise(resolve => {
                const wake = () => { clearTimeout(timer); this.waiters.delete(wake); resolve(); };
                const timer = setTimeout(wake, delay);
                this.waiters.add(wake);
            });
        }
    }
    wake() {
        this.notifications++;
        for (const waiter of this.waiters)
            waiter();
    }
    stop() { this.controller.abort(); this.wake(); }
}
