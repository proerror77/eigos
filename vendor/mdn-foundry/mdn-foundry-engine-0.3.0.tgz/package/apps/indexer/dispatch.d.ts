import type pg from 'pg';
/** The Indexer's automation work: Scenario cleanup, rule scans and durable workflow runs. */
export interface AutomationDispatch {
    /** Removes expired Scenario state and reports whether more remains. */
    cleanup(): Promise<{
        more: boolean;
    }>;
    /** Independent change consumers; each scan reports whether it found work. */
    scans: readonly (() => Promise<boolean>)[];
    /** Claims and executes one durable workflow run, reporting whether one was claimed. */
    run(signal: AbortSignal): Promise<boolean>;
    /** Optional PostgreSQL pool for LISTEN wakeup notifications on `eigos_automation`. */
    pool?: Pick<pg.Pool, 'connect'>;
}
export interface AutomationDispatchOptions {
    /** Number of concurrent workflow runner loops (default 1, or EIGOS_AUTOMATION_CONCURRENCY). */
    concurrency?: number;
    /** PostgreSQL LISTEN channel name (default 'eigos_automation'). */
    channel?: string;
}
/**
 * Runs Scenario cleanup, each scan and workflow execution in separate loops, so a slow run does not delay rule
 * discovery and a slow consumer does not delay the others. Runs stay durable rows claimed with leases; a productive
 * scan or a PostgreSQL `LISTEN eigos_automation` notification wakes idle runners while polling remains as a fallback.
 * If any loop fails, the others stop after their current step and the first error is reported.
 */
export declare function dispatchAutomation(parts: AutomationDispatch, signal: AbortSignal, idleMs?: number, options?: AutomationDispatchOptions): Promise<void>;
