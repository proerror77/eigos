import { setTimeout as delay } from 'node:timers/promises';
function configuredConcurrency(explicit) {
    const raw = explicit ?? (process.env.EIGOS_AUTOMATION_CONCURRENCY
        ? Number.parseInt(process.env.EIGOS_AUTOMATION_CONCURRENCY, 10) : 1);
    if (!Number.isFinite(raw) || raw < 1)
        return 1;
    return Math.min(32, Math.floor(raw));
}
/**
 * Runs Scenario cleanup, each scan and workflow execution in separate loops, so a slow run does not delay rule
 * discovery and a slow consumer does not delay the others. Runs stay durable rows claimed with leases; a productive
 * scan or a PostgreSQL `LISTEN eigos_automation` notification wakes idle runners while polling remains as a fallback.
 * If any loop fails, the others stop after their current step and the first error is reported.
 */
export async function dispatchAutomation(parts, signal, idleMs = 1000, options = {}) {
    const stop = new AbortController(), stopped = AbortSignal.any([signal, stop.signal]);
    const concurrency = configuredConcurrency(options.concurrency);
    const channel = options.channel ?? 'eigos_automation';
    if (!/^[a-z0-9_]+$/.test(channel))
        throw new Error('Invalid automation notification channel');
    let found = 0;
    const waiters = new Set();
    const wakeAll = () => {
        found++;
        for (const wake of [...waiters])
            wake();
    };
    const runnerIdle = () => new Promise(resolve => {
        if (stopped.aborted)
            return resolve();
        const done = () => {
            clearTimeout(timer);
            stopped.removeEventListener('abort', done);
            waiters.delete(done);
            resolve();
        };
        const timer = setTimeout(done, idleMs);
        stopped.addEventListener('abort', done, { once: true });
        waiters.add(done);
    });
    const pause = (ms) => delay(ms, undefined, { signal: stopped }).catch(() => { });
    let listener;
    let listenerError = false;
    if (parts.pool) {
        listener = await parts.pool.connect();
        listener.on('notification', () => wakeAll());
        listener.on('error', () => { listenerError = true; wakeAll(); });
        await listener.query(`LISTEN ${channel}`);
    }
    async function cleanup() {
        while (!stopped.aborted) {
            const cleaned = await parts.cleanup();
            await pause(cleaned.more ? Math.min(1000, idleMs) : 60000);
        }
    }
    async function scan(scanOne) {
        while (!stopped.aborted) {
            if (await scanOne())
                wakeAll();
            else
                await pause(idleMs);
        }
    }
    async function run() {
        while (!stopped.aborted) {
            const seen = found;
            // The process signal, not a sibling failure, interrupts a run already in progress.
            if (await parts.run(signal))
                continue;
            if (seen === found)
                await runnerIdle();
        }
    }
    let failure;
    const settle = (loop) => loop.catch(error => { failure ??= { error }; stop.abort(); });
    try {
        const runners = Array.from({ length: concurrency }, () => settle(run()));
        await Promise.all([settle(cleanup()), ...parts.scans.map(scanOne => settle(scan(scanOne))), ...runners]);
    }
    finally {
        if (listener) {
            await listener.query(`UNLISTEN ${channel}`).catch(() => { });
            listener.release(listenerError);
        }
    }
    if (failure)
        throw failure.error;
}
