import type { ObjectData, ObjectRef } from '../ontology/schema.js';
import type { Objects, Query } from './objects.js';
import type { Database, Sql } from './database.js';
import type { PublishedOntology } from './metadata.js';
export declare const scenarioMetadataType = "OntologyScenario";
/** The shared metadata has a local FK target for each explicitly authorized identity. */
export declare function syncScenarioMetadata(db: Database, model: PublishedOntology, id: string, client: Sql, previousReaders?: string[]): Promise<void>;
export declare function removeScenarioMetadata(db: Database, owner: string, ids: string[], client: Sql): Promise<void>;
export declare function scenarioMetadataRead(graph: Objects, ref: ObjectRef): Promise<ObjectData>;
export declare function scenarioMetadataQuery(graph: Objects, input: Query): Promise<{
    items: ObjectData[];
    cursor: string | undefined;
}>;
