import { type ExecutionActor } from '../core/identity.js';
import { type ActionCall, type ActionResultRead } from '../ontology/invocation.js';
import { PublishedOntology } from './metadata.js';
import { Access } from './access.js';
import { type ObjectRef } from '../ontology/schema.js';
import { Database, type Sql } from './database.js';
import { Functions, type FunctionContext, type ScenarioEvaluation } from './functions.js';
import { Effects, type ActionEffect } from './effects.js';
import { type ObjectChange } from './action-journal.js';
type TaskExecution = NonNullable<FunctionContext['execution']>;
export type CommittedEffects = (model: PublishedOntology, owner: string, changes: readonly ObjectChange[]) => Promise<ActionEffect[]>;
export declare class Actions {
    private readonly db;
    private readonly functions;
    private readonly effects?;
    private readonly committedEffects?;
    constructor(db: Database, functions: Functions, effects?: Effects | undefined, committedEffects?: CommittedEffects | undefined);
    /**
     * `context` is where the Action takes effect: in a Scenario, or on the live data. A merge replays a Scenario's Actions
     * inside the Scenario's view, but their edits take effect on the live data, so it checks them as live.
     */
    private checkSubmission;
    private checkInput;
    resolve(access: Access, model: PublishedOntology, call: ActionCall): {
        action: string;
        input: Record<string, unknown>;
    };
    private requireActive;
    private lockRequest;
    validateSubmission(access: Access, model: PublishedOntology, call: ActionCall, client: Sql, signal: AbortSignal): Promise<string>;
    validate(access: Access, model: PublishedOntology, call: ActionCall, signal?: AbortSignal): Promise<{
        valid: true;
        phase: 'submission';
        action: string;
        release: string;
    }>;
    applyBatch(access: Access, model: PublishedOntology, raw: unknown, signal?: AbortSignal): Promise<{
        release: string;
        items: {
            requestId: string;
            result: {
                type: string;
                id: string;
            };
        }[];
    }>;
    apply(access: Access, model: PublishedOntology, actionName: string, raw: Record<string, unknown>, requestId: string, beforeCommit?: (client: Sql) => Promise<void>, execution?: FunctionContext['execution'], signal?: AbortSignal, executor?: ExecutionActor, scenarioEvaluation?: ScenarioEvaluation): Promise<{
        type: string;
        id: string;
    }>;
    private execute;
    /** Complete an MCP invocation, with a durable pause only for task execution. */
    complete(access: Access, model: PublishedOntology, selected: {
        action: string;
        input: Record<string, unknown>;
    }, requestId: string, read: ActionResultRead | undefined, execution: TaskExecution | undefined, signal: AbortSignal, options?: {
        allowPause?: boolean;
        applied?: (reference: ObjectRef) => void;
        authorize?: (client: Sql) => Promise<void>;
    }): Promise<unknown>;
    resume(access: Access, model: PublishedOntology, execution: TaskExecution, signal: AbortSignal): Promise<unknown>;
    undo(access: Access, model: PublishedOntology, originalRequestId: string, requestId: string): Promise<any>;
}
export {};
