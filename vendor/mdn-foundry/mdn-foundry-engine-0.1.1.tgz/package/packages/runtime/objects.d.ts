import type { CognitiveStep } from './cognitive-workflow.js';
import { z } from 'zod';
import { type ExecutionActor } from '../core/identity.js';
import { PublishedOntology } from './metadata.js';
import { Access } from './access.js';
import { type ObjectData, type ObjectRef, type LinkData } from '../ontology/schema.js';
import { Database, type Sql } from './database.js';
import { type ScenarioMutation } from './scenario-store.js';
import { type Metric } from './stored-query.js';
import { type KernelUse } from './kernel/routing.js';
export declare const querySchema: z.ZodObject<{
    type: z.ZodString;
    where: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodNumber, z.ZodBoolean, z.ZodNull]>>>;
    filter: z.ZodOptional<z.ZodPipe<z.ZodUnknown, z.ZodType<import("./query-filter.js").Predicate, unknown, z.core.$ZodTypeInternals<import("./query-filter.js").Predicate, unknown>>>>;
    orderBy: z.ZodOptional<z.ZodArray<z.ZodObject<{
        property: z.ZodString;
        direction: z.ZodDefault<z.ZodEnum<{
            asc: "asc";
            desc: "desc";
        }>>;
    }, z.core.$strict>>>;
    intervalOverlap: z.ZodOptional<z.ZodObject<{
        start: z.ZodString;
        end: z.ZodString;
        from: z.ZodISODateTime;
        until: z.ZodISODateTime;
        includeUnknown: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>>;
    select: z.ZodOptional<z.ZodArray<z.ZodString>>;
    limit: z.ZodDefault<z.ZodNumber>;
    cursor: z.ZodOptional<z.ZodString>;
    from: z.ZodOptional<z.ZodObject<{
        object: z.ZodObject<{
            type: z.ZodString;
            id: z.ZodString;
        }, z.core.$strict>;
        link: z.ZodString;
        as: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type Query = z.input<typeof querySchema>;
export declare function queryFields(query: Pick<z.output<typeof querySchema>, 'where' | 'filter' | 'orderBy' | 'select' | 'intervalOverlap'>): string[];
export declare class Objects {
    readonly db: Database;
    readonly model: PublishedOntology;
    readonly access: Access;
    readonly client: Sql;
    readonly change?: {
        action?: string;
        requestId?: string;
        taskId?: string;
        inputDigest?: string;
        reviewedChangeDigest?: string;
        executor?: ExecutionActor;
        scenarioEdits?: ScenarioMutation[];
        validateWorkflow?: (objects: Objects, validation: CognitiveStep['validation'], object: ObjectRef) => Promise<void>;
    } | undefined;
    /** How `query` uses the query kernel: by default from EIGOS_KERNEL and the process's kernels. Tests replace it. */
    static kernels: () => KernelUse;
    constructor(db: Database, model: PublishedOntology, access: Access, client?: Sql, change?: {
        action?: string;
        requestId?: string;
        taskId?: string;
        inputDigest?: string;
        reviewedChangeDigest?: string;
        executor?: ExecutionActor;
        scenarioEdits?: ScenarioMutation[];
        validateWorkflow?: (objects: Objects, validation: CognitiveStep['validation'], object: ObjectRef) => Promise<void>;
    } | undefined);
    get owner(): string;
    /** Object-scoped commits lock each object before reading (shared) or writing it or its relationships (exclusive). */
    protected lockObjects(refs: readonly ObjectRef[], mode: 'shared' | 'exclusive'): Promise<void>;
    /** A read whose conflicts object locks cannot bound sends an object-scoped commit to its exclusive rerun. */
    protected requireExclusive(reason: string): void;
    /**
     * In an object-scoped commit, a read bounded by one source's relationship locks every target of it before
     * reading: the source's shared lock fixes the relationship, and the targets' locks fix what filters see.
     */
    private lockRelationshipTargets;
    private writeReady?;
    lockWrites(): Promise<void>;
    private prepareWrite;
    private assertStoredFields;
    private writeType;
    maskSnapshot(ref: ObjectRef, properties: Record<string, unknown>): Record<string, unknown> | null;
    private visible;
    private row;
    private stored;
    readStored(input: ObjectRef): Promise<ObjectData>;
    private loadStored;
    private linkedSecurityReads;
    /** Source fields must match their baseline; unrelated local notes may remain. */
    matchesSource(ref: ObjectRef, sourceName: string): Promise<boolean>;
    private sourceMatch;
    /**
     * For objects this graph has read, whether each named property is visible, as propertyVisible decides, from
     * one read. Objects whose rows need a row policy or cannot be read here are left to the per-object check.
     */
    propertyVisibility(items: readonly {
        ref: ObjectRef;
        names: readonly string[];
    }[]): Promise<Map<string, boolean>>;
    /**
     * The objects linked from each source along one step, as queryStored with `from` returns them for that source,
     * from one read. Undefined when the target type needs the per-source path: it has derived properties, row
     * policies of its own kind, or the relationship is too large to hold at once.
     */
    linkedTargets(sources: readonly ObjectRef[], link: string, as?: string): Promise<Map<string, ObjectData[]> | undefined>;
    propertyVisible(ref: ObjectRef, field: string): Promise<boolean>;
    /**
     * The objects `read` returns for these references, read together: one statement per type, each row checked and
     * masked as `read` does, and the derived values of the batch evaluated together. A reference whose object is missing
     * or unreadable is left out, where `read` would throw.
     */
    readBatch(refs: readonly ObjectRef[]): Promise<ObjectData[]>;
    read(input: ObjectRef): Promise<ObjectData>;
    private readObject;
    query(input: Query): Promise<{
        items: ObjectData[];
        cursor?: string;
    }>;
    /**
     * One page of a query. A query the reference evaluates completely (it filters, orders, or reads derived properties or
     * nested fields) goes through the query kernel as EIGOS_KERNEL says, like an Object Set: `route` answers it from the
     * kernel, in the reference's order, and `shadow` compares the kernel's answer with the reference's. Inside a caller's
     * transaction, while decision evidence records each read and outside the owner's row security context, the
     * reference answers. In a Scenario the kernel reads the Scenario's edits over the live data.
     */
    private queryPage;
    /** Whether the reference evaluates the query completely rather than reading it page by page from storage. */
    private completeQuery;
    private routedQuery;
    /**
     * One page from the kernel. Like the reference's complete evaluation, it reads with a fork of the access, which must
     * still be able to return what it read; this access adopts the reads once the kernel answered.
     */
    private kernelQuery;
    private shadowQuery;
    /**
     * Every match of a query for a caller that needs the whole set, such as Object Set evaluation. A query that
     * needs complete evaluation (derived properties, filters, ordering) is evaluated once rather than once per
     * page; other queries are read page by page from storage.
     */
    /**
     * The matches of a query among the given objects of its type, for a consumer that re-evaluates only the objects that
     * changed. It applies the visibility, filters and derived properties of `query`, and reads only those objects.
     */
    queryAmong(input: Query, ids: readonly string[]): Promise<ObjectData[]>;
    queryAll(input: Query): Promise<ObjectData[]>;
    /** `among` restricts the query to those object ids of its type. */
    private queryObjects;
    private visibleViewField;
    private mayUseStoredFields;
    private storedSelection;
    private storedFields;
    private scalarCandidates;
    /** `among` restricts the query to those object ids of its type. */
    queryStored(input: Query, among?: readonly string[]): Promise<{
        items: ObjectData[];
        cursor?: string;
    }>;
    /** Compile membership when this read needs no per-row authorization evidence. */
    storedSetSelection(input: Query, path: readonly {
        link: string;
        as?: string;
    }[]): Promise<{
        type: string;
        prefix: string;
        relation: string;
        filter: string;
        values: unknown[];
        bind: (value: unknown) => string;
        property: (path: string, view?: string) => string;
    } | undefined>;
    private recordSetRead;
    private readSetQuery;
    readStoredSet(input: Query, path: readonly {
        link: string;
        as?: string;
    }[], limit: number): Promise<ObjectData[] | undefined>;
    /** Keep eligible set membership and reduction inside PostgreSQL. */
    aggregateStored(input: Query, view: string | undefined, groupBy: string[], metrics: Record<string, Metric>, groupLimit: number, path: readonly {
        link: string;
        as?: string;
    }[]): Promise<{
        count: number;
        items: {
            group: {
                [k: string]: any;
            };
            metrics: {
                [k: string]: number | null;
            };
        }[];
    } | undefined>;
    /** Object Set frontiers have already been read within this transaction. Recheck both endpoints in the join. */
    followSet(sourceType: string, ids: string[], link: string, as: string | undefined, maximum: number): Promise<ObjectData[] | undefined>;
    follow(ref: ObjectRef, link: string, view?: string, maximum?: number): Promise<ObjectData[]>;
    /**
     * An object's relationship, through the query kernel as EIGOS_KERNEL says, on the same conditions as `query`: `route`
     * answers from the kernel and `shadow` compares the kernel's answer with the reference's.
     */
    private followTargets;
    /** The targets from the kernel, read with a fork of the access as `kernelQuery` reads a page. */
    private kernelFollow;
    /** A mandatory relationship guard needs to distinguish a complete empty result from filtered targets. */
    readCompleteRelationship(ref: ObjectRef, link: string): Promise<{
        items: ObjectData[];
        complete: boolean;
    }>;
    private followObjects;
    create(ref: ObjectRef, input: Record<string, unknown>): Promise<void>;
    ingestBatch(input: readonly {
        ref: ObjectRef;
        properties: Record<string, unknown> | null;
    }[], source?: string, observedAt?: string): Promise<void>;
    /** Stored rows for source ingestion: the raw value it replaces, and the parsed value when the caller may see it. */
    private storedSources;
    edit(ref: ObjectRef, revision: number, fields: Record<string, unknown>): Promise<void>;
    link(edge: LinkData): Promise<void>;
    linkBatch(edges: readonly LinkData[]): Promise<void>;
    unlink(edge: LinkData): Promise<void>;
    remove(ref: ObjectRef, revision: number): Promise<void>;
}
