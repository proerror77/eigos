import { z } from 'zod';
import { Ontology } from '../ontology/model.js';
import { assembleRuntime } from './assembly.js';
import type { Database } from './database.js';
import type { FunctionHandler } from './functions.js';
import type { RuntimeExtensions } from './extensions.js';
import type { AgentDriver, Capabilities } from './agent.js';
import type { ScheduleTerminal } from './scheduled-actions.js';
import type { TaskResultProjection } from './tasks.js';
import type { ScenarioDecisionSupport } from './scenarios.js';
declare const publicSkill: z.ZodObject<{
    id: z.ZodString;
    name: z.ZodString;
    description: z.ZodString;
    tags: z.ZodArray<z.ZodString>;
}, z.core.$strict>;
export interface InstalledRuntime extends Capabilities {
    publicSkills?: z.infer<typeof publicSkill>[];
    registerServices?: import('./services.js').RegisterServices;
    effects: ReturnType<typeof assembleRuntime>['effects'];
    projectTaskResult: TaskResultProjection;
    scheduledTerminals?: ReadonlyMap<string, ScheduleTerminal>;
    scenarioDecisions?: ScenarioDecisionSupport;
}
export interface Installation {
    model: Ontology;
    expectedDefinition?: string;
    /** Includes the identity of the implementation actually loaded by every role. */
    runtimeId(core: string): string;
    assemble(db: Database): InstalledRuntime;
    afterActivation?(db: Database, model: Ontology): Promise<void>;
    driver(): AgentDriver;
}
export declare const installationManifest: z.ZodObject<{
    format: z.ZodLiteral<"ontology-installation-v1">;
    definition: z.ZodString;
    publicSkills: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
        description: z.ZodString;
        tags: z.ZodArray<z.ZodString>;
    }, z.core.$strict>>>;
    definitionDigest: z.ZodString;
    implementation: z.ZodOptional<z.ZodObject<{
        file: z.ZodString;
        sha256: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export interface Registration extends RuntimeExtensions {
    agentInstructions?: readonly string[];
    handlers?: ReadonlyMap<string, FunctionHandler>;
    driver?: () => AgentDriver;
}
/** The manifest is selected by the operator. Modules are trusted, self-contained deployment artifacts. */
export declare function loadInstallation(path: string): Promise<Installation>;
export {};
