import { z } from 'zod';
import type { Database, Sql } from './database.js';
declare const allocationSchema: z.ZodObject<{
    allocation: z.ZodString;
    resource: z.ZodString;
    start: z.ZodISODateTime;
    end: z.ZodISODateTime;
}, z.core.$strict>;
export type ResourceAllocation = z.infer<typeof allocationSchema>;
export declare function initializeResourceReservations(db: Database): Promise<void>;
/** One authority for occupied resource intervals. Call from the Action's existing transaction. */
export declare class ResourceReservations {
    private readonly db;
    constructor(db: Database);
    replace(owner: string, holder: string, raw: readonly ResourceAllocation[], state: 'held' | 'committed', client: Sql): Promise<void>;
}
export {};
