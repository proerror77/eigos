import { z } from 'zod';
import type { Database, Sql } from './database.js';
/**
 * Provider budgets (runtime budget 06.3): each owner may call each provider at a bounded rate. A token bucket per owner
 * and provider, kept in PostgreSQL so every process shares it, refills at `perMinute` tokens a minute up to `burst`.
 * A call without a token is deferred, not failed: a task resumes when the bucket has refilled, and a direct request
 * learns when to retry.
 */
export declare const providerRatesSchema: z.ZodRecord<z.ZodString, z.ZodObject<{
    perMinute: z.ZodNumber;
    burst: z.ZodNumber;
}, z.core.$strict>>;
export type ProviderRates = z.output<typeof providerRatesSchema>;
/** The rates of EIGOS_PROVIDER_RATES, a JSON object by source name; providers not named are not limited. */
export declare function configuredProviderRates(text?: string | undefined): ProviderRates;
/** A provider call over its owner's budget. A Worker defers the task until `until`; a request answers 429. */
export declare class ProviderBudgetExceeded extends Error {
    readonly provider: string;
    readonly until: string;
    constructor(provider: string, until: string);
}
export declare function initializeProviderBudgets(db: Database): Promise<void>;
export declare class ProviderBudgets {
    private readonly db;
    private readonly rates;
    constructor(db: Database, rates?: ProviderRates);
    /** Takes one token of the owner's budget for `provider`, or throws ProviderBudgetExceeded with when one will be back. */
    take(owner: string, provider: string, client?: Sql): Promise<void>;
}
