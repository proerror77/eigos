import { z } from 'zod';
import { type Classification } from '../ontology/classification.js';
import type { Database, Sql } from './database.js';
export declare const modelClearanceSchema: z.ZodObject<{
    owner: z.ZodString;
    provider: z.ZodString;
    model: z.ZodString;
    clearance: z.ZodObject<{
        sensitivity: z.ZodEnum<{
            CONFIDENTIAL: "CONFIDENTIAL";
            INTERNAL: "INTERNAL";
            PUBLIC: "PUBLIC";
            RESTRICTED: "RESTRICTED";
        }>;
        compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>;
    active: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>;
export type ModelClearance = z.output<typeof modelClearanceSchema>;
export declare const harnessProvider = "openai-codex";
export declare function initializeModelEgress(db: Database): Promise<void>;
export declare function setModelClearance(db: Database, raw: unknown, client?: Sql): Promise<void>;
export declare class ModelEgressDenied extends Error {
    constructor();
}
export declare class ModelEgress {
    private readonly db;
    private readonly owner;
    private readonly model;
    private readonly provider?;
    constructor(db: Database, owner: string, model: string, provider?: string | undefined);
    decide(required: Classification): Promise<{
        allowed: boolean;
        clearance: {
            sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
            compartments: string[];
        } | undefined;
        policyDigest: string;
    }>;
}
