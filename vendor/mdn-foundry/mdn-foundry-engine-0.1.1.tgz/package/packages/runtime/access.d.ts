import { z } from 'zod';
import { type Principal } from '../core/identity.js';
import { type Classification } from '../ontology/classification.js';
import type { Ontology } from '../ontology/model.js';
import { Database, type Sql } from './database.js';
import { type ObjectPolicy } from './security.js';
export declare const permissionSchema: z.ZodEnum<{
    apply_action: "apply_action";
    dispatch_source: "dispatch_source";
    edit_definition: "edit_definition";
    execute_function: "execute_function";
    ingest_source: "ingest_source";
    manage_definition: "manage_definition";
    migrate_objects: "migrate_objects";
    read_source: "read_source";
    view_definition: "view_definition";
    view_objects: "view_objects";
    view_property: "view_property";
}>;
export type Permission = z.infer<typeof permissionSchema>;
export declare const grantSchema: z.ZodObject<{
    resource: z.ZodString;
    permission: z.ZodEnum<{
        apply_action: "apply_action";
        dispatch_source: "dispatch_source";
        edit_definition: "edit_definition";
        execute_function: "execute_function";
        ingest_source: "ingest_source";
        manage_definition: "manage_definition";
        migrate_objects: "migrate_objects";
        read_source: "read_source";
        view_definition: "view_definition";
        view_objects: "view_objects";
        view_property: "view_property";
    }>;
}, z.core.$strict>;
export type Grant = z.infer<typeof grantSchema>;
export interface RowRequirement {
    projection: string;
    type: string;
    id: string;
    fields: string[];
    scenario?: string;
}
type ScenarioRequirement = {
    id: string;
    release: string;
    merged?: true;
};
export type Requirement = Grant & {
    ontology: string;
    security?: string;
    row?: RowRequirement;
    scenario?: ScenarioRequirement;
};
export declare class TaskResult {
    readonly value: unknown;
    readonly permissions: Requirement[];
    constructor(value: unknown, permissions: Requirement[]);
}
export declare const resource: (ontology: string, kind: string, name: string) => string;
export { PermissionDenied } from '../core/identity.js';
/** Which rows of a type a principal may read; see `Access.rowRule`. */
export type RowRule = {
    kind: 'deny';
} | {
    kind: 'unsupported';
} | {
    kind: 'rows';
    policy?: ObjectPolicy['read'];
    markingsProperty?: string;
    tracked: boolean;
    markings: string[];
    subject: string;
    groups: string[];
    clearance?: {
        rank: number;
        compartments: string[];
        availableMarks: string[];
        classificationProperty?: string;
    };
};
/** Resource grants and object/property visibility, independent of OAuth transport scopes. */
export declare class Access {
    private readonly db;
    private readonly inheritedClearance?;
    private policies;
    private security;
    private securityDigest;
    private readMarkings;
    private grants;
    private properties;
    private required;
    private data;
    private observedClassification;
    private readonly egress;
    readonly principal: Principal;
    private constructor();
    observeClassification(label?: Classification): void;
    measureEgress<T>(operation: () => Promise<T>, clearance?: {
        sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
        compartments: string[];
    } | undefined): Promise<{
        result: Awaited<T>;
        classification: {
            sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
            compartments: string[];
        };
        requirements: Requirement[];
    }>;
    private modelClearance;
    fork(client?: Sql): Promise<Access>;
    canSeeModelData(label?: Classification): boolean;
    useModelData(label?: Classification): void;
    private recordData;
    canDisclose(requirements: Requirement[]): Promise<boolean>;
    needsEgressRead(model: Ontology, type: string): boolean;
    private rowClassification;
    observeRowClassification(model: Ontology, type: string, properties: Record<string, unknown>): void;
    private rowModelSql;
    get runtimeId(): string;
    static load(db: Database, principal: Principal, client?: Sql): Promise<Access>;
    refresh(client?: Sql): Promise<void>;
    allows({ permission, resource: target, ontology, security }: Requirement): boolean;
    require(ontology: string, permission: Permission, target: string, data?: boolean): void;
    definition(model: Ontology, kind: string, name: string, data?: boolean): void;
    /**
     * Everything this principal's object and property visibility depends on besides the objects themselves: resource
     * grants, property security, object policies and security memberships. It changes whenever visibility can change.
     */
    get visibilityDigest(): string;
    canDefine(model: Ontology, kind: string, name: string): boolean;
    private available;
    private requireAvailable;
    canRead(model: Ontology, type: string): boolean;
    /**
     * The rows of the type this principal may read, as rules another query engine can evaluate: `rowSql` in structured
     * form, with the same type-level effects. Document chunks and process logs filter rows through other objects, so
     * only the reference evaluates them.
     */
    rowRule(model: Ontology, type: string): RowRule;
    /** A cell's visibility as `cellRule` decides it, without recording the check. */
    cellVisibility(model: Ontology, type: string, field: string): {
        visible: false;
    } | {
        visible: true;
        policy?: ObjectPolicy['read'];
    };
    /** A cell's visibility for this principal as `cellSql` evaluates it, with the same effects. */
    cellRule(model: Ontology, type: string, field: string): {
        visible: false;
    } | {
        visible: true;
        policy?: ObjectPolicy['read'];
    };
    /** Records the row dependencies the reference records for every row of a policy-bound type it reads. */
    trackRows(model: Ontology, type: string, ids: readonly string[]): void;
    /** Records the markings of rows read elsewhere, as reading each row does. */
    observeReadMarkings(markings: readonly string[]): void;
    /** Whether a property's cells are subject to property security, so its visibility can differ per object. */
    hasPropertySecurity(model: Ontology, type: string, property: string): boolean;
    hasObjectPolicy(model: Ontology, type: string): boolean;
    workbenchRole(ontology: string): 'admin' | 'editor' | 'member';
    read(model: Ontology, type: string): void;
    property(model: Ontology, type: string, property: string): boolean;
    adoptReads(other: Access): void;
    readMarkingsSnapshot(): string[];
    /** Restore the security context of persisted inputs without recomputing their frozen values. */
    restoreReads(requirements: Requirement[], markings: string[], client?: Sql): Promise<void>;
    private trackSecurity;
    private trackRow;
    private rowsAllowed;
    rowAllowed(model: Ontology, type: string, properties: Record<string, unknown>): boolean;
    readRow(model: Ontology, type: string, properties: Record<string, unknown>, track?: boolean): void;
    sourceRow(model: Ontology, type: string, properties: Record<string, unknown>): void;
    private visibleCell;
    cell(model: Ontology, type: string, field: string, properties: Record<string, unknown>): boolean;
    /** A locked historical draft snapshot has current policy dependencies, not a fictitious live row. */
    maskHistoricalSnapshot(model: Ontology, type: string, properties: Record<string, unknown>): {
        [k: string]: unknown;
    } | null;
    rowSql(model: Ontology, type: string, values: unknown[], column?: string): string;
    cellSql(model: Ontology, type: string, field: string, values: unknown[], column?: string): string;
    writeRow(model: Ontology, type: string, properties: Record<string, unknown>): void;
    action(model: Ontology, name: string): void;
    function(model: Ontology, name: string): void;
    source(model: Ontology, name: string): void;
    dispatchSource(model: Ontology, name: string): void;
    exportedClassification(): {
        sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
        compartments: string[];
    };
    recordScenarioRead(model: Ontology, id: string, release: string): void;
    dataRequirements(): Requirement[];
    requirements(): Requirement[];
    /** Return a copy of the dependencies, preserving deleted inputs and all permission evidence. */
    private requirementsAfterMerges;
    /** Use after Action commit for final task results. Failed merges leave the original dependency intact. */
    finalDataRequirements(client?: Sql): Promise<Requirement[]>;
    /** Queue effects with the same transaction that commits the scenario, so rollback also removes this copy. */
    finalRequirements(client?: Sql): Promise<Requirement[]>;
    canReturn(requirements: Requirement[], client?: Sql): Promise<boolean>;
    private scenarioViews;
    describe(model: Ontology, executable?: boolean, include?: (_kind: string, _name: string) => boolean): {
        id: string;
        version: string;
        classification?: {
            sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
            compartments: string[];
        } | undefined;
        sharedProperties?: {
            typeClasses?: {
                kind: string;
                name: string;
            }[] | undefined;
            renderHints?: Record<string, string | number | boolean> | undefined;
            status?: "active" | "deprecated" | "experimental" | undefined;
            classification?: {
                sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                compartments: string[];
            } | undefined;
            description: string;
            schema: Record<string, unknown>;
            required: boolean;
            sharedProperty?: string | undefined;
            valueType?: {
                name: string;
                version: string;
            } | undefined;
            struct?: {
                type: string;
                mainField?: string | undefined;
                reducer?: {
                    op: "first" | "last" | "max" | "min";
                    field?: string | undefined;
                } | undefined;
                array?: boolean | undefined;
            } | undefined;
            format?: {
                kind: "currency" | "date" | "number" | "percent" | "text";
                locale?: string | undefined;
                currency?: string | undefined;
                minimumFractionDigits?: number | undefined;
                maximumFractionDigits?: number | undefined;
            } | undefined;
            derived?: import("../ontology/schema.js").DerivedExpression | undefined;
            apiName: string;
        }[] | undefined;
        valueTypes?: {
            typeClasses?: {
                kind: string;
                name: string;
            }[] | undefined;
            renderHints?: Record<string, string | number | boolean> | undefined;
            status?: "active" | "deprecated" | "experimental" | undefined;
            classification?: {
                sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                compartments: string[];
            } | undefined;
            apiName: string;
            version: string;
            description: string;
            schema: Record<string, unknown>;
        }[] | undefined;
        structTypes?: {
            typeClasses?: {
                kind: string;
                name: string;
            }[] | undefined;
            renderHints?: Record<string, string | number | boolean> | undefined;
            status?: "active" | "deprecated" | "experimental" | undefined;
            classification?: {
                sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                compartments: string[];
            } | undefined;
            apiName: string;
            description: string;
            fields: Record<string, Record<string, unknown>>;
            required?: string[] | undefined;
            mainField?: string | undefined;
        }[] | undefined;
        typeGroups?: {
            apiName: string;
            displayName: string;
            description: string;
            objectTypes: string[];
        }[] | undefined;
        agentProfiles?: {
            apiName: string;
            terms: string[];
            objects?: string[] | undefined;
            interfaces?: string[] | undefined;
            actions?: string[] | undefined;
            functions?: string[] | undefined;
            sources?: string[] | undefined;
            links?: string[] | undefined;
            instructions?: {
                action?: string | undefined;
                function?: string | undefined;
                text: string;
            }[] | undefined;
        }[] | undefined;
        imports?: {
            ontology: string;
            version: string;
            digest: string;
            namespace: string;
            document: unknown;
        }[] | undefined;
        objectTypes: {
            typeClasses?: {
                kind: string;
                name: string;
            }[] | undefined;
            renderHints?: Record<string, string | number | boolean> | undefined;
            status?: "active" | "deprecated" | "experimental" | undefined;
            classification?: {
                sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                compartments: string[];
            } | undefined;
            apiName: string;
            displayName: string;
            description: string;
            primaryKey: string;
            titleProperty: string;
            properties: Record<string, {
                typeClasses?: {
                    kind: string;
                    name: string;
                }[] | undefined;
                renderHints?: Record<string, string | number | boolean> | undefined;
                status?: "active" | "deprecated" | "experimental" | undefined;
                classification?: {
                    sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                    compartments: string[];
                } | undefined;
                description: string;
                schema: Record<string, unknown>;
                required: boolean;
                sharedProperty?: string | undefined;
                valueType?: {
                    name: string;
                    version: string;
                } | undefined;
                struct?: {
                    type: string;
                    mainField?: string | undefined;
                    reducer?: {
                        op: "first" | "last" | "max" | "min";
                        field?: string | undefined;
                    } | undefined;
                    array?: boolean | undefined;
                } | undefined;
                format?: {
                    kind: "currency" | "date" | "number" | "percent" | "text";
                    locale?: string | undefined;
                    currency?: string | undefined;
                    minimumFractionDigits?: number | undefined;
                    maximumFractionDigits?: number | undefined;
                } | undefined;
                derived?: import("../ontology/schema.js").DerivedExpression | undefined;
            }>;
            machinery?: {
                states: {
                    name: string;
                    terminal?: boolean | undefined;
                    dwellSeconds?: number | undefined;
                }[];
                transitions: {
                    from: string | null;
                    to: string | null;
                    action?: string | undefined;
                    execution?: {
                        subject: string;
                        parameters?: Record<string, string> | undefined;
                        requires?: {
                            process: string;
                            link?: string | undefined;
                            states: string[];
                            match: "all" | "any";
                        }[] | undefined;
                    } | undefined;
                }[];
                subprocesses?: {
                    link: string;
                    process: string;
                }[] | undefined;
                parallel?: string[] | undefined;
                metrics?: {
                    node?: {
                        label: string;
                        aggregation: {
                            op: "count";
                        } | {
                            op: "avg" | "max" | "min" | "sum";
                            property: string;
                        };
                        decimals?: number | undefined;
                        unit?: string | undefined;
                        colors?: {
                            min: number;
                            color: "amber" | "green" | "red";
                        }[] | undefined;
                    } | undefined;
                    edge?: {
                        label: string;
                        aggregation: {
                            op: "count";
                        } | {
                            op: "avg" | "max" | "min" | "sum";
                            property: string;
                        };
                        decimals?: number | undefined;
                        unit?: string | undefined;
                        colors?: {
                            min: number;
                            color: "amber" | "green" | "red";
                        }[] | undefined;
                    } | undefined;
                } | undefined;
            } | undefined;
            classificationProperty?: string | undefined;
            groups?: string[] | undefined;
            interfaces: Record<string, {
                properties: Record<string, string>;
                links: Record<string, string>;
                actions: Record<string, {
                    action: string;
                    parameters: Record<string, string>;
                }>;
            }>;
        }[];
        interfaceTypes: {
            typeClasses?: {
                kind: string;
                name: string;
            }[] | undefined;
            renderHints?: Record<string, string | number | boolean> | undefined;
            status?: "active" | "deprecated" | "experimental" | undefined;
            classification?: {
                sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                compartments: string[];
            } | undefined;
            apiName: string;
            description: string;
            properties: Record<string, {
                typeClasses?: {
                    kind: string;
                    name: string;
                }[] | undefined;
                renderHints?: Record<string, string | number | boolean> | undefined;
                status?: "active" | "deprecated" | "experimental" | undefined;
                classification?: {
                    sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                    compartments: string[];
                } | undefined;
                description: string;
                schema: Record<string, unknown>;
                required: boolean;
                sharedProperty?: string | undefined;
                valueType?: {
                    name: string;
                    version: string;
                } | undefined;
                struct?: {
                    type: string;
                    mainField?: string | undefined;
                    reducer?: {
                        op: "first" | "last" | "max" | "min";
                        field?: string | undefined;
                    } | undefined;
                    array?: boolean | undefined;
                } | undefined;
                format?: {
                    kind: "currency" | "date" | "number" | "percent" | "text";
                    locale?: string | undefined;
                    currency?: string | undefined;
                    minimumFractionDigits?: number | undefined;
                    maximumFractionDigits?: number | undefined;
                } | undefined;
                derived?: import("../ontology/schema.js").DerivedExpression | undefined;
            }>;
            extends?: string[] | undefined;
            optionalProperties: string[];
            links: Record<string, {
                target: string;
                cardinality: "many" | "one";
                required: boolean;
            }>;
            actions: Record<string, {
                parameters: Record<string, unknown>;
                objectParameters: Record<string, string>;
                required: boolean;
            }>;
        }[];
        linkTypes: {
            typeClasses?: {
                kind: string;
                name: string;
            }[] | undefined;
            renderHints?: Record<string, string | number | boolean> | undefined;
            status?: "active" | "deprecated" | "experimental" | undefined;
            classification?: {
                sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                compartments: string[];
            } | undefined;
            apiName: string;
            description: string;
            from: {
                type: string;
                name: string;
                cardinality: "many" | "one";
            };
            to: {
                type: string;
                name: string;
                cardinality: "many" | "one";
            };
        }[];
        functionTypes: {
            typeClasses?: {
                kind: string;
                name: string;
            }[] | undefined;
            renderHints?: Record<string, string | number | boolean> | undefined;
            status?: "active" | "deprecated" | "experimental" | undefined;
            classification?: {
                sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                compartments: string[];
            } | undefined;
            apiName: string;
            description: string;
            parameters: Record<string, unknown>;
            returns: Record<string, unknown>;
            source?: string | undefined;
            edits?: boolean | undefined;
            version?: string | undefined;
            dependencies?: {
                objectTypes?: string[] | undefined;
                interfaceTypes?: string[] | undefined;
                linkTypes?: string[] | undefined;
                functions?: string[] | undefined;
                dataSources?: string[] | undefined;
                actions?: string[] | undefined;
            } | undefined;
            implementation?: {
                kind: "component";
                sha256: string;
                limits: {
                    fuel: number;
                    memoryMb: number;
                    deadlineMs: number;
                    inputBytes?: number | undefined;
                    outputBytes?: number | undefined;
                };
            } | undefined;
        }[];
        actionTypes: {
            typeClasses?: {
                kind: string;
                name: string;
            }[] | undefined;
            renderHints?: Record<string, string | number | boolean> | undefined;
            status?: "active" | "deprecated" | "experimental" | undefined;
            classification?: {
                sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                compartments: string[];
            } | undefined;
            apiName: string;
            description: string;
            parameters: Record<string, unknown>;
            objectParameters: Record<string, string>;
            submissionCriteria: {
                function: string;
                arguments: Record<string, {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                }>;
                message?: string | undefined;
                functionVersion?: string | undefined;
                executionContext?: "live" | "scenario" | undefined;
            }[];
            rules?: ({
                op: "createObject";
                object: {
                    type: string;
                    id: {
                        parameter: string;
                        path?: string[] | undefined;
                    } | {
                        literal: unknown;
                    };
                };
                properties: Record<string, {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                }>;
            } | {
                op: "editObject";
                object: {
                    parameter: string;
                    path?: string[] | undefined;
                };
                expectedRevision: {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                };
                properties: Record<string, {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                }>;
            } | {
                op: "addLink";
                link: string;
                from: {
                    type: string;
                    id: {
                        parameter: string;
                        path?: string[] | undefined;
                    } | {
                        literal: unknown;
                    };
                };
                to: {
                    type: string;
                    id: {
                        parameter: string;
                        path?: string[] | undefined;
                    } | {
                        literal: unknown;
                    };
                };
            } | {
                op: "removeLink";
                link: string;
                from: {
                    type: string;
                    id: {
                        parameter: string;
                        path?: string[] | undefined;
                    } | {
                        literal: unknown;
                    };
                };
                to: {
                    type: string;
                    id: {
                        parameter: string;
                        path?: string[] | undefined;
                    } | {
                        literal: unknown;
                    };
                };
            } | {
                op: "deleteObject";
                object: {
                    parameter: string;
                    path?: string[] | undefined;
                };
                expectedRevision: {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                };
            } | {
                op: "editStruct";
                object: {
                    parameter: string;
                    path?: string[] | undefined;
                };
                expectedRevision: {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                };
                property: string;
                fields: Record<string, {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                }>;
            } | {
                op: "applyScenario";
                scenario: {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                };
                expectedRevision: {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                };
                objectTypes: string[];
                linkTypes: string[];
            })[] | undefined;
            result?: {
                type: string;
                id: {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                };
            } | undefined;
            function?: string | undefined;
            functionVersion?: string | undefined;
            effects?: ({
                name: string;
                handler: string;
                payload: Record<string, {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                }>;
            } | {
                name: string;
                webhook: {
                    source: string;
                    method: "DELETE" | "PATCH" | "POST" | "PUT";
                    path: string;
                    function?: string | undefined;
                };
                payload: Record<string, {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                }>;
            })[] | undefined;
        }[];
        dataSources: {
            apiName: string;
            objectType: string;
            function: string;
            classification?: {
                sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                compartments: string[];
            } | undefined;
            properties: Record<string, string>;
        }[];
    };
}
/** Administrative configuration, run using the existing database administration role. */
export declare function setGrants(db: Database, subject: string, grants: Grant[], client?: Sql): Promise<void>;
export declare function businessGrants(model: Ontology, sandboxEnabled?: boolean): Grant[];
/** Replace legacy group grants with the fixed subset supported by this release. */
export declare function syncAccountGrants(db: Database, model: Ontology, client?: Sql): Promise<void>;
export declare function syncAccountGrantsAfterActivation(db: Database, activated: Ontology): Promise<void>;
