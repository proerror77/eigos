import type { ConfiguredComponentSources } from './component-source-egress.js';
import type { VersionedFunction } from './functions.js';
import type { EffectHandler } from './effects.js';
import type { SourceProjection } from './sources.js';
export interface RuntimeExtensions {
    functions?: readonly VersionedFunction[];
    effects?: ReadonlyMap<string, EffectHandler>;
    sources?: ReadonlyMap<string, SourceProjection>;
    componentSources?: ConfiguredComponentSources;
}
/** Operator-configured, trusted deployment code. Never accepts a request-supplied module path. */
export declare function loadExtensions(path?: string): Promise<RuntimeExtensions>;
