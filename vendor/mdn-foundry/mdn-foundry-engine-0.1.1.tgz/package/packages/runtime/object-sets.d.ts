import { z } from 'zod';
import { type ObjectData, type ObjectRef } from '../ontology/schema.js';
import { Access } from './access.js';
import { Database, type Sql } from './database.js';
import { PublishedOntology } from './metadata.js';
import { type KernelUse } from './kernel/routing.js';
declare const setQuerySchema: z.ZodObject<{
    type: z.ZodString;
    where: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodNumber, z.ZodBoolean, z.ZodNull]>>>;
    filter: z.ZodOptional<z.ZodPipe<z.ZodUnknown, z.ZodType<import("./query-filter.js").Predicate, unknown, z.core.$ZodTypeInternals<import("./query-filter.js").Predicate, unknown>>>>;
    orderBy: z.ZodOptional<z.ZodArray<z.ZodObject<{
        property: z.ZodString;
        direction: z.ZodDefault<z.ZodEnum<{
            asc: "asc";
            desc: "desc";
        }>>;
    }, z.core.$strict>>>;
    intervalOverlap: z.ZodOptional<z.ZodObject<{
        start: z.ZodString;
        end: z.ZodString;
        from: z.ZodISODateTime;
        until: z.ZodISODateTime;
        includeUnknown: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>>;
    from: z.ZodOptional<z.ZodObject<{
        object: z.ZodObject<{
            type: z.ZodString;
            id: z.ZodString;
        }, z.core.$strict>;
        link: z.ZodString;
        as: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type SetExpression = {
    op: 'query';
    query: z.input<typeof setQuerySchema>;
} | {
    op: 'refs';
    objects: ObjectRef[];
} | {
    op: 'union' | 'intersection';
    sets: SetExpression[];
} | {
    op: 'difference';
    left: SetExpression;
    right: SetExpression;
} | {
    op: 'traverse';
    set: SetExpression;
    path: {
        link: string;
        as?: string;
    }[];
} | {
    op: 'saved';
    id: string;
} | {
    op: 'machinery';
    analysis: Record<string, unknown>;
};
export declare const setExpressionSchema: z.ZodPipe<z.ZodUnknown, z.ZodType<SetExpression, unknown, z.core.$ZodTypeInternals<SetExpression, unknown>>>;
export declare const evaluateSetSchema: z.ZodObject<{
    set: z.ZodPipe<z.ZodUnknown, z.ZodType<SetExpression, unknown, z.core.$ZodTypeInternals<SetExpression, unknown>>>;
    view: z.ZodOptional<z.ZodString>;
    limit: z.ZodDefault<z.ZodNumber>;
    cursor: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export declare const aggregateSetSchema: z.ZodObject<{
    set: z.ZodPipe<z.ZodUnknown, z.ZodType<SetExpression, unknown, z.core.$ZodTypeInternals<SetExpression, unknown>>>;
    view: z.ZodOptional<z.ZodString>;
    groupBy: z.ZodDefault<z.ZodArray<z.ZodString>>;
    metrics: z.ZodRecord<z.ZodString, z.ZodDiscriminatedUnion<[z.ZodObject<{
        op: z.ZodLiteral<"count">;
        property: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        op: z.ZodEnum<{
            avg: "avg";
            max: "max";
            min: "min";
            sum: "sum";
        }>;
        property: z.ZodString;
    }, z.core.$strict>], "op">>;
}, z.core.$strict>;
export declare const evaluateSetViewSchema: z.ZodObject<{
    set: z.ZodPipe<z.ZodUnknown, z.ZodType<SetExpression, unknown, z.core.$ZodTypeInternals<SetExpression, unknown>>>;
    view: z.ZodOptional<z.ZodString>;
    limit: z.ZodDefault<z.ZodNumber>;
    cursor: z.ZodOptional<z.ZodString>;
    scenarioId: z.ZodOptional<z.ZodUUID>;
}, z.core.$strict>;
export declare const aggregateSetViewSchema: z.ZodObject<{
    set: z.ZodPipe<z.ZodUnknown, z.ZodType<SetExpression, unknown, z.core.$ZodTypeInternals<SetExpression, unknown>>>;
    view: z.ZodOptional<z.ZodString>;
    groupBy: z.ZodDefault<z.ZodArray<z.ZodString>>;
    metrics: z.ZodRecord<z.ZodString, z.ZodDiscriminatedUnion<[z.ZodObject<{
        op: z.ZodLiteral<"count">;
        property: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>, z.ZodObject<{
        op: z.ZodEnum<{
            avg: "avg";
            max: "max";
            min: "min";
            sum: "sum";
        }>;
        property: z.ZodString;
    }, z.core.$strict>], "op">>;
    scenarioId: z.ZodOptional<z.ZodUUID>;
}, z.core.$strict>;
export declare const saveSetSchema: z.ZodObject<{
    id: z.ZodOptional<z.ZodUUID>;
    revision: z.ZodOptional<z.ZodNumber>;
    requestId: z.ZodString;
    name: z.ZodString;
    mode: z.ZodEnum<{
        dynamic: "dynamic";
        static: "static";
    }>;
    set: z.ZodPipe<z.ZodUnknown, z.ZodType<SetExpression, unknown, z.core.$ZodTypeInternals<SetExpression, unknown>>>;
    readers: z.ZodDefault<z.ZodArray<z.ZodString>>;
}, z.core.$strict>;
export declare const listSetsSchema: z.ZodObject<{
    cursor: z.ZodOptional<z.ZodUUID>;
    limit: z.ZodDefault<z.ZodNumber>;
}, z.core.$strict>;
export declare function initializeObjectSets(db: Database): Promise<void>;
/** Object sets reuse the live object's authorization and Scenario view for every evaluation. */
export declare class ObjectSets {
    private readonly db;
    private readonly maximumObjects;
    private readonly kernels;
    /** `kernels` sets how evaluation uses the query kernel; by default from EIGOS_KERNEL and the process's kernels. */
    constructor(db: Database, maximumObjects?: number, kernels?: KernelUse);
    /**
     * Whether an evaluation may use the kernel. It may not inside a caller's transaction, whose own writes the kernel
     * cannot see; while decision evidence records each read; with a smaller evaluation limit; or outside
     * the principal owner's context when owner isolation is on. The kernel reads past row security, so it answers only
     * where row security lets the reference read the owner's rows.
     */
    private kernelAllowed;
    private kernelAnswer;
    private kernelIdentity;
    private snapshot;
    private saved;
    private metadata;
    private resolve;
    private project;
    private storedPlan;
    members(access: Access, model: PublishedOntology, set: SetExpression, client: Sql): Promise<ObjectRef[]>;
    evaluate(access: Access, model: PublishedOntology, raw: unknown, client?: Sql): Promise<{
        items: ObjectData[];
        total: number;
        cursor: string | undefined;
    }>;
    private evaluateSet;
    /** One page from the kernel, or undefined when the reference evaluates it. */
    private routedEvaluate;
    private shadow;
    private shadowEvaluate;
    private referenceEvaluate;
    aggregate(access: Access, model: PublishedOntology, raw: unknown, client?: Sql): Promise<{
        count: number;
        items: {
            group: Record<string, unknown>;
            metrics: Record<string, number | null>;
        }[] | {
            group: {};
            metrics: {
                [k: string]: number | null;
            };
        }[];
    }>;
    private aggregateSet;
    private referenceAggregate;
    save(access: Access, model: PublishedOntology, raw: unknown): Promise<{
        id: string;
        name: string;
        mode: "dynamic" | "static";
        revision: number;
        owned: boolean;
        set?: SetExpression | undefined;
        readers?: string[] | undefined;
    }>;
    get(access: Access, model: PublishedOntology, id: string): Promise<{
        id: string;
        name: string;
        mode: "dynamic" | "static";
        revision: number;
        owned: boolean;
        set?: SetExpression | undefined;
        readers?: string[] | undefined;
    }>;
    list(access: Access, model: PublishedOntology, raw?: unknown): Promise<{
        items: {
            id: string;
            name: string;
            mode: "dynamic" | "static";
            revision: number;
            owned: boolean;
            set?: SetExpression | undefined;
            readers?: string[] | undefined;
        }[];
        cursor: string | undefined;
    }>;
    remove(access: Access, model: PublishedOntology, id: string, revision: number): Promise<{
        id: string;
        deleted: boolean;
    }>;
}
export {};
