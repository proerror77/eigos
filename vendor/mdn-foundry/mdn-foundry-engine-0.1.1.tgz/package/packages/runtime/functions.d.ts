import { type Principal, type ExecutionActor } from '../core/identity.js';
import type { ComponentFunctions } from './component-functions.js';
import type { ProviderBudgets } from './provider-budgets.js';
import type { FunctionInvocations } from './function-invocations.js';
import { type Ontology } from '../ontology/model.js';
import { Objects } from './objects.js';
import type { Tasks, Task } from './tasks.js';
import { type ObjectRef, type OntologyDocument } from '../ontology/schema.js';
import type { PublishedOntology } from './metadata.js';
import type { Sql } from './database.js';
import type { Access } from './access.js';
import type { ActionEffect } from './effects.js';
export type ScenarioEvaluation = {
    client: Sql;
    evaluatedAt: number;
};
export interface FunctionContext {
    scenarioEvaluation?: ScenarioEvaluation;
    principal: Principal;
    objects: Pick<Objects, 'model' | 'access' | 'read' | 'query' | 'follow' | 'matchesSource'>;
    signal: AbortSignal;
    taskId?: string;
    execution?: {
        task: Task;
        tasks: Tasks;
        executor?: ExecutionActor;
    };
    operationId?: string;
    directAction?: boolean;
    validateScenarioAction?: (live: Objects, action: string, input: Record<string, unknown>) => Promise<void>;
    assertCurrent?: (client?: Sql) => Promise<void>;
    /** An existing provider operation must persist its dispatch claim in this transaction. */
    assertDispatch?: (client: Sql) => Promise<void>;
    /** Queue a declared effect with the Action's eventual atomic commit. */
    deferEffect?: (effect: ActionEffect) => void;
    /**
     * Stages the edits of an Action's edit Function, which `write` applies in the Action's commit. A `write` that returns
     * a reference decides the Action's result there, as a component Function does once it has run.
     */
    edit?: (result: ObjectRef, write: (objects: Objects) => Promise<void | ObjectRef>) => ObjectRef;
}
export type FunctionHandler = ((input: Record<string, unknown>, context: FunctionContext) => unknown | Promise<unknown>) & {
    scenarioPARead?: true;
    scenarioEvaluation?: true;
};
export declare const withScenarioPARead: (handler: FunctionHandler) => FunctionHandler;
export declare const withScenarioEvaluation: (handler: FunctionHandler) => FunctionHandler;
type Definition = OntologyDocument['functionTypes'][number];
export interface VersionedFunction {
    definition: Definition & {
        version: string;
    };
    /** Immutable build/artifact identity. A changed implementation requires a new version. */
    implementationId: string;
    handler: FunctionHandler;
}
export declare class Functions {
    private readonly components?;
    private readonly budgets?;
    private readonly invocations?;
    private readonly registered;
    constructor(handlers: ReadonlyMap<string, FunctionHandler>, definitions: OntologyDocument['functionTypes'], versions?: readonly VersionedFunction[], components?: ComponentFunctions | undefined, budgets?: ProviderBudgets | undefined, invocations?: FunctionInvocations | undefined);
    versions(): {
        name: string;
        version: string | null;
        binding: string;
    }[];
    bindings(model: Ontology): Record<string, string>;
    /** Checks a release's component Functions before it is prepared. */
    checkRelease(model: Ontology): Promise<void>;
    formatWebhook(model: PublishedOntology, name: string, input: Record<string, unknown>, access: Access, signal: AbortSignal): Promise<unknown>;
    supportsScenarioEvaluation(model: PublishedOntology, name: string): boolean;
    requireScenarioEvaluation(model: PublishedOntology, name: string): void;
    invoke(model: PublishedOntology, name: string, input: Record<string, unknown>, context: FunctionContext): Promise<unknown>;
    private measure;
    private componentSourceBinding;
    /** A Function implemented by a WebAssembly component: the function host runs it on the validated parameters. */
    private invokeComponent;
}
export {};
