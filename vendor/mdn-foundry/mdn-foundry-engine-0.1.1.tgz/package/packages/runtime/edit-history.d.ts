import { z } from 'zod';
import type { ObjectRef } from '../ontology/schema.js';
import type { Database, Sql } from './database.js';
import type { Objects } from './objects.js';
import type { Access } from './access.js';
import type { PublishedOntology } from './metadata.js';
export declare const conflictPolicySchema: z.ZodEnum<{
    latest_value: "latest_value";
    user_wins: "user_wins";
}>;
type Properties = Record<string, unknown>;
export declare function initializeEditHistory(db: Database): Promise<void>;
/**
 * Journals the relationships a statement's CTE returned (type, from_type, from_id, to_type, to_id), with the
 * graph's change identity. Appends its parameters to `values`; `projection` and `owner` are placeholders already bound.
 */
export declare function journalLinks(graph: Objects, operation: 'link' | 'unlink', rows: string, projection: string, owner: string, values: unknown[], source?: string | null): string;
export declare function setConflictPolicy(db: Database, access: Access, model: PublishedOntology, type: string, policy: unknown): Promise<{
    type: string;
    policy: unknown;
}>;
/** Called after the live mutation, in the same transaction. Scenario deltas are journaled when merged. */
export declare function recordObjectEdit(graph: Objects, ref: ObjectRef, before: Properties | null, after: Properties | null, changedFields?: Properties, kind?: 'create' | 'edit' | 'delete'): Promise<void>;
/** One source observation of an object, with the stored value it may replace. */
export interface SourceObservation {
    ref: ObjectRef;
    incoming: Properties | null;
    before: Properties | null;
}
/** The value to store for an observed object. A stale observation leaves the stored value current. */
export interface ResolvedSource {
    value: Properties | null;
    current: boolean;
}
/**
 * Persists the source baselines of a batch and resolves each object with its user edits, in input order.
 * Each object needs the same decisions as a single observation; the statements are shared by the batch.
 * The caller writes the returned object values in the same transaction.
 */
export declare function resolveSourceEdits(graph: Objects, observations: readonly SourceObservation[], source?: string, observedAt?: string): Promise<ResolvedSource[]>;
export declare class EditHistory {
    private readonly db;
    private readonly archive;
    /** `archive` reads history that commit log retention archived; without it, only the tables' history is read. */
    constructor(db: Database, archive?: {
        dir: string;
        codec: import("./log-retention.js").ArchiveCodec;
    } | undefined);
    read(graph: Objects, ref: ObjectRef, after?: string, limit?: number): Promise<{
        items: {
            sequence: string;
            operation: string;
            source: string | null;
            before: Record<string, unknown> | null;
            after: Record<string, unknown> | null;
            actor: string;
            at: Date;
            release: string;
            action: string | null;
            requestId: string | null;
            taskId: string | null;
            observedAt: Date | null;
            executor: {
                kind: string;
                id: string;
            } | null;
        }[];
        cursor: string | undefined;
        archive?: "unavailable" | undefined;
    }>;
    /** The object's archived history after `after`, in this ontology's releases, as the tables would return it. */
    private archived;
}
/** A replacement publication carries conflict baselines and overlays forward with the resolved objects. */
export declare function copyEditState(db: Database, from: string, to: string, client: Sql, types?: readonly string[]): Promise<void>;
export {};
