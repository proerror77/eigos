import { accountActionsGroup, accountGroup } from './accounts.js';
import { AsyncLocalStorage } from 'node:async_hooks';
import { z } from 'zod';
import { digest, PermissionDenied } from '../core/identity.js';
import { betaQueries } from '../ontology/beta-queries.js';
import { allowsClassification, classificationSchema, combineClassification, internalClassification, marksClassification, sensitivityRank } from '../ontology/classification.js';
import { documentChunkType, documentType } from '../ontology/documents.js';
import { processLogTarget } from '../ontology/process-definition.js';
import { isSandboxResource } from '../ontology/sandbox.js';
import { ModelEgressDenied } from './model-egress.js';
import { markingsOf, permits, policySql } from './security.js';
export const permissionSchema = z.enum(['view_definition', 'edit_definition', 'manage_definition', 'view_objects', 'view_property', 'apply_action', 'execute_function', 'read_source', 'ingest_source', 'dispatch_source', 'migrate_objects']);
export const grantSchema = z.strictObject({ resource: z.string().min(1).max(300), permission: permissionSchema });
export class TaskResult {
    value;
    permissions;
    constructor(value, permissions) {
        this.value = value;
        this.permissions = permissions;
    }
}
export const resource = (ontology, kind, name) => `${ontology}/${kind}/${name}`;
export { PermissionDenied } from '../core/identity.js';
const businessOntology = 'Eigos';
const accountSearchActions = new Map(betaQueries.actions);
const accountGrantKeys = new Set([
    'view_definition:Eigos',
    ...betaQueries.sources.map(name => `read_source:Eigos/source/${name}`),
    ...betaQueries.objects.map(name => `view_objects:Eigos/object/${name}`),
    ...[...betaQueries.functions,
        ...accountSearchActions.values()].map(name => `execute_function:Eigos/function/${name}`),
    ...[...accountSearchActions.keys()].map(name => `apply_action:Eigos/action/${name}`),
]);
const grantKey = (grant) => `${grant.permission}:${grant.resource}`;
const accountActionPermissions = new Set(['view_objects', 'apply_action', 'execute_function', 'read_source']);
/** Resource grants and object/property visibility, independent of OAuth transport scopes. */
export class Access {
    db;
    inheritedClearance;
    policies = new Map();
    security = { subject: '', groups: [], markings: [] };
    securityDigest = '';
    readMarkings = new Set();
    grants = new Set();
    properties = new Set();
    required = new Map();
    data = new Map();
    observedClassification;
    egress = new AsyncLocalStorage();
    principal;
    constructor(db, principal, inheritedClearance) {
        this.db = db;
        this.inheritedClearance = inheritedClearance;
        this.principal = Object.freeze({ owner: principal.owner, scopes: Object.freeze([...principal.scopes]), clientId: principal.clientId, memberAccess: principal.memberAccess });
    }
    observeClassification(label) {
        if (!label)
            return;
        this.observedClassification = combineClassification(this.observedClassification, label);
        const scope = this.egress.getStore();
        if (scope)
            scope.classification = combineClassification(scope.classification, label);
    }
    async measureEgress(operation, clearance = this.modelClearance()) {
        const scope = { classification: internalClassification, requirements: new Map(), clearance };
        const result = await this.egress.run(scope, operation);
        return { result, classification: scope.classification, requirements: [...scope.requirements.values()] };
    }
    modelClearance() { return this.egress.getStore()?.clearance ?? this.inheritedClearance; }
    async fork(client) {
        const child = new Access(this.db, this.principal, this.modelClearance());
        await child.refresh(client);
        return child;
    }
    canSeeModelData(label) {
        const clearance = this.modelClearance();
        return !clearance || !label || allowsClassification(clearance, label);
    }
    useModelData(label) {
        if (!this.canSeeModelData(label))
            throw new ModelEgressDenied();
        this.observeClassification(label);
    }
    recordData(key, requirement) {
        this.data.set(key, requirement);
        this.egress.getStore()?.requirements.set(key, requirement);
    }
    async canDisclose(requirements) {
        return this.canReturn(await this.requirementsAfterMerges(requirements));
    }
    needsEgressRead(model, type) {
        const definition = model.object(type);
        return Boolean(model.document.classification || definition.classification || definition.classificationProperty
            || Object.values(definition.properties).some(field => field.classification) || this.policies.has(model.document.id + '/' + type) || !this.canRead(model, type)
            || processLogTarget(model, type) || type === documentChunkType);
    }
    rowClassification(model, type, properties) {
        const definition = model.object(type), key = definition.classificationProperty;
        const dynamic = key && properties[key] !== undefined ? classificationSchema.parse(properties[key]) : undefined;
        const markings = markingsOf(this.policies.get(model.document.id + '/' + type), properties);
        return combineClassification(model.document.classification, definition.classification, dynamic, marksClassification(markings));
    }
    observeRowClassification(model, type, properties) {
        this.observeClassification(this.rowClassification(model, type, properties));
    }
    rowModelSql(model, type, values, column, markingsProperty) {
        const clearance = this.modelClearance();
        if (!clearance)
            return 'TRUE';
        const definition = model.object(type);
        if (!allowsClassification(clearance, combineClassification(model.document.classification, definition.classification)))
            return 'FALSE';
        const rank = sensitivityRank[clearance.sensitivity];
        const available = Object.entries(sensitivityRank).flatMap(([label, level]) => level <= rank ? [label] : []);
        const bind = (value) => { values.push(value); return '$' + values.length; };
        const clauses = [];
        if (definition.classificationProperty) {
            const label = `${column}->${bind(definition.classificationProperty)}::text`;
            clauses.push(`(${label} IS NULL OR ((${label}->>'sensitivity')=ANY(${bind(available)}::text[])
        AND COALESCE(${label}->'compartments','[]'::jsonb)<@${bind(JSON.stringify(clearance.compartments))}::jsonb))`);
        }
        if (markingsProperty) {
            const markings = `${column}->${bind(markingsProperty)}::text`;
            const availableMarks = [...available, ...clearance.compartments.filter(name => !Object.hasOwn(sensitivityRank, name))];
            clauses.push(`COALESCE(NULLIF(${markings},'null'::jsonb),'[]'::jsonb)<@${bind(JSON.stringify(availableMarks))}::jsonb`);
        }
        return clauses.join(' AND ') || 'TRUE';
    }
    get runtimeId() { return this.db.runtimeId; }
    static async load(db, principal, client) {
        if (!principal.owner)
            throw new PermissionDenied('Authenticated owner is required');
        const access = new Access(db, principal);
        await access.refresh(client);
        return access;
    }
    async refresh(client) {
        const grantSubject = this.principal.memberAccess
            ? `subject IN ($2,$3,$4) AND EXISTS (SELECT 1 FROM ${this.db.schema}.accounts WHERE owner=$1 AND status='active' AND approved_at IS NOT NULL AND revoked_at IS NULL)`
            : `(subject=$1 OR subject IN (SELECT 'group:'||name FROM ${this.db.schema}.security_memberships WHERE subject=$1 AND kind='group'))`;
        const defaultGroup = 'group:' + accountGroup;
        const subjects = this.principal.memberAccess
            ? [this.principal.owner, defaultGroup, 'group:' + accountActionsGroup, 'account-actions:' + this.principal.owner] : [this.principal.owner];
        const result = await this.db.query(`SELECT
      (SELECT coalesce(jsonb_agg(jsonb_build_object('resource',resource,'permission',permission,'subject',subject)),'[]')
        FROM ${this.db.schema}.resource_grants WHERE ${grantSubject}) AS grants,
      (SELECT coalesce(jsonb_agg(ontology||'/property/'||type||'/'||property),'[]') FROM ${this.db.schema}.property_security) AS properties,
      (SELECT coalesce(jsonb_agg(jsonb_build_object('ontology',ontology,'type',type,'policy',policy)),'[]') FROM ${this.db.schema}.object_policies) AS policies,
      (SELECT coalesce(jsonb_agg(jsonb_build_object('kind',kind,'name',name)),'[]') FROM ${this.db.schema}.security_memberships WHERE subject=$1) AS memberships,
      (SELECT coalesce(jsonb_agg(jsonb_build_object('ontology',ontology,'resource',resource,'project',project)),'[]') FROM ${this.db.schema}.ontology_resource_projects) AS projects`, subjects, client);
        const grants = result.rows[0].grants;
        this.grants = new Set(grants.filter(grant => !this.principal.memberAccess || (grant.subject === defaultGroup
            ? accountGrantKeys.has(grantKey(grant))
            : grant.resource.startsWith(businessOntology + '/') && accountActionPermissions.has(grant.permission))).map(grantKey));
        for (const assignment of result.rows[0].projects) {
            for (const permission of ['view_definition', 'edit_definition', 'manage_definition']) {
                if (this.grants.has(`${permission}:${assignment.ontology}/project/${assignment.project}`))
                    this.grants.add(`${permission}:${assignment.resource}`);
            }
        }
        this.properties = new Set(result.rows[0].properties);
        this.policies = new Map(result.rows[0].policies.map((p) => [p.ontology + '/' + p.type, p.policy]));
        const memberships = result.rows[0].memberships;
        this.security = { subject: this.principal.owner, groups: memberships.filter(m => m.kind === 'group').map(m => m.name).sort(), markings: memberships.filter(m => m.kind === 'marking').map(m => m.name).sort() };
        this.securityDigest = digest({ policies: [...this.policies].sort(), security: this.security });
        for (const requirement of this.required.values())
            if (!this.allows(requirement))
                throw new PermissionDenied('Permission changed during execution');
    }
    allows({ permission, resource: target, ontology, security }) {
        if (security && security !== this.securityDigest)
            return false;
        if (permission === 'view_property' && !this.properties.has(target))
            return true;
        const permissions = permission === 'view_definition' ? ['view_definition', 'edit_definition', 'manage_definition']
            : permission === 'edit_definition' ? ['edit_definition', 'manage_definition'] : [permission];
        return permissions.some(p => this.grants.has(`${p}:${target}`) || permission.endsWith('_definition') && this.grants.has(`${p}:${ontology}`));
    }
    require(ontology, permission, target, data = false) {
        const requirement = { ontology, permission, resource: target };
        if (!this.allows(requirement))
            throw new PermissionDenied(`Permission required: ${permission}`);
        const key = `${permission}:${target}`;
        this.required.set(key, requirement);
        if (data)
            this.recordData(key, requirement);
    }
    definition(model, kind, name, data = false) {
        this.require(model.document.id, 'view_definition', resource(model.document.id, kind, name), data);
        if (kind === 'link')
            this.useModelData(model.links.get(name)?.classification);
    }
    /**
     * Everything this principal's object and property visibility depends on besides the objects themselves: resource
     * grants, property security, object policies and security memberships. It changes whenever visibility can change.
     */
    get visibilityDigest() {
        return digest({ grants: [...this.grants].sort(), properties: [...this.properties].sort(), security: this.securityDigest });
    }
    canDefine(model, kind, name) { return this.allows({ ontology: model.document.id, permission: 'view_definition', resource: resource(model.document.id, kind, name) }); }
    available(model, kind, name) {
        return this.db.sandboxEnabled || !isSandboxResource(model, kind, name);
    }
    requireAvailable(model, kind, name) {
        if (!this.available(model, kind, name))
            throw new PermissionDenied('Capability requires explicit sandbox development mode');
    }
    canRead(model, type) {
        return this.available(model, 'object', type) && this.canDefine(model, 'object', type)
            && this.allows({ ontology: model.document.id, permission: 'view_objects', resource: resource(model.document.id, 'object', type) });
    }
    /**
     * The rows of the type this principal may read, as rules another query engine can evaluate: `rowSql` in structured
     * form, with the same type-level effects. Document chunks and process logs filter rows through other objects, so
     * only the reference evaluates them.
     */
    rowRule(model, type) {
        this.trackSecurity(model, type);
        const definitionLabel = model.object(type).classification;
        if (!this.canSeeModelData(definitionLabel))
            return { kind: 'deny' };
        this.observeClassification(definitionLabel);
        if (type === documentChunkType || processLogTarget(model, type))
            return { kind: 'unsupported' };
        const key = model.document.id + '/' + type, policy = this.policies.get(key);
        const rule = { kind: 'rows', policy: policy?.read, markingsProperty: policy?.markingsProperty,
            tracked: this.policies.has(key), markings: [...this.security.markings], subject: this.security.subject, groups: [...this.security.groups] };
        const clearance = this.modelClearance();
        if (clearance) {
            const definition = model.object(type);
            if (!allowsClassification(clearance, combineClassification(model.document.classification, definition.classification)))
                return { kind: 'deny' };
            const rank = sensitivityRank[clearance.sensitivity];
            const available = Object.entries(sensitivityRank).flatMap(([label, level]) => level <= rank ? [label] : []);
            rule.clearance = { rank, compartments: [...clearance.compartments], classificationProperty: definition.classificationProperty,
                availableMarks: [...available, ...clearance.compartments.filter(name => !Object.hasOwn(sensitivityRank, name))] };
        }
        return rule;
    }
    /** A cell's visibility as `cellRule` decides it, without recording the check. */
    cellVisibility(model, type, field) {
        const classification = model.object(type).properties[field]?.classification;
        const target = resource(model.document.id, 'property', `${type}/${field}`);
        if (!this.canSeeModelData(classification) || !this.allows({ ontology: model.document.id, permission: 'view_property', resource: target }))
            return { visible: false };
        return { visible: true, policy: this.policies.get(model.document.id + '/' + type)?.properties[field] };
    }
    /** A cell's visibility for this principal as `cellSql` evaluates it, with the same effects. */
    cellRule(model, type, field) {
        const classification = model.object(type).properties[field]?.classification;
        if (!this.canSeeModelData(classification) || !this.property(model, type, field))
            return { visible: false };
        this.observeClassification(classification);
        return { visible: true, policy: this.policies.get(model.document.id + '/' + type)?.properties[field] };
    }
    /** Records the row dependencies the reference records for every row of a policy-bound type it reads. */
    trackRows(model, type, ids) {
        const key = model.object(type).primaryKey;
        for (const id of ids)
            this.trackRow(model, type, { [key]: id });
    }
    /** Records the markings of rows read elsewhere, as reading each row does. */
    observeReadMarkings(markings) { for (const marking of markings)
        this.readMarkings.add(marking); }
    /** Whether a property's cells are subject to property security, so its visibility can differ per object. */
    hasPropertySecurity(model, type, property) { return this.properties.has(`${model.document.id}/property/${type}/${property}`); }
    hasObjectPolicy(model, type) { return type === documentChunkType || Boolean(model.object(type).classificationProperty) || this.policies.has(model.document.id + '/' + type); }
    workbenchRole(ontology) {
        if (this.allows({ ontology, resource: ontology, permission: 'manage_definition' }))
            return 'admin';
        if (this.allows({ ontology, resource: ontology, permission: 'edit_definition' }) ||
            [...this.grants].some(grant => grant.startsWith('edit_definition:' + ontology + '/project/') ||
                grant.startsWith('manage_definition:' + ontology + '/project/')))
            return 'editor';
        return 'member';
    }
    read(model, type) {
        this.requireAvailable(model, 'object', type);
        this.definition(model, 'object', type);
        this.require(model.document.id, 'view_objects', resource(model.document.id, 'object', type), true);
    }
    property(model, type, property) {
        const target = resource(model.document.id, 'property', `${type}/${property}`);
        if (!this.allows({ ontology: model.document.id, permission: 'view_property', resource: target }))
            return false;
        this.require(model.document.id, 'view_property', target, true);
        return true;
    }
    adoptReads(other) {
        if (other.principal.owner !== this.principal.owner)
            throw new PermissionDenied('Read context owner differs');
        for (const [key, value] of other.data)
            this.recordData(key, structuredClone(value));
        for (const [key, value] of other.required)
            this.required.set(key, structuredClone(value));
        for (const marking of other.readMarkings)
            this.readMarkings.add(marking);
        this.observeClassification(other.observedClassification);
    }
    readMarkingsSnapshot() {
        return [...this.readMarkings].sort();
    }
    /** Restore the security context of persisted inputs without recomputing their frozen values. */
    async restoreReads(requirements, markings, client) {
        if (!(await this.canReturn(requirements, client))) {
            throw new PermissionDenied('Frozen input permissions changed');
        }
        if (markings.some(marking => !this.security.markings.includes(marking))) {
            throw new PermissionDenied('Frozen input markings are unavailable');
        }
        for (const requirement of requirements) {
            const key = 'restored:' + digest(requirement);
            const copy = structuredClone(requirement);
            this.recordData(key, copy);
            this.required.set(key, copy);
        }
        for (const marking of markings)
            this.readMarkings.add(marking);
        if (markings.length)
            this.observeClassification(marksClassification(markings));
    }
    trackSecurity(model, type) {
        const r = { ontology: model.document.id, permission: 'view_objects', resource: resource(model.document.id, 'object', type), security: this.securityDigest };
        this.required.set('security:' + r.resource, r);
        this.recordData('security:' + r.resource, r);
    }
    trackRow(model, type, properties, field, force = false) {
        // Virtual, immutable log rows inherit a recorded dependency on their business object.
        if (processLogTarget(model, type))
            return;
        const publication = model;
        if (!force && !this.policies.has(model.document.id + '/' + type) && !publication.scenario && type !== 'OntologyScenario')
            return;
        const id = properties[model.object(type).primaryKey];
        if (!publication.projection || typeof id !== 'string')
            throw new PermissionDenied('A published object identity is required for policy evaluation');
        const key = 'row:' + digest([model.document.id, publication.projection, publication.scenario, type, id]);
        const previous = this.data.get(key)?.row;
        const fields = [...new Set([...(previous?.fields ?? []), ...(field ? [field] : [])])];
        const row = { projection: publication.projection, type, id, fields, ...(publication.scenario ? { scenario: publication.scenario } : {}) };
        const requirement = { ontology: model.document.id, permission: 'view_objects', resource: resource(model.document.id, 'object', type), row };
        this.recordData(key, requirement);
    }
    async rowsAllowed(requirements, client) {
        const dependencies = requirements.filter((requirement) => Boolean(requirement.row));
        if (!dependencies.length)
            return true;
        const rows = await this.db.query(`SELECT input.ordinal,CASE WHEN input.type='OntologyScenario' THEN jsonb_build_object('id',meta.id::text,'name',meta.name,'owner',meta.owner,'state',meta.state,'release',meta.release,'revision',meta.revision,'expiresAt',to_char(meta.expires_at AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'),'kind',meta.kind,'description',meta.description) WHEN delta.scenario_id IS NULL THEN object.properties ELSE delta.properties END AS properties,
      CASE WHEN input.type='OntologyScenario' THEN meta.id IS NOT NULL AND meta.kind='persisted' AND meta.release=active.release AND meta.expires_at>now() AND (meta.owner=$1 OR meta.readers ? $1)
      ELSE input.scenario IS NULL OR (scenario.id IS NOT NULL AND scenario.state='open' AND scenario.release=active.release AND scenario.expires_at>now() AND (scenario.session_id IS NULL OR (session.id IS NOT NULL AND session.closed_at IS NULL AND session.expires_at>now()))) END AS current
      FROM jsonb_to_recordset($2::jsonb) AS input(ordinal integer,ontology text,projection text,type text,id text,scenario uuid)
      LEFT JOIN ${this.db.schema}.ontology active ON active.id=input.ontology
      LEFT JOIN ${this.db.schema}.releases current_release ON current_release.digest=active.release
      LEFT JOIN ${this.db.schema}.objects object ON object.projection=CASE WHEN input.scenario IS NULL THEN current_release.projection ELSE input.projection END AND object.owner=$1 AND object.type=input.type AND object.id=input.id
      LEFT JOIN ${this.db.schema}.scenarios scenario ON scenario.id=input.scenario AND scenario.owner=$1
      LEFT JOIN ${this.db.schema}.scenario_sessions session ON session.id=scenario.session_id
      LEFT JOIN ${this.db.schema}.scenarios meta ON input.type='OntologyScenario' AND meta.id::text=input.id
      LEFT JOIN ${this.db.schema}.scenario_objects delta ON delta.scenario_id=input.scenario AND delta.owner=$1 AND delta.type=input.type AND delta.id=input.id`, [this.principal.owner, JSON.stringify(dependencies.map((requirement, ordinal) => ({ ordinal, ontology: requirement.ontology, ...requirement.row })))], client);
        return rows.rows.length === dependencies.length && rows.rows.every(row => {
            const requirement = dependencies[Number(row.ordinal)];
            if (!row.current || !row.properties)
                return false;
            const policy = this.policies.get(requirement.ontology + '/' + requirement.row.type);
            if (!permits(policy?.read, row.properties, this.security))
                return false;
            if (!markingsOf(policy, row.properties).every(marking => this.security.markings.includes(marking)))
                return false;
            return requirement.row.fields.every(field => {
                const target = resource(requirement.ontology, 'property', requirement.row.type + '/' + field);
                return this.allows({ ontology: requirement.ontology, permission: 'view_property', resource: target }) && permits(policy?.properties[field], row.properties, this.security);
            });
        });
    }
    rowAllowed(model, type, properties) {
        this.trackSecurity(model, type);
        const policy = this.policies.get(model.document.id + '/' + type);
        return (!this.modelClearance() || this.canSeeModelData(this.rowClassification(model, type, properties)))
            && permits(policy?.read, properties, this.security) && markingsOf(policy, properties).every(m => this.security.markings.includes(m));
    }
    readRow(model, type, properties, track = false) {
        this.read(model, type);
        if (!this.rowAllowed(model, type, properties))
            throw new PermissionDenied('Object policy denied access');
        this.observeRowClassification(model, type, properties);
        this.trackRow(model, type, properties, undefined, track);
        for (const marking of markingsOf(this.policies.get(model.document.id + '/' + type), properties))
            this.readMarkings.add(marking);
    }
    sourceRow(model, type, properties) {
        this.read(model, type);
        if (!this.rowAllowed(model, type, properties))
            throw new PermissionDenied('Source object policy denied access');
        this.trackRow(model, type, properties);
    }
    visibleCell(model, type, field, properties) {
        const classification = model.object(type).properties[field]?.classification;
        const allowed = this.canSeeModelData(classification) && this.property(model, type, field) && permits(this.policies.get(model.document.id + '/' + type)?.properties[field], properties, this.security);
        if (allowed)
            this.observeClassification(classification);
        return allowed;
    }
    cell(model, type, field, properties) {
        const allowed = this.visibleCell(model, type, field, properties);
        if (allowed)
            this.trackRow(model, type, properties, field);
        return allowed;
    }
    /** A locked historical draft snapshot has current policy dependencies, not a fictitious live row. */
    maskHistoricalSnapshot(model, type, properties) {
        this.read(model, type);
        if (!this.rowAllowed(model, type, properties))
            return null;
        this.observeRowClassification(model, type, properties);
        for (const marking of markingsOf(this.policies.get(model.document.id + '/' + type), properties))
            this.readMarkings.add(marking);
        return Object.fromEntries(Object.entries(properties).filter(([field]) => model.object(type).properties[field])
            .map(([field, value]) => [field, this.visibleCell(model, type, field, properties) ? value : null]));
    }
    rowSql(model, type, values, column = 'properties') {
        this.trackSecurity(model, type);
        const definitionLabel = model.object(type).classification;
        if (!this.canSeeModelData(definitionLabel))
            return 'FALSE';
        this.observeClassification(definitionLabel);
        const policy = this.policies.get(model.document.id + '/' + type);
        const clauses = [policySql(policy?.read, values, this.security, column), this.rowModelSql(model, type, values, column, policy?.markingsProperty)];
        if (policy?.markingsProperty) {
            values.push(policy.markingsProperty);
            const field = `${column}->$${values.length}::text`;
            values.push(JSON.stringify(this.security.markings));
            clauses.push(`COALESCE(NULLIF(${field},'null'::jsonb),'[]'::jsonb) <@ $${values.length}::jsonb`);
        }
        if (type === documentChunkType) {
            if (!this.canRead(model, documentType))
                return 'FALSE';
            this.read(model, documentType);
            const publication = model;
            values.push(this.principal.owner, publication.projection, documentType);
            const [owner, projection, parentType] = [values.length - 2, values.length - 1, values.length];
            const policy = this.rowSql(model, documentType, values, 'version.properties');
            const readable = this.cellSql(model, documentType, 'extractedText', values, 'version.properties');
            clauses.push(`EXISTS(SELECT 1 FROM ${publication.scenario ? 'view_objects' : this.db.schema + '.objects'} version
        WHERE version.owner=$${owner} AND version.projection=$${projection} AND version.type=$${parentType}
          AND version.id=${column}->>'documentId' AND ${policy} AND ${readable})`);
        }
        const log = processLogTarget(model, type);
        if (log) {
            if (!this.canRead(model, log.objectType))
                return 'FALSE';
            this.read(model, log.objectType);
            const publication = model;
            const bind = (value) => { values.push(value); return '$' + values.length; };
            const parentType = bind(log.objectType), owner = bind(this.principal.owner), projection = bind(publication.projection);
            const allowed = (snapshot) => `(${this.rowSql(model, log.objectType, values, snapshot)} AND ${this.cellSql(model, log.objectType, log.property, values, snapshot)})`;
            clauses.push(`EXISTS(SELECT 1 FROM ${publication.scenario ? 'view_objects' : this.db.schema + '.objects'} process
        JOIN ${this.db.schema}.edit_history history ON history.owner=process.owner AND history.type=process.type AND history.id=process.id
        WHERE process.owner=${owner} AND process.projection=${projection} AND process.type=${parentType}
          AND process.id=${column}->>'processId' AND history.sequence::text=${column}->>'sequence'
          AND history.release=${column}->>'release' AND ${allowed('process.properties')}
          AND (history.before_values IS NULL OR ${allowed('history.before_values')})
          AND (history.after_values IS NULL OR ${allowed('history.after_values')}))`);
        }
        return '(' + clauses.join(' AND ') + ')';
    }
    cellSql(model, type, field, values, column = 'properties') {
        const classification = model.object(type).properties[field]?.classification;
        if (!this.canSeeModelData(classification) || !this.property(model, type, field))
            return 'FALSE';
        this.observeClassification(classification);
        return '(' + policySql(this.policies.get(model.document.id + '/' + type)?.properties[field], values, this.security, column) + ')';
    }
    writeRow(model, type, properties) {
        this.readRow(model, type, properties);
        const markings = markingsOf(this.policies.get(model.document.id + '/' + type), properties);
        if ([...this.readMarkings].some(marking => !markings.includes(marking)))
            throw new PermissionDenied('Output must retain input security markings');
    }
    action(model, name) {
        this.requireAvailable(model, 'action', name);
        const action = model.actions.get(name);
        this.useModelData(action?.classification);
        this.definition(model, 'action', name);
        this.require(model.document.id, 'apply_action', resource(model.document.id, 'action', name), this.principal.memberAccess);
        if (this.principal.memberAccess && accountSearchActions.has(name) && (action?.function !== accountSearchActions.get(name) ||
            action?.rules?.length || action?.effects?.length))
            throw new PermissionDenied('The shared Beta query Action changed its contract');
    }
    function(model, name) {
        this.requireAvailable(model, 'function', name);
        this.useModelData(model.functions.get(name)?.classification);
        this.definition(model, 'function', name);
        this.require(model.document.id, 'execute_function', resource(model.document.id, 'function', name));
    }
    source(model, name) { this.require(model.document.id, 'read_source', resource(model.document.id, 'source', name), true); }
    dispatchSource(model, name) { this.require(model.document.id, 'dispatch_source', resource(model.document.id, 'source', name), true); }
    exportedClassification() { return combineClassification(internalClassification, this.observedClassification); }
    recordScenarioRead(model, id, release) {
        const ontology = model.document.id;
        this.require(ontology, 'view_definition', ontology);
        this.recordData('scenario:' + digest([ontology, id, release]), {
            ontology, resource: ontology, permission: 'view_definition', scenario: { id, release },
        });
    }
    dataRequirements() { return structuredClone([...this.data.values()]); }
    requirements() { return structuredClone([...new Map([...this.required.values(), ...this.data.values()].map(item => [digest(item), item])).values()]); }
    /** Return a copy of the dependencies, preserving deleted inputs and all permission evidence. */
    async requirementsAfterMerges(requirements, client) {
        const mergedViews = await this.scenarioViews(requirements, client, true);
        if (mergedViews.rows.length)
            requirements = [...requirements];
        for (const { ordinal } of mergedViews.rows) {
            const requirement = requirements[ordinal];
            requirements[ordinal] = { ...requirement, scenario: { ...requirement.scenario, merged: true } };
        }
        const pending = requirements.flatMap((requirement, ordinal) => requirement.row?.scenario ? [{ ordinal, ontology: requirement.ontology, ...requirement.row }] : []);
        if (!pending.length)
            return requirements;
        const merged = await this.db.query(`SELECT input.ordinal,live.projection
      FROM jsonb_to_recordset($2::jsonb) AS input(ordinal integer,ontology text,projection text,type text,id text,scenario uuid)
      JOIN ${this.db.schema}.scenarios scenario ON scenario.id=input.scenario AND scenario.owner=$1 AND scenario.state='merged'
      JOIN ${this.db.schema}.releases original ON original.digest=scenario.release AND original.projection=input.projection AND original.body->>'id'=input.ontology
      JOIN ${this.db.schema}.ontology active ON active.id=input.ontology
      JOIN ${this.db.schema}.releases live ON live.digest=active.release
      JOIN ${this.db.schema}.objects object ON object.projection=live.projection AND object.owner=$1 AND object.type=input.type AND object.id=input.id
      LEFT JOIN ${this.db.schema}.scenario_objects delta ON delta.scenario_id=scenario.id AND delta.owner=$1 AND delta.type=input.type AND delta.id=input.id
      WHERE input.type<>'OntologyScenario' AND (delta.id IS NULL OR delta.properties IS NOT NULL)`, [this.principal.owner, JSON.stringify(pending)], client);
        for (const item of merged.rows) {
            const requirement = requirements[Number(item.ordinal)];
            const { scenario: _scenario, ...row } = requirement.row;
            requirement.row = { ...row, projection: String(item.projection) };
        }
        return requirements;
    }
    /** Use after Action commit for final task results. Failed merges leave the original dependency intact. */
    finalDataRequirements(client) {
        return this.requirementsAfterMerges(this.dataRequirements(), client);
    }
    /** Queue effects with the same transaction that commits the scenario, so rollback also removes this copy. */
    finalRequirements(client) {
        return this.requirementsAfterMerges(this.requirements(), client);
    }
    async canReturn(requirements, client) {
        try {
            await this.refresh(client);
        }
        catch (error) {
            if (error instanceof PermissionDenied)
                return false;
            throw error;
        }
        const evidencedResources = new Set(requirements.filter(requirement => requirement.security === this.securityDigest).map(requirement => requirement.resource));
        const grantsAllowed = requirements.every(requirement => {
            if (!this.allows(requirement))
                return false;
            if (requirement.permission !== 'view_objects')
                return true;
            if (!this.allows({ ...requirement, permission: 'view_definition' }))
                return false;
            const prefix = requirement.ontology + '/object/';
            const type = requirement.resource.startsWith(prefix) ? requirement.resource.slice(prefix.length) : '';
            if (!this.policies.has(requirement.ontology + '/' + type))
                return true;
            // Older cached results have no policy evidence. Require a recorded policy context before reusing them.
            return evidencedResources.has(requirement.resource);
        });
        if (!grantsAllowed || !await this.rowsAllowed(requirements, client))
            return false;
        const views = await this.scenarioViews(requirements, client);
        return views.rows.length === views.expected;
    }
    async scenarioViews(requirements, client, checkMerged = false) {
        const views = requirements.flatMap((requirement, ordinal) => requirement.scenario
            ? [{ ordinal, ontology: requirement.ontology, ...requirement.scenario, state: checkMerged || requirement.scenario.merged ? 'merged' : 'open' }]
            : []);
        if (!views.length)
            return { expected: 0, rows: [] };
        const available = await this.db.query(`
      SELECT input.ordinal FROM jsonb_to_recordset($2::jsonb) AS input(ordinal integer, id uuid, release text, ontology text, state text)
      JOIN ${this.db.schema}.ontology current ON current.id=input.ontology AND current.release=input.release
      JOIN ${this.db.schema}.scenarios scenario ON scenario.id=input.id AND scenario.owner=$1 AND scenario.release=input.release
      LEFT JOIN ${this.db.schema}.scenario_sessions session ON session.id=scenario.session_id AND session.owner=scenario.owner
      WHERE scenario.state=input.state AND (input.state='merged' OR (scenario.expires_at>now()
        AND (scenario.session_id IS NULL OR (session.closed_at IS NULL AND session.expires_at>now()))))`, [this.principal.owner, JSON.stringify(views)], client);
        return { expected: views.length, rows: available.rows };
    }
    describe(model, executable = false, include = (_kind, _name) => true) {
        const document = structuredClone(model.resolvedDocument);
        const definitionAdministration = !executable && this.allows({
            ontology: model.document.id, resource: model.document.id, permission: 'edit_definition',
        });
        const visibleInCatalogue = (kind, name) => definitionAdministration || this.available(model, kind, name);
        const limited = Boolean(this.modelClearance());
        const modelVisible = (item) => {
            if (!limited)
                return true;
            if (!this.canSeeModelData(item.classification))
                return false;
            this.observeClassification(item.classification);
            return true;
        };
        document.objectTypes = document.objectTypes.filter(type => include('object', type.apiName) && visibleInCatalogue('object', type.apiName) &&
            this.canDefine(model, 'object', type.apiName) && (!this.principal.memberAccess || !executable || this.canRead(model, type.apiName)) && modelVisible(type));
        document.interfaceTypes = document.interfaceTypes.filter(type => include('interface', type.apiName) && this.canDefine(model, 'interface', type.apiName) && modelVisible(type));
        if (limited) {
            for (const type of [...document.objectTypes, ...document.interfaceTypes])
                type.properties = Object.fromEntries(Object.entries(type.properties).filter(([, property]) => modelVisible(property)));
        }
        const objects = new Set(document.objectTypes.map(type => type.apiName)), interfaces = new Set(document.interfaceTypes.map(type => type.apiName));
        document.linkTypes = document.linkTypes.filter(link => include('link', link.apiName) && this.canDefine(model, 'link', link.apiName) && objects.has(link.from.type) && objects.has(link.to.type) && modelVisible(link));
        document.functionTypes = document.functionTypes.filter(fn => include('function', fn.apiName) && visibleInCatalogue('function', fn.apiName) && this.canDefine(model, 'function', fn.apiName) && (!executable || this.allows({ ontology: model.document.id, permission: 'execute_function', resource: resource(model.document.id, 'function', fn.apiName) })) && modelVisible(fn));
        const functions = new Set(document.functionTypes.map(fn => fn.apiName));
        const webhookVisible = (action) => (action.effects ?? []).every(effect => {
            if (!('webhook' in effect))
                return true;
            const { source, function: formatter } = effect.webhook;
            return (!formatter || functions.has(formatter)) && (!executable || ('scenario' in model && Boolean(model.scenario)) || this.allows({
                ontology: model.document.id, permission: 'dispatch_source', resource: resource(model.document.id, 'source', source),
            }));
        });
        document.actionTypes = document.actionTypes.filter(action => include('action', action.apiName) && visibleInCatalogue('action', action.apiName) && this.canDefine(model, 'action', action.apiName) && (!executable || this.allows({ ontology: model.document.id, permission: 'apply_action', resource: resource(model.document.id, 'action', action.apiName) })) && (!action.function || functions.has(action.function)) && Object.values(action.objectParameters).every(type => objects.has(type) || interfaces.has(type)) && webhookVisible(action) && modelVisible(action));
        const actions = new Set(document.actionTypes.map(action => action.apiName));
        document.dataSources = document.dataSources.filter(source => include('datasource', source.apiName) && this.canDefine(model, 'datasource', source.apiName) && objects.has(source.objectType) && functions.has(source.function) && modelVisible(source));
        if (limited) {
            const visibleObjects = new Map(document.objectTypes.map(type => [type.apiName, type]));
            for (const source of document.dataSources) {
                const fields = visibleObjects.get(source.objectType).properties;
                source.properties = Object.fromEntries(Object.entries(source.properties).filter(([name]) => Object.hasOwn(fields, name)));
            }
        }
        const visibleProcessObjects = new Map(document.objectTypes.map(type => [type.apiName, type]));
        const visibleLinks = new Set(document.linkTypes.map(link => link.apiName));
        for (const type of document.objectTypes) {
            if (type.machinery) {
                const process = processLogTarget(model, type.apiName);
                if (!this.canRead(model, process.type) || !this.canRead(model, process.objectType)
                    || !visibleProcessObjects.get(process.objectType)?.properties[process.property]
                    || !this.property(model, process.objectType, process.property)) {
                    delete type.machinery;
                }
                else {
                    for (const edge of type.machinery.transitions) {
                        if (edge.action && !actions.has(edge.action))
                            delete edge.action;
                    }
                    type.machinery.subprocesses = type.machinery.subprocesses?.filter(child => {
                        const target = model.navigation(process.objectType, child.link);
                        return objects.has(child.process) && this.canRead(model, child.process)
                            && this.canRead(model, target.target) && visibleLinks.has(target.link);
                    });
                }
            }
            type.interfaces = Object.fromEntries(Object.entries(type.interfaces).filter(([name]) => interfaces.has(name)));
            for (const mapping of Object.values(type.interfaces))
                mapping.actions = Object.fromEntries(Object.entries(mapping.actions).filter(([, action]) => actions.has(action.action)));
            if (limited) {
                for (const [name, mapping] of Object.entries(type.interfaces)) {
                    const iface = document.interfaceTypes.find(item => item.apiName === name);
                    mapping.properties = Object.fromEntries(Object.entries(mapping.properties)
                        .filter(([property, mapped]) => Object.hasOwn(iface.properties, property) && Object.hasOwn(type.properties, mapped)));
                    const links = new Set(document.linkTypes.flatMap(link => [
                        ...(link.from.type === type.apiName ? [link.from.name] : []),
                        ...(link.to.type === type.apiName ? [link.to.name] : []),
                    ]));
                    mapping.links = Object.fromEntries(Object.entries(mapping.links).filter(([, mapped]) => links.has(mapped)));
                }
            }
        }
        for (const type of document.interfaceTypes) {
            if (limited)
                type.optionalProperties = type.optionalProperties.filter(name => Object.hasOwn(type.properties, name));
            type.links = Object.fromEntries(Object.entries(type.links).filter(([, link]) => objects.has(link.target) || interfaces.has(link.target)));
            type.actions = Object.fromEntries(Object.entries(type.actions).filter(([name]) => document.objectTypes.some(object => object.interfaces[type.apiName]?.actions[name])));
        }
        document.sharedProperties = document.sharedProperties?.filter(item => include('sharedProperty', item.apiName) && this.canDefine(model, 'sharedProperty', item.apiName) && modelVisible(item));
        document.valueTypes = document.valueTypes?.filter(item => include('valueType', item.apiName + '@' + item.version) && this.canDefine(model, 'valueType', item.apiName + '@' + item.version) && modelVisible(item));
        document.structTypes = document.structTypes?.filter(item => include('struct', item.apiName) && this.canDefine(model, 'struct', item.apiName) && modelVisible(item));
        document.typeGroups = document.typeGroups?.filter(item => include('group', item.apiName) && this.canDefine(model, 'group', item.apiName)).map(item => ({ ...item, objectTypes: item.objectTypes.filter(type => objects.has(type)) }));
        const sources = new Set(document.dataSources.map(source => source.apiName));
        document.agentProfiles = document.agentProfiles?.filter(profile => include('agentProfile', profile.apiName) && this.canDefine(model, 'agentProfile', profile.apiName))
            .map(profile => ({
            ...profile,
            objects: profile.objects?.filter(name => objects.has(name)),
            interfaces: profile.interfaces?.filter(name => interfaces.has(name)),
            links: profile.links?.filter(name => visibleLinks.has(name)),
            actions: profile.actions?.filter(name => actions.has(name)),
            functions: profile.functions?.filter(name => functions.has(name)),
            sources: profile.sources?.filter(name => sources.has(name)),
            instructions: profile.instructions?.filter(hint => (!hint.action || actions.has(hint.action)) && (!hint.function || functions.has(hint.function))),
        }));
        delete document.imports;
        return document;
    }
}
/** Administrative configuration, run using the existing database administration role. */
export async function setGrants(db, subject, grants, client) {
    z.string().min(1).max(200).parse(subject);
    grants = z.array(grantSchema).parse(grants);
    const write = async (client) => {
        await db.query(`DELETE FROM ${db.schema}.resource_grants WHERE subject=$1`, [subject], client);
        await db.query(`INSERT INTO ${db.schema}.resource_grants(subject,resource,permission) SELECT $1,resource,permission FROM jsonb_to_recordset($2::jsonb) AS g(resource text,permission text) ON CONFLICT DO NOTHING`, [subject, JSON.stringify(grants)], client);
    };
    if (client)
        await write(client);
    else
        await db.transaction(write);
}
export function businessGrants(model, sandboxEnabled = false) {
    const available = (kind) => (item) => sandboxEnabled || !isSandboxResource(model, kind, item.apiName);
    const functions = model.resolvedDocument.functionTypes.filter(available('function'));
    return [{ resource: model.document.id, permission: 'view_definition' },
        ...model.resolvedDocument.objectTypes.filter(available('object')).map(type => ({ resource: resource(model.document.id, 'object', type.apiName), permission: 'view_objects' })),
        ...functions.map(fn => ({ resource: resource(model.document.id, 'function', fn.apiName), permission: 'execute_function' })),
        ...model.resolvedDocument.actionTypes.filter(available('action')).map(action => ({ resource: resource(model.document.id, 'action', action.apiName), permission: 'apply_action' })),
        ...[...new Set(functions.flatMap(fn => fn.source ? [fn.source] : []))].map(name => ({ resource: resource(model.document.id, 'source', name), permission: 'read_source' })),
    ];
}
/** Replace legacy group grants with the fixed subset supported by this release. */
export async function syncAccountGrants(db, model, client) {
    if (model.document.id !== businessOntology)
        throw new Error('Expected the published business Ontology');
    await setGrants(db, 'group:' + accountGroup, businessGrants(model).filter(grant => accountGrantKeys.has(grantKey(grant))), client);
}
export async function syncAccountGrantsAfterActivation(db, activated) {
    if (activated.document.id === businessOntology)
        await syncAccountGrants(db, activated);
}
