/** A TypeScript view of the existing client, parameterized by a published definition's generated types. */
export class TypedOntologyClient {
    client;
    constructor(client) {
        this.client = client;
    }
    query(query, options) {
        return this.client.query(query, options);
    }
    evaluate(name, input, options) {
        return this.client.evaluate(name, input, options);
    }
    apply(action, input, requestId, options) {
        return this.client.apply({ action, input, requestId }, options);
    }
    validateAction(action, input, options = {}) {
        return this.client.validateAction({ action, input, scenarioId: options.scenarioId }, options.signal);
    }
    applyActionBatch(actions, signal) {
        return this.client.applyActionBatch({ actions }, signal);
    }
}
