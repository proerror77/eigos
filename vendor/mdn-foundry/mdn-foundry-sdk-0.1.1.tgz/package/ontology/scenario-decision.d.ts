import { z } from 'zod';
import { objectRefSchema } from './schema.js';
export declare const scenarioDecisionSchema: z.ZodObject<{
    reason: z.ZodString;
    alternative: z.ZodString;
    rejectedBecause: z.ZodString;
    assumption: z.ZodString;
    expectedTravelMinutes: z.ZodNumber;
}, z.core.$strict>;
export declare const transferLessonReference: z.ZodObject<{
    decision: z.ZodObject<{
        type: z.ZodString;
        id: z.ZodString;
    }, z.core.$strict>;
    version: z.ZodString;
}, z.core.$strict>;
export declare const scenarioDecisionApprovalSchema: z.ZodObject<{
    reason: z.ZodString;
    alternative: z.ZodString;
    rejectedBecause: z.ZodString;
    assumption: z.ZodString;
    expectedTravelMinutes: z.ZodNumber;
    adoptedLesson: z.ZodOptional<z.ZodObject<{
        decision: z.ZodObject<{
            type: z.ZodString;
            id: z.ZodString;
        }, z.core.$strict>;
        version: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type ScenarioDecision = z.output<typeof scenarioDecisionApprovalSchema>;
export declare const decisionAssessment: z.ZodEnum<{
    insufficient: "insufficient";
    refuted: "refuted";
    supported: "supported";
}>;
export interface ScenarioDecisionMemory {
    departure: string;
    arriveBy: string;
    prior: {
        decision: z.output<typeof objectRefSchema>;
        version: string;
        date: string;
        judgment: z.output<typeof scenarioDecisionSchema>;
        expectedBufferMinutes: number;
        actualTravelMinutes: number;
        actualBufferMinutes: number;
        assessment: z.output<typeof decisionAssessment>;
        lesson: string;
        appliesWhen: string;
    }[];
}
