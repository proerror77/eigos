import { type ProposalEvidence } from './machinery-proposal.js';
import { z } from 'zod';
import { type OntologyDocument } from '../ontology/schema.js';
import { Access } from './access.js';
import type { Database } from './database.js';
import { Metadata, type Bindings } from './metadata.js';
export declare const projectSchema: z.ZodObject<{
    ontology: z.ZodString;
    id: z.ZodString;
    name: z.ZodString;
}, z.core.$strict>;
export declare const assignProjectSchema: z.ZodObject<{
    ontology: z.ZodString;
    project: z.ZodString;
    resources: z.ZodArray<z.ZodString>;
}, z.core.$strict>;
export declare const branchCreateSchema: z.ZodObject<{
    ontology: z.ZodString;
    project: z.ZodOptional<z.ZodString>;
    name: z.ZodString;
    body: z.ZodOptional<z.ZodObject<{
        id: z.ZodString;
        version: z.ZodString;
        classification: z.ZodOptional<z.ZodObject<{
            sensitivity: z.ZodEnum<{
                CONFIDENTIAL: "CONFIDENTIAL";
                INTERNAL: "INTERNAL";
                PUBLIC: "PUBLIC";
                RESTRICTED: "RESTRICTED";
            }>;
            compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        sharedProperties: z.ZodOptional<z.ZodArray<z.ZodObject<{
            typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>>;
            renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
            status: z.ZodOptional<z.ZodEnum<{
                active: "active";
                deprecated: "deprecated";
                experimental: "experimental";
            }>>;
            classification: z.ZodOptional<z.ZodObject<{
                sensitivity: z.ZodEnum<{
                    CONFIDENTIAL: "CONFIDENTIAL";
                    INTERNAL: "INTERNAL";
                    PUBLIC: "PUBLIC";
                    RESTRICTED: "RESTRICTED";
                }>;
                compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            description: z.ZodDefault<z.ZodString>;
            schema: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
            required: z.ZodDefault<z.ZodBoolean>;
            sharedProperty: z.ZodOptional<z.ZodString>;
            valueType: z.ZodOptional<z.ZodObject<{
                name: z.ZodString;
                version: z.ZodString;
            }, z.core.$strict>>;
            struct: z.ZodOptional<z.ZodObject<{
                type: z.ZodString;
                mainField: z.ZodOptional<z.ZodString>;
                reducer: z.ZodOptional<z.ZodObject<{
                    op: z.ZodEnum<{
                        first: "first";
                        last: "last";
                        max: "max";
                        min: "min";
                    }>;
                    field: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
                array: z.ZodOptional<z.ZodBoolean>;
            }, z.core.$strict>>;
            format: z.ZodOptional<z.ZodObject<{
                kind: z.ZodEnum<{
                    currency: "currency";
                    date: "date";
                    number: "number";
                    percent: "percent";
                    text: "text";
                }>;
                locale: z.ZodOptional<z.ZodString>;
                currency: z.ZodOptional<z.ZodString>;
                minimumFractionDigits: z.ZodOptional<z.ZodNumber>;
                maximumFractionDigits: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>>;
            derived: z.ZodOptional<z.ZodType<import("../ontology/schema.js").DerivedExpression, unknown, z.core.$ZodTypeInternals<import("../ontology/schema.js").DerivedExpression, unknown>>>;
            apiName: z.ZodString;
        }, z.core.$strict>>>;
        valueTypes: z.ZodOptional<z.ZodArray<z.ZodObject<{
            typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>>;
            renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
            status: z.ZodOptional<z.ZodEnum<{
                active: "active";
                deprecated: "deprecated";
                experimental: "experimental";
            }>>;
            classification: z.ZodOptional<z.ZodObject<{
                sensitivity: z.ZodEnum<{
                    CONFIDENTIAL: "CONFIDENTIAL";
                    INTERNAL: "INTERNAL";
                    PUBLIC: "PUBLIC";
                    RESTRICTED: "RESTRICTED";
                }>;
                compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            apiName: z.ZodString;
            version: z.ZodString;
            description: z.ZodString;
            schema: z.ZodRecord<z.ZodString, z.ZodUnknown>;
        }, z.core.$strict>>>;
        structTypes: z.ZodOptional<z.ZodArray<z.ZodObject<{
            typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>>;
            renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
            status: z.ZodOptional<z.ZodEnum<{
                active: "active";
                deprecated: "deprecated";
                experimental: "experimental";
            }>>;
            classification: z.ZodOptional<z.ZodObject<{
                sensitivity: z.ZodEnum<{
                    CONFIDENTIAL: "CONFIDENTIAL";
                    INTERNAL: "INTERNAL";
                    PUBLIC: "PUBLIC";
                    RESTRICTED: "RESTRICTED";
                }>;
                compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            apiName: z.ZodString;
            description: z.ZodString;
            fields: z.ZodRecord<z.ZodString, z.ZodRecord<z.ZodString, z.ZodUnknown>>;
            required: z.ZodOptional<z.ZodArray<z.ZodString>>;
            mainField: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>>;
        typeGroups: z.ZodOptional<z.ZodArray<z.ZodObject<{
            apiName: z.ZodString;
            displayName: z.ZodString;
            description: z.ZodString;
            objectTypes: z.ZodArray<z.ZodString>;
        }, z.core.$strict>>>;
        agentProfiles: z.ZodOptional<z.ZodArray<z.ZodObject<{
            apiName: z.ZodString;
            terms: z.ZodArray<z.ZodString>;
            objects: z.ZodOptional<z.ZodArray<z.ZodString>>;
            interfaces: z.ZodOptional<z.ZodArray<z.ZodString>>;
            actions: z.ZodOptional<z.ZodArray<z.ZodString>>;
            functions: z.ZodOptional<z.ZodArray<z.ZodString>>;
            sources: z.ZodOptional<z.ZodArray<z.ZodString>>;
            links: z.ZodOptional<z.ZodArray<z.ZodString>>;
            instructions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                action: z.ZodOptional<z.ZodString>;
                function: z.ZodOptional<z.ZodString>;
                text: z.ZodString;
            }, z.core.$strict>>>;
        }, z.core.$strict>>>;
        imports: z.ZodOptional<z.ZodArray<z.ZodObject<{
            ontology: z.ZodString;
            version: z.ZodString;
            digest: z.ZodString;
            namespace: z.ZodString;
            document: z.ZodUnknown;
        }, z.core.$strict>>>;
        objectTypes: z.ZodArray<z.ZodObject<{
            typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>>;
            renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
            status: z.ZodOptional<z.ZodEnum<{
                active: "active";
                deprecated: "deprecated";
                experimental: "experimental";
            }>>;
            classification: z.ZodOptional<z.ZodObject<{
                sensitivity: z.ZodEnum<{
                    CONFIDENTIAL: "CONFIDENTIAL";
                    INTERNAL: "INTERNAL";
                    PUBLIC: "PUBLIC";
                    RESTRICTED: "RESTRICTED";
                }>;
                compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            apiName: z.ZodString;
            displayName: z.ZodString;
            description: z.ZodString;
            primaryKey: z.ZodString;
            titleProperty: z.ZodString;
            properties: z.ZodRecord<z.ZodString, z.ZodObject<{
                typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    kind: z.ZodString;
                    name: z.ZodString;
                }, z.core.$strict>>>;
                renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
                status: z.ZodOptional<z.ZodEnum<{
                    active: "active";
                    deprecated: "deprecated";
                    experimental: "experimental";
                }>>;
                classification: z.ZodOptional<z.ZodObject<{
                    sensitivity: z.ZodEnum<{
                        CONFIDENTIAL: "CONFIDENTIAL";
                        INTERNAL: "INTERNAL";
                        PUBLIC: "PUBLIC";
                        RESTRICTED: "RESTRICTED";
                    }>;
                    compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                description: z.ZodDefault<z.ZodString>;
                schema: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
                required: z.ZodDefault<z.ZodBoolean>;
                sharedProperty: z.ZodOptional<z.ZodString>;
                valueType: z.ZodOptional<z.ZodObject<{
                    name: z.ZodString;
                    version: z.ZodString;
                }, z.core.$strict>>;
                struct: z.ZodOptional<z.ZodObject<{
                    type: z.ZodString;
                    mainField: z.ZodOptional<z.ZodString>;
                    reducer: z.ZodOptional<z.ZodObject<{
                        op: z.ZodEnum<{
                            first: "first";
                            last: "last";
                            max: "max";
                            min: "min";
                        }>;
                        field: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>>;
                    array: z.ZodOptional<z.ZodBoolean>;
                }, z.core.$strict>>;
                format: z.ZodOptional<z.ZodObject<{
                    kind: z.ZodEnum<{
                        currency: "currency";
                        date: "date";
                        number: "number";
                        percent: "percent";
                        text: "text";
                    }>;
                    locale: z.ZodOptional<z.ZodString>;
                    currency: z.ZodOptional<z.ZodString>;
                    minimumFractionDigits: z.ZodOptional<z.ZodNumber>;
                    maximumFractionDigits: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>>;
                derived: z.ZodOptional<z.ZodType<import("../ontology/schema.js").DerivedExpression, unknown, z.core.$ZodTypeInternals<import("../ontology/schema.js").DerivedExpression, unknown>>>;
            }, z.core.$strict>>;
            machinery: z.ZodOptional<z.ZodObject<{
                states: z.ZodArray<z.ZodObject<{
                    name: z.ZodString;
                    terminal: z.ZodOptional<z.ZodBoolean>;
                    dwellSeconds: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>>;
                transitions: z.ZodArray<z.ZodObject<{
                    from: z.ZodNullable<z.ZodString>;
                    to: z.ZodNullable<z.ZodString>;
                    action: z.ZodOptional<z.ZodString>;
                    execution: z.ZodOptional<z.ZodObject<{
                        subject: z.ZodString;
                        parameters: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
                        requires: z.ZodOptional<z.ZodArray<z.ZodObject<{
                            process: z.ZodString;
                            link: z.ZodOptional<z.ZodString>;
                            states: z.ZodArray<z.ZodString>;
                            match: z.ZodDefault<z.ZodEnum<{
                                all: "all";
                                any: "any";
                            }>>;
                        }, z.core.$strict>>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                subprocesses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    link: z.ZodString;
                    process: z.ZodString;
                }, z.core.$strict>>>;
                parallel: z.ZodOptional<z.ZodArray<z.ZodString>>;
                metrics: z.ZodOptional<z.ZodObject<{
                    node: z.ZodOptional<z.ZodObject<{
                        label: z.ZodString;
                        aggregation: z.ZodDiscriminatedUnion<[z.ZodObject<{
                            op: z.ZodLiteral<"count">;
                        }, z.core.$strict>, z.ZodObject<{
                            op: z.ZodEnum<{
                                avg: "avg";
                                max: "max";
                                min: "min";
                                sum: "sum";
                            }>;
                            property: z.ZodString;
                        }, z.core.$strict>], "op">;
                        decimals: z.ZodOptional<z.ZodNumber>;
                        unit: z.ZodOptional<z.ZodString>;
                        colors: z.ZodOptional<z.ZodArray<z.ZodObject<{
                            min: z.ZodNumber;
                            color: z.ZodEnum<{
                                amber: "amber";
                                green: "green";
                                red: "red";
                            }>;
                        }, z.core.$strict>>>;
                    }, z.core.$strict>>;
                    edge: z.ZodOptional<z.ZodObject<{
                        label: z.ZodString;
                        aggregation: z.ZodDiscriminatedUnion<[z.ZodObject<{
                            op: z.ZodLiteral<"count">;
                        }, z.core.$strict>, z.ZodObject<{
                            op: z.ZodEnum<{
                                avg: "avg";
                                max: "max";
                                min: "min";
                                sum: "sum";
                            }>;
                            property: z.ZodString;
                        }, z.core.$strict>], "op">;
                        decimals: z.ZodOptional<z.ZodNumber>;
                        unit: z.ZodOptional<z.ZodString>;
                        colors: z.ZodOptional<z.ZodArray<z.ZodObject<{
                            min: z.ZodNumber;
                            color: z.ZodEnum<{
                                amber: "amber";
                                green: "green";
                                red: "red";
                            }>;
                        }, z.core.$strict>>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            classificationProperty: z.ZodOptional<z.ZodString>;
            groups: z.ZodOptional<z.ZodArray<z.ZodString>>;
            interfaces: z.ZodRecord<z.ZodString, z.ZodObject<{
                properties: z.ZodRecord<z.ZodString, z.ZodString>;
                links: z.ZodRecord<z.ZodString, z.ZodString>;
                actions: z.ZodRecord<z.ZodString, z.ZodObject<{
                    action: z.ZodString;
                    parameters: z.ZodRecord<z.ZodString, z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        interfaceTypes: z.ZodArray<z.ZodObject<{
            typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>>;
            renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
            status: z.ZodOptional<z.ZodEnum<{
                active: "active";
                deprecated: "deprecated";
                experimental: "experimental";
            }>>;
            classification: z.ZodOptional<z.ZodObject<{
                sensitivity: z.ZodEnum<{
                    CONFIDENTIAL: "CONFIDENTIAL";
                    INTERNAL: "INTERNAL";
                    PUBLIC: "PUBLIC";
                    RESTRICTED: "RESTRICTED";
                }>;
                compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            apiName: z.ZodString;
            description: z.ZodString;
            properties: z.ZodRecord<z.ZodString, z.ZodObject<{
                typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    kind: z.ZodString;
                    name: z.ZodString;
                }, z.core.$strict>>>;
                renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
                status: z.ZodOptional<z.ZodEnum<{
                    active: "active";
                    deprecated: "deprecated";
                    experimental: "experimental";
                }>>;
                classification: z.ZodOptional<z.ZodObject<{
                    sensitivity: z.ZodEnum<{
                        CONFIDENTIAL: "CONFIDENTIAL";
                        INTERNAL: "INTERNAL";
                        PUBLIC: "PUBLIC";
                        RESTRICTED: "RESTRICTED";
                    }>;
                    compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                description: z.ZodDefault<z.ZodString>;
                schema: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
                required: z.ZodDefault<z.ZodBoolean>;
                sharedProperty: z.ZodOptional<z.ZodString>;
                valueType: z.ZodOptional<z.ZodObject<{
                    name: z.ZodString;
                    version: z.ZodString;
                }, z.core.$strict>>;
                struct: z.ZodOptional<z.ZodObject<{
                    type: z.ZodString;
                    mainField: z.ZodOptional<z.ZodString>;
                    reducer: z.ZodOptional<z.ZodObject<{
                        op: z.ZodEnum<{
                            first: "first";
                            last: "last";
                            max: "max";
                            min: "min";
                        }>;
                        field: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>>;
                    array: z.ZodOptional<z.ZodBoolean>;
                }, z.core.$strict>>;
                format: z.ZodOptional<z.ZodObject<{
                    kind: z.ZodEnum<{
                        currency: "currency";
                        date: "date";
                        number: "number";
                        percent: "percent";
                        text: "text";
                    }>;
                    locale: z.ZodOptional<z.ZodString>;
                    currency: z.ZodOptional<z.ZodString>;
                    minimumFractionDigits: z.ZodOptional<z.ZodNumber>;
                    maximumFractionDigits: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>>;
                derived: z.ZodOptional<z.ZodType<import("../ontology/schema.js").DerivedExpression, unknown, z.core.$ZodTypeInternals<import("../ontology/schema.js").DerivedExpression, unknown>>>;
            }, z.core.$strict>>;
            extends: z.ZodOptional<z.ZodArray<z.ZodString>>;
            optionalProperties: z.ZodArray<z.ZodString>;
            links: z.ZodRecord<z.ZodString, z.ZodObject<{
                target: z.ZodString;
                cardinality: z.ZodEnum<{
                    many: "many";
                    one: "one";
                }>;
                required: z.ZodBoolean;
            }, z.core.$strict>>;
            actions: z.ZodRecord<z.ZodString, z.ZodObject<{
                parameters: z.ZodRecord<z.ZodString, z.ZodUnknown>;
                objectParameters: z.ZodRecord<z.ZodString, z.ZodString>;
                required: z.ZodBoolean;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        linkTypes: z.ZodArray<z.ZodObject<{
            typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>>;
            renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
            status: z.ZodOptional<z.ZodEnum<{
                active: "active";
                deprecated: "deprecated";
                experimental: "experimental";
            }>>;
            classification: z.ZodOptional<z.ZodObject<{
                sensitivity: z.ZodEnum<{
                    CONFIDENTIAL: "CONFIDENTIAL";
                    INTERNAL: "INTERNAL";
                    PUBLIC: "PUBLIC";
                    RESTRICTED: "RESTRICTED";
                }>;
                compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            apiName: z.ZodString;
            description: z.ZodString;
            from: z.ZodObject<{
                type: z.ZodString;
                name: z.ZodString;
                cardinality: z.ZodEnum<{
                    many: "many";
                    one: "one";
                }>;
            }, z.core.$strict>;
            to: z.ZodObject<{
                type: z.ZodString;
                name: z.ZodString;
                cardinality: z.ZodEnum<{
                    many: "many";
                    one: "one";
                }>;
            }, z.core.$strict>;
        }, z.core.$strict>>;
        functionTypes: z.ZodArray<z.ZodObject<{
            typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>>;
            renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
            status: z.ZodOptional<z.ZodEnum<{
                active: "active";
                deprecated: "deprecated";
                experimental: "experimental";
            }>>;
            classification: z.ZodOptional<z.ZodObject<{
                sensitivity: z.ZodEnum<{
                    CONFIDENTIAL: "CONFIDENTIAL";
                    INTERNAL: "INTERNAL";
                    PUBLIC: "PUBLIC";
                    RESTRICTED: "RESTRICTED";
                }>;
                compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            apiName: z.ZodString;
            description: z.ZodString;
            parameters: z.ZodRecord<z.ZodString, z.ZodUnknown>;
            returns: z.ZodRecord<z.ZodString, z.ZodUnknown>;
            source: z.ZodOptional<z.ZodString>;
            edits: z.ZodOptional<z.ZodBoolean>;
            version: z.ZodOptional<z.ZodString>;
            dependencies: z.ZodOptional<z.ZodObject<{
                objectTypes: z.ZodOptional<z.ZodArray<z.ZodString>>;
                interfaceTypes: z.ZodOptional<z.ZodArray<z.ZodString>>;
                linkTypes: z.ZodOptional<z.ZodArray<z.ZodString>>;
                functions: z.ZodOptional<z.ZodArray<z.ZodString>>;
                dataSources: z.ZodOptional<z.ZodArray<z.ZodString>>;
                actions: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            implementation: z.ZodOptional<z.ZodObject<{
                kind: z.ZodLiteral<"component">;
                sha256: z.ZodString;
                limits: z.ZodObject<{
                    fuel: z.ZodNumber;
                    memoryMb: z.ZodNumber;
                    deadlineMs: z.ZodNumber;
                    inputBytes: z.ZodOptional<z.ZodNumber>;
                    outputBytes: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        actionTypes: z.ZodArray<z.ZodObject<{
            typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>>;
            renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
            status: z.ZodOptional<z.ZodEnum<{
                active: "active";
                deprecated: "deprecated";
                experimental: "experimental";
            }>>;
            classification: z.ZodOptional<z.ZodObject<{
                sensitivity: z.ZodEnum<{
                    CONFIDENTIAL: "CONFIDENTIAL";
                    INTERNAL: "INTERNAL";
                    PUBLIC: "PUBLIC";
                    RESTRICTED: "RESTRICTED";
                }>;
                compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            apiName: z.ZodString;
            description: z.ZodString;
            parameters: z.ZodRecord<z.ZodString, z.ZodUnknown>;
            objectParameters: z.ZodRecord<z.ZodString, z.ZodString>;
            submissionCriteria: z.ZodArray<z.ZodObject<{
                function: z.ZodString;
                arguments: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>>;
                message: z.ZodOptional<z.ZodString>;
                functionVersion: z.ZodOptional<z.ZodString>;
                executionContext: z.ZodOptional<z.ZodEnum<{
                    live: "live";
                    scenario: "scenario";
                }>>;
            }, z.core.$strict>>;
            rules: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                op: z.ZodLiteral<"createObject">;
                object: z.ZodObject<{
                    type: z.ZodString;
                    id: z.ZodUnion<readonly [z.ZodObject<{
                        parameter: z.ZodString;
                        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>, z.ZodObject<{
                        literal: z.ZodUnknown;
                    }, z.core.$strict>]>;
                }, z.core.$strict>;
                properties: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>>;
            }, z.core.$strict>, z.ZodObject<{
                op: z.ZodLiteral<"editObject">;
                object: z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>;
                expectedRevision: z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>;
                properties: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>>;
            }, z.core.$strict>, z.ZodObject<{
                op: z.ZodLiteral<"addLink">;
                link: z.ZodString;
                from: z.ZodObject<{
                    type: z.ZodString;
                    id: z.ZodUnion<readonly [z.ZodObject<{
                        parameter: z.ZodString;
                        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>, z.ZodObject<{
                        literal: z.ZodUnknown;
                    }, z.core.$strict>]>;
                }, z.core.$strict>;
                to: z.ZodObject<{
                    type: z.ZodString;
                    id: z.ZodUnion<readonly [z.ZodObject<{
                        parameter: z.ZodString;
                        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>, z.ZodObject<{
                        literal: z.ZodUnknown;
                    }, z.core.$strict>]>;
                }, z.core.$strict>;
            }, z.core.$strict>, z.ZodObject<{
                op: z.ZodLiteral<"removeLink">;
                link: z.ZodString;
                from: z.ZodObject<{
                    type: z.ZodString;
                    id: z.ZodUnion<readonly [z.ZodObject<{
                        parameter: z.ZodString;
                        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>, z.ZodObject<{
                        literal: z.ZodUnknown;
                    }, z.core.$strict>]>;
                }, z.core.$strict>;
                to: z.ZodObject<{
                    type: z.ZodString;
                    id: z.ZodUnion<readonly [z.ZodObject<{
                        parameter: z.ZodString;
                        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>, z.ZodObject<{
                        literal: z.ZodUnknown;
                    }, z.core.$strict>]>;
                }, z.core.$strict>;
            }, z.core.$strict>, z.ZodObject<{
                op: z.ZodLiteral<"deleteObject">;
                object: z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>;
                expectedRevision: z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>;
            }, z.core.$strict>, z.ZodObject<{
                op: z.ZodLiteral<"editStruct">;
                object: z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>;
                expectedRevision: z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>;
                property: z.ZodString;
                fields: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>>;
            }, z.core.$strict>, z.ZodObject<{
                op: z.ZodLiteral<"applyScenario">;
                scenario: z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>;
                expectedRevision: z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>;
                objectTypes: z.ZodArray<z.ZodString>;
                linkTypes: z.ZodArray<z.ZodString>;
            }, z.core.$strict>], "op">>>;
            result: z.ZodOptional<z.ZodObject<{
                type: z.ZodString;
                id: z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>;
            }, z.core.$strict>>;
            function: z.ZodOptional<z.ZodString>;
            functionVersion: z.ZodOptional<z.ZodString>;
            effects: z.ZodOptional<z.ZodArray<z.ZodUnion<readonly [z.ZodObject<{
                name: z.ZodString;
                handler: z.ZodString;
                payload: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>>;
            }, z.core.$strict>, z.ZodObject<{
                name: z.ZodString;
                webhook: z.ZodObject<{
                    source: z.ZodString;
                    method: z.ZodEnum<{
                        DELETE: "DELETE";
                        PATCH: "PATCH";
                        POST: "POST";
                        PUT: "PUT";
                    }>;
                    path: z.ZodString;
                    function: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                payload: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>>;
            }, z.core.$strict>]>>>;
        }, z.core.$strict>>;
        dataSources: z.ZodArray<z.ZodObject<{
            apiName: z.ZodString;
            objectType: z.ZodString;
            function: z.ZodString;
            classification: z.ZodOptional<z.ZodObject<{
                sensitivity: z.ZodEnum<{
                    CONFIDENTIAL: "CONFIDENTIAL";
                    INTERNAL: "INTERNAL";
                    PUBLIC: "PUBLIC";
                    RESTRICTED: "RESTRICTED";
                }>;
                compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            properties: z.ZodRecord<z.ZodString, z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    baseRelease: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export declare const branchRevisionSchema: z.ZodObject<{
    id: z.ZodUUID;
    revision: z.ZodNumber;
}, z.core.$strict>;
export declare const branchUpdateSchema: z.ZodObject<{
    id: z.ZodUUID;
    revision: z.ZodNumber;
    body: z.ZodObject<{
        id: z.ZodString;
        version: z.ZodString;
        classification: z.ZodOptional<z.ZodObject<{
            sensitivity: z.ZodEnum<{
                CONFIDENTIAL: "CONFIDENTIAL";
                INTERNAL: "INTERNAL";
                PUBLIC: "PUBLIC";
                RESTRICTED: "RESTRICTED";
            }>;
            compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        sharedProperties: z.ZodOptional<z.ZodArray<z.ZodObject<{
            typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>>;
            renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
            status: z.ZodOptional<z.ZodEnum<{
                active: "active";
                deprecated: "deprecated";
                experimental: "experimental";
            }>>;
            classification: z.ZodOptional<z.ZodObject<{
                sensitivity: z.ZodEnum<{
                    CONFIDENTIAL: "CONFIDENTIAL";
                    INTERNAL: "INTERNAL";
                    PUBLIC: "PUBLIC";
                    RESTRICTED: "RESTRICTED";
                }>;
                compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            description: z.ZodDefault<z.ZodString>;
            schema: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
            required: z.ZodDefault<z.ZodBoolean>;
            sharedProperty: z.ZodOptional<z.ZodString>;
            valueType: z.ZodOptional<z.ZodObject<{
                name: z.ZodString;
                version: z.ZodString;
            }, z.core.$strict>>;
            struct: z.ZodOptional<z.ZodObject<{
                type: z.ZodString;
                mainField: z.ZodOptional<z.ZodString>;
                reducer: z.ZodOptional<z.ZodObject<{
                    op: z.ZodEnum<{
                        first: "first";
                        last: "last";
                        max: "max";
                        min: "min";
                    }>;
                    field: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
                array: z.ZodOptional<z.ZodBoolean>;
            }, z.core.$strict>>;
            format: z.ZodOptional<z.ZodObject<{
                kind: z.ZodEnum<{
                    currency: "currency";
                    date: "date";
                    number: "number";
                    percent: "percent";
                    text: "text";
                }>;
                locale: z.ZodOptional<z.ZodString>;
                currency: z.ZodOptional<z.ZodString>;
                minimumFractionDigits: z.ZodOptional<z.ZodNumber>;
                maximumFractionDigits: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>>;
            derived: z.ZodOptional<z.ZodType<import("../ontology/schema.js").DerivedExpression, unknown, z.core.$ZodTypeInternals<import("../ontology/schema.js").DerivedExpression, unknown>>>;
            apiName: z.ZodString;
        }, z.core.$strict>>>;
        valueTypes: z.ZodOptional<z.ZodArray<z.ZodObject<{
            typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>>;
            renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
            status: z.ZodOptional<z.ZodEnum<{
                active: "active";
                deprecated: "deprecated";
                experimental: "experimental";
            }>>;
            classification: z.ZodOptional<z.ZodObject<{
                sensitivity: z.ZodEnum<{
                    CONFIDENTIAL: "CONFIDENTIAL";
                    INTERNAL: "INTERNAL";
                    PUBLIC: "PUBLIC";
                    RESTRICTED: "RESTRICTED";
                }>;
                compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            apiName: z.ZodString;
            version: z.ZodString;
            description: z.ZodString;
            schema: z.ZodRecord<z.ZodString, z.ZodUnknown>;
        }, z.core.$strict>>>;
        structTypes: z.ZodOptional<z.ZodArray<z.ZodObject<{
            typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>>;
            renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
            status: z.ZodOptional<z.ZodEnum<{
                active: "active";
                deprecated: "deprecated";
                experimental: "experimental";
            }>>;
            classification: z.ZodOptional<z.ZodObject<{
                sensitivity: z.ZodEnum<{
                    CONFIDENTIAL: "CONFIDENTIAL";
                    INTERNAL: "INTERNAL";
                    PUBLIC: "PUBLIC";
                    RESTRICTED: "RESTRICTED";
                }>;
                compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            apiName: z.ZodString;
            description: z.ZodString;
            fields: z.ZodRecord<z.ZodString, z.ZodRecord<z.ZodString, z.ZodUnknown>>;
            required: z.ZodOptional<z.ZodArray<z.ZodString>>;
            mainField: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>>;
        typeGroups: z.ZodOptional<z.ZodArray<z.ZodObject<{
            apiName: z.ZodString;
            displayName: z.ZodString;
            description: z.ZodString;
            objectTypes: z.ZodArray<z.ZodString>;
        }, z.core.$strict>>>;
        agentProfiles: z.ZodOptional<z.ZodArray<z.ZodObject<{
            apiName: z.ZodString;
            terms: z.ZodArray<z.ZodString>;
            objects: z.ZodOptional<z.ZodArray<z.ZodString>>;
            interfaces: z.ZodOptional<z.ZodArray<z.ZodString>>;
            actions: z.ZodOptional<z.ZodArray<z.ZodString>>;
            functions: z.ZodOptional<z.ZodArray<z.ZodString>>;
            sources: z.ZodOptional<z.ZodArray<z.ZodString>>;
            links: z.ZodOptional<z.ZodArray<z.ZodString>>;
            instructions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                action: z.ZodOptional<z.ZodString>;
                function: z.ZodOptional<z.ZodString>;
                text: z.ZodString;
            }, z.core.$strict>>>;
        }, z.core.$strict>>>;
        imports: z.ZodOptional<z.ZodArray<z.ZodObject<{
            ontology: z.ZodString;
            version: z.ZodString;
            digest: z.ZodString;
            namespace: z.ZodString;
            document: z.ZodUnknown;
        }, z.core.$strict>>>;
        objectTypes: z.ZodArray<z.ZodObject<{
            typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>>;
            renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
            status: z.ZodOptional<z.ZodEnum<{
                active: "active";
                deprecated: "deprecated";
                experimental: "experimental";
            }>>;
            classification: z.ZodOptional<z.ZodObject<{
                sensitivity: z.ZodEnum<{
                    CONFIDENTIAL: "CONFIDENTIAL";
                    INTERNAL: "INTERNAL";
                    PUBLIC: "PUBLIC";
                    RESTRICTED: "RESTRICTED";
                }>;
                compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            apiName: z.ZodString;
            displayName: z.ZodString;
            description: z.ZodString;
            primaryKey: z.ZodString;
            titleProperty: z.ZodString;
            properties: z.ZodRecord<z.ZodString, z.ZodObject<{
                typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    kind: z.ZodString;
                    name: z.ZodString;
                }, z.core.$strict>>>;
                renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
                status: z.ZodOptional<z.ZodEnum<{
                    active: "active";
                    deprecated: "deprecated";
                    experimental: "experimental";
                }>>;
                classification: z.ZodOptional<z.ZodObject<{
                    sensitivity: z.ZodEnum<{
                        CONFIDENTIAL: "CONFIDENTIAL";
                        INTERNAL: "INTERNAL";
                        PUBLIC: "PUBLIC";
                        RESTRICTED: "RESTRICTED";
                    }>;
                    compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                description: z.ZodDefault<z.ZodString>;
                schema: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
                required: z.ZodDefault<z.ZodBoolean>;
                sharedProperty: z.ZodOptional<z.ZodString>;
                valueType: z.ZodOptional<z.ZodObject<{
                    name: z.ZodString;
                    version: z.ZodString;
                }, z.core.$strict>>;
                struct: z.ZodOptional<z.ZodObject<{
                    type: z.ZodString;
                    mainField: z.ZodOptional<z.ZodString>;
                    reducer: z.ZodOptional<z.ZodObject<{
                        op: z.ZodEnum<{
                            first: "first";
                            last: "last";
                            max: "max";
                            min: "min";
                        }>;
                        field: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>>;
                    array: z.ZodOptional<z.ZodBoolean>;
                }, z.core.$strict>>;
                format: z.ZodOptional<z.ZodObject<{
                    kind: z.ZodEnum<{
                        currency: "currency";
                        date: "date";
                        number: "number";
                        percent: "percent";
                        text: "text";
                    }>;
                    locale: z.ZodOptional<z.ZodString>;
                    currency: z.ZodOptional<z.ZodString>;
                    minimumFractionDigits: z.ZodOptional<z.ZodNumber>;
                    maximumFractionDigits: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>>;
                derived: z.ZodOptional<z.ZodType<import("../ontology/schema.js").DerivedExpression, unknown, z.core.$ZodTypeInternals<import("../ontology/schema.js").DerivedExpression, unknown>>>;
            }, z.core.$strict>>;
            machinery: z.ZodOptional<z.ZodObject<{
                states: z.ZodArray<z.ZodObject<{
                    name: z.ZodString;
                    terminal: z.ZodOptional<z.ZodBoolean>;
                    dwellSeconds: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>>;
                transitions: z.ZodArray<z.ZodObject<{
                    from: z.ZodNullable<z.ZodString>;
                    to: z.ZodNullable<z.ZodString>;
                    action: z.ZodOptional<z.ZodString>;
                    execution: z.ZodOptional<z.ZodObject<{
                        subject: z.ZodString;
                        parameters: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
                        requires: z.ZodOptional<z.ZodArray<z.ZodObject<{
                            process: z.ZodString;
                            link: z.ZodOptional<z.ZodString>;
                            states: z.ZodArray<z.ZodString>;
                            match: z.ZodDefault<z.ZodEnum<{
                                all: "all";
                                any: "any";
                            }>>;
                        }, z.core.$strict>>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                subprocesses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    link: z.ZodString;
                    process: z.ZodString;
                }, z.core.$strict>>>;
                parallel: z.ZodOptional<z.ZodArray<z.ZodString>>;
                metrics: z.ZodOptional<z.ZodObject<{
                    node: z.ZodOptional<z.ZodObject<{
                        label: z.ZodString;
                        aggregation: z.ZodDiscriminatedUnion<[z.ZodObject<{
                            op: z.ZodLiteral<"count">;
                        }, z.core.$strict>, z.ZodObject<{
                            op: z.ZodEnum<{
                                avg: "avg";
                                max: "max";
                                min: "min";
                                sum: "sum";
                            }>;
                            property: z.ZodString;
                        }, z.core.$strict>], "op">;
                        decimals: z.ZodOptional<z.ZodNumber>;
                        unit: z.ZodOptional<z.ZodString>;
                        colors: z.ZodOptional<z.ZodArray<z.ZodObject<{
                            min: z.ZodNumber;
                            color: z.ZodEnum<{
                                amber: "amber";
                                green: "green";
                                red: "red";
                            }>;
                        }, z.core.$strict>>>;
                    }, z.core.$strict>>;
                    edge: z.ZodOptional<z.ZodObject<{
                        label: z.ZodString;
                        aggregation: z.ZodDiscriminatedUnion<[z.ZodObject<{
                            op: z.ZodLiteral<"count">;
                        }, z.core.$strict>, z.ZodObject<{
                            op: z.ZodEnum<{
                                avg: "avg";
                                max: "max";
                                min: "min";
                                sum: "sum";
                            }>;
                            property: z.ZodString;
                        }, z.core.$strict>], "op">;
                        decimals: z.ZodOptional<z.ZodNumber>;
                        unit: z.ZodOptional<z.ZodString>;
                        colors: z.ZodOptional<z.ZodArray<z.ZodObject<{
                            min: z.ZodNumber;
                            color: z.ZodEnum<{
                                amber: "amber";
                                green: "green";
                                red: "red";
                            }>;
                        }, z.core.$strict>>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            classificationProperty: z.ZodOptional<z.ZodString>;
            groups: z.ZodOptional<z.ZodArray<z.ZodString>>;
            interfaces: z.ZodRecord<z.ZodString, z.ZodObject<{
                properties: z.ZodRecord<z.ZodString, z.ZodString>;
                links: z.ZodRecord<z.ZodString, z.ZodString>;
                actions: z.ZodRecord<z.ZodString, z.ZodObject<{
                    action: z.ZodString;
                    parameters: z.ZodRecord<z.ZodString, z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        interfaceTypes: z.ZodArray<z.ZodObject<{
            typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>>;
            renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
            status: z.ZodOptional<z.ZodEnum<{
                active: "active";
                deprecated: "deprecated";
                experimental: "experimental";
            }>>;
            classification: z.ZodOptional<z.ZodObject<{
                sensitivity: z.ZodEnum<{
                    CONFIDENTIAL: "CONFIDENTIAL";
                    INTERNAL: "INTERNAL";
                    PUBLIC: "PUBLIC";
                    RESTRICTED: "RESTRICTED";
                }>;
                compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            apiName: z.ZodString;
            description: z.ZodString;
            properties: z.ZodRecord<z.ZodString, z.ZodObject<{
                typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    kind: z.ZodString;
                    name: z.ZodString;
                }, z.core.$strict>>>;
                renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
                status: z.ZodOptional<z.ZodEnum<{
                    active: "active";
                    deprecated: "deprecated";
                    experimental: "experimental";
                }>>;
                classification: z.ZodOptional<z.ZodObject<{
                    sensitivity: z.ZodEnum<{
                        CONFIDENTIAL: "CONFIDENTIAL";
                        INTERNAL: "INTERNAL";
                        PUBLIC: "PUBLIC";
                        RESTRICTED: "RESTRICTED";
                    }>;
                    compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                description: z.ZodDefault<z.ZodString>;
                schema: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
                required: z.ZodDefault<z.ZodBoolean>;
                sharedProperty: z.ZodOptional<z.ZodString>;
                valueType: z.ZodOptional<z.ZodObject<{
                    name: z.ZodString;
                    version: z.ZodString;
                }, z.core.$strict>>;
                struct: z.ZodOptional<z.ZodObject<{
                    type: z.ZodString;
                    mainField: z.ZodOptional<z.ZodString>;
                    reducer: z.ZodOptional<z.ZodObject<{
                        op: z.ZodEnum<{
                            first: "first";
                            last: "last";
                            max: "max";
                            min: "min";
                        }>;
                        field: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>>;
                    array: z.ZodOptional<z.ZodBoolean>;
                }, z.core.$strict>>;
                format: z.ZodOptional<z.ZodObject<{
                    kind: z.ZodEnum<{
                        currency: "currency";
                        date: "date";
                        number: "number";
                        percent: "percent";
                        text: "text";
                    }>;
                    locale: z.ZodOptional<z.ZodString>;
                    currency: z.ZodOptional<z.ZodString>;
                    minimumFractionDigits: z.ZodOptional<z.ZodNumber>;
                    maximumFractionDigits: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>>;
                derived: z.ZodOptional<z.ZodType<import("../ontology/schema.js").DerivedExpression, unknown, z.core.$ZodTypeInternals<import("../ontology/schema.js").DerivedExpression, unknown>>>;
            }, z.core.$strict>>;
            extends: z.ZodOptional<z.ZodArray<z.ZodString>>;
            optionalProperties: z.ZodArray<z.ZodString>;
            links: z.ZodRecord<z.ZodString, z.ZodObject<{
                target: z.ZodString;
                cardinality: z.ZodEnum<{
                    many: "many";
                    one: "one";
                }>;
                required: z.ZodBoolean;
            }, z.core.$strict>>;
            actions: z.ZodRecord<z.ZodString, z.ZodObject<{
                parameters: z.ZodRecord<z.ZodString, z.ZodUnknown>;
                objectParameters: z.ZodRecord<z.ZodString, z.ZodString>;
                required: z.ZodBoolean;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        linkTypes: z.ZodArray<z.ZodObject<{
            typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>>;
            renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
            status: z.ZodOptional<z.ZodEnum<{
                active: "active";
                deprecated: "deprecated";
                experimental: "experimental";
            }>>;
            classification: z.ZodOptional<z.ZodObject<{
                sensitivity: z.ZodEnum<{
                    CONFIDENTIAL: "CONFIDENTIAL";
                    INTERNAL: "INTERNAL";
                    PUBLIC: "PUBLIC";
                    RESTRICTED: "RESTRICTED";
                }>;
                compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            apiName: z.ZodString;
            description: z.ZodString;
            from: z.ZodObject<{
                type: z.ZodString;
                name: z.ZodString;
                cardinality: z.ZodEnum<{
                    many: "many";
                    one: "one";
                }>;
            }, z.core.$strict>;
            to: z.ZodObject<{
                type: z.ZodString;
                name: z.ZodString;
                cardinality: z.ZodEnum<{
                    many: "many";
                    one: "one";
                }>;
            }, z.core.$strict>;
        }, z.core.$strict>>;
        functionTypes: z.ZodArray<z.ZodObject<{
            typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>>;
            renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
            status: z.ZodOptional<z.ZodEnum<{
                active: "active";
                deprecated: "deprecated";
                experimental: "experimental";
            }>>;
            classification: z.ZodOptional<z.ZodObject<{
                sensitivity: z.ZodEnum<{
                    CONFIDENTIAL: "CONFIDENTIAL";
                    INTERNAL: "INTERNAL";
                    PUBLIC: "PUBLIC";
                    RESTRICTED: "RESTRICTED";
                }>;
                compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            apiName: z.ZodString;
            description: z.ZodString;
            parameters: z.ZodRecord<z.ZodString, z.ZodUnknown>;
            returns: z.ZodRecord<z.ZodString, z.ZodUnknown>;
            source: z.ZodOptional<z.ZodString>;
            edits: z.ZodOptional<z.ZodBoolean>;
            version: z.ZodOptional<z.ZodString>;
            dependencies: z.ZodOptional<z.ZodObject<{
                objectTypes: z.ZodOptional<z.ZodArray<z.ZodString>>;
                interfaceTypes: z.ZodOptional<z.ZodArray<z.ZodString>>;
                linkTypes: z.ZodOptional<z.ZodArray<z.ZodString>>;
                functions: z.ZodOptional<z.ZodArray<z.ZodString>>;
                dataSources: z.ZodOptional<z.ZodArray<z.ZodString>>;
                actions: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            implementation: z.ZodOptional<z.ZodObject<{
                kind: z.ZodLiteral<"component">;
                sha256: z.ZodString;
                limits: z.ZodObject<{
                    fuel: z.ZodNumber;
                    memoryMb: z.ZodNumber;
                    deadlineMs: z.ZodNumber;
                    inputBytes: z.ZodOptional<z.ZodNumber>;
                    outputBytes: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        actionTypes: z.ZodArray<z.ZodObject<{
            typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>>;
            renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
            status: z.ZodOptional<z.ZodEnum<{
                active: "active";
                deprecated: "deprecated";
                experimental: "experimental";
            }>>;
            classification: z.ZodOptional<z.ZodObject<{
                sensitivity: z.ZodEnum<{
                    CONFIDENTIAL: "CONFIDENTIAL";
                    INTERNAL: "INTERNAL";
                    PUBLIC: "PUBLIC";
                    RESTRICTED: "RESTRICTED";
                }>;
                compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            apiName: z.ZodString;
            description: z.ZodString;
            parameters: z.ZodRecord<z.ZodString, z.ZodUnknown>;
            objectParameters: z.ZodRecord<z.ZodString, z.ZodString>;
            submissionCriteria: z.ZodArray<z.ZodObject<{
                function: z.ZodString;
                arguments: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>>;
                message: z.ZodOptional<z.ZodString>;
                functionVersion: z.ZodOptional<z.ZodString>;
                executionContext: z.ZodOptional<z.ZodEnum<{
                    live: "live";
                    scenario: "scenario";
                }>>;
            }, z.core.$strict>>;
            rules: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                op: z.ZodLiteral<"createObject">;
                object: z.ZodObject<{
                    type: z.ZodString;
                    id: z.ZodUnion<readonly [z.ZodObject<{
                        parameter: z.ZodString;
                        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>, z.ZodObject<{
                        literal: z.ZodUnknown;
                    }, z.core.$strict>]>;
                }, z.core.$strict>;
                properties: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>>;
            }, z.core.$strict>, z.ZodObject<{
                op: z.ZodLiteral<"editObject">;
                object: z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>;
                expectedRevision: z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>;
                properties: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>>;
            }, z.core.$strict>, z.ZodObject<{
                op: z.ZodLiteral<"addLink">;
                link: z.ZodString;
                from: z.ZodObject<{
                    type: z.ZodString;
                    id: z.ZodUnion<readonly [z.ZodObject<{
                        parameter: z.ZodString;
                        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>, z.ZodObject<{
                        literal: z.ZodUnknown;
                    }, z.core.$strict>]>;
                }, z.core.$strict>;
                to: z.ZodObject<{
                    type: z.ZodString;
                    id: z.ZodUnion<readonly [z.ZodObject<{
                        parameter: z.ZodString;
                        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>, z.ZodObject<{
                        literal: z.ZodUnknown;
                    }, z.core.$strict>]>;
                }, z.core.$strict>;
            }, z.core.$strict>, z.ZodObject<{
                op: z.ZodLiteral<"removeLink">;
                link: z.ZodString;
                from: z.ZodObject<{
                    type: z.ZodString;
                    id: z.ZodUnion<readonly [z.ZodObject<{
                        parameter: z.ZodString;
                        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>, z.ZodObject<{
                        literal: z.ZodUnknown;
                    }, z.core.$strict>]>;
                }, z.core.$strict>;
                to: z.ZodObject<{
                    type: z.ZodString;
                    id: z.ZodUnion<readonly [z.ZodObject<{
                        parameter: z.ZodString;
                        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>, z.ZodObject<{
                        literal: z.ZodUnknown;
                    }, z.core.$strict>]>;
                }, z.core.$strict>;
            }, z.core.$strict>, z.ZodObject<{
                op: z.ZodLiteral<"deleteObject">;
                object: z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>;
                expectedRevision: z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>;
            }, z.core.$strict>, z.ZodObject<{
                op: z.ZodLiteral<"editStruct">;
                object: z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>;
                expectedRevision: z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>;
                property: z.ZodString;
                fields: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>>;
            }, z.core.$strict>, z.ZodObject<{
                op: z.ZodLiteral<"applyScenario">;
                scenario: z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>;
                expectedRevision: z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>;
                objectTypes: z.ZodArray<z.ZodString>;
                linkTypes: z.ZodArray<z.ZodString>;
            }, z.core.$strict>], "op">>>;
            result: z.ZodOptional<z.ZodObject<{
                type: z.ZodString;
                id: z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>;
            }, z.core.$strict>>;
            function: z.ZodOptional<z.ZodString>;
            functionVersion: z.ZodOptional<z.ZodString>;
            effects: z.ZodOptional<z.ZodArray<z.ZodUnion<readonly [z.ZodObject<{
                name: z.ZodString;
                handler: z.ZodString;
                payload: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>>;
            }, z.core.$strict>, z.ZodObject<{
                name: z.ZodString;
                webhook: z.ZodObject<{
                    source: z.ZodString;
                    method: z.ZodEnum<{
                        DELETE: "DELETE";
                        PATCH: "PATCH";
                        POST: "POST";
                        PUT: "PUT";
                    }>;
                    path: z.ZodString;
                    function: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                payload: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>>;
            }, z.core.$strict>]>>>;
        }, z.core.$strict>>;
        dataSources: z.ZodArray<z.ZodObject<{
            apiName: z.ZodString;
            objectType: z.ZodString;
            function: z.ZodString;
            classification: z.ZodOptional<z.ZodObject<{
                sensitivity: z.ZodEnum<{
                    CONFIDENTIAL: "CONFIDENTIAL";
                    INTERNAL: "INTERNAL";
                    PUBLIC: "PUBLIC";
                    RESTRICTED: "RESTRICTED";
                }>;
                compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            properties: z.ZodRecord<z.ZodString, z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const branchReviewSchema: z.ZodObject<{
    id: z.ZodUUID;
    revision: z.ZodNumber;
    release: z.ZodString;
}, z.core.$strict>;
export declare function initializeGovernance(db: Database): Promise<void>;
export interface Branch {
    id: string;
    ontology: string;
    project: string | null;
    name: string;
    author: string;
    base_release: string;
    machinery_evidence: ProposalEvidence | null;
    body: OntologyDocument;
    revision: number;
    state: string;
    candidate: string | null;
    reviewer: string | null;
    reviewed_digest: string | null;
}
export declare class Governance {
    private readonly db;
    private readonly metadata;
    private readonly bindings;
    constructor(db: Database, metadata: Metadata, bindings: Bindings);
    private authorize;
    private row;
    project(access: Access, raw: unknown): Promise<{
        ontology: string;
        id: string;
        name: string;
    }>;
    assign(access: Access, raw: unknown): Promise<{
        ontology: string;
        project: string;
        resources: string[];
    }>;
    private validateChanges;
    create(access: Access, raw: unknown, evidence?: ProposalEvidence): Promise<{
        id: string;
        ontology: string;
        project: string | null;
        name: string;
        author: string;
        base_release: string;
        body: OntologyDocument;
        revision: number;
        state: string;
        candidate: string | null;
        reviewer: string | null;
        reviewed_digest: string | null;
        proposalEvidence?: {
            process: string;
            release: string;
            from: string;
            to: string;
            scope: 'earlier_revision';
        } | {
            process: string;
            release: string;
            from: string;
            to: string;
            scope: 'recorded';
            summary: {
                cases: number;
                deviationCases: number;
                candidateDeviationCases: number;
                bottlenecks: {
                    state: string;
                    completedP95Ms: number | null;
                }[];
                affectedEdges: {
                    from: string | null;
                    to: string | null;
                    observedCases: number;
                }[];
            };
        } | {
            process: string;
            release: string;
            from: string;
            to: string;
            scope: 'restricted';
        } | {
            process: string;
            release: string;
            from: string;
            to: string;
            scope: 'reviewer';
            summary: {
                cases: number;
                deviationCases: number;
                candidateDeviationCases: number;
                bottlenecks: {
                    state: string;
                    completedP95Ms: number | null;
                }[];
                affectedEdges: {
                    from: string | null;
                    to: string | null;
                    observedCases: number;
                }[];
            };
        } | {
            process: string;
            release: string;
            from: string;
            to: string;
            scope: 'unavailable';
        } | undefined;
    }>;
    read(access: Access, id: string): Promise<{
        id: string;
        ontology: string;
        project: string | null;
        name: string;
        author: string;
        base_release: string;
        body: OntologyDocument;
        revision: number;
        state: string;
        candidate: string | null;
        reviewer: string | null;
        reviewed_digest: string | null;
        proposalEvidence?: {
            process: string;
            release: string;
            from: string;
            to: string;
            scope: 'earlier_revision';
        } | {
            process: string;
            release: string;
            from: string;
            to: string;
            scope: 'recorded';
            summary: {
                cases: number;
                deviationCases: number;
                candidateDeviationCases: number;
                bottlenecks: {
                    state: string;
                    completedP95Ms: number | null;
                }[];
                affectedEdges: {
                    from: string | null;
                    to: string | null;
                    observedCases: number;
                }[];
            };
        } | {
            process: string;
            release: string;
            from: string;
            to: string;
            scope: 'restricted';
        } | {
            process: string;
            release: string;
            from: string;
            to: string;
            scope: 'reviewer';
            summary: {
                cases: number;
                deviationCases: number;
                candidateDeviationCases: number;
                bottlenecks: {
                    state: string;
                    completedP95Ms: number | null;
                }[];
                affectedEdges: {
                    from: string | null;
                    to: string | null;
                    observedCases: number;
                }[];
            };
        } | {
            process: string;
            release: string;
            from: string;
            to: string;
            scope: 'unavailable';
        } | undefined;
    }>;
    list(access: Access, ontology: string): Promise<import("pg").QueryResultRow[]>;
    update(access: Access, raw: unknown): Promise<{
        id: string;
        revision: number;
        state: string;
    }>;
    prepare(access: Access, raw: unknown): Promise<{
        id: string;
        revision: number;
        state: string;
        release: string;
    }>;
    /** Catch-up retains the projection identity and invalidates the prior review. */
    catchUp(access: Access, raw: unknown): Promise<{
        release: string;
        projection: string;
        objectsUpdated: number;
        linksAdded: number;
        id: string;
        revision: number;
        state: string;
    }>;
    rebase(access: Access, raw: unknown): Promise<{
        id: string;
        revision: number;
        state: string;
        baseRelease: string;
    }>;
    refreshMachineryEvidence(access: Access, id: string, revision: number, query: ProposalEvidence['query']): Promise<{
        id: string;
        revision: any;
        state: string;
    }>;
    private reviewDigest;
    review(access: Access, raw: unknown): Promise<{
        id: string;
        revision: number;
        state: string;
        release: string;
    }>;
    merge(access: Access, raw: unknown): Promise<{
        id: string;
        revision: number;
        state: string;
        release: string;
    }>;
}
