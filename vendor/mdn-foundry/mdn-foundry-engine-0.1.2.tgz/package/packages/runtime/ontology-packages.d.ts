import { z } from 'zod';
export { migrateOntologyDataSchema, readDataMigrationSchema } from './ontology-migrations.js';
import { type OntologyDocument } from '../ontology/schema.js';
import { Access } from './access.js';
import type { Database } from './database.js';
import { Metadata, type Bindings } from './metadata.js';
export declare const ontologyResourceSchema: z.ZodObject<{
    kind: z.ZodEnum<{
        action: "action";
        agentProfile: "agentProfile";
        datasource: "datasource";
        function: "function";
        group: "group";
        interface: "interface";
        link: "link";
        object: "object";
        sharedProperty: "sharedProperty";
        struct: "struct";
        valueType: "valueType";
    }>;
    name: z.ZodString;
    version: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export declare const exportPackageSchema: z.ZodObject<{
    ontology: z.ZodString;
    resources: z.ZodArray<z.ZodObject<{
        kind: z.ZodEnum<{
            action: "action";
            agentProfile: "agentProfile";
            datasource: "datasource";
            function: "function";
            group: "group";
            interface: "interface";
            link: "link";
            object: "object";
            sharedProperty: "sharedProperty";
            struct: "struct";
            valueType: "valueType";
        }>;
        name: z.ZodString;
        version: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const ontologyPackageSchema: z.ZodObject<{
    format: z.ZodLiteral<"eigos-ontology-package-v1">;
    ontology: z.ZodString;
    version: z.ZodString;
    digest: z.ZodString;
    document: z.ZodObject<{
        id: z.ZodString;
        version: z.ZodString;
        classification: z.ZodOptional<z.ZodObject<{
            sensitivity: z.ZodEnum<{
                CONFIDENTIAL: "CONFIDENTIAL";
                INTERNAL: "INTERNAL";
                PUBLIC: "PUBLIC";
                RESTRICTED: "RESTRICTED";
            }>;
            compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        sharedProperties: z.ZodOptional<z.ZodArray<z.ZodObject<{
            typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>>;
            renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
            status: z.ZodOptional<z.ZodEnum<{
                active: "active";
                deprecated: "deprecated";
                experimental: "experimental";
            }>>;
            classification: z.ZodOptional<z.ZodObject<{
                sensitivity: z.ZodEnum<{
                    CONFIDENTIAL: "CONFIDENTIAL";
                    INTERNAL: "INTERNAL";
                    PUBLIC: "PUBLIC";
                    RESTRICTED: "RESTRICTED";
                }>;
                compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            description: z.ZodDefault<z.ZodString>;
            schema: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
            required: z.ZodDefault<z.ZodBoolean>;
            sharedProperty: z.ZodOptional<z.ZodString>;
            valueType: z.ZodOptional<z.ZodObject<{
                name: z.ZodString;
                version: z.ZodString;
            }, z.core.$strict>>;
            struct: z.ZodOptional<z.ZodObject<{
                type: z.ZodString;
                mainField: z.ZodOptional<z.ZodString>;
                reducer: z.ZodOptional<z.ZodObject<{
                    op: z.ZodEnum<{
                        first: "first";
                        last: "last";
                        max: "max";
                        min: "min";
                    }>;
                    field: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
                array: z.ZodOptional<z.ZodBoolean>;
            }, z.core.$strict>>;
            format: z.ZodOptional<z.ZodObject<{
                kind: z.ZodEnum<{
                    currency: "currency";
                    date: "date";
                    number: "number";
                    percent: "percent";
                    text: "text";
                }>;
                locale: z.ZodOptional<z.ZodString>;
                currency: z.ZodOptional<z.ZodString>;
                minimumFractionDigits: z.ZodOptional<z.ZodNumber>;
                maximumFractionDigits: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>>;
            derived: z.ZodOptional<z.ZodType<import("../ontology/schema.js").DerivedExpression, unknown, z.core.$ZodTypeInternals<import("../ontology/schema.js").DerivedExpression, unknown>>>;
            apiName: z.ZodString;
        }, z.core.$strict>>>;
        valueTypes: z.ZodOptional<z.ZodArray<z.ZodObject<{
            typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>>;
            renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
            status: z.ZodOptional<z.ZodEnum<{
                active: "active";
                deprecated: "deprecated";
                experimental: "experimental";
            }>>;
            classification: z.ZodOptional<z.ZodObject<{
                sensitivity: z.ZodEnum<{
                    CONFIDENTIAL: "CONFIDENTIAL";
                    INTERNAL: "INTERNAL";
                    PUBLIC: "PUBLIC";
                    RESTRICTED: "RESTRICTED";
                }>;
                compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            apiName: z.ZodString;
            version: z.ZodString;
            description: z.ZodString;
            schema: z.ZodRecord<z.ZodString, z.ZodUnknown>;
        }, z.core.$strict>>>;
        structTypes: z.ZodOptional<z.ZodArray<z.ZodObject<{
            typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>>;
            renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
            status: z.ZodOptional<z.ZodEnum<{
                active: "active";
                deprecated: "deprecated";
                experimental: "experimental";
            }>>;
            classification: z.ZodOptional<z.ZodObject<{
                sensitivity: z.ZodEnum<{
                    CONFIDENTIAL: "CONFIDENTIAL";
                    INTERNAL: "INTERNAL";
                    PUBLIC: "PUBLIC";
                    RESTRICTED: "RESTRICTED";
                }>;
                compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            apiName: z.ZodString;
            description: z.ZodString;
            fields: z.ZodRecord<z.ZodString, z.ZodRecord<z.ZodString, z.ZodUnknown>>;
            required: z.ZodOptional<z.ZodArray<z.ZodString>>;
            mainField: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>>;
        typeGroups: z.ZodOptional<z.ZodArray<z.ZodObject<{
            apiName: z.ZodString;
            displayName: z.ZodString;
            description: z.ZodString;
            objectTypes: z.ZodArray<z.ZodString>;
        }, z.core.$strict>>>;
        agentProfiles: z.ZodOptional<z.ZodArray<z.ZodObject<{
            apiName: z.ZodString;
            terms: z.ZodArray<z.ZodString>;
            objects: z.ZodOptional<z.ZodArray<z.ZodString>>;
            interfaces: z.ZodOptional<z.ZodArray<z.ZodString>>;
            actions: z.ZodOptional<z.ZodArray<z.ZodString>>;
            functions: z.ZodOptional<z.ZodArray<z.ZodString>>;
            sources: z.ZodOptional<z.ZodArray<z.ZodString>>;
            links: z.ZodOptional<z.ZodArray<z.ZodString>>;
            instructions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                action: z.ZodOptional<z.ZodString>;
                function: z.ZodOptional<z.ZodString>;
                text: z.ZodString;
            }, z.core.$strict>>>;
        }, z.core.$strict>>>;
        imports: z.ZodOptional<z.ZodArray<z.ZodObject<{
            ontology: z.ZodString;
            version: z.ZodString;
            digest: z.ZodString;
            namespace: z.ZodString;
            document: z.ZodUnknown;
        }, z.core.$strict>>>;
        objectTypes: z.ZodArray<z.ZodObject<{
            typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>>;
            renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
            status: z.ZodOptional<z.ZodEnum<{
                active: "active";
                deprecated: "deprecated";
                experimental: "experimental";
            }>>;
            classification: z.ZodOptional<z.ZodObject<{
                sensitivity: z.ZodEnum<{
                    CONFIDENTIAL: "CONFIDENTIAL";
                    INTERNAL: "INTERNAL";
                    PUBLIC: "PUBLIC";
                    RESTRICTED: "RESTRICTED";
                }>;
                compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            apiName: z.ZodString;
            displayName: z.ZodString;
            description: z.ZodString;
            primaryKey: z.ZodString;
            titleProperty: z.ZodString;
            properties: z.ZodRecord<z.ZodString, z.ZodObject<{
                typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    kind: z.ZodString;
                    name: z.ZodString;
                }, z.core.$strict>>>;
                renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
                status: z.ZodOptional<z.ZodEnum<{
                    active: "active";
                    deprecated: "deprecated";
                    experimental: "experimental";
                }>>;
                classification: z.ZodOptional<z.ZodObject<{
                    sensitivity: z.ZodEnum<{
                        CONFIDENTIAL: "CONFIDENTIAL";
                        INTERNAL: "INTERNAL";
                        PUBLIC: "PUBLIC";
                        RESTRICTED: "RESTRICTED";
                    }>;
                    compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                description: z.ZodDefault<z.ZodString>;
                schema: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
                required: z.ZodDefault<z.ZodBoolean>;
                sharedProperty: z.ZodOptional<z.ZodString>;
                valueType: z.ZodOptional<z.ZodObject<{
                    name: z.ZodString;
                    version: z.ZodString;
                }, z.core.$strict>>;
                struct: z.ZodOptional<z.ZodObject<{
                    type: z.ZodString;
                    mainField: z.ZodOptional<z.ZodString>;
                    reducer: z.ZodOptional<z.ZodObject<{
                        op: z.ZodEnum<{
                            first: "first";
                            last: "last";
                            max: "max";
                            min: "min";
                        }>;
                        field: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>>;
                    array: z.ZodOptional<z.ZodBoolean>;
                }, z.core.$strict>>;
                format: z.ZodOptional<z.ZodObject<{
                    kind: z.ZodEnum<{
                        currency: "currency";
                        date: "date";
                        number: "number";
                        percent: "percent";
                        text: "text";
                    }>;
                    locale: z.ZodOptional<z.ZodString>;
                    currency: z.ZodOptional<z.ZodString>;
                    minimumFractionDigits: z.ZodOptional<z.ZodNumber>;
                    maximumFractionDigits: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>>;
                derived: z.ZodOptional<z.ZodType<import("../ontology/schema.js").DerivedExpression, unknown, z.core.$ZodTypeInternals<import("../ontology/schema.js").DerivedExpression, unknown>>>;
            }, z.core.$strict>>;
            machinery: z.ZodOptional<z.ZodObject<{
                states: z.ZodArray<z.ZodObject<{
                    name: z.ZodString;
                    terminal: z.ZodOptional<z.ZodBoolean>;
                    dwellSeconds: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>>;
                transitions: z.ZodArray<z.ZodObject<{
                    from: z.ZodNullable<z.ZodString>;
                    to: z.ZodNullable<z.ZodString>;
                    action: z.ZodOptional<z.ZodString>;
                    execution: z.ZodOptional<z.ZodObject<{
                        subject: z.ZodString;
                        parameters: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
                        requires: z.ZodOptional<z.ZodArray<z.ZodObject<{
                            process: z.ZodString;
                            link: z.ZodOptional<z.ZodString>;
                            states: z.ZodArray<z.ZodString>;
                            match: z.ZodDefault<z.ZodEnum<{
                                all: "all";
                                any: "any";
                            }>>;
                        }, z.core.$strict>>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                subprocesses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    link: z.ZodString;
                    process: z.ZodString;
                }, z.core.$strict>>>;
                parallel: z.ZodOptional<z.ZodArray<z.ZodString>>;
                metrics: z.ZodOptional<z.ZodObject<{
                    node: z.ZodOptional<z.ZodObject<{
                        label: z.ZodString;
                        aggregation: z.ZodDiscriminatedUnion<[z.ZodObject<{
                            op: z.ZodLiteral<"count">;
                        }, z.core.$strict>, z.ZodObject<{
                            op: z.ZodEnum<{
                                avg: "avg";
                                max: "max";
                                min: "min";
                                sum: "sum";
                            }>;
                            property: z.ZodString;
                        }, z.core.$strict>], "op">;
                        decimals: z.ZodOptional<z.ZodNumber>;
                        unit: z.ZodOptional<z.ZodString>;
                        colors: z.ZodOptional<z.ZodArray<z.ZodObject<{
                            min: z.ZodNumber;
                            color: z.ZodEnum<{
                                amber: "amber";
                                green: "green";
                                red: "red";
                            }>;
                        }, z.core.$strict>>>;
                    }, z.core.$strict>>;
                    edge: z.ZodOptional<z.ZodObject<{
                        label: z.ZodString;
                        aggregation: z.ZodDiscriminatedUnion<[z.ZodObject<{
                            op: z.ZodLiteral<"count">;
                        }, z.core.$strict>, z.ZodObject<{
                            op: z.ZodEnum<{
                                avg: "avg";
                                max: "max";
                                min: "min";
                                sum: "sum";
                            }>;
                            property: z.ZodString;
                        }, z.core.$strict>], "op">;
                        decimals: z.ZodOptional<z.ZodNumber>;
                        unit: z.ZodOptional<z.ZodString>;
                        colors: z.ZodOptional<z.ZodArray<z.ZodObject<{
                            min: z.ZodNumber;
                            color: z.ZodEnum<{
                                amber: "amber";
                                green: "green";
                                red: "red";
                            }>;
                        }, z.core.$strict>>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            classificationProperty: z.ZodOptional<z.ZodString>;
            groups: z.ZodOptional<z.ZodArray<z.ZodString>>;
            interfaces: z.ZodRecord<z.ZodString, z.ZodObject<{
                properties: z.ZodRecord<z.ZodString, z.ZodString>;
                links: z.ZodRecord<z.ZodString, z.ZodString>;
                actions: z.ZodRecord<z.ZodString, z.ZodObject<{
                    action: z.ZodString;
                    parameters: z.ZodRecord<z.ZodString, z.ZodString>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        interfaceTypes: z.ZodArray<z.ZodObject<{
            typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>>;
            renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
            status: z.ZodOptional<z.ZodEnum<{
                active: "active";
                deprecated: "deprecated";
                experimental: "experimental";
            }>>;
            classification: z.ZodOptional<z.ZodObject<{
                sensitivity: z.ZodEnum<{
                    CONFIDENTIAL: "CONFIDENTIAL";
                    INTERNAL: "INTERNAL";
                    PUBLIC: "PUBLIC";
                    RESTRICTED: "RESTRICTED";
                }>;
                compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            apiName: z.ZodString;
            description: z.ZodString;
            properties: z.ZodRecord<z.ZodString, z.ZodObject<{
                typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    kind: z.ZodString;
                    name: z.ZodString;
                }, z.core.$strict>>>;
                renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
                status: z.ZodOptional<z.ZodEnum<{
                    active: "active";
                    deprecated: "deprecated";
                    experimental: "experimental";
                }>>;
                classification: z.ZodOptional<z.ZodObject<{
                    sensitivity: z.ZodEnum<{
                        CONFIDENTIAL: "CONFIDENTIAL";
                        INTERNAL: "INTERNAL";
                        PUBLIC: "PUBLIC";
                        RESTRICTED: "RESTRICTED";
                    }>;
                    compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                description: z.ZodDefault<z.ZodString>;
                schema: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
                required: z.ZodDefault<z.ZodBoolean>;
                sharedProperty: z.ZodOptional<z.ZodString>;
                valueType: z.ZodOptional<z.ZodObject<{
                    name: z.ZodString;
                    version: z.ZodString;
                }, z.core.$strict>>;
                struct: z.ZodOptional<z.ZodObject<{
                    type: z.ZodString;
                    mainField: z.ZodOptional<z.ZodString>;
                    reducer: z.ZodOptional<z.ZodObject<{
                        op: z.ZodEnum<{
                            first: "first";
                            last: "last";
                            max: "max";
                            min: "min";
                        }>;
                        field: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>>;
                    array: z.ZodOptional<z.ZodBoolean>;
                }, z.core.$strict>>;
                format: z.ZodOptional<z.ZodObject<{
                    kind: z.ZodEnum<{
                        currency: "currency";
                        date: "date";
                        number: "number";
                        percent: "percent";
                        text: "text";
                    }>;
                    locale: z.ZodOptional<z.ZodString>;
                    currency: z.ZodOptional<z.ZodString>;
                    minimumFractionDigits: z.ZodOptional<z.ZodNumber>;
                    maximumFractionDigits: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>>;
                derived: z.ZodOptional<z.ZodType<import("../ontology/schema.js").DerivedExpression, unknown, z.core.$ZodTypeInternals<import("../ontology/schema.js").DerivedExpression, unknown>>>;
            }, z.core.$strict>>;
            extends: z.ZodOptional<z.ZodArray<z.ZodString>>;
            optionalProperties: z.ZodArray<z.ZodString>;
            links: z.ZodRecord<z.ZodString, z.ZodObject<{
                target: z.ZodString;
                cardinality: z.ZodEnum<{
                    many: "many";
                    one: "one";
                }>;
                required: z.ZodBoolean;
            }, z.core.$strict>>;
            actions: z.ZodRecord<z.ZodString, z.ZodObject<{
                parameters: z.ZodRecord<z.ZodString, z.ZodUnknown>;
                objectParameters: z.ZodRecord<z.ZodString, z.ZodString>;
                required: z.ZodBoolean;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        linkTypes: z.ZodArray<z.ZodObject<{
            typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>>;
            renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
            status: z.ZodOptional<z.ZodEnum<{
                active: "active";
                deprecated: "deprecated";
                experimental: "experimental";
            }>>;
            classification: z.ZodOptional<z.ZodObject<{
                sensitivity: z.ZodEnum<{
                    CONFIDENTIAL: "CONFIDENTIAL";
                    INTERNAL: "INTERNAL";
                    PUBLIC: "PUBLIC";
                    RESTRICTED: "RESTRICTED";
                }>;
                compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            apiName: z.ZodString;
            description: z.ZodString;
            from: z.ZodObject<{
                type: z.ZodString;
                name: z.ZodString;
                cardinality: z.ZodEnum<{
                    many: "many";
                    one: "one";
                }>;
            }, z.core.$strict>;
            to: z.ZodObject<{
                type: z.ZodString;
                name: z.ZodString;
                cardinality: z.ZodEnum<{
                    many: "many";
                    one: "one";
                }>;
            }, z.core.$strict>;
        }, z.core.$strict>>;
        functionTypes: z.ZodArray<z.ZodObject<{
            typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>>;
            renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
            status: z.ZodOptional<z.ZodEnum<{
                active: "active";
                deprecated: "deprecated";
                experimental: "experimental";
            }>>;
            classification: z.ZodOptional<z.ZodObject<{
                sensitivity: z.ZodEnum<{
                    CONFIDENTIAL: "CONFIDENTIAL";
                    INTERNAL: "INTERNAL";
                    PUBLIC: "PUBLIC";
                    RESTRICTED: "RESTRICTED";
                }>;
                compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            apiName: z.ZodString;
            description: z.ZodString;
            parameters: z.ZodRecord<z.ZodString, z.ZodUnknown>;
            returns: z.ZodRecord<z.ZodString, z.ZodUnknown>;
            source: z.ZodOptional<z.ZodString>;
            edits: z.ZodOptional<z.ZodBoolean>;
            version: z.ZodOptional<z.ZodString>;
            dependencies: z.ZodOptional<z.ZodObject<{
                objectTypes: z.ZodOptional<z.ZodArray<z.ZodString>>;
                interfaceTypes: z.ZodOptional<z.ZodArray<z.ZodString>>;
                linkTypes: z.ZodOptional<z.ZodArray<z.ZodString>>;
                functions: z.ZodOptional<z.ZodArray<z.ZodString>>;
                dataSources: z.ZodOptional<z.ZodArray<z.ZodString>>;
                actions: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            implementation: z.ZodOptional<z.ZodObject<{
                kind: z.ZodLiteral<"component">;
                sha256: z.ZodString;
                limits: z.ZodObject<{
                    fuel: z.ZodNumber;
                    memoryMb: z.ZodNumber;
                    deadlineMs: z.ZodNumber;
                    inputBytes: z.ZodOptional<z.ZodNumber>;
                    outputBytes: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        actionTypes: z.ZodArray<z.ZodObject<{
            typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>>;
            renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
            status: z.ZodOptional<z.ZodEnum<{
                active: "active";
                deprecated: "deprecated";
                experimental: "experimental";
            }>>;
            classification: z.ZodOptional<z.ZodObject<{
                sensitivity: z.ZodEnum<{
                    CONFIDENTIAL: "CONFIDENTIAL";
                    INTERNAL: "INTERNAL";
                    PUBLIC: "PUBLIC";
                    RESTRICTED: "RESTRICTED";
                }>;
                compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            apiName: z.ZodString;
            description: z.ZodString;
            parameters: z.ZodRecord<z.ZodString, z.ZodUnknown>;
            objectParameters: z.ZodRecord<z.ZodString, z.ZodString>;
            submissionCriteria: z.ZodArray<z.ZodObject<{
                function: z.ZodString;
                arguments: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>>;
                message: z.ZodOptional<z.ZodString>;
                functionVersion: z.ZodOptional<z.ZodString>;
                executionContext: z.ZodOptional<z.ZodEnum<{
                    live: "live";
                    scenario: "scenario";
                }>>;
            }, z.core.$strict>>;
            rules: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                op: z.ZodLiteral<"createObject">;
                object: z.ZodObject<{
                    type: z.ZodString;
                    id: z.ZodUnion<readonly [z.ZodObject<{
                        parameter: z.ZodString;
                        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>, z.ZodObject<{
                        literal: z.ZodUnknown;
                    }, z.core.$strict>]>;
                }, z.core.$strict>;
                properties: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>>;
            }, z.core.$strict>, z.ZodObject<{
                op: z.ZodLiteral<"editObject">;
                object: z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>;
                expectedRevision: z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>;
                properties: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>>;
            }, z.core.$strict>, z.ZodObject<{
                op: z.ZodLiteral<"addLink">;
                link: z.ZodString;
                from: z.ZodObject<{
                    type: z.ZodString;
                    id: z.ZodUnion<readonly [z.ZodObject<{
                        parameter: z.ZodString;
                        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>, z.ZodObject<{
                        literal: z.ZodUnknown;
                    }, z.core.$strict>]>;
                }, z.core.$strict>;
                to: z.ZodObject<{
                    type: z.ZodString;
                    id: z.ZodUnion<readonly [z.ZodObject<{
                        parameter: z.ZodString;
                        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>, z.ZodObject<{
                        literal: z.ZodUnknown;
                    }, z.core.$strict>]>;
                }, z.core.$strict>;
            }, z.core.$strict>, z.ZodObject<{
                op: z.ZodLiteral<"removeLink">;
                link: z.ZodString;
                from: z.ZodObject<{
                    type: z.ZodString;
                    id: z.ZodUnion<readonly [z.ZodObject<{
                        parameter: z.ZodString;
                        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>, z.ZodObject<{
                        literal: z.ZodUnknown;
                    }, z.core.$strict>]>;
                }, z.core.$strict>;
                to: z.ZodObject<{
                    type: z.ZodString;
                    id: z.ZodUnion<readonly [z.ZodObject<{
                        parameter: z.ZodString;
                        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>, z.ZodObject<{
                        literal: z.ZodUnknown;
                    }, z.core.$strict>]>;
                }, z.core.$strict>;
            }, z.core.$strict>, z.ZodObject<{
                op: z.ZodLiteral<"deleteObject">;
                object: z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>;
                expectedRevision: z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>;
            }, z.core.$strict>, z.ZodObject<{
                op: z.ZodLiteral<"editStruct">;
                object: z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>;
                expectedRevision: z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>;
                property: z.ZodString;
                fields: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>>;
            }, z.core.$strict>, z.ZodObject<{
                op: z.ZodLiteral<"applyScenario">;
                scenario: z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>;
                expectedRevision: z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>;
                objectTypes: z.ZodArray<z.ZodString>;
                linkTypes: z.ZodArray<z.ZodString>;
            }, z.core.$strict>], "op">>>;
            result: z.ZodOptional<z.ZodObject<{
                type: z.ZodString;
                id: z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>;
            }, z.core.$strict>>;
            function: z.ZodOptional<z.ZodString>;
            functionVersion: z.ZodOptional<z.ZodString>;
            effects: z.ZodOptional<z.ZodArray<z.ZodUnion<readonly [z.ZodObject<{
                name: z.ZodString;
                handler: z.ZodString;
                payload: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>>;
            }, z.core.$strict>, z.ZodObject<{
                name: z.ZodString;
                webhook: z.ZodObject<{
                    source: z.ZodString;
                    method: z.ZodEnum<{
                        DELETE: "DELETE";
                        PATCH: "PATCH";
                        POST: "POST";
                        PUT: "PUT";
                    }>;
                    path: z.ZodString;
                    function: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>;
                payload: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>>;
            }, z.core.$strict>]>>>;
        }, z.core.$strict>>;
        dataSources: z.ZodArray<z.ZodObject<{
            apiName: z.ZodString;
            objectType: z.ZodString;
            function: z.ZodString;
            classification: z.ZodOptional<z.ZodObject<{
                sensitivity: z.ZodEnum<{
                    CONFIDENTIAL: "CONFIDENTIAL";
                    INTERNAL: "INTERNAL";
                    PUBLIC: "PUBLIC";
                    RESTRICTED: "RESTRICTED";
                }>;
                compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            properties: z.ZodRecord<z.ZodString, z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const importPackageSchema: z.ZodObject<{
    targetOntology: z.ZodString;
    namespace: z.ZodString;
    package: z.ZodObject<{
        format: z.ZodLiteral<"eigos-ontology-package-v1">;
        ontology: z.ZodString;
        version: z.ZodString;
        digest: z.ZodString;
        document: z.ZodObject<{
            id: z.ZodString;
            version: z.ZodString;
            classification: z.ZodOptional<z.ZodObject<{
                sensitivity: z.ZodEnum<{
                    CONFIDENTIAL: "CONFIDENTIAL";
                    INTERNAL: "INTERNAL";
                    PUBLIC: "PUBLIC";
                    RESTRICTED: "RESTRICTED";
                }>;
                compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            sharedProperties: z.ZodOptional<z.ZodArray<z.ZodObject<{
                typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    kind: z.ZodString;
                    name: z.ZodString;
                }, z.core.$strict>>>;
                renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
                status: z.ZodOptional<z.ZodEnum<{
                    active: "active";
                    deprecated: "deprecated";
                    experimental: "experimental";
                }>>;
                classification: z.ZodOptional<z.ZodObject<{
                    sensitivity: z.ZodEnum<{
                        CONFIDENTIAL: "CONFIDENTIAL";
                        INTERNAL: "INTERNAL";
                        PUBLIC: "PUBLIC";
                        RESTRICTED: "RESTRICTED";
                    }>;
                    compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                description: z.ZodDefault<z.ZodString>;
                schema: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
                required: z.ZodDefault<z.ZodBoolean>;
                sharedProperty: z.ZodOptional<z.ZodString>;
                valueType: z.ZodOptional<z.ZodObject<{
                    name: z.ZodString;
                    version: z.ZodString;
                }, z.core.$strict>>;
                struct: z.ZodOptional<z.ZodObject<{
                    type: z.ZodString;
                    mainField: z.ZodOptional<z.ZodString>;
                    reducer: z.ZodOptional<z.ZodObject<{
                        op: z.ZodEnum<{
                            first: "first";
                            last: "last";
                            max: "max";
                            min: "min";
                        }>;
                        field: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>>;
                    array: z.ZodOptional<z.ZodBoolean>;
                }, z.core.$strict>>;
                format: z.ZodOptional<z.ZodObject<{
                    kind: z.ZodEnum<{
                        currency: "currency";
                        date: "date";
                        number: "number";
                        percent: "percent";
                        text: "text";
                    }>;
                    locale: z.ZodOptional<z.ZodString>;
                    currency: z.ZodOptional<z.ZodString>;
                    minimumFractionDigits: z.ZodOptional<z.ZodNumber>;
                    maximumFractionDigits: z.ZodOptional<z.ZodNumber>;
                }, z.core.$strict>>;
                derived: z.ZodOptional<z.ZodType<import("../ontology/schema.js").DerivedExpression, unknown, z.core.$ZodTypeInternals<import("../ontology/schema.js").DerivedExpression, unknown>>>;
                apiName: z.ZodString;
            }, z.core.$strict>>>;
            valueTypes: z.ZodOptional<z.ZodArray<z.ZodObject<{
                typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    kind: z.ZodString;
                    name: z.ZodString;
                }, z.core.$strict>>>;
                renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
                status: z.ZodOptional<z.ZodEnum<{
                    active: "active";
                    deprecated: "deprecated";
                    experimental: "experimental";
                }>>;
                classification: z.ZodOptional<z.ZodObject<{
                    sensitivity: z.ZodEnum<{
                        CONFIDENTIAL: "CONFIDENTIAL";
                        INTERNAL: "INTERNAL";
                        PUBLIC: "PUBLIC";
                        RESTRICTED: "RESTRICTED";
                    }>;
                    compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                apiName: z.ZodString;
                version: z.ZodString;
                description: z.ZodString;
                schema: z.ZodRecord<z.ZodString, z.ZodUnknown>;
            }, z.core.$strict>>>;
            structTypes: z.ZodOptional<z.ZodArray<z.ZodObject<{
                typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    kind: z.ZodString;
                    name: z.ZodString;
                }, z.core.$strict>>>;
                renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
                status: z.ZodOptional<z.ZodEnum<{
                    active: "active";
                    deprecated: "deprecated";
                    experimental: "experimental";
                }>>;
                classification: z.ZodOptional<z.ZodObject<{
                    sensitivity: z.ZodEnum<{
                        CONFIDENTIAL: "CONFIDENTIAL";
                        INTERNAL: "INTERNAL";
                        PUBLIC: "PUBLIC";
                        RESTRICTED: "RESTRICTED";
                    }>;
                    compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                apiName: z.ZodString;
                description: z.ZodString;
                fields: z.ZodRecord<z.ZodString, z.ZodRecord<z.ZodString, z.ZodUnknown>>;
                required: z.ZodOptional<z.ZodArray<z.ZodString>>;
                mainField: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>>;
            typeGroups: z.ZodOptional<z.ZodArray<z.ZodObject<{
                apiName: z.ZodString;
                displayName: z.ZodString;
                description: z.ZodString;
                objectTypes: z.ZodArray<z.ZodString>;
            }, z.core.$strict>>>;
            agentProfiles: z.ZodOptional<z.ZodArray<z.ZodObject<{
                apiName: z.ZodString;
                terms: z.ZodArray<z.ZodString>;
                objects: z.ZodOptional<z.ZodArray<z.ZodString>>;
                interfaces: z.ZodOptional<z.ZodArray<z.ZodString>>;
                actions: z.ZodOptional<z.ZodArray<z.ZodString>>;
                functions: z.ZodOptional<z.ZodArray<z.ZodString>>;
                sources: z.ZodOptional<z.ZodArray<z.ZodString>>;
                links: z.ZodOptional<z.ZodArray<z.ZodString>>;
                instructions: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    action: z.ZodOptional<z.ZodString>;
                    function: z.ZodOptional<z.ZodString>;
                    text: z.ZodString;
                }, z.core.$strict>>>;
            }, z.core.$strict>>>;
            imports: z.ZodOptional<z.ZodArray<z.ZodObject<{
                ontology: z.ZodString;
                version: z.ZodString;
                digest: z.ZodString;
                namespace: z.ZodString;
                document: z.ZodUnknown;
            }, z.core.$strict>>>;
            objectTypes: z.ZodArray<z.ZodObject<{
                typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    kind: z.ZodString;
                    name: z.ZodString;
                }, z.core.$strict>>>;
                renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
                status: z.ZodOptional<z.ZodEnum<{
                    active: "active";
                    deprecated: "deprecated";
                    experimental: "experimental";
                }>>;
                classification: z.ZodOptional<z.ZodObject<{
                    sensitivity: z.ZodEnum<{
                        CONFIDENTIAL: "CONFIDENTIAL";
                        INTERNAL: "INTERNAL";
                        PUBLIC: "PUBLIC";
                        RESTRICTED: "RESTRICTED";
                    }>;
                    compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                apiName: z.ZodString;
                displayName: z.ZodString;
                description: z.ZodString;
                primaryKey: z.ZodString;
                titleProperty: z.ZodString;
                properties: z.ZodRecord<z.ZodString, z.ZodObject<{
                    typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        kind: z.ZodString;
                        name: z.ZodString;
                    }, z.core.$strict>>>;
                    renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
                    status: z.ZodOptional<z.ZodEnum<{
                        active: "active";
                        deprecated: "deprecated";
                        experimental: "experimental";
                    }>>;
                    classification: z.ZodOptional<z.ZodObject<{
                        sensitivity: z.ZodEnum<{
                            CONFIDENTIAL: "CONFIDENTIAL";
                            INTERNAL: "INTERNAL";
                            PUBLIC: "PUBLIC";
                            RESTRICTED: "RESTRICTED";
                        }>;
                        compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>>;
                    description: z.ZodDefault<z.ZodString>;
                    schema: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
                    required: z.ZodDefault<z.ZodBoolean>;
                    sharedProperty: z.ZodOptional<z.ZodString>;
                    valueType: z.ZodOptional<z.ZodObject<{
                        name: z.ZodString;
                        version: z.ZodString;
                    }, z.core.$strict>>;
                    struct: z.ZodOptional<z.ZodObject<{
                        type: z.ZodString;
                        mainField: z.ZodOptional<z.ZodString>;
                        reducer: z.ZodOptional<z.ZodObject<{
                            op: z.ZodEnum<{
                                first: "first";
                                last: "last";
                                max: "max";
                                min: "min";
                            }>;
                            field: z.ZodOptional<z.ZodString>;
                        }, z.core.$strict>>;
                        array: z.ZodOptional<z.ZodBoolean>;
                    }, z.core.$strict>>;
                    format: z.ZodOptional<z.ZodObject<{
                        kind: z.ZodEnum<{
                            currency: "currency";
                            date: "date";
                            number: "number";
                            percent: "percent";
                            text: "text";
                        }>;
                        locale: z.ZodOptional<z.ZodString>;
                        currency: z.ZodOptional<z.ZodString>;
                        minimumFractionDigits: z.ZodOptional<z.ZodNumber>;
                        maximumFractionDigits: z.ZodOptional<z.ZodNumber>;
                    }, z.core.$strict>>;
                    derived: z.ZodOptional<z.ZodType<import("../ontology/schema.js").DerivedExpression, unknown, z.core.$ZodTypeInternals<import("../ontology/schema.js").DerivedExpression, unknown>>>;
                }, z.core.$strict>>;
                machinery: z.ZodOptional<z.ZodObject<{
                    states: z.ZodArray<z.ZodObject<{
                        name: z.ZodString;
                        terminal: z.ZodOptional<z.ZodBoolean>;
                        dwellSeconds: z.ZodOptional<z.ZodNumber>;
                    }, z.core.$strict>>;
                    transitions: z.ZodArray<z.ZodObject<{
                        from: z.ZodNullable<z.ZodString>;
                        to: z.ZodNullable<z.ZodString>;
                        action: z.ZodOptional<z.ZodString>;
                        execution: z.ZodOptional<z.ZodObject<{
                            subject: z.ZodString;
                            parameters: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
                            requires: z.ZodOptional<z.ZodArray<z.ZodObject<{
                                process: z.ZodString;
                                link: z.ZodOptional<z.ZodString>;
                                states: z.ZodArray<z.ZodString>;
                                match: z.ZodDefault<z.ZodEnum<{
                                    all: "all";
                                    any: "any";
                                }>>;
                            }, z.core.$strict>>>;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                    subprocesses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        link: z.ZodString;
                        process: z.ZodString;
                    }, z.core.$strict>>>;
                    parallel: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    metrics: z.ZodOptional<z.ZodObject<{
                        node: z.ZodOptional<z.ZodObject<{
                            label: z.ZodString;
                            aggregation: z.ZodDiscriminatedUnion<[z.ZodObject<{
                                op: z.ZodLiteral<"count">;
                            }, z.core.$strict>, z.ZodObject<{
                                op: z.ZodEnum<{
                                    avg: "avg";
                                    max: "max";
                                    min: "min";
                                    sum: "sum";
                                }>;
                                property: z.ZodString;
                            }, z.core.$strict>], "op">;
                            decimals: z.ZodOptional<z.ZodNumber>;
                            unit: z.ZodOptional<z.ZodString>;
                            colors: z.ZodOptional<z.ZodArray<z.ZodObject<{
                                min: z.ZodNumber;
                                color: z.ZodEnum<{
                                    amber: "amber";
                                    green: "green";
                                    red: "red";
                                }>;
                            }, z.core.$strict>>>;
                        }, z.core.$strict>>;
                        edge: z.ZodOptional<z.ZodObject<{
                            label: z.ZodString;
                            aggregation: z.ZodDiscriminatedUnion<[z.ZodObject<{
                                op: z.ZodLiteral<"count">;
                            }, z.core.$strict>, z.ZodObject<{
                                op: z.ZodEnum<{
                                    avg: "avg";
                                    max: "max";
                                    min: "min";
                                    sum: "sum";
                                }>;
                                property: z.ZodString;
                            }, z.core.$strict>], "op">;
                            decimals: z.ZodOptional<z.ZodNumber>;
                            unit: z.ZodOptional<z.ZodString>;
                            colors: z.ZodOptional<z.ZodArray<z.ZodObject<{
                                min: z.ZodNumber;
                                color: z.ZodEnum<{
                                    amber: "amber";
                                    green: "green";
                                    red: "red";
                                }>;
                            }, z.core.$strict>>>;
                        }, z.core.$strict>>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
                classificationProperty: z.ZodOptional<z.ZodString>;
                groups: z.ZodOptional<z.ZodArray<z.ZodString>>;
                interfaces: z.ZodRecord<z.ZodString, z.ZodObject<{
                    properties: z.ZodRecord<z.ZodString, z.ZodString>;
                    links: z.ZodRecord<z.ZodString, z.ZodString>;
                    actions: z.ZodRecord<z.ZodString, z.ZodObject<{
                        action: z.ZodString;
                        parameters: z.ZodRecord<z.ZodString, z.ZodString>;
                    }, z.core.$strict>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            interfaceTypes: z.ZodArray<z.ZodObject<{
                typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    kind: z.ZodString;
                    name: z.ZodString;
                }, z.core.$strict>>>;
                renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
                status: z.ZodOptional<z.ZodEnum<{
                    active: "active";
                    deprecated: "deprecated";
                    experimental: "experimental";
                }>>;
                classification: z.ZodOptional<z.ZodObject<{
                    sensitivity: z.ZodEnum<{
                        CONFIDENTIAL: "CONFIDENTIAL";
                        INTERNAL: "INTERNAL";
                        PUBLIC: "PUBLIC";
                        RESTRICTED: "RESTRICTED";
                    }>;
                    compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                apiName: z.ZodString;
                description: z.ZodString;
                properties: z.ZodRecord<z.ZodString, z.ZodObject<{
                    typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        kind: z.ZodString;
                        name: z.ZodString;
                    }, z.core.$strict>>>;
                    renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
                    status: z.ZodOptional<z.ZodEnum<{
                        active: "active";
                        deprecated: "deprecated";
                        experimental: "experimental";
                    }>>;
                    classification: z.ZodOptional<z.ZodObject<{
                        sensitivity: z.ZodEnum<{
                            CONFIDENTIAL: "CONFIDENTIAL";
                            INTERNAL: "INTERNAL";
                            PUBLIC: "PUBLIC";
                            RESTRICTED: "RESTRICTED";
                        }>;
                        compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>>;
                    description: z.ZodDefault<z.ZodString>;
                    schema: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
                    required: z.ZodDefault<z.ZodBoolean>;
                    sharedProperty: z.ZodOptional<z.ZodString>;
                    valueType: z.ZodOptional<z.ZodObject<{
                        name: z.ZodString;
                        version: z.ZodString;
                    }, z.core.$strict>>;
                    struct: z.ZodOptional<z.ZodObject<{
                        type: z.ZodString;
                        mainField: z.ZodOptional<z.ZodString>;
                        reducer: z.ZodOptional<z.ZodObject<{
                            op: z.ZodEnum<{
                                first: "first";
                                last: "last";
                                max: "max";
                                min: "min";
                            }>;
                            field: z.ZodOptional<z.ZodString>;
                        }, z.core.$strict>>;
                        array: z.ZodOptional<z.ZodBoolean>;
                    }, z.core.$strict>>;
                    format: z.ZodOptional<z.ZodObject<{
                        kind: z.ZodEnum<{
                            currency: "currency";
                            date: "date";
                            number: "number";
                            percent: "percent";
                            text: "text";
                        }>;
                        locale: z.ZodOptional<z.ZodString>;
                        currency: z.ZodOptional<z.ZodString>;
                        minimumFractionDigits: z.ZodOptional<z.ZodNumber>;
                        maximumFractionDigits: z.ZodOptional<z.ZodNumber>;
                    }, z.core.$strict>>;
                    derived: z.ZodOptional<z.ZodType<import("../ontology/schema.js").DerivedExpression, unknown, z.core.$ZodTypeInternals<import("../ontology/schema.js").DerivedExpression, unknown>>>;
                }, z.core.$strict>>;
                extends: z.ZodOptional<z.ZodArray<z.ZodString>>;
                optionalProperties: z.ZodArray<z.ZodString>;
                links: z.ZodRecord<z.ZodString, z.ZodObject<{
                    target: z.ZodString;
                    cardinality: z.ZodEnum<{
                        many: "many";
                        one: "one";
                    }>;
                    required: z.ZodBoolean;
                }, z.core.$strict>>;
                actions: z.ZodRecord<z.ZodString, z.ZodObject<{
                    parameters: z.ZodRecord<z.ZodString, z.ZodUnknown>;
                    objectParameters: z.ZodRecord<z.ZodString, z.ZodString>;
                    required: z.ZodBoolean;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            linkTypes: z.ZodArray<z.ZodObject<{
                typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    kind: z.ZodString;
                    name: z.ZodString;
                }, z.core.$strict>>>;
                renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
                status: z.ZodOptional<z.ZodEnum<{
                    active: "active";
                    deprecated: "deprecated";
                    experimental: "experimental";
                }>>;
                classification: z.ZodOptional<z.ZodObject<{
                    sensitivity: z.ZodEnum<{
                        CONFIDENTIAL: "CONFIDENTIAL";
                        INTERNAL: "INTERNAL";
                        PUBLIC: "PUBLIC";
                        RESTRICTED: "RESTRICTED";
                    }>;
                    compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                apiName: z.ZodString;
                description: z.ZodString;
                from: z.ZodObject<{
                    type: z.ZodString;
                    name: z.ZodString;
                    cardinality: z.ZodEnum<{
                        many: "many";
                        one: "one";
                    }>;
                }, z.core.$strict>;
                to: z.ZodObject<{
                    type: z.ZodString;
                    name: z.ZodString;
                    cardinality: z.ZodEnum<{
                        many: "many";
                        one: "one";
                    }>;
                }, z.core.$strict>;
            }, z.core.$strict>>;
            functionTypes: z.ZodArray<z.ZodObject<{
                typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    kind: z.ZodString;
                    name: z.ZodString;
                }, z.core.$strict>>>;
                renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
                status: z.ZodOptional<z.ZodEnum<{
                    active: "active";
                    deprecated: "deprecated";
                    experimental: "experimental";
                }>>;
                classification: z.ZodOptional<z.ZodObject<{
                    sensitivity: z.ZodEnum<{
                        CONFIDENTIAL: "CONFIDENTIAL";
                        INTERNAL: "INTERNAL";
                        PUBLIC: "PUBLIC";
                        RESTRICTED: "RESTRICTED";
                    }>;
                    compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                apiName: z.ZodString;
                description: z.ZodString;
                parameters: z.ZodRecord<z.ZodString, z.ZodUnknown>;
                returns: z.ZodRecord<z.ZodString, z.ZodUnknown>;
                source: z.ZodOptional<z.ZodString>;
                edits: z.ZodOptional<z.ZodBoolean>;
                version: z.ZodOptional<z.ZodString>;
                dependencies: z.ZodOptional<z.ZodObject<{
                    objectTypes: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    interfaceTypes: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    linkTypes: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    functions: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    dataSources: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    actions: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                implementation: z.ZodOptional<z.ZodObject<{
                    kind: z.ZodLiteral<"component">;
                    sha256: z.ZodString;
                    limits: z.ZodObject<{
                        fuel: z.ZodNumber;
                        memoryMb: z.ZodNumber;
                        deadlineMs: z.ZodNumber;
                        inputBytes: z.ZodOptional<z.ZodNumber>;
                        outputBytes: z.ZodOptional<z.ZodNumber>;
                    }, z.core.$strict>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            actionTypes: z.ZodArray<z.ZodObject<{
                typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    kind: z.ZodString;
                    name: z.ZodString;
                }, z.core.$strict>>>;
                renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
                status: z.ZodOptional<z.ZodEnum<{
                    active: "active";
                    deprecated: "deprecated";
                    experimental: "experimental";
                }>>;
                classification: z.ZodOptional<z.ZodObject<{
                    sensitivity: z.ZodEnum<{
                        CONFIDENTIAL: "CONFIDENTIAL";
                        INTERNAL: "INTERNAL";
                        PUBLIC: "PUBLIC";
                        RESTRICTED: "RESTRICTED";
                    }>;
                    compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                apiName: z.ZodString;
                description: z.ZodString;
                parameters: z.ZodRecord<z.ZodString, z.ZodUnknown>;
                objectParameters: z.ZodRecord<z.ZodString, z.ZodString>;
                submissionCriteria: z.ZodArray<z.ZodObject<{
                    function: z.ZodString;
                    arguments: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                        parameter: z.ZodString;
                        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>, z.ZodObject<{
                        literal: z.ZodUnknown;
                    }, z.core.$strict>]>>;
                    message: z.ZodOptional<z.ZodString>;
                    functionVersion: z.ZodOptional<z.ZodString>;
                    executionContext: z.ZodOptional<z.ZodEnum<{
                        live: "live";
                        scenario: "scenario";
                    }>>;
                }, z.core.$strict>>;
                rules: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
                    op: z.ZodLiteral<"createObject">;
                    object: z.ZodObject<{
                        type: z.ZodString;
                        id: z.ZodUnion<readonly [z.ZodObject<{
                            parameter: z.ZodString;
                            path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                        }, z.core.$strict>, z.ZodObject<{
                            literal: z.ZodUnknown;
                        }, z.core.$strict>]>;
                    }, z.core.$strict>;
                    properties: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                        parameter: z.ZodString;
                        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>, z.ZodObject<{
                        literal: z.ZodUnknown;
                    }, z.core.$strict>]>>;
                }, z.core.$strict>, z.ZodObject<{
                    op: z.ZodLiteral<"editObject">;
                    object: z.ZodObject<{
                        parameter: z.ZodString;
                        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>;
                    expectedRevision: z.ZodUnion<readonly [z.ZodObject<{
                        parameter: z.ZodString;
                        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>, z.ZodObject<{
                        literal: z.ZodUnknown;
                    }, z.core.$strict>]>;
                    properties: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                        parameter: z.ZodString;
                        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>, z.ZodObject<{
                        literal: z.ZodUnknown;
                    }, z.core.$strict>]>>;
                }, z.core.$strict>, z.ZodObject<{
                    op: z.ZodLiteral<"addLink">;
                    link: z.ZodString;
                    from: z.ZodObject<{
                        type: z.ZodString;
                        id: z.ZodUnion<readonly [z.ZodObject<{
                            parameter: z.ZodString;
                            path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                        }, z.core.$strict>, z.ZodObject<{
                            literal: z.ZodUnknown;
                        }, z.core.$strict>]>;
                    }, z.core.$strict>;
                    to: z.ZodObject<{
                        type: z.ZodString;
                        id: z.ZodUnion<readonly [z.ZodObject<{
                            parameter: z.ZodString;
                            path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                        }, z.core.$strict>, z.ZodObject<{
                            literal: z.ZodUnknown;
                        }, z.core.$strict>]>;
                    }, z.core.$strict>;
                }, z.core.$strict>, z.ZodObject<{
                    op: z.ZodLiteral<"removeLink">;
                    link: z.ZodString;
                    from: z.ZodObject<{
                        type: z.ZodString;
                        id: z.ZodUnion<readonly [z.ZodObject<{
                            parameter: z.ZodString;
                            path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                        }, z.core.$strict>, z.ZodObject<{
                            literal: z.ZodUnknown;
                        }, z.core.$strict>]>;
                    }, z.core.$strict>;
                    to: z.ZodObject<{
                        type: z.ZodString;
                        id: z.ZodUnion<readonly [z.ZodObject<{
                            parameter: z.ZodString;
                            path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                        }, z.core.$strict>, z.ZodObject<{
                            literal: z.ZodUnknown;
                        }, z.core.$strict>]>;
                    }, z.core.$strict>;
                }, z.core.$strict>, z.ZodObject<{
                    op: z.ZodLiteral<"deleteObject">;
                    object: z.ZodObject<{
                        parameter: z.ZodString;
                        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>;
                    expectedRevision: z.ZodUnion<readonly [z.ZodObject<{
                        parameter: z.ZodString;
                        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>, z.ZodObject<{
                        literal: z.ZodUnknown;
                    }, z.core.$strict>]>;
                }, z.core.$strict>, z.ZodObject<{
                    op: z.ZodLiteral<"editStruct">;
                    object: z.ZodObject<{
                        parameter: z.ZodString;
                        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>;
                    expectedRevision: z.ZodUnion<readonly [z.ZodObject<{
                        parameter: z.ZodString;
                        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>, z.ZodObject<{
                        literal: z.ZodUnknown;
                    }, z.core.$strict>]>;
                    property: z.ZodString;
                    fields: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                        parameter: z.ZodString;
                        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>, z.ZodObject<{
                        literal: z.ZodUnknown;
                    }, z.core.$strict>]>>;
                }, z.core.$strict>, z.ZodObject<{
                    op: z.ZodLiteral<"applyScenario">;
                    scenario: z.ZodUnion<readonly [z.ZodObject<{
                        parameter: z.ZodString;
                        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>, z.ZodObject<{
                        literal: z.ZodUnknown;
                    }, z.core.$strict>]>;
                    expectedRevision: z.ZodUnion<readonly [z.ZodObject<{
                        parameter: z.ZodString;
                        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>, z.ZodObject<{
                        literal: z.ZodUnknown;
                    }, z.core.$strict>]>;
                    objectTypes: z.ZodArray<z.ZodString>;
                    linkTypes: z.ZodArray<z.ZodString>;
                }, z.core.$strict>], "op">>>;
                result: z.ZodOptional<z.ZodObject<{
                    type: z.ZodString;
                    id: z.ZodUnion<readonly [z.ZodObject<{
                        parameter: z.ZodString;
                        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>, z.ZodObject<{
                        literal: z.ZodUnknown;
                    }, z.core.$strict>]>;
                }, z.core.$strict>>;
                function: z.ZodOptional<z.ZodString>;
                functionVersion: z.ZodOptional<z.ZodString>;
                effects: z.ZodOptional<z.ZodArray<z.ZodUnion<readonly [z.ZodObject<{
                    name: z.ZodString;
                    handler: z.ZodString;
                    payload: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                        parameter: z.ZodString;
                        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>, z.ZodObject<{
                        literal: z.ZodUnknown;
                    }, z.core.$strict>]>>;
                }, z.core.$strict>, z.ZodObject<{
                    name: z.ZodString;
                    webhook: z.ZodObject<{
                        source: z.ZodString;
                        method: z.ZodEnum<{
                            DELETE: "DELETE";
                            PATCH: "PATCH";
                            POST: "POST";
                            PUT: "PUT";
                        }>;
                        path: z.ZodString;
                        function: z.ZodOptional<z.ZodString>;
                    }, z.core.$strict>;
                    payload: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                        parameter: z.ZodString;
                        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                    }, z.core.$strict>, z.ZodObject<{
                        literal: z.ZodUnknown;
                    }, z.core.$strict>]>>;
                }, z.core.$strict>]>>>;
            }, z.core.$strict>>;
            dataSources: z.ZodArray<z.ZodObject<{
                apiName: z.ZodString;
                objectType: z.ZodString;
                function: z.ZodString;
                classification: z.ZodOptional<z.ZodObject<{
                    sensitivity: z.ZodEnum<{
                        CONFIDENTIAL: "CONFIDENTIAL";
                        INTERNAL: "INTERNAL";
                        PUBLIC: "PUBLIC";
                        RESTRICTED: "RESTRICTED";
                    }>;
                    compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>>;
                properties: z.ZodRecord<z.ZodString, z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>;
    }, z.core.$strict>;
    branchName: z.ZodString;
    project: z.ZodOptional<z.ZodString>;
    mode: z.ZodDefault<z.ZodEnum<{
        copy: "copy";
        shared: "shared";
    }>>;
}, z.core.$strict>;
export declare const migrateDefinitionsSchema: z.ZodObject<{
    ontology: z.ZodString;
    resources: z.ZodArray<z.ZodObject<{
        kind: z.ZodEnum<{
            action: "action";
            agentProfile: "agentProfile";
            datasource: "datasource";
            function: "function";
            group: "group";
            interface: "interface";
            link: "link";
            object: "object";
            sharedProperty: "sharedProperty";
            struct: "struct";
            valueType: "valueType";
        }>;
        name: z.ZodString;
        version: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    targetOntology: z.ZodString;
    mapping: z.ZodRecord<z.ZodEnum<{
        action: "action";
        agentProfile: "agentProfile";
        datasource: "datasource";
        function: "function";
        group: "group";
        interface: "interface";
        link: "link";
        object: "object";
        sharedProperty: "sharedProperty";
        struct: "struct";
        valueType: "valueType";
    }> & z.core.$partial, z.ZodRecord<z.ZodString, z.ZodString>>;
    branchName: z.ZodString;
    project: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export declare class OntologyPackages {
    private readonly db;
    private readonly metadata;
    private readonly governance;
    constructor(db: Database, metadata: Metadata, bindings: Bindings);
    export(access: Access, raw: unknown): Promise<{
        format: 'eigos-ontology-package-v1';
        ontology: string;
        version: string;
        digest: string;
        document: {
            id: string;
            version: string;
            classification?: {
                sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                compartments: string[];
            } | undefined;
            sharedProperties?: {
                typeClasses?: {
                    kind: string;
                    name: string;
                }[] | undefined;
                renderHints?: Record<string, string | number | boolean> | undefined;
                status?: "active" | "deprecated" | "experimental" | undefined;
                classification?: {
                    sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                    compartments: string[];
                } | undefined;
                description: string;
                schema: Record<string, unknown>;
                required: boolean;
                sharedProperty?: string | undefined;
                valueType?: {
                    name: string;
                    version: string;
                } | undefined;
                struct?: {
                    type: string;
                    mainField?: string | undefined;
                    reducer?: {
                        op: "first" | "last" | "max" | "min";
                        field?: string | undefined;
                    } | undefined;
                    array?: boolean | undefined;
                } | undefined;
                format?: {
                    kind: "currency" | "date" | "number" | "percent" | "text";
                    locale?: string | undefined;
                    currency?: string | undefined;
                    minimumFractionDigits?: number | undefined;
                    maximumFractionDigits?: number | undefined;
                } | undefined;
                derived?: import("../ontology/schema.js").DerivedExpression | undefined;
                apiName: string;
            }[] | undefined;
            valueTypes?: {
                typeClasses?: {
                    kind: string;
                    name: string;
                }[] | undefined;
                renderHints?: Record<string, string | number | boolean> | undefined;
                status?: "active" | "deprecated" | "experimental" | undefined;
                classification?: {
                    sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                    compartments: string[];
                } | undefined;
                apiName: string;
                version: string;
                description: string;
                schema: Record<string, unknown>;
            }[] | undefined;
            structTypes?: {
                typeClasses?: {
                    kind: string;
                    name: string;
                }[] | undefined;
                renderHints?: Record<string, string | number | boolean> | undefined;
                status?: "active" | "deprecated" | "experimental" | undefined;
                classification?: {
                    sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                    compartments: string[];
                } | undefined;
                apiName: string;
                description: string;
                fields: Record<string, Record<string, unknown>>;
                required?: string[] | undefined;
                mainField?: string | undefined;
            }[] | undefined;
            typeGroups?: {
                apiName: string;
                displayName: string;
                description: string;
                objectTypes: string[];
            }[] | undefined;
            agentProfiles?: {
                apiName: string;
                terms: string[];
                objects?: string[] | undefined;
                interfaces?: string[] | undefined;
                actions?: string[] | undefined;
                functions?: string[] | undefined;
                sources?: string[] | undefined;
                links?: string[] | undefined;
                instructions?: {
                    action?: string | undefined;
                    function?: string | undefined;
                    text: string;
                }[] | undefined;
            }[] | undefined;
            imports?: {
                ontology: string;
                version: string;
                digest: string;
                namespace: string;
                document: unknown;
            }[] | undefined;
            objectTypes: {
                typeClasses?: {
                    kind: string;
                    name: string;
                }[] | undefined;
                renderHints?: Record<string, string | number | boolean> | undefined;
                status?: "active" | "deprecated" | "experimental" | undefined;
                classification?: {
                    sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                    compartments: string[];
                } | undefined;
                apiName: string;
                displayName: string;
                description: string;
                primaryKey: string;
                titleProperty: string;
                properties: Record<string, {
                    typeClasses?: {
                        kind: string;
                        name: string;
                    }[] | undefined;
                    renderHints?: Record<string, string | number | boolean> | undefined;
                    status?: "active" | "deprecated" | "experimental" | undefined;
                    classification?: {
                        sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                        compartments: string[];
                    } | undefined;
                    description: string;
                    schema: Record<string, unknown>;
                    required: boolean;
                    sharedProperty?: string | undefined;
                    valueType?: {
                        name: string;
                        version: string;
                    } | undefined;
                    struct?: {
                        type: string;
                        mainField?: string | undefined;
                        reducer?: {
                            op: "first" | "last" | "max" | "min";
                            field?: string | undefined;
                        } | undefined;
                        array?: boolean | undefined;
                    } | undefined;
                    format?: {
                        kind: "currency" | "date" | "number" | "percent" | "text";
                        locale?: string | undefined;
                        currency?: string | undefined;
                        minimumFractionDigits?: number | undefined;
                        maximumFractionDigits?: number | undefined;
                    } | undefined;
                    derived?: import("../ontology/schema.js").DerivedExpression | undefined;
                }>;
                machinery?: {
                    states: {
                        name: string;
                        terminal?: boolean | undefined;
                        dwellSeconds?: number | undefined;
                    }[];
                    transitions: {
                        from: string | null;
                        to: string | null;
                        action?: string | undefined;
                        execution?: {
                            subject: string;
                            parameters?: Record<string, string> | undefined;
                            requires?: {
                                process: string;
                                link?: string | undefined;
                                states: string[];
                                match: "all" | "any";
                            }[] | undefined;
                        } | undefined;
                    }[];
                    subprocesses?: {
                        link: string;
                        process: string;
                    }[] | undefined;
                    parallel?: string[] | undefined;
                    metrics?: {
                        node?: {
                            label: string;
                            aggregation: {
                                op: "count";
                            } | {
                                op: "avg" | "max" | "min" | "sum";
                                property: string;
                            };
                            decimals?: number | undefined;
                            unit?: string | undefined;
                            colors?: {
                                min: number;
                                color: "amber" | "green" | "red";
                            }[] | undefined;
                        } | undefined;
                        edge?: {
                            label: string;
                            aggregation: {
                                op: "count";
                            } | {
                                op: "avg" | "max" | "min" | "sum";
                                property: string;
                            };
                            decimals?: number | undefined;
                            unit?: string | undefined;
                            colors?: {
                                min: number;
                                color: "amber" | "green" | "red";
                            }[] | undefined;
                        } | undefined;
                    } | undefined;
                } | undefined;
                classificationProperty?: string | undefined;
                groups?: string[] | undefined;
                interfaces: Record<string, {
                    properties: Record<string, string>;
                    links: Record<string, string>;
                    actions: Record<string, {
                        action: string;
                        parameters: Record<string, string>;
                    }>;
                }>;
            }[];
            interfaceTypes: {
                typeClasses?: {
                    kind: string;
                    name: string;
                }[] | undefined;
                renderHints?: Record<string, string | number | boolean> | undefined;
                status?: "active" | "deprecated" | "experimental" | undefined;
                classification?: {
                    sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                    compartments: string[];
                } | undefined;
                apiName: string;
                description: string;
                properties: Record<string, {
                    typeClasses?: {
                        kind: string;
                        name: string;
                    }[] | undefined;
                    renderHints?: Record<string, string | number | boolean> | undefined;
                    status?: "active" | "deprecated" | "experimental" | undefined;
                    classification?: {
                        sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                        compartments: string[];
                    } | undefined;
                    description: string;
                    schema: Record<string, unknown>;
                    required: boolean;
                    sharedProperty?: string | undefined;
                    valueType?: {
                        name: string;
                        version: string;
                    } | undefined;
                    struct?: {
                        type: string;
                        mainField?: string | undefined;
                        reducer?: {
                            op: "first" | "last" | "max" | "min";
                            field?: string | undefined;
                        } | undefined;
                        array?: boolean | undefined;
                    } | undefined;
                    format?: {
                        kind: "currency" | "date" | "number" | "percent" | "text";
                        locale?: string | undefined;
                        currency?: string | undefined;
                        minimumFractionDigits?: number | undefined;
                        maximumFractionDigits?: number | undefined;
                    } | undefined;
                    derived?: import("../ontology/schema.js").DerivedExpression | undefined;
                }>;
                extends?: string[] | undefined;
                optionalProperties: string[];
                links: Record<string, {
                    target: string;
                    cardinality: "many" | "one";
                    required: boolean;
                }>;
                actions: Record<string, {
                    parameters: Record<string, unknown>;
                    objectParameters: Record<string, string>;
                    required: boolean;
                }>;
            }[];
            linkTypes: {
                typeClasses?: {
                    kind: string;
                    name: string;
                }[] | undefined;
                renderHints?: Record<string, string | number | boolean> | undefined;
                status?: "active" | "deprecated" | "experimental" | undefined;
                classification?: {
                    sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                    compartments: string[];
                } | undefined;
                apiName: string;
                description: string;
                from: {
                    type: string;
                    name: string;
                    cardinality: "many" | "one";
                };
                to: {
                    type: string;
                    name: string;
                    cardinality: "many" | "one";
                };
            }[];
            functionTypes: {
                typeClasses?: {
                    kind: string;
                    name: string;
                }[] | undefined;
                renderHints?: Record<string, string | number | boolean> | undefined;
                status?: "active" | "deprecated" | "experimental" | undefined;
                classification?: {
                    sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                    compartments: string[];
                } | undefined;
                apiName: string;
                description: string;
                parameters: Record<string, unknown>;
                returns: Record<string, unknown>;
                source?: string | undefined;
                edits?: boolean | undefined;
                version?: string | undefined;
                dependencies?: {
                    objectTypes?: string[] | undefined;
                    interfaceTypes?: string[] | undefined;
                    linkTypes?: string[] | undefined;
                    functions?: string[] | undefined;
                    dataSources?: string[] | undefined;
                    actions?: string[] | undefined;
                } | undefined;
                implementation?: {
                    kind: "component";
                    sha256: string;
                    limits: {
                        fuel: number;
                        memoryMb: number;
                        deadlineMs: number;
                        inputBytes?: number | undefined;
                        outputBytes?: number | undefined;
                    };
                } | undefined;
            }[];
            actionTypes: {
                typeClasses?: {
                    kind: string;
                    name: string;
                }[] | undefined;
                renderHints?: Record<string, string | number | boolean> | undefined;
                status?: "active" | "deprecated" | "experimental" | undefined;
                classification?: {
                    sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                    compartments: string[];
                } | undefined;
                apiName: string;
                description: string;
                parameters: Record<string, unknown>;
                objectParameters: Record<string, string>;
                submissionCriteria: {
                    function: string;
                    arguments: Record<string, {
                        parameter: string;
                        path?: string[] | undefined;
                    } | {
                        literal: unknown;
                    }>;
                    message?: string | undefined;
                    functionVersion?: string | undefined;
                    executionContext?: "live" | "scenario" | undefined;
                }[];
                rules?: ({
                    op: "createObject";
                    object: {
                        type: string;
                        id: {
                            parameter: string;
                            path?: string[] | undefined;
                        } | {
                            literal: unknown;
                        };
                    };
                    properties: Record<string, {
                        parameter: string;
                        path?: string[] | undefined;
                    } | {
                        literal: unknown;
                    }>;
                } | {
                    op: "editObject";
                    object: {
                        parameter: string;
                        path?: string[] | undefined;
                    };
                    expectedRevision: {
                        parameter: string;
                        path?: string[] | undefined;
                    } | {
                        literal: unknown;
                    };
                    properties: Record<string, {
                        parameter: string;
                        path?: string[] | undefined;
                    } | {
                        literal: unknown;
                    }>;
                } | {
                    op: "addLink";
                    link: string;
                    from: {
                        type: string;
                        id: {
                            parameter: string;
                            path?: string[] | undefined;
                        } | {
                            literal: unknown;
                        };
                    };
                    to: {
                        type: string;
                        id: {
                            parameter: string;
                            path?: string[] | undefined;
                        } | {
                            literal: unknown;
                        };
                    };
                } | {
                    op: "removeLink";
                    link: string;
                    from: {
                        type: string;
                        id: {
                            parameter: string;
                            path?: string[] | undefined;
                        } | {
                            literal: unknown;
                        };
                    };
                    to: {
                        type: string;
                        id: {
                            parameter: string;
                            path?: string[] | undefined;
                        } | {
                            literal: unknown;
                        };
                    };
                } | {
                    op: "deleteObject";
                    object: {
                        parameter: string;
                        path?: string[] | undefined;
                    };
                    expectedRevision: {
                        parameter: string;
                        path?: string[] | undefined;
                    } | {
                        literal: unknown;
                    };
                } | {
                    op: "editStruct";
                    object: {
                        parameter: string;
                        path?: string[] | undefined;
                    };
                    expectedRevision: {
                        parameter: string;
                        path?: string[] | undefined;
                    } | {
                        literal: unknown;
                    };
                    property: string;
                    fields: Record<string, {
                        parameter: string;
                        path?: string[] | undefined;
                    } | {
                        literal: unknown;
                    }>;
                } | {
                    op: "applyScenario";
                    scenario: {
                        parameter: string;
                        path?: string[] | undefined;
                    } | {
                        literal: unknown;
                    };
                    expectedRevision: {
                        parameter: string;
                        path?: string[] | undefined;
                    } | {
                        literal: unknown;
                    };
                    objectTypes: string[];
                    linkTypes: string[];
                })[] | undefined;
                result?: {
                    type: string;
                    id: {
                        parameter: string;
                        path?: string[] | undefined;
                    } | {
                        literal: unknown;
                    };
                } | undefined;
                function?: string | undefined;
                functionVersion?: string | undefined;
                effects?: ({
                    name: string;
                    handler: string;
                    payload: Record<string, {
                        parameter: string;
                        path?: string[] | undefined;
                    } | {
                        literal: unknown;
                    }>;
                } | {
                    name: string;
                    webhook: {
                        source: string;
                        method: "DELETE" | "PATCH" | "POST" | "PUT";
                        path: string;
                        function?: string | undefined;
                    };
                    payload: Record<string, {
                        parameter: string;
                        path?: string[] | undefined;
                    } | {
                        literal: unknown;
                    }>;
                })[] | undefined;
            }[];
            dataSources: {
                apiName: string;
                objectType: string;
                function: string;
                classification?: {
                    sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                    compartments: string[];
                } | undefined;
                properties: Record<string, string>;
            }[];
        };
    }>;
    private verify;
    import(access: Access, raw: unknown): Promise<{
        id: string;
        ontology: string;
        project: string | null;
        name: string;
        author: string;
        base_release: string;
        body: OntologyDocument;
        revision: number;
        state: string;
        candidate: string | null;
        reviewer: string | null;
        reviewed_digest: string | null;
        proposalEvidence?: {
            process: string;
            release: string;
            from: string;
            to: string;
            scope: 'earlier_revision';
        } | {
            process: string;
            release: string;
            from: string;
            to: string;
            scope: 'recorded';
            summary: {
                cases: number;
                deviationCases: number;
                candidateDeviationCases: number;
                bottlenecks: {
                    state: string;
                    completedP95Ms: number | null;
                }[];
                affectedEdges: {
                    from: string | null;
                    to: string | null;
                    observedCases: number;
                }[];
            };
        } | {
            process: string;
            release: string;
            from: string;
            to: string;
            scope: 'restricted';
        } | {
            process: string;
            release: string;
            from: string;
            to: string;
            scope: 'reviewer';
            summary: {
                cases: number;
                deviationCases: number;
                candidateDeviationCases: number;
                bottlenecks: {
                    state: string;
                    completedP95Ms: number | null;
                }[];
                affectedEdges: {
                    from: string | null;
                    to: string | null;
                    observedCases: number;
                }[];
            };
        } | {
            process: string;
            release: string;
            from: string;
            to: string;
            scope: 'unavailable';
        } | undefined;
    }>;
    private append;
    migrateData(access: Access, raw: unknown): Promise<{
        id: string;
        requestId: string;
        sourceOntology: string;
        targetOntology: string;
        sourceRelease: string;
        targetRelease: string;
        objects: number;
        links: number;
        createdAt: any;
        provenance: 'copied_ontology_objects';
    }>;
    migrationReceipt(access: Access, raw: unknown): Promise<{
        id: string;
        requestId: string;
        sourceOntology: string;
        targetOntology: string;
        sourceRelease: string;
        targetRelease: string;
        objects: number;
        links: number;
        createdAt: any;
        provenance: 'copied_ontology_objects';
        items: import("pg").QueryResultRow[];
        cursor: number | undefined;
    }>;
    migrate(access: Access, raw: unknown): Promise<{
        id: string;
        ontology: string;
        project: string | null;
        name: string;
        author: string;
        base_release: string;
        body: OntologyDocument;
        revision: number;
        state: string;
        candidate: string | null;
        reviewer: string | null;
        reviewed_digest: string | null;
        proposalEvidence?: {
            process: string;
            release: string;
            from: string;
            to: string;
            scope: 'earlier_revision';
        } | {
            process: string;
            release: string;
            from: string;
            to: string;
            scope: 'recorded';
            summary: {
                cases: number;
                deviationCases: number;
                candidateDeviationCases: number;
                bottlenecks: {
                    state: string;
                    completedP95Ms: number | null;
                }[];
                affectedEdges: {
                    from: string | null;
                    to: string | null;
                    observedCases: number;
                }[];
            };
        } | {
            process: string;
            release: string;
            from: string;
            to: string;
            scope: 'restricted';
        } | {
            process: string;
            release: string;
            from: string;
            to: string;
            scope: 'reviewer';
            summary: {
                cases: number;
                deviationCases: number;
                candidateDeviationCases: number;
                bottlenecks: {
                    state: string;
                    completedP95Ms: number | null;
                }[];
                affectedEdges: {
                    from: string | null;
                    to: string | null;
                    observedCases: number;
                }[];
            };
        } | {
            process: string;
            release: string;
            from: string;
            to: string;
            scope: 'unavailable';
        } | undefined;
    }>;
}
