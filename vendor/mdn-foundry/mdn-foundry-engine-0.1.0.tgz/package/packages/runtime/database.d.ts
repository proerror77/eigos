import pg, { type PoolClient, type QueryResultRow } from 'pg';
export type Sql = Pick<pg.Pool, 'query'> | Pick<PoolClient, 'query'>;
/** Thrown inside an object-scoped commit whose conflicts object locks cannot bound; the commit reruns exclusively. */
export declare class ExclusiveScopeRequired extends Error {
    readonly reason: string;
    constructor(reason: string);
}
/**
 * Object locks one object-scoped transaction may hold. Advisory locks share PostgreSQL's lock table with every
 * session, so a larger commit takes the exclusive owner lock instead of exhausting it.
 */
export declare const objectLockBudget = 128;
export declare class Database {
    readonly runtimeId: string;
    readonly ownerIsolation: boolean;
    readonly sandboxEnabled: boolean;
    readonly pool: pg.Pool;
    readonly schema: string;
    readonly queryPool?: pg.Pool;
    queries: number;
    private readonly ownerContext;
    private readonly transactionOwners;
    private readonly editLocks;
    private readonly sharedEditLocks;
    private readonly objectScopes;
    private readonly objectAccess;
    constructor(connectionString: string, schema?: string, runtimeId?: string, queryConnectionString?: string, ownerIsolation?: boolean, sandboxEnabled?: boolean);
    query<T extends QueryResultRow = QueryResultRow>(text: string, values?: unknown[], client?: Sql): Promise<pg.QueryResult<T>>;
    /** Times acquiring the Ontology edit locks and how long the transaction then holds them. */
    acquireEditLocks(client: Sql, acquire: () => Promise<void>): Promise<void>;
    lockKey(namespace: string, ...parts: string[]): string;
    withOwner<T>(owner: string, operation: () => T): T;
    /**
     * Whether row security lets this context read the owner's rows: owner isolation is off, or the operation runs in
     * the owner's context. Readers that bypass row security, such as the query kernel, answer only where this holds.
     */
    readsAsOwner(owner: string): boolean;
    setOwner(client: Sql, owner: string): Promise<void>;
    withTransactionOwner<T>(client: Sql, owner: string, operation: () => Promise<T>): Promise<T>;
    measureQueries<T>(operation: (count: () => number) => Promise<T>): Promise<T>;
    /** Whether this transaction shares the owner's Ontology edit lock because it locks the objects it touches. */
    sharesEditLocks(client: Sql): boolean;
    /** Object locks one object-scoped transaction may hold before it reruns with the exclusive owner lock. */
    get objectLockBudget(): number;
    /** Whether this transaction locks the objects it touches instead of the whole owner. */
    objectScoped(client: Sql): boolean;
    /** Runs Ontology data statements that the caller has covered with object locks. */
    withObjectAccess<T>(run: () => T): T;
    /**
     * In an object-scoped transaction, abandons the attempt because an operation's conflicts cannot be bounded
     * by object locks; the transaction then reruns with the exclusive owner lock. Elsewhere it does nothing.
     */
    requireExclusive(client: Sql, reason: string): void;
    /** Takes shared or exclusive locks on object keys for the rest of an object-scoped transaction, in key order. */
    lockObjects(client: Sql, keys: readonly string[], mode: 'shared' | 'exclusive'): Promise<void>;
    /**
     * Runs an Action commit that locks only what it touches: the owner's edit lock is shared, every object it reads
     * is locked shared and every object it writes, or whose relationships it changes, exclusively, until COMMIT.
     * Commits on unrelated objects therefore proceed in parallel without depending on predicate locks. A set query,
     * an unlocked Ontology data statement or a deadlock reruns the commit once with the exclusive owner lock, which
     * never overlaps shared holders; the escalation also applies when the commit code caught it.
     */
    objectScopedTransaction<T>(action: (client: PoolClient) => Promise<T>, operation?: string): Promise<T>;
    /**
     * Reruns a write transaction that timed out waiting for a lock, after a growing backoff, until `signal` ends
     * or 30 seconds pass. Contention then queues the work instead of failing it at the 2-second lock_timeout; each
     * attempt still releases its connection while it backs off.
     */
    waitForLocks<T>(run: () => Promise<T>, signal: AbortSignal): Promise<T>;
    transaction<T>(action: (client: PoolClient) => Promise<T>): Promise<T>;
    private readTransaction;
    readQuery<T extends QueryResultRow = QueryResultRow>(text: string, values?: unknown[], client?: Sql): Promise<pg.QueryResult<T>>;
    close(): Promise<void>;
    initialize(): Promise<void>;
}
