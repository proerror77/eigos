import { initializeObservationInterests } from './observation-interests.js';
import { developmentSandboxEnabled } from '../core/sandbox-mode.js';
import { initializeReleaseEvaluation } from './release-evaluation.js';
import { initializeOntologyDataMigrations } from './ontology-migrations.js';
import { initializeEntityResolution } from './entity-resolution.js';
import { initializeSemantic } from './semantic.js';
import { initializeApplications } from './applications.js';
import { initializeAutomation } from './automation.js';
import { initializeScenarioLifecycle } from './scenarios.js';
import { initializeMachineryStates } from './machinery-state.js';
import { initializeActionUndo } from './action-journal.js';
import { initializeObjectSets } from './object-sets.js';
import { initializeChangeSubscriptions } from './change-subscriptions.js';
import { initializeLogArchives } from './log-retention.js';
import { initializeProviderBudgets } from './provider-budgets.js';
import { initializeProcessNotifications } from './process-notifications.js';
import { initializeFunctionArtifacts } from './component-functions.js';
import { initializeComponentOAuthGrants } from './component-source-oauth.js';
import { flushFunctionInvocations, initializeFunctionInvocations } from './function-invocations.js';
import { initializeGovernance } from './governance.js';
import { initializeEffects } from './effects.js';
import { initializeIndexing } from './indexing.js';
import { initializeEditHistory } from './edit-history.js';
import { initializeMaterializations } from './materializations.js';
import { AsyncLocalStorage } from 'node:async_hooks';
import { setTimeout as delay } from 'node:timers/promises';
import { activeProfiles, chargeProfiles, profileDatabase } from '../core/database-profile.js';
import { recordOperationEvent } from '../core/operation-timing.js';
import pg from 'pg';
import { initializeSecurity } from './security.js';
import { implementationDigest } from './implementation.js';
import { initializeScenarioEvaluations } from './scenario-evaluation.js';
import { initializeMachineryHistory } from './machinery-history.js';
import { initializeExecutionTrace } from './execution-trace.js';
import { initializeAccounts } from './accounts.js';
/** Thrown inside an object-scoped commit whose conflicts object locks cannot bound; the commit reruns exclusively. */
export class ExclusiveScopeRequired extends Error {
    reason;
    constructor(reason) {
        super(`Object-scoped commit needs the exclusive edit lock: ${reason}`);
        this.reason = reason;
    }
}
/**
 * Object locks one object-scoped transaction may hold. Advisory locks share PostgreSQL's lock table with every
 * session, so a larger commit takes the exclusive owner lock instead of exhausting it.
 */
export const objectLockBudget = 128;
/** Tables whose rows object locks protect; statements on them must come from code that took those locks. */
const ontologyData = /\.(?:objects|links|source_values|object_edits|edit_history|scenario_objects|scenario_links)\b/;
/** Connections a process keeps to PostgreSQL. A Worker needs about one per slot and two more. */
const poolSize = () => Math.min(100, Math.max(2, Number(process.env.EIGOS_DB_POOL_MAX ?? 8) || 8));
export class Database {
    runtimeId;
    ownerIsolation;
    sandboxEnabled;
    pool;
    schema;
    queryPool;
    queries = 0;
    ownerContext = new AsyncLocalStorage();
    transactionOwners = new WeakMap();
    editLocks = new WeakMap();
    sharedEditLocks = new WeakSet();
    objectScopes = new WeakMap();
    objectAccess = new AsyncLocalStorage();
    constructor(connectionString, schema = 'eigos', runtimeId = implementationDigest(), queryConnectionString, ownerIsolation = process.env.EIGOS_ENFORCE_OWNER_RLS === 'true', sandboxEnabled = developmentSandboxEnabled()) {
        this.runtimeId = runtimeId;
        this.ownerIsolation = ownerIsolation;
        this.sandboxEnabled = sandboxEnabled;
        if (!/^eigos(?:_[a-z0-9]+)*$/.test(schema))
            throw new Error('Invalid schema');
        this.schema = `"${schema}"`;
        // Each process sizes its own pool (runtime budget 06.3): EIGOS_DB_POOL_MAX, 8 by default.
        this.pool = new pg.Pool({ connectionString, max: poolSize(), connectionTimeoutMillis: 5000, statement_timeout: 10000 });
        if (queryConnectionString) {
            this.queryPool = new pg.Pool({ connectionString: queryConnectionString, max: 8, connectionTimeoutMillis: 1000, statement_timeout: 10000, options: '-c default_transaction_read_only=on' });
            this.queryPool.on('error', () => { });
        }
        this.pool.on('error', error => process.stderr.write(`PostgreSQL connection error: ${error.name}\n`));
    }
    async query(text, values = [], client = this.pool) {
        if (this.ownerIsolation && client === this.pool && this.ownerContext.getStore()) {
            return this.transaction(connection => this.query(text, values, connection));
        }
        if (this.objectScopes.has(client) && !this.objectAccess.getStore() && ontologyData.test(text))
            this.requireExclusive(client, 'unlocked Ontology data statement');
        this.queries++;
        const profiles = activeProfiles(), started = performance.now();
        try {
            return await client.query(text, values);
        }
        catch (error) {
            if (error?.code === '55P03')
                chargeProfiles(profiles, 'lockTimeouts', 1);
            throw error;
        }
        finally {
            chargeProfiles(profiles, 'statements', 1);
            chargeProfiles(profiles, 'durationMs', performance.now() - started);
        }
    }
    /** Times acquiring the Ontology edit locks and how long the transaction then holds them. */
    async acquireEditLocks(client, acquire) {
        const profiles = activeProfiles(), started = performance.now();
        try {
            await acquire();
        }
        finally {
            chargeProfiles(profiles, 'editLockWaitMs', performance.now() - started);
        }
        if (client !== this.pool && client !== this.queryPool && !this.editLocks.has(client))
            this.editLocks.set(client, { since: performance.now(), profiles });
    }
    lockKey(namespace, ...parts) {
        return JSON.stringify([this.schema, namespace, ...parts]);
    }
    withOwner(owner, operation) {
        return this.ownerIsolation ? this.ownerContext.run(owner, operation) : operation();
    }
    /**
     * Whether row security lets this context read the owner's rows: owner isolation is off, or the operation runs in
     * the owner's context. Readers that bypass row security, such as the query kernel, answer only where this holds.
     */
    readsAsOwner(owner) { return !this.ownerIsolation || this.ownerContext.getStore() === owner; }
    async setOwner(client, owner) {
        if (!this.ownerIsolation)
            return;
        if (client === this.pool || client === this.queryPool)
            throw new Error('Owner context requires a database transaction');
        await this.query(`SET LOCAL eigos.owner TO ${pg.escapeLiteral(owner)}`, [], client);
        this.transactionOwners.set(client, owner);
    }
    async withTransactionOwner(client, owner, operation) {
        if (!this.ownerIsolation)
            return operation();
        const prior = this.transactionOwners.get(client) ?? '';
        if (owner === prior)
            return operation();
        await this.setOwner(client, owner);
        let result;
        try {
            result = await operation();
        }
        catch (error) {
            await this.setOwner(client, prior).catch(() => { });
            throw error;
        }
        await this.setOwner(client, prior);
        return result;
    }
    measureQueries(operation) {
        return profileDatabase(profile => operation(() => profile.statements));
    }
    /** Whether this transaction shares the owner's Ontology edit lock because it locks the objects it touches. */
    sharesEditLocks(client) { return this.sharedEditLocks.has(client); }
    /** Object locks one object-scoped transaction may hold before it reruns with the exclusive owner lock. */
    get objectLockBudget() { return objectLockBudget; }
    /** Whether this transaction locks the objects it touches instead of the whole owner. */
    objectScoped(client) { return this.objectScopes.has(client); }
    /** Runs Ontology data statements that the caller has covered with object locks. */
    withObjectAccess(run) { return this.objectAccess.run(true, run); }
    /**
     * In an object-scoped transaction, abandons the attempt because an operation's conflicts cannot be bounded
     * by object locks; the transaction then reruns with the exclusive owner lock. Elsewhere it does nothing.
     */
    requireExclusive(client, reason) {
        const scope = this.objectScopes.get(client);
        if (!scope)
            return;
        scope.escalated ??= reason;
        throw new ExclusiveScopeRequired(reason);
    }
    /** Takes shared or exclusive locks on object keys for the rest of an object-scoped transaction, in key order. */
    async lockObjects(client, keys, mode) {
        const scope = this.objectScopes.get(client);
        if (!scope)
            return;
        const needed = [...new Set(keys)].filter(key => {
            const held = scope.held.get(key);
            return !held || mode === 'exclusive' && held === 'shared';
        }).sort();
        if (!needed.length)
            return;
        if (scope.held.size + needed.filter(key => !scope.held.has(key)).length > objectLockBudget)
            this.requireExclusive(client, 'object lock budget');
        const lock = mode === 'exclusive' ? 'pg_advisory_xact_lock' : 'pg_advisory_xact_lock_shared';
        await this.query(`SELECT ${lock}(hashtextextended(key,0)) FROM unnest($1::text[]) AS keys(key)`, [needed], client);
        for (const key of needed)
            scope.held.set(key, mode);
    }
    /**
     * Runs an Action commit that locks only what it touches: the owner's edit lock is shared, every object it reads
     * is locked shared and every object it writes, or whose relationships it changes, exclusively, until COMMIT.
     * Commits on unrelated objects therefore proceed in parallel without depending on predicate locks. A set query,
     * an unlocked Ontology data statement or a deadlock reruns the commit once with the exclusive owner lock, which
     * never overlaps shared holders; the escalation also applies when the commit code caught it.
     */
    async objectScopedTransaction(action, operation) {
        const profiles = activeProfiles();
        try {
            return await this.transaction(async (client) => {
                const scope = { held: new Map() };
                this.objectScopes.set(client, scope);
                this.sharedEditLocks.add(client);
                try {
                    const result = await action(client);
                    if (scope.escalated)
                        throw new ExclusiveScopeRequired(scope.escalated);
                    return result;
                }
                catch (error) {
                    if (scope.escalated && !(error instanceof ExclusiveScopeRequired))
                        throw new ExclusiveScopeRequired(scope.escalated);
                    throw error;
                }
                finally {
                    this.objectScopes.delete(client);
                    this.sharedEditLocks.delete(client);
                }
            });
        }
        catch (error) {
            const code = error?.code;
            const reason = error instanceof ExclusiveScopeRequired ? error.reason : code === '40P01' ? 'deadlock' : undefined;
            if (!reason)
                throw error;
            chargeProfiles(profiles, 'commitFallbacks', 1);
            recordOperationEvent('commit_fallback', { operation, reason, code: typeof code === 'string' ? code : undefined });
            await delay(Math.random() * 5);
            return this.transaction(action);
        }
    }
    /**
     * Reruns a write transaction that timed out waiting for a lock, after a growing backoff, until `signal` ends
     * or 30 seconds pass. Contention then queues the work instead of failing it at the 2-second lock_timeout; each
     * attempt still releases its connection while it backs off.
     */
    async waitForLocks(run, signal) {
        const deadline = AbortSignal.any([signal, AbortSignal.timeout(30_000)]);
        for (let attempt = 1;; attempt++) {
            try {
                return await run();
            }
            catch (error) {
                if (error?.code !== '55P03' || deadline.aborted)
                    throw error;
                await delay(Math.min(1000, 50 * 2 ** attempt) * (0.5 + Math.random() / 2), undefined, { signal: deadline }).catch(() => { throw error; });
            }
        }
    }
    async transaction(action) {
        const client = await this.pool.connect();
        try {
            await this.query('BEGIN', [], client);
            await this.query("SET LOCAL lock_timeout='2s'", [], client);
            const owner = this.ownerContext.getStore();
            if (owner)
                await this.setOwner(client, owner);
            const result = await action(client);
            await this.query('COMMIT', [], client);
            return result;
        }
        catch (error) {
            await client.query('ROLLBACK').catch(() => { });
            throw error;
        }
        finally {
            const held = this.editLocks.get(client);
            if (held) {
                chargeProfiles(held.profiles, 'editLockHoldMs', performance.now() - held.since);
                this.editLocks.delete(client);
            }
            this.transactionOwners.delete(client);
            client.release();
        }
    }
    async readTransaction(pool, text, values, authority) {
        const connection = await pool.connect();
        try {
            await connection.query('BEGIN READ ONLY');
            const owner = this.ownerContext.getStore();
            if (owner)
                await this.setOwner(connection, owner);
            if (authority) {
                const replica = (await connection.query(`SELECT id,NOT pg_is_in_recovery() OR pg_last_wal_replay_lsn()>=$1::pg_lsn AS current FROM ${this.schema}.storage_identity`, [authority.position])).rows[0];
                if (replica?.id !== authority.id || !replica.current) {
                    await connection.query('ROLLBACK');
                    return undefined;
                }
            }
            const result = await this.query(text, values, connection);
            await connection.query('COMMIT');
            return result;
        }
        catch (error) {
            await connection.query('ROLLBACK').catch(() => { });
            throw error;
        }
        finally {
            this.transactionOwners.delete(connection);
            connection.release();
        }
    }
    async readQuery(text, values = [], client = this.pool) {
        if (!this.queryPool || client !== this.pool)
            return this.query(text, values, client);
        const primary = (await this.query(`SELECT id,pg_current_wal_lsn()::text AS position FROM ${this.schema}.storage_identity`)).rows[0];
        if (!primary)
            throw new Error('Storage identity is unavailable');
        try {
            const result = await this.readTransaction(this.queryPool, text, values, primary);
            if (result)
                return result;
        }
        catch (error) {
            if (error.code === '25006')
                throw error;
            // A pooler may ignore startup options. Both paths use explicit read-only transactions.
        }
        return (await this.readTransaction(this.pool, text, values));
    }
    async close() {
        await flushFunctionInvocations(this);
        await this.queryPool?.end();
        await this.pool.end();
    }
    async initialize() {
        const s = this.schema;
        await this.query(`CREATE SCHEMA IF NOT EXISTS ${s};
      CREATE TABLE IF NOT EXISTS ${s}.storage_identity(singleton boolean PRIMARY KEY DEFAULT true CHECK(singleton),id uuid NOT NULL DEFAULT gen_random_uuid());
      INSERT INTO ${s}.storage_identity(singleton) VALUES(true) ON CONFLICT DO NOTHING;
      CREATE TABLE IF NOT EXISTS ${s}.releases (digest text PRIMARY KEY, body jsonb NOT NULL, created_at timestamptz NOT NULL DEFAULT now());
      CREATE TABLE IF NOT EXISTS ${s}.ontology (id text PRIMARY KEY, release text NOT NULL REFERENCES ${s}.releases(digest));
      ALTER TABLE ${s}.releases ADD COLUMN IF NOT EXISTS definition_digest text;
      ALTER TABLE ${s}.releases ADD COLUMN IF NOT EXISTS transform_id uuid;
      ALTER TABLE ${s}.releases ADD COLUMN IF NOT EXISTS projection text;
      ALTER TABLE ${s}.releases ADD COLUMN IF NOT EXISTS runtime_id text;
      ALTER TABLE ${s}.releases ADD COLUMN IF NOT EXISTS bindings jsonb;
      ALTER TABLE ${s}.releases ADD COLUMN IF NOT EXISTS state text;
      ALTER TABLE ${s}.releases ADD COLUMN IF NOT EXISTS prepared_from text;
      ALTER TABLE ${s}.releases ADD COLUMN IF NOT EXISTS source_fingerprint text;
      ALTER TABLE ${s}.releases ADD COLUMN IF NOT EXISTS projection_fingerprint text;
      CREATE TABLE IF NOT EXISTS ${s}.resource_grants (subject text NOT NULL, resource text NOT NULL, permission text NOT NULL, PRIMARY KEY(subject,resource,permission));
      CREATE TABLE IF NOT EXISTS ${s}.property_security (ontology text NOT NULL, type text NOT NULL, property text NOT NULL, PRIMARY KEY(ontology,type,property));
      CREATE TABLE IF NOT EXISTS ${s}.objects (projection text NOT NULL, owner text NOT NULL, type text NOT NULL, id text NOT NULL, revision bigint NOT NULL DEFAULT 1, properties jsonb NOT NULL, PRIMARY KEY(projection,owner,type,id));
      CREATE INDEX IF NOT EXISTS objects_properties ON ${s}.objects USING gin(properties jsonb_path_ops);
      CREATE TABLE IF NOT EXISTS ${s}.links (projection text NOT NULL, owner text NOT NULL, type text NOT NULL, from_type text NOT NULL, from_id text NOT NULL, to_type text NOT NULL, to_id text NOT NULL,
        single_from boolean NOT NULL, single_to boolean NOT NULL,
        PRIMARY KEY(projection,owner,type,from_type,from_id,to_type,to_id),
        FOREIGN KEY(projection,owner,from_type,from_id) REFERENCES ${s}.objects(projection,owner,type,id),
        FOREIGN KEY(projection,owner,to_type,to_id) REFERENCES ${s}.objects(projection,owner,type,id));
      CREATE INDEX IF NOT EXISTS links_reverse ON ${s}.links(projection,owner,to_type,to_id,type);
      CREATE INDEX IF NOT EXISTS links_forward ON ${s}.links(projection,owner,from_type,from_id,type);
      CREATE UNIQUE INDEX IF NOT EXISTS links_single_from ON ${s}.links(projection,owner,type,from_type,from_id) WHERE single_from;
      CREATE UNIQUE INDEX IF NOT EXISTS links_single_to ON ${s}.links(projection,owner,type,to_type,to_id) WHERE single_to;
      CREATE TABLE IF NOT EXISTS ${s}.actions (owner text NOT NULL, request_id text NOT NULL, digest text NOT NULL, action text NOT NULL, release text NOT NULL REFERENCES ${s}.releases(digest), result jsonb NOT NULL, applied_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(owner,request_id));
      CREATE INDEX IF NOT EXISTS actions_log_order ON ${s}.actions(owner,release,applied_at DESC,request_id DESC);
      ALTER TABLE ${s}.actions ADD COLUMN IF NOT EXISTS executor_kind text;
      ALTER TABLE ${s}.actions ADD COLUMN IF NOT EXISTS executor_id text;
      ALTER TABLE ${s}.actions ADD COLUMN IF NOT EXISTS task_id uuid;
      CREATE TABLE IF NOT EXISTS ${s}.tasks (id uuid PRIMARY KEY, owner text NOT NULL, request_id text NOT NULL, input_digest text NOT NULL, input jsonb NOT NULL, release text NOT NULL REFERENCES ${s}.releases(digest), scopes jsonb NOT NULL,
        state text NOT NULL DEFAULT 'submitted', token uuid, lease_until timestamptz, result jsonb, error text, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(), UNIQUE(owner,request_id));
      ALTER TABLE ${s}.tasks ADD COLUMN IF NOT EXISTS result_permissions jsonb;
      ALTER TABLE ${s}.tasks ADD COLUMN IF NOT EXISTS available_at timestamptz NOT NULL DEFAULT now();
      ALTER TABLE ${s}.tasks ADD COLUMN IF NOT EXISTS execution_step integer NOT NULL DEFAULT 0;
      ALTER TABLE ${s}.tasks ADD COLUMN IF NOT EXISTS conversation_id text;
      ALTER TABLE ${s}.tasks ADD COLUMN IF NOT EXISTS conversation_batch bigint;
      ALTER TABLE ${s}.tasks ADD COLUMN IF NOT EXISTS message_count integer NOT NULL DEFAULT 1;
      CREATE INDEX IF NOT EXISTS tasks_queue ON ${s}.tasks(state,created_at);
      CREATE UNIQUE INDEX IF NOT EXISTS tasks_conversation_batch ON ${s}.tasks(owner,conversation_id,conversation_batch) WHERE conversation_id IS NOT NULL;
      CREATE INDEX IF NOT EXISTS tasks_conversation_pending ON ${s}.tasks(owner,conversation_id,conversation_batch)
        WHERE conversation_id IS NOT NULL AND state IN('submitted','working','input-required');
      CREATE INDEX IF NOT EXISTS tasks_conversation_available ON ${s}.tasks(available_at) WHERE conversation_id IS NOT NULL AND state='submitted';
      -- Runtime budgets (06.1, 06.2): the running tasks of an owner, and when each owner was last served.
      CREATE INDEX IF NOT EXISTS tasks_owner_working ON ${s}.tasks(owner) WHERE state='working';
      CREATE TABLE IF NOT EXISTS ${s}.task_turns (owner text PRIMARY KEY, served_at timestamptz NOT NULL);
      CREATE TABLE IF NOT EXISTS ${s}.task_inbox_events (
        owner text NOT NULL, request_id text NOT NULL, input_digest text NOT NULL, message text NOT NULL,
        task_id uuid NOT NULL REFERENCES ${s}.tasks(id), position integer NOT NULL,
        received_at timestamptz NOT NULL DEFAULT clock_timestamp(), PRIMARY KEY(owner,request_id), UNIQUE(task_id,position));
      CREATE TABLE IF NOT EXISTS ${s}.source_calls (task_id uuid NOT NULL REFERENCES ${s}.tasks(id), name text NOT NULL, state text NOT NULL, input_digest text NOT NULL, result jsonb, PRIMARY KEY(task_id,name));
      ALTER TABLE ${s}.source_calls ADD COLUMN IF NOT EXISTS lease_token uuid;`);
        // Existing tasks already pin a release. Derive ownership from that release for every producer,
        // including cognitive and scheduled tasks, and backfill old inbox rows in the same transaction.
        await this.query(`DO $migration$ BEGIN
      IF NOT EXISTS (SELECT 1 FROM pg_attribute WHERE attrelid='${s}.tasks'::regclass AND attname='ontology' AND NOT attisdropped) THEN
        ALTER TABLE ${s}.tasks ADD COLUMN ontology text;
        UPDATE ${s}.tasks t SET ontology=r.body->>'id' FROM ${s}.releases r WHERE r.digest=t.release;
        ALTER TABLE ${s}.tasks ALTER COLUMN ontology SET NOT NULL;
        CREATE FUNCTION ${s}.assign_task_ontology() RETURNS trigger LANGUAGE plpgsql AS $fn$ BEGIN
          SELECT body->>'id' INTO STRICT NEW.ontology FROM ${s}.releases WHERE digest=NEW.release;
          RETURN NEW;
        END $fn$;
        CREATE TRIGGER assign_task_ontology BEFORE INSERT OR UPDATE OF release,ontology ON ${s}.tasks
          FOR EACH ROW EXECUTE FUNCTION ${s}.assign_task_ontology();
        ALTER TABLE ${s}.task_inbox_events ADD COLUMN ontology text;
        UPDATE ${s}.task_inbox_events e SET ontology=t.ontology FROM ${s}.tasks t WHERE t.id=e.task_id;
        ALTER TABLE ${s}.task_inbox_events ALTER COLUMN ontology SET NOT NULL;
        ALTER TABLE ${s}.task_inbox_events DROP CONSTRAINT task_inbox_events_pkey, ADD PRIMARY KEY(ontology,owner,request_id);
        ALTER TABLE ${s}.tasks DROP CONSTRAINT IF EXISTS tasks_owner_request_id_key, ADD UNIQUE(ontology,owner,request_id);
        DROP INDEX ${s}.tasks_conversation_batch;
        CREATE UNIQUE INDEX tasks_conversation_batch ON ${s}.tasks(ontology,owner,conversation_id,conversation_batch) WHERE conversation_id IS NOT NULL;
      END IF;
    END $migration$`);
        await initializeAccounts(this);
        await this.query(`
      CREATE TABLE IF NOT EXISTS ${s}.scenarios (id uuid PRIMARY KEY, owner text NOT NULL, request_id text NOT NULL, name text NOT NULL,
        release text NOT NULL REFERENCES ${s}.releases(digest), revision bigint NOT NULL DEFAULT 1, state text NOT NULL DEFAULT 'open',
        created_at timestamptz NOT NULL DEFAULT now(), expires_at timestamptz NOT NULL DEFAULT now()+interval '31 days', UNIQUE(owner,request_id));
      CREATE TABLE IF NOT EXISTS ${s}.scenario_objects (scenario_id uuid NOT NULL REFERENCES ${s}.scenarios(id), owner text NOT NULL,
        type text NOT NULL, id text NOT NULL, base_revision bigint, base_properties jsonb, base_links jsonb NOT NULL, revision bigint NOT NULL, properties jsonb,
        PRIMARY KEY(scenario_id,owner,type,id));
      CREATE TABLE IF NOT EXISTS ${s}.scenario_links (scenario_id uuid NOT NULL REFERENCES ${s}.scenarios(id), owner text NOT NULL,
        type text NOT NULL, from_type text NOT NULL, from_id text NOT NULL, to_type text NOT NULL, to_id text NOT NULL,
        single_from boolean NOT NULL, single_to boolean NOT NULL, base_present boolean NOT NULL, removed boolean NOT NULL,
        PRIMARY KEY(scenario_id,owner,type,from_type,from_id,to_type,to_id));
      CREATE TABLE IF NOT EXISTS ${s}.scenario_actions (scenario_id uuid NOT NULL REFERENCES ${s}.scenarios(id), owner text NOT NULL,
        request_id text NOT NULL, digest text NOT NULL, action text NOT NULL, result jsonb NOT NULL, requirements jsonb NOT NULL,
        PRIMARY KEY(scenario_id,owner,request_id));
      CREATE TABLE IF NOT EXISTS ${s}.pa_requests (id uuid PRIMARY KEY, task_id uuid NOT NULL REFERENCES ${s}.tasks(id), owner text NOT NULL,
        request_key text NOT NULL, request jsonb NOT NULL, response jsonb, response_digest text, created_at timestamptz NOT NULL DEFAULT now(),
        UNIQUE(task_id,request_key));
      CREATE TABLE IF NOT EXISTS ${s}.external_operations (owner text NOT NULL,operation_key text NOT NULL,scope_digest text NOT NULL,state text NOT NULL,result jsonb,
        requirements jsonb NOT NULL DEFAULT '[]',created_at timestamptz NOT NULL DEFAULT now(),updated_at timestamptz NOT NULL DEFAULT now(),PRIMARY KEY(owner,operation_key));
      CREATE TABLE IF NOT EXISTS ${s}.scheduled_actions (id text NOT NULL,owner text NOT NULL,body jsonb NOT NULL,scopes jsonb NOT NULL,run_at timestamptz NOT NULL,deadline timestamptz NOT NULL,
        state text NOT NULL DEFAULT 'scheduled',task_id uuid UNIQUE REFERENCES ${s}.tasks(id),error text,created_at timestamptz NOT NULL DEFAULT now(),PRIMARY KEY(owner,id));
      ALTER TABLE ${s}.scheduled_actions ADD COLUMN IF NOT EXISTS machinery_retry_at timestamptz;
      CREATE INDEX IF NOT EXISTS scheduled_actions_inputs ON ${s}.scheduled_actions USING gin(body jsonb_path_ops) WHERE state='scheduled';
      CREATE INDEX IF NOT EXISTS scheduled_actions_due ON ${s}.scheduled_actions(run_at) WHERE state='scheduled';`);
        await this.query(`ALTER TABLE ${s}.tasks ADD COLUMN IF NOT EXISTS workflow_trace jsonb NOT NULL DEFAULT '[]'`);
        await this.query(`ALTER TABLE ${s}.scheduled_actions ADD COLUMN IF NOT EXISTS continue_at timestamptz`);
        await this.query(`ALTER TABLE ${s}.external_operations ADD COLUMN IF NOT EXISTS requirements jsonb NOT NULL DEFAULT '[]'`);
        await initializeOntologyDataMigrations(this);
        await initializeEntityResolution(this);
        await initializeSemantic(this);
        await initializeApplications(this);
        await initializeAutomation(this);
        await initializeObservationInterests(this);
        await initializeMachineryHistory(this);
        await initializeScenarioEvaluations(this);
        await initializeReleaseEvaluation(this);
        await initializeScenarioLifecycle(this);
        await initializeMachineryStates(this);
        await initializeActionUndo(this);
        await initializeSecurity(this);
        await initializeObjectSets(this);
        await initializeGovernance(this);
        await initializeEffects(this);
        await initializeEditHistory(this);
        await initializeChangeSubscriptions(this);
        await initializeLogArchives(this);
        await initializeProviderBudgets(this);
        await initializeProcessNotifications(this);
        await initializeFunctionArtifacts(this);
        await initializeComponentOAuthGrants(this);
        await initializeFunctionInvocations(this);
        await initializeExecutionTrace(this);
        await initializeIndexing(this);
        await initializeMaterializations(this);
    }
}
