import type { ObjectData } from '../../ontology/schema.js';
import type { Access } from '../access.js';
import type { Database } from '../database.js';
import type { PublishedOntology } from '../metadata.js';
import { type KernelClient } from './client.js';
import { type KernelMode, type KernelRegistry } from './registry.js';
/**
 * How Object Sets and queries use the query kernel: routing, shadow comparisons and kernel cursors, shared by
 * `ObjectSets` and `Objects.query`.
 */
/** Where evaluations find their kernels: the process's registry, or a stand-in for one. */
export type KernelSource = Pick<KernelRegistry, 'kernelFor'> & Partial<Pick<KernelRegistry, 'reload' | 'lost'>>;
/** How an evaluation uses the query kernel: its mode and where it finds its kernels. */
export type KernelUse = {
    mode: KernelMode;
    registry: KernelSource;
};
/** The process's kernel use, from EIGOS_KERNEL and the process's kernels. */
export declare const defaultKernelUse: () => KernelUse;
/** A kernel cursor: the evaluation it continues, where the next page starts, and the members it was computed over. */
export type KernelCursor = {
    identity: string;
    offset: number;
    membership: string;
};
export declare const encodeKernelCursor: (cursor: KernelCursor) => string;
export declare function kernelCursor(cursor: string): KernelCursor | undefined;
/** Where a reference cursor's page starts. */
export declare function referenceOffset(cursor: string): number;
/** Ontology values of objects: a missing value and null are the same value. */
export declare const ontologyValues: (items: readonly ObjectData[]) => {
    ref: {
        type: string;
        id: string;
    };
    revision: number;
    properties: {
        [k: string]: unknown;
    };
}[];
/**
 * Compares the kernel's answer with the reference's, each on a fork of the principal's access, outside every database
 * profile. With EIGOS_KERNEL_SHADOW_STRICT=true the comparison finishes before the request answers, so a mismatch
 * fails it; otherwise it runs after the request answers, adding no latency.
 */
export declare function compareWithKernel(db: Database, registry: KernelSource, access: Access, model: PublishedOntology, input: unknown, reference: (fork: Access) => Promise<unknown>, kernel: (client: KernelClient, fork: Access) => Promise<unknown | undefined>): Promise<void>;
/**
 * The kernel's answer, or undefined when the kernel failed, so that the reference answers. A routed query never fails
 * because of the kernel: a lost kernel is set aside until its registry opens it again.
 */
export declare function kernelAnswer<T>(db: Database, registry: KernelSource, model: PublishedOntology, answer: () => Promise<T | undefined>): Promise<T | undefined>;
