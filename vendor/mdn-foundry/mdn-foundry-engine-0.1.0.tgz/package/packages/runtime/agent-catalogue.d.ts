import { z } from 'zod';
type AgentProfile = NonNullable<OntologyDocument['agentProfiles']>[number];
import type { Ontology } from '../ontology/model.js';
import type { OntologyDocument } from '../ontology/schema.js';
import type { Task } from './tasks.js';
import type { Access } from './access.js';
export declare function checkAgentCapability(model: Ontology, sandbox: boolean, kind: 'action' | 'function', name: string): void;
type Candidate = {
    apiName: string;
    description?: string;
    displayName?: string;
};
export declare function taskCatalogueScope(model: Ontology, access: Pick<Access, 'canDefine'>, input: Task['input'], additional?: {
    profiles: readonly string[];
    resources: readonly string[];
}, legacyProfiles?: readonly AgentProfile[]): {
    profiles: {
        apiName: string;
        terms: string[];
        objects?: string[] | undefined;
        interfaces?: string[] | undefined;
        actions?: string[] | undefined;
        functions?: string[] | undefined;
        sources?: string[] | undefined;
        links?: string[] | undefined;
        instructions?: {
            action?: string | undefined;
            function?: string | undefined;
            text: string;
        }[] | undefined;
    }[];
    include: (kind: string, name: string) => boolean;
};
export declare const discoveryOptions: z.ZodObject<{
    query: z.ZodOptional<z.ZodString>;
    names: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strict>;
export declare function discoverOntology(model: Ontology, document: OntologyDocument, { query, names }: z.infer<typeof discoveryOptions>): {
    ontology: string;
    version: string;
    definition: string;
    resources: {
        kind: string;
        apiName: string;
        definition: {
            typeClasses?: {
                kind: string;
                name: string;
            }[] | undefined;
            renderHints?: Record<string, string | number | boolean> | undefined;
            status?: "active" | "deprecated" | "experimental" | undefined;
            classification?: {
                sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                compartments: string[];
            } | undefined;
            apiName: string;
            description: string;
            parameters: Record<string, unknown>;
            returns: Record<string, unknown>;
            source?: string | undefined;
            edits?: boolean | undefined;
            version?: string | undefined;
            dependencies?: {
                objectTypes?: string[] | undefined;
                interfaceTypes?: string[] | undefined;
                linkTypes?: string[] | undefined;
                functions?: string[] | undefined;
                dataSources?: string[] | undefined;
                actions?: string[] | undefined;
            } | undefined;
            implementation?: {
                kind: "component";
                sha256: string;
                limits: {
                    fuel: number;
                    memoryMb: number;
                    deadlineMs: number;
                    inputBytes?: number | undefined;
                    outputBytes?: number | undefined;
                };
            } | undefined;
        } | {
            typeClasses?: {
                kind: string;
                name: string;
            }[] | undefined;
            renderHints?: Record<string, string | number | boolean> | undefined;
            status?: "active" | "deprecated" | "experimental" | undefined;
            classification?: {
                sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                compartments: string[];
            } | undefined;
            apiName: string;
            description: string;
            parameters: Record<string, unknown>;
            objectParameters: Record<string, string>;
            submissionCriteria: {
                function: string;
                arguments: Record<string, {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                }>;
                message?: string | undefined;
                functionVersion?: string | undefined;
                executionContext?: "live" | "scenario" | undefined;
            }[];
            rules?: ({
                op: "createObject";
                object: {
                    type: string;
                    id: {
                        parameter: string;
                        path?: string[] | undefined;
                    } | {
                        literal: unknown;
                    };
                };
                properties: Record<string, {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                }>;
            } | {
                op: "editObject";
                object: {
                    parameter: string;
                    path?: string[] | undefined;
                };
                expectedRevision: {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                };
                properties: Record<string, {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                }>;
            } | {
                op: "addLink";
                link: string;
                from: {
                    type: string;
                    id: {
                        parameter: string;
                        path?: string[] | undefined;
                    } | {
                        literal: unknown;
                    };
                };
                to: {
                    type: string;
                    id: {
                        parameter: string;
                        path?: string[] | undefined;
                    } | {
                        literal: unknown;
                    };
                };
            } | {
                op: "removeLink";
                link: string;
                from: {
                    type: string;
                    id: {
                        parameter: string;
                        path?: string[] | undefined;
                    } | {
                        literal: unknown;
                    };
                };
                to: {
                    type: string;
                    id: {
                        parameter: string;
                        path?: string[] | undefined;
                    } | {
                        literal: unknown;
                    };
                };
            } | {
                op: "deleteObject";
                object: {
                    parameter: string;
                    path?: string[] | undefined;
                };
                expectedRevision: {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                };
            } | {
                op: "editStruct";
                object: {
                    parameter: string;
                    path?: string[] | undefined;
                };
                expectedRevision: {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                };
                property: string;
                fields: Record<string, {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                }>;
            } | {
                op: "applyScenario";
                scenario: {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                };
                expectedRevision: {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                };
                objectTypes: string[];
                linkTypes: string[];
            })[] | undefined;
            result?: {
                type: string;
                id: {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                };
            } | undefined;
            function?: string | undefined;
            functionVersion?: string | undefined;
            effects?: ({
                name: string;
                handler: string;
                payload: Record<string, {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                }>;
            } | {
                name: string;
                webhook: {
                    source: string;
                    method: "DELETE" | "PATCH" | "POST" | "PUT";
                    path: string;
                    function?: string | undefined;
                };
                payload: Record<string, {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                }>;
            })[] | undefined;
        } | {
            typeClasses?: {
                kind: string;
                name: string;
            }[] | undefined;
            renderHints?: Record<string, string | number | boolean> | undefined;
            status?: "active" | "deprecated" | "experimental" | undefined;
            classification?: {
                sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                compartments: string[];
            } | undefined;
            description: string;
            schema: Record<string, unknown>;
            required: boolean;
            sharedProperty?: string | undefined;
            valueType?: {
                name: string;
                version: string;
            } | undefined;
            struct?: {
                type: string;
                mainField?: string | undefined;
                reducer?: {
                    op: "first" | "last" | "max" | "min";
                    field?: string | undefined;
                } | undefined;
                array?: boolean | undefined;
            } | undefined;
            format?: {
                kind: "currency" | "date" | "number" | "percent" | "text";
                locale?: string | undefined;
                currency?: string | undefined;
                minimumFractionDigits?: number | undefined;
                maximumFractionDigits?: number | undefined;
            } | undefined;
            derived?: import("../ontology/schema.js").DerivedExpression | undefined;
            apiName: string;
        } | {
            typeClasses?: {
                kind: string;
                name: string;
            }[] | undefined;
            renderHints?: Record<string, string | number | boolean> | undefined;
            status?: "active" | "deprecated" | "experimental" | undefined;
            classification?: {
                sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                compartments: string[];
            } | undefined;
            apiName: string;
            version: string;
            description: string;
            schema: Record<string, unknown>;
        } | {
            typeClasses?: {
                kind: string;
                name: string;
            }[] | undefined;
            renderHints?: Record<string, string | number | boolean> | undefined;
            status?: "active" | "deprecated" | "experimental" | undefined;
            classification?: {
                sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                compartments: string[];
            } | undefined;
            apiName: string;
            description: string;
            fields: Record<string, Record<string, unknown>>;
            required?: string[] | undefined;
            mainField?: string | undefined;
        } | {
            apiName: string;
            displayName: string;
            description: string;
            objectTypes: string[];
        } | {
            apiName: string;
            terms: string[];
            objects?: string[] | undefined;
            interfaces?: string[] | undefined;
            actions?: string[] | undefined;
            functions?: string[] | undefined;
            sources?: string[] | undefined;
            links?: string[] | undefined;
            instructions?: {
                action?: string | undefined;
                function?: string | undefined;
                text: string;
            }[] | undefined;
        } | {
            typeClasses?: {
                kind: string;
                name: string;
            }[] | undefined;
            renderHints?: Record<string, string | number | boolean> | undefined;
            status?: "active" | "deprecated" | "experimental" | undefined;
            classification?: {
                sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                compartments: string[];
            } | undefined;
            apiName: string;
            description: string;
            properties: Record<string, {
                typeClasses?: {
                    kind: string;
                    name: string;
                }[] | undefined;
                renderHints?: Record<string, string | number | boolean> | undefined;
                status?: "active" | "deprecated" | "experimental" | undefined;
                classification?: {
                    sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                    compartments: string[];
                } | undefined;
                description: string;
                schema: Record<string, unknown>;
                required: boolean;
                sharedProperty?: string | undefined;
                valueType?: {
                    name: string;
                    version: string;
                } | undefined;
                struct?: {
                    type: string;
                    mainField?: string | undefined;
                    reducer?: {
                        op: "first" | "last" | "max" | "min";
                        field?: string | undefined;
                    } | undefined;
                    array?: boolean | undefined;
                } | undefined;
                format?: {
                    kind: "currency" | "date" | "number" | "percent" | "text";
                    locale?: string | undefined;
                    currency?: string | undefined;
                    minimumFractionDigits?: number | undefined;
                    maximumFractionDigits?: number | undefined;
                } | undefined;
                derived?: import("../ontology/schema.js").DerivedExpression | undefined;
            }>;
            extends?: string[] | undefined;
            optionalProperties: string[];
            links: Record<string, {
                target: string;
                cardinality: "many" | "one";
                required: boolean;
            }>;
            actions: Record<string, {
                parameters: Record<string, unknown>;
                objectParameters: Record<string, string>;
                required: boolean;
            }>;
        } | {
            typeClasses?: {
                kind: string;
                name: string;
            }[] | undefined;
            renderHints?: Record<string, string | number | boolean> | undefined;
            status?: "active" | "deprecated" | "experimental" | undefined;
            classification?: {
                sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                compartments: string[];
            } | undefined;
            apiName: string;
            displayName: string;
            description: string;
            primaryKey: string;
            titleProperty: string;
            properties: Record<string, {
                typeClasses?: {
                    kind: string;
                    name: string;
                }[] | undefined;
                renderHints?: Record<string, string | number | boolean> | undefined;
                status?: "active" | "deprecated" | "experimental" | undefined;
                classification?: {
                    sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                    compartments: string[];
                } | undefined;
                description: string;
                schema: Record<string, unknown>;
                required: boolean;
                sharedProperty?: string | undefined;
                valueType?: {
                    name: string;
                    version: string;
                } | undefined;
                struct?: {
                    type: string;
                    mainField?: string | undefined;
                    reducer?: {
                        op: "first" | "last" | "max" | "min";
                        field?: string | undefined;
                    } | undefined;
                    array?: boolean | undefined;
                } | undefined;
                format?: {
                    kind: "currency" | "date" | "number" | "percent" | "text";
                    locale?: string | undefined;
                    currency?: string | undefined;
                    minimumFractionDigits?: number | undefined;
                    maximumFractionDigits?: number | undefined;
                } | undefined;
                derived?: import("../ontology/schema.js").DerivedExpression | undefined;
            }>;
            machinery?: {
                states: {
                    name: string;
                    terminal?: boolean | undefined;
                    dwellSeconds?: number | undefined;
                }[];
                transitions: {
                    from: string | null;
                    to: string | null;
                    action?: string | undefined;
                    execution?: {
                        subject: string;
                        parameters?: Record<string, string> | undefined;
                        requires?: {
                            process: string;
                            link?: string | undefined;
                            states: string[];
                            match: "all" | "any";
                        }[] | undefined;
                    } | undefined;
                }[];
                subprocesses?: {
                    link: string;
                    process: string;
                }[] | undefined;
                parallel?: string[] | undefined;
                metrics?: {
                    node?: {
                        label: string;
                        aggregation: {
                            op: "count";
                        } | {
                            op: "avg" | "max" | "min" | "sum";
                            property: string;
                        };
                        decimals?: number | undefined;
                        unit?: string | undefined;
                        colors?: {
                            min: number;
                            color: "amber" | "green" | "red";
                        }[] | undefined;
                    } | undefined;
                    edge?: {
                        label: string;
                        aggregation: {
                            op: "count";
                        } | {
                            op: "avg" | "max" | "min" | "sum";
                            property: string;
                        };
                        decimals?: number | undefined;
                        unit?: string | undefined;
                        colors?: {
                            min: number;
                            color: "amber" | "green" | "red";
                        }[] | undefined;
                    } | undefined;
                } | undefined;
            } | undefined;
            classificationProperty?: string | undefined;
            groups?: string[] | undefined;
            interfaces: Record<string, {
                properties: Record<string, string>;
                links: Record<string, string>;
                actions: Record<string, {
                    action: string;
                    parameters: Record<string, string>;
                }>;
            }>;
        } | {
            typeClasses?: {
                kind: string;
                name: string;
            }[] | undefined;
            renderHints?: Record<string, string | number | boolean> | undefined;
            status?: "active" | "deprecated" | "experimental" | undefined;
            classification?: {
                sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                compartments: string[];
            } | undefined;
            apiName: string;
            description: string;
            from: {
                type: string;
                name: string;
                cardinality: "many" | "one";
            };
            to: {
                type: string;
                name: string;
                cardinality: "many" | "one";
            };
        } | {
            apiName: string;
            objectType: string;
            function: string;
            classification?: {
                sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                compartments: string[];
            } | undefined;
            properties: Record<string, string>;
        };
    }[];
} | {
    ontology: string;
    version: string;
    definition: string;
    resources: {
        kind: string;
        apiName: string;
        description: string | undefined;
    }[];
};
/** The API names an identity can see, grouped by resource kind, for a client that then searches or names them. */
export declare function ontologyIndex(model: Ontology, document: OntologyDocument): {
    ontology: string;
    version: string;
    definition: string;
    catalogue: {
        [k: string]: string[];
    };
    next: string;
};
export declare function catalogue(model: Ontology, access: Access, sandbox: boolean, include?: (_kind: string, _name: string) => boolean, compact?: boolean): {
    definition: string;
    interfaces: {
        apiName: string;
        description: string | undefined;
    }[];
    links: {
        apiName: string;
        description: string | undefined;
    }[];
    objects: {
        apiName: string;
        description: string;
        interfaces?: Record<string, {
            properties: Record<string, string>;
            links: Record<string, string>;
            actions: Record<string, {
                action: string;
                parameters: Record<string, string>;
            }>;
        }> | undefined;
    }[];
    functions: {
        apiName: string;
        description: string | undefined;
    }[];
    actions: {
        apiName: string;
        description: string | undefined;
    }[];
    dataSources: {
        apiName: string;
        description: string | undefined;
    }[] | {
        apiName: string;
        objectType: string;
        function: string;
    }[];
};
export declare function describeAgentResources(model: Ontology, access: Access, sandbox: boolean, names: string[]): Candidate[];
export {};
