import type { OntologyDocument } from '../ontology/schema.js';
/** Emit TypeScript from describe()'s permission-filtered published definition. */
export declare function generateOntologyTypes(document: OntologyDocument): string;
