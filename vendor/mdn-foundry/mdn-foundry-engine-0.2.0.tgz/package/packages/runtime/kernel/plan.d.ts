import { z } from 'zod';
import type { Ontology } from '../../ontology/model.js';
import type { ObjectRef } from '../../ontology/schema.js';
import type { Access } from '../access.js';
import type { aggregateSetSchema, setExpressionSchema } from '../object-sets.js';
import type { Objects } from '../objects.js';
import { querySchema } from '../objects.js';
/**
 * Semantic planning for the Ontology query kernel (route C).
 *
 * The planner compiles an Object Set expression into a kernel plan only when every part has a proven equivalent, and
 * otherwise returns `undefined` so the caller uses the reference implementation. Row security comes from the reference
 * rules themselves (`Access.rowRule`, `Access.cellRule`): object policies, markings and a model clearance become row
 * predicates on every table the plan reads, and property security masks the cells predicates and aggregations see.
 * Access checks the reference would make are made here first; a check that would fail also yields `undefined`, so the
 * reference reports its own error.
 *
 * The kernel reports every row the reference reads, so the client records the same row classifications, markings and
 * row dependencies:
 * - the members of every node, and every readable row of a type whose filter reads derived values;
 * - each traversal step's targets;
 * - the objects the derived properties of those rows reach.
 * Type-level checks are made while planning, also for inputs that turn out to be empty, where the reference may skip
 * them; the kernel path then records at least what the reference records.
 */
export type KernelKind = 'string' | 'integer' | 'number' | 'boolean' | 'strings';
type Scalar = string | number | boolean | null;
export type KernelPredicate = {
    op: 'all' | 'any';
    predicates: KernelPredicate[];
} | {
    op: 'not';
    predicate: KernelPredicate;
} | {
    op: 'const';
    value: boolean;
} | {
    op: 'eq' | 'ne';
    column: string;
    value: Scalar;
} | {
    op: 'gt' | 'gte' | 'lt' | 'lte';
    column: string;
    value: number;
} | {
    op: 'in';
    column: string;
    values: Scalar[];
} | {
    op: 'contains';
    column: string;
    value: string;
}
/** Every element of a string list is one of `values`; a missing list is empty. */
 | {
    op: 'subset';
    column: string;
    values: string[];
}
/** A string list holds at least one of `values`. */
 | {
    op: 'hasAny';
    column: string;
    values: string[];
};
/** `candidates`: the filter reads derived values, so the reference reads every candidate before it filters. */
export type KernelMove = {
    source: string;
    link: string;
    forward: boolean;
    target: string;
    filter?: KernelPredicate;
    candidates?: true;
};
export type KernelSet = {
    op: 'empty';
} | {
    op: 'scan';
    type: string;
    filter?: KernelPredicate;
    candidates?: true;
}
/** `enrich: false` for the source of a relationship query, which the reference reads without derived values. */
 | {
    op: 'refs';
    refs: ObjectRef[];
    enrich?: false;
} | {
    op: 'union' | 'intersect';
    sets: KernelSet[];
} | {
    op: 'except';
    left: KernelSet;
    right: KernelSet;
} | {
    op: 'traverse';
    set: KernelSet;
    steps: KernelMove[][];
} | {
    op: 'boundedTraverse';
    set: KernelSet;
    steps: KernelMove[][];
    limit: number;
};
/** One step of a derived relationship path; a link whose label the principal may not see reaches nothing. */
export type KernelStep = {
    link: string;
    forward: boolean;
    target: string;
    visible?: false;
};
/** A derived value as the kernel computes it; see `kernel/src/main.rs`. */
export type KernelDerived = {
    op: 'literal';
    value: number;
} | {
    op: 'field';
    column: string;
    hidden?: boolean;
    policy?: KernelPredicate;
} | {
    op: 'derived';
    column: string;
} | {
    op: 'arith';
    kind: 'add' | 'subtract' | 'multiply' | 'divide';
    left: KernelDerived;
    right: KernelDerived;
} | {
    op: 'linked';
    steps: KernelStep[];
    aggregate: string;
    value?: KernelDerived;
};
declare const bounds: readonly ['minimum', 'maximum', 'exclusiveMinimum', 'exclusiveMaximum'];
/** A derived column with the numeric bounds of its property schema, which the reference validates each value against. */
export type KernelDerivedSpec = {
    column: string;
    kind: Exclude<KernelKind, 'strings'>;
    expr: KernelDerived;
} & Partial<Record<typeof bounds[number], number>>;
/** How the kernel reports each type the plan reads: the rows to record for policy-bound types, and markings read. */
export type KernelMember = {
    type: string;
    track: boolean;
    markings?: string;
};
export type KernelPlan = {
    set: KernelSet;
    types: Set<string>;
    /** The row predicate the kernel applies to every read of each type. */
    rows: Record<string, KernelPredicate>;
    members: Map<string, KernelMember>;
    /** The derived columns each type's reads carry. */
    derived: Record<string, KernelDerivedSpec[]>;
    /**
     * The derived properties of each type whose rows the reference reads with their derived values. The reference checks
     * their visibility for each such row it reads, so the client records the checks where the kernel read such rows.
     */
    enriched: Map<string, string[]>;
};
type SetExpression = z.output<typeof setExpressionSchema>;
type AggregateInput = z.output<typeof aggregateSetSchema>;
/** The kernel column kind of a stored property, or undefined when its values are not one kernel kind. */
export declare function columnKind(model: Ontology, type: string, property: string): KernelKind | undefined;
/** The columns the kernel loads for a type. */
export declare function loadedColumns(model: Ontology, type: string): {
    name: string;
    kind: KernelKind;
}[];
/** Whether the reference can show an object of `type` in `view`. */
export declare const showsType: (model: Ontology, view: string, type: string) => boolean;
type Query = z.output<typeof querySchema>;
/**
 * Compiles an Object Set expression for the kernel. `graph` reads the source object of a relationship query, as the
 * reference does before it reads the relationship.
 */
export declare function compileSet(model: Ontology, access: Access, graph: Objects, expression: SetExpression, completePageType?: string): Promise<KernelPlan | undefined>;
/**
 * The targets of one object's relationship, as `Objects.follow` reads them, or undefined. The reference checks the view's
 * Interface and the navigation, reads the source object with its derived values through `graph`, then checks the
 * target type, the Link and its label; a Link label beyond the clearance has no targets. The kernel computes only the
 * targets, under the target type's row rule.
 */
export declare function compileFollow(model: Ontology, access: Access, graph: Objects, ref: ObjectRef, link: string, view: string): Promise<KernelPlan | undefined>;
/**
 * One member type of an aggregation: each field the aggregation reads, from the type's own column through its mask, or
 * null where the type does not map it.
 */
export type KernelAggregatePart = {
    type: string;
    fields: {
        name: string;
        column?: string;
        hidden?: true;
        policy?: KernelPredicate;
    }[];
};
type FieldKind = Exclude<KernelKind, 'strings'>;
/**
 * Aggregation over a set's members, in `view` or in their own types, or undefined. Each member type contributes its
 * fields read through the view: an Interface maps them to the type's own properties, which may be stored or derived.
 */
export declare function compileAggregate(model: Ontology, access: Access, plan: KernelPlan, input: Pick<AggregateInput, 'view' | 'groupBy' | 'metrics'>): {
    kind: 'aggregate';
    parts: KernelAggregatePart[];
    kinds: Record<string, FieldKind>;
    groupBy: string[];
    metrics: {
        name: string;
        op: "avg" | "count" | "max" | "min" | "sum";
        column: string | undefined;
    }[];
} | undefined;
/**
 * One page of a query's members in the order the reference gives a query it evaluates completely, or undefined. Each
 * member type contributes the order fields read through the query's type: an Interface maps them to the type's own
 * properties, stored or derived, which are null where the type maps none or property security hides them. Nested
 * fields, lists and fields whose kinds differ across member types, other than integers with numbers, stay on the
 * reference, which compares them itself. Ordering reads nothing beyond the members, so it records nothing either.
 */
export declare function compileQueryOrder(model: Ontology, access: Access, plan: KernelPlan, query: Pick<Query, 'type' | 'orderBy'>, offset: number, limit: number): {
    kind: 'query';
    offset: number;
    limit: number;
    parts: KernelAggregatePart[];
    kinds: Record<string, FieldKind>;
    order: {
        name: string;
        desc: boolean;
    }[];
} | undefined;
export {};
