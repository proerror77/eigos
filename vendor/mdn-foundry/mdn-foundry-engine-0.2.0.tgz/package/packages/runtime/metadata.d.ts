import { type ReleaseCheck } from './release-evaluation.js';
import { Ontology } from '../ontology/model.js';
import type { ObjectRef } from '../ontology/schema.js';
import { Database, type Sql } from './database.js';
import { Access } from './access.js';
export interface BindingManifest {
    functions: Record<string, string>;
    sources: Record<string, string>;
    webhooks?: Record<string, string>;
}
export interface Bindings {
    describe(model: Ontology): BindingManifest;
    /** Checks what `describe` cannot check offline, such as the components of component Functions, before a release is prepared. */
    checkRelease?(model: Ontology): Promise<void>;
    evaluateRelease?(model: Ontology): {
        policy: string;
        checks: ReleaseCheck[];
    };
}
export declare class PublishedOntology extends Ontology {
    readonly release: string;
    readonly projection: string;
    readonly runtimeId: string;
    readonly bindings: BindingManifest;
    readonly scenario?: string | undefined;
    readonly evaluation?: {
        base: string;
        client: Sql;
    } | undefined;
    constructor(body: unknown, release: string, projection: string, runtimeId: string, bindings: BindingManifest, scenario?: string | undefined, evaluation?: {
        base: string;
        client: Sql;
    } | undefined);
    /** The same compiled release seen through a Scenario or a candidate evaluation, without compiling it again. */
    scoped(scenario: string | undefined, evaluation: PublishedOntology['evaluation']): PublishedOntology;
}
export type ProjectionTransform = (ref: ObjectRef, properties: Record<string, unknown>) => Record<string, unknown>;
export declare class Metadata {
    private readonly db;
    readonly ontologyId: string;
    private readonly models;
    private readonly transforms;
    constructor(db: Database, ontologyId?: string);
    fingerprint(projection: string, client?: Sql, ontology?: string): Promise<string>;
    private validateEditState;
    prepare(input: unknown, bindings: Bindings, access: Access, transform?: ProjectionTransform, permissionTarget?: string): Promise<PublishedOntology>;
    activate(release: string, bindings: Bindings, access: Access, transaction?: Sql): Promise<PublishedOntology>;
    catchUp(release: string, bindings: Bindings, access: Access, permissionTarget?: string, transaction?: Sql): Promise<{
        release: string;
        projection: string;
        objectsUpdated: number;
        linksAdded: number;
    }>;
    publish(input: unknown, bindings: Bindings, access: Access, transform?: ProjectionTransform): Promise<PublishedOntology>;
    checkBindings(model: PublishedOntology, bindings: Bindings): void;
    active(id?: string, client?: Sql, lock?: boolean): Promise<PublishedOntology>;
    findAncestor(model: PublishedOntology, identity: string, client?: Sql, match?: 'definition' | 'release'): Promise<PublishedOntology | undefined>;
    get(release: string, client?: Sql): Promise<PublishedOntology>;
}
