//! Parquet checkpoint persistence and owner-partitioned restoration (`FORMAT = 2`).

use std::collections::{HashMap, HashSet};
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::time::{Duration, Instant};

use datafusion::arrow::array::{ArrayRef, RecordBatch, StringArray};
use datafusion::arrow::compute::concat_batches;
use datafusion::arrow::datatypes::{Schema, SchemaRef};
use datafusion::parquet::arrow::ArrowWriter;
use datafusion::parquet::basic::{Compression, ZstdLevel};
use datafusion::parquet::file::properties::WriterProperties;
use datafusion::prelude::{ParquetReadOptions, SessionConfig, SessionContext};
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};

use crate::arrow_util::{empty_table, req_str_at, table_of};
use crate::pg::{PgOpError, PgPool};
use crate::server::{AppState, Shared};
use crate::store::{check_budget, max_bytes, LinkStore, OwnerLinkStore, OwnerTypeStore, Snapshot, TypeStore};
use crate::types::{
  checkpoint_edge_schema, checkpoint_object_schema, edge_schema, internal, invalid, object_schema, partitions, quote,
  Failure, LoadRequest, TypeDef,
};

/// Checkpoint manifest format version.
/// Format 2 stores owner-grouped Parquet tables for partitioned restoration; format 1 checkpoints automatically
/// fall back to loading from PostgreSQL.
pub const FORMAT: u32 = 2;

/// Where checkpoints are kept, from `EIGOS_KERNEL_DATA`; without it the kernel keeps none.
pub fn data_dir() -> Option<PathBuf> { std::env::var_os("EIGOS_KERNEL_DATA").map(PathBuf::from) }

/// The directory of one projection's checkpoints.
pub fn checkpoint_root(projection: &str) -> Option<PathBuf> {
  data_dir().map(|dir| {
    dir.join(
      projection
        .chars()
        .map(|c| if c.is_ascii_alphanumeric() || c == '-' || c == '_' { c } else { '_' })
        .collect::<String>(),
    )
  })
}

fn io(error: impl ToString) -> Failure { internal(error) }

/// An owner's last applied commit and its transaction, which identifies the commit in this database.
#[derive(Serialize, Deserialize, Clone, PartialEq, Eq, Debug)]
pub struct Position {
  pub owner: String,
  pub commit: i64,
  pub xact: String,
}

/// What a checkpoint holds: the definition its files follow, and each owner's last applied commit.
#[derive(Serialize, Deserialize, Debug)]
pub struct Manifest {
  pub format: u32,
  pub schema: String,
  pub projection: String,
  pub types: Vec<TypeDef>,
  pub links: Vec<String>,
  pub ranks: HashMap<String, i64>,
  pub positions: Vec<Position>,
  pub objects: usize,
  pub edges: usize,
}

/// The transactions of the given positions, as `change_commits` records them.
async fn positions_of(pool: &Arc<PgPool>, database: &str, schema: &str, applied: &HashMap<String, i64>) -> Result<Vec<Position>, Failure> {
  let (owners, commits): (Vec<String>, Vec<i64>) = applied.iter().map(|(o, c)| (o.clone(), *c)).unzip();
  let schema_owned = schema.to_string();
  pool
    .run(database, move |client| {
      let owners = owners.clone();
      let commits = commits.clone();
      let schema_owned = schema_owned.clone();
      Box::pin(async move {
        let rows = client
          .query(
            format!(
              "SELECT c.owner, c.commit_seq, c.xact::text FROM {schema_owned}.change_commits c
               JOIN unnest($1::text[], $2::bigint[]) AS p(owner, commit_seq)
               ON c.owner=p.owner AND c.commit_seq=p.commit_seq"
            )
            .as_str(),
            &[&owners, &commits],
          )
          .await?;
        if rows.len() != owners.len() {
          return Err(PgOpError::App(internal("A position has no commit in change_commits")));
        }
        Ok::<_, PgOpError>(
          rows.iter().map(|row| Position { owner: row.get(0), commit: row.get(1), xact: row.get(2) }).collect(),
        )
      })
    })
    .await
}

fn writer_properties() -> WriterProperties {
  WriterProperties::builder()
    .set_compression(Compression::ZSTD(ZstdLevel::try_new(1).unwrap_or_default()))
    .build()
}

fn prepend_owner_column(ckpt_schema: &SchemaRef, owner: &str, batch: &RecordBatch) -> Result<RecordBatch, Failure> {
  let owner_col: ArrayRef = Arc::new(StringArray::from(vec![owner; batch.num_rows()]));
  let mut cols = Vec::with_capacity(batch.num_columns() + 1);
  cols.push(owner_col);
  cols.extend(batch.columns().iter().cloned());
  RecordBatch::try_new(ckpt_schema.clone(), cols).map_err(internal)
}

/// Writes a snapshot version as owner-grouped Parquet files (one per type and per link) with a `FORMAT = 2` manifest.
/// Files are staged in a dot-directory and swapped atomically only after complete write.
pub async fn write_checkpoint_to(pool: &Arc<PgPool>, snapshot: &Snapshot, root: &Path) -> Result<Value, Failure> {
  let started = Instant::now();
  let positions = positions_of(pool, &snapshot.request.database, &quote(&snapshot.request.schema), &snapshot.applied).await?;
  write_checkpoint_files(snapshot, root, positions, started).await
}

/// Pure filesystem checkpoint writer (also usable directly by unit tests without PostgreSQL).
pub async fn write_checkpoint_files(
  snapshot: &Snapshot,
  root: &Path,
  positions: Vec<Position>,
  started: Instant,
) -> Result<Value, Failure> {
  let id = format!("{}", std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map_err(io)?.as_nanos());
  let staging = root.join(format!(".{id}"));
  std::fs::create_dir_all(&staging).map_err(io)?;

  let mut written_objects = 0usize;
  for (i, def) in snapshot.request.types.iter().enumerate() {
    let ckpt_schema = checkpoint_object_schema(def);
    let file = std::fs::File::create(staging.join(format!("t{i}.parquet"))).map_err(io)?;
    let mut writer = ArrowWriter::try_new(file, ckpt_schema.clone(), Some(writer_properties())).map_err(internal)?;
    if let Some(store) = snapshot.types.get(&def.name) {
      let mut owners: Vec<&String> = store.owners.keys().collect();
      owners.sort();
      for owner in owners {
        let batches = snapshot.object_rows_for(&def.name, owner)?.collect().await.map_err(internal)?;
        for batch in batches {
          if batch.num_rows() == 0 { continue; }
          written_objects += batch.num_rows();
          let ckpt_batch = prepend_owner_column(&ckpt_schema, owner, &batch)?;
          writer.write(&ckpt_batch).map_err(internal)?;
        }
      }
    }
    writer.close().map_err(internal)?;
  }

  let mut written_edges = 0usize;
  let ckpt_edge_schema = checkpoint_edge_schema();
  for (i, link) in snapshot.request.links.iter().enumerate() {
    let file = std::fs::File::create(staging.join(format!("l{i}.parquet"))).map_err(io)?;
    let mut writer = ArrowWriter::try_new(file, ckpt_edge_schema.clone(), Some(writer_properties())).map_err(internal)?;
    if let Some(store) = snapshot.edges.get(link) {
      let mut owners: Vec<&String> = store.owners.keys().collect();
      owners.sort();
      for owner in owners {
        let batches = snapshot.edge_rows_for(link, owner)?.collect().await.map_err(internal)?;
        for batch in batches {
          if batch.num_rows() == 0 { continue; }
          written_edges += batch.num_rows();
          let ckpt_batch = prepend_owner_column(&ckpt_edge_schema, owner, &batch)?;
          writer.write(&ckpt_batch).map_err(internal)?;
        }
      }
    }
    writer.close().map_err(internal)?;
  }

  let request = &snapshot.request;
  let manifest = Manifest {
    format: FORMAT,
    schema: request.schema.clone(),
    projection: request.projection.clone(),
    types: request.types.clone(),
    links: request.links.clone(),
    ranks: request.ranks.clone(),
    positions,
    objects: written_objects,
    edges: written_edges,
  };
  std::fs::write(staging.join("manifest.json"), serde_json::to_vec(&manifest).map_err(internal)?).map_err(io)?;
  std::fs::rename(&staging, root.join(&id)).map_err(io)?;
  std::fs::write(root.join(".current"), &id).map_err(io)?;
  std::fs::rename(root.join(".current"), root.join("current")).map_err(io)?;
  for entry in std::fs::read_dir(root).map_err(io)?.flatten() {
    let name = entry.file_name().to_string_lossy().to_string();
    if name != id && name != "current" && entry.path().is_dir() {
      let _ = std::fs::remove_dir_all(entry.path());
    }
  }
  Ok(json!({ "checkpoint": id, "elapsedMs": started.elapsed().as_secs_f64() * 1000.0 }))
}

pub async fn write_checkpoint(pool: &Arc<PgPool>, snapshot: &Snapshot) -> Result<Value, Failure> {
  let root = checkpoint_root(&snapshot.request.projection).ok_or_else(|| invalid("EIGOS_KERNEL_DATA is not set"))?;
  write_checkpoint_to(pool, snapshot, &root).await
}

/// Reads a Parquet file into batches of the expected schema; `None` when missing, unreadable, or schema mismatches.
async fn read_rows(ctx: &SessionContext, file: &Path, schema: &SchemaRef) -> Result<Option<Vec<RecordBatch>>, Failure> {
  let read = async {
    ctx.read_parquet(file.to_string_lossy().as_ref(), ParquetReadOptions::default().schema(schema.as_ref())).await?.collect().await
  };
  let Ok(batches) = read.await else { return Ok(None) };
  let same = |found: &Schema| {
    found.fields().len() == schema.fields().len()
      && found.fields().iter().zip(schema.fields().iter()).all(|(a, b)| a.name() == b.name() && a.data_type() == b.data_type())
  };
  if batches.iter().any(|batch| !same(&batch.schema())) { return Ok(None); }
  Ok(Some(
    batches
      .into_iter()
      .map(|batch| RecordBatch::try_new(schema.clone(), batch.columns().to_vec()))
      .collect::<Result<_, _>>()
      .map_err(internal)?,
  ))
}

/// Splits owner-prepended checkpoint batches into per-owner batches without `$owner`, isolating memory buffers per tenant.
fn partition_batches_by_owner(
  batches: Vec<RecordBatch>,
  inner_schema: &SchemaRef,
  bytes: &mut usize,
  budget: Option<usize>,
) -> Result<HashMap<String, (Vec<RecordBatch>, usize, usize)>, Failure> {
  let mut by_owner: HashMap<String, (Vec<RecordBatch>, usize, usize)> = HashMap::new();
  for batch in batches {
    let n = batch.num_rows();
    if n == 0 { continue; }
    let owner_col = batch.column(0).as_ref();
    let mut start = 0usize;
    while start < n {
      let current_owner = req_str_at(owner_col, start)?;
      let mut end = start + 1;
      while end < n && req_str_at(owner_col, end)? == current_owner { end += 1; }
      let len = end - start;
      let stripped = if start == 0 && len == n {
        // Whole batch belongs to a single owner: zero-copy strip of `$owner`.
        RecordBatch::try_new(inner_schema.clone(), batch.columns()[1..].to_vec()).map_err(internal)?
      } else {
        // Multi-owner batch: copy sliced rows into tight tenant-owned buffers to avoid cross-tenant buffer pinning.
        let sliced = batch.slice(start, len);
        let view = RecordBatch::try_new(inner_schema.clone(), sliced.columns()[1..].to_vec()).map_err(internal)?;
        concat_batches(inner_schema, &[view]).map_err(internal)?
      };
      let batch_bytes = stripped.get_array_memory_size();
      *bytes = bytes.saturating_add(batch_bytes);
      check_budget(*bytes, budget)?;
      let entry = by_owner.entry(current_owner.to_string()).or_insert_with(|| (Vec::new(), 0, 0));
      entry.1 += len;
      entry.2 += batch_bytes;
      entry.0.push(stripped);
      start = end;
    }
  }
  Ok(by_owner)
}

/// Restores a snapshot from checkpoint files in `dir` after verifying manifest compatibility (without PG check, for tests & `restore`).
pub async fn restore_from_dir(request: &LoadRequest, dir: &Path, manifest: Manifest) -> Result<Option<Snapshot>, Failure> {
  let budget = max_bytes();
  let parts = partitions();
  let ctx = SessionContext::new_with_config(SessionConfig::new().with_target_partitions(parts));
  let (mut kinds, mut classified, mut types, mut edges) = (HashMap::new(), HashSet::new(), HashMap::new(), HashMap::new());
  let (mut objects, mut edge_count, mut bytes) = (0usize, 0usize, 0usize);

  for (i, def) in request.types.iter().enumerate() {
    let ckpt_schema = checkpoint_object_schema(def);
    let table_schema = object_schema(def);
    let Some(batches) = read_rows(&ctx, &dir.join(format!("t{i}.parquet")), &ckpt_schema).await? else {
      return Ok(None);
    };
    let partitioned = partition_batches_by_owner(batches, &table_schema, &mut bytes, budget)?;
    let mut owner_stores = HashMap::with_capacity(partitioned.len());
    for (owner, (owner_batches, base_rows, base_bytes)) in partitioned {
      objects += base_rows;
      owner_stores.insert(owner, OwnerTypeStore {
        base: table_of(table_schema.clone(), owner_batches)?,
        base_rows,
        base_bytes,
        changed: Arc::default(),
        overlay: None,
        overlay_bytes: 0,
      });
    }
    if def.classification.is_some() { classified.insert(def.name.clone()); }
    kinds.insert(def.name.clone(), def.columns.iter().map(|c| (c.name.clone(), c.kind)).collect());
    types.insert(
      def.name.clone(),
      Arc::new(TypeStore {
        def: Arc::new(def.clone()),
        empty: empty_table(table_schema.clone())?,
        schema: table_schema,
        owners: owner_stores,
      }),
    );
  }

  let ckpt_edge_schema = checkpoint_edge_schema();
  let e_schema = edge_schema();
  for (i, link) in request.links.iter().enumerate() {
    let Some(batches) = read_rows(&ctx, &dir.join(format!("l{i}.parquet")), &ckpt_edge_schema).await? else {
      return Ok(None);
    };
    let partitioned = partition_batches_by_owner(batches, &e_schema, &mut bytes, budget)?;
    let mut owner_stores = HashMap::with_capacity(partitioned.len());
    for (owner, (owner_batches, base_rows, base_bytes)) in partitioned {
      edge_count += base_rows;
      owner_stores.insert(owner, OwnerLinkStore {
        base: table_of(e_schema.clone(), owner_batches)?,
        base_rows,
        base_bytes,
        changed: Arc::default(),
        overlay: None,
        overlay_bytes: 0,
      });
    }
    edges.insert(
      link.clone(),
      Arc::new(LinkStore { empty: empty_table(e_schema.clone())?, owners: owner_stores }),
    );
  }

  let applied = manifest.positions.into_iter().map(|p| (p.owner, p.commit)).collect();
  Ok(Some(Snapshot {
    ctx,
    request: Arc::new(request.clone()),
    kinds,
    classified,
    links: request.links.clone(),
    types,
    edges,
    applied,
    objects,
    edge_count,
    bytes,
  }))
}

/// Validates and reads a manifest from `root/current`, returning `(dir, manifest)` only when format and definition match.
pub fn read_matching_manifest(request: &LoadRequest, root: &Path) -> Option<(PathBuf, Manifest)> {
  let id = std::fs::read_to_string(root.join("current")).ok()?;
  let dir = root.join(id.trim());
  let text = std::fs::read_to_string(dir.join("manifest.json")).ok()?;
  let manifest = serde_json::from_str::<Manifest>(&text).ok()?;
  if manifest.format != FORMAT
    || manifest.schema != request.schema
    || manifest.projection != request.projection
    || manifest.types != request.types
    || manifest.links != request.links
    || manifest.ranks != request.ranks
  {
    return None;
  }
  Some((dir, manifest))
}

/// Restores the projection's last checkpoint when its format/definition match and every recorded position
/// still exists in PostgreSQL `change_commits` with the same transaction; otherwise `None`.
pub async fn restore(pool: &Arc<PgPool>, request: &LoadRequest) -> Result<Option<Snapshot>, Failure> {
  let Some(root) = checkpoint_root(&request.projection) else { return Ok(None) };
  let Some((dir, manifest)) = read_matching_manifest(request, &root) else { return Ok(None) };
  let owners: Vec<String> = manifest.positions.iter().map(|p| p.owner.clone()).collect();
  let commits: Vec<i64> = manifest.positions.iter().map(|p| p.commit).collect();
  let xacts: Vec<String> = manifest.positions.iter().map(|p| p.xact.clone()).collect();
  let expected_len = manifest.positions.len();
  let schema = quote(&request.schema);
  let found: i64 = pool
    .run(&request.database, move |client| {
      let owners = owners.clone();
      let commits = commits.clone();
      let xacts = xacts.clone();
      let schema = schema.clone();
      Box::pin(async move {
        let count: i64 = client
          .query_one(
            format!(
              "SELECT count(*) FROM {schema}.change_commits c
               JOIN unnest($1::text[], $2::bigint[], $3::text[]) AS p(owner, commit_seq, xact)
               ON c.owner=p.owner AND c.commit_seq=p.commit_seq AND c.xact::text=p.xact"
            )
            .as_str(),
            &[&owners, &commits, &xacts],
          )
          .await?
          .get(0);
        Ok::<_, PgOpError>(count)
      })
    })
    .await?;
  if found as usize != expected_len { return Ok(None); }
  restore_from_dir(request, &dir, manifest).await
}

/// Writes a checkpoint of a version unless the last one already holds it.
pub async fn checkpoint(state: &AppState, snapshot: &Arc<Snapshot>) -> Result<Value, Failure> {
  let mut last = state.checkpointed.lock().await;
  if let Some((version, written)) = last.as_ref() {
    if Arc::ptr_eq(version, snapshot) { return Ok(written.clone()); }
  }
  let written = write_checkpoint(&state.pool, snapshot).await?;
  *last = Some((snapshot.clone(), written.clone()));
  Ok(written)
}

/// Writes a checkpoint of each new version every `EIGOS_KERNEL_CHECKPOINT_S` seconds.
pub async fn checkpoints(state: Shared, every: Duration) {
  loop {
    tokio::time::sleep(every).await;
    let Some(snapshot) = state.snapshot.read().await.clone() else { continue };
    let _ = checkpoint(&state, &snapshot).await;
  }
}
