//! Scenario overlay loading, caching, and memory-budget-aware eviction.

use std::collections::{BTreeMap, HashMap};
use std::sync::atomic::Ordering;
use std::sync::Arc;
use std::time::Instant;

use datafusion::arrow::array::{BooleanBuilder, RecordBatch, StringBuilder};
use datafusion::datasource::MemTable;
use serde_json::Value;
use tokio_postgres::IsolationLevel;

use crate::arrow_util::ObjectBuilder;
use crate::pg::PgOpError;
use crate::server::Shared;
use crate::store::{max_bytes, Snapshot};
use crate::types::{
  fallback, internal, object_schema, quote, scenario_link_schema, stale, strings_schema, Failure, ScenarioRequest,
  OVERLAYS,
};

/// One owner's Scenario at one revision, as the reference's Scenario view reads it over the live data:
/// - each type's rows the Scenario stages, with `$sid` the ids it changed or deleted, and the staged rows that exist;
/// - each link's staged edges that differ from the live ones, `$sremoved` true for an edge the Scenario removes.
pub struct Overlay {
  pub revision: i64,
  pub objects: HashMap<String, (Arc<MemTable>, Arc<MemTable>)>,
  pub links: HashMap<String, Arc<MemTable>>,
  pub bytes: usize,
}

/// Reads an owner's Scenario at the revision the query saw, or reuses the last read of that revision.
/// A Scenario at another revision leaves the query to the reference (409 stale).
pub async fn load_overlay(
  state: &Shared,
  snapshot: &Snapshot,
  owner: &str,
  scenario: &ScenarioRequest,
) -> Result<Arc<Overlay>, Failure> {
  let key = (snapshot.request.projection.clone(), owner.to_string(), scenario.id.clone());
  {
    let mut overlays = state.overlays.lock().await;
    if let Some((known, used)) = overlays.get_mut(&key).filter(|(o, _)| o.revision == scenario.revision) {
      *used = Instant::now();
      return Ok(known.clone());
    }
  }

  let req = snapshot.request.clone();
  let links_list = snapshot.links.clone();
  let owner_owned = owner.to_string();
  let scenario_id = scenario.id.clone();
  let expected_revision = scenario.revision;

  let read = state
    .pool
    .run(&snapshot.request.database, move |client| {
      let req = req.clone();
      let links_list = links_list.clone();
      let owner_owned = owner_owned.clone();
      let scenario_id = scenario_id.clone();
      Box::pin(async move {
        let tx = client
          .build_transaction()
          .isolation_level(IsolationLevel::RepeatableRead)
          .read_only(true)
          .start()
          .await?;
        let schema = quote(&req.schema);
        let id = scenario_id.as_str();
        let owner_ref = owner_owned.as_str();
        // Bound as text and cast, so the indexes on the uuid columns apply.
        let revision: Option<i64> = tx
          .query_opt(
            &format!("SELECT revision FROM {schema}.scenarios WHERE id=($1::text)::uuid AND owner=$2"),
            &[&id, &owner_ref],
          )
          .await?
          .map(|row| row.get(0));
        if revision != Some(expected_revision) {
          let _ = tx.commit().await;
          return Err(PgOpError::App(stale("the Scenario changed")));
        }

        let mut overlay_bytes = 0usize;
        let mut objects = HashMap::new();
        let rows = tx
          .query(
            &format!(
              "SELECT type, id, properties::text FROM {schema}.scenario_objects WHERE scenario_id=($1::text)::uuid AND owner=$2 ORDER BY type"
            ),
            &[&id, &owner_ref],
          )
          .await?;
        let mut by_type: BTreeMap<String, Vec<(String, Option<Value>)>> = BTreeMap::new();
        for row in &rows {
          let properties = row
            .get::<_, Option<&str>>(2)
            .map(serde_json::from_str::<Value>)
            .transpose()
            .map_err(internal)?;
          by_type.entry(row.get(0)).or_default().push((row.get(1), properties));
        }
        for (kind, staged) in by_type {
          let Some(def) = req.types.iter().find(|t| t.name == kind) else { continue };
          let mut ids = StringBuilder::new();
          let mut builder = ObjectBuilder::new(def);
          for (object, properties) in &staged {
            ids.append_value(object);
            if let Some(properties) = properties { builder.push(def, object, properties, &req.ranks); }
          }
          let changed = RecordBatch::try_new(strings_schema(&["$sid"]), vec![Arc::new(ids.finish())]).map_err(internal)?;
          let schema = object_schema(def);
          let live = builder.finish(schema.clone())?;
          overlay_bytes = overlay_bytes
            .saturating_add(changed.get_array_memory_size())
            .saturating_add(live.get_array_memory_size());
          objects.insert(
            kind,
            (
              Arc::new(MemTable::try_new(changed.schema(), vec![vec![changed]]).map_err(internal)?),
              Arc::new(MemTable::try_new(schema, vec![vec![live]]).map_err(internal)?),
            ),
          );
        }

        let mut links = HashMap::new();
        let rows = tx
          .query(
            &format!(
              "SELECT type, from_id, to_id, removed FROM {schema}.scenario_links
               WHERE scenario_id=($1::text)::uuid AND owner=$2 AND (NOT removed) IS DISTINCT FROM base_present ORDER BY type"
            ),
            &[&id, &owner_ref],
          )
          .await?;
        let mut by_link: BTreeMap<String, Vec<(String, String, bool)>> = BTreeMap::new();
        for row in &rows { by_link.entry(row.get(0)).or_default().push((row.get(1), row.get(2), row.get(3))); }
        let link_schema = scenario_link_schema();
        for (link, staged) in by_link {
          if !links_list.contains(&link) { continue; }
          let (mut from, mut to, mut removed) = (StringBuilder::new(), StringBuilder::new(), BooleanBuilder::new());
          for (f, t, r) in &staged {
            from.append_value(f);
            to.append_value(t);
            removed.append_value(*r);
          }
          let batch = RecordBatch::try_new(
            link_schema.clone(),
            vec![Arc::new(from.finish()), Arc::new(to.finish()), Arc::new(removed.finish())],
          )
          .map_err(internal)?;
          overlay_bytes = overlay_bytes.saturating_add(batch.get_array_memory_size());
          links.insert(link, Arc::new(MemTable::try_new(link_schema.clone(), vec![vec![batch]]).map_err(internal)?));
        }
        tx.commit().await?;
        Ok::<_, PgOpError>(Arc::new(Overlay { revision: expected_revision, objects, links, bytes: overlay_bytes }))
      })
    })
    .await?;

  let mut overlays = state.overlays.lock().await;
  if let Some(limit) = max_bytes() {
    if snapshot.bytes.saturating_add(read.bytes) > limit {
      overlays.clear();
      state.metrics.over_budget.store(true, Ordering::Relaxed);
      return Err(fallback("memory budget exceeded while loading Scenario overlay"));
    }
    loop {
      let cached: usize = overlays.values().map(|(o, _)| o.bytes).sum();
      if snapshot.bytes.saturating_add(cached).saturating_add(read.bytes) <= limit { break; }
      let Some(oldest) = overlays.iter().min_by_key(|(_, (_, used))| *used).map(|(k, _)| k.clone()) else { break };
      overlays.remove(&oldest);
    }
  }
  overlays.insert(key, (read.clone(), Instant::now()));
  while overlays.len() > OVERLAYS {
    let Some(oldest) = overlays.iter().min_by_key(|(_, (_, used))| *used).map(|(k, _)| k.clone()) else { break };
    overlays.remove(&oldest);
  }
  Ok(read)
}
