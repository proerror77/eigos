//! Derived property evaluation, validation, and read-evidence tracking.

use datafusion::arrow::datatypes::DataType;
use datafusion::common::ScalarValue;
use datafusion::functions::core::expr_fn::coalesce;
use datafusion::functions_aggregate::expr_fn::{avg, bool_or, count, max, min, sum};
use datafusion::logical_expr::{cast, lit, when, Expr, JoinType};
use datafusion::prelude::DataFrame;
use futures_util::future::BoxFuture;

use crate::predicate::predicate;
use crate::query::{base, edges, Ctx};
use crate::store::Snapshot;
use crate::types::{
  column, data_type, fallback, internal, invalid, Derived, DerivedSpec, Failure, Kind, LinkStep, DERIVED_REACH,
  SAFE_LIMIT,
};

pub fn flag(value: Expr) -> Expr { coalesce(vec![value, lit(false)]) }

/// True for a value that is not a finite number, false for null.
pub fn not_finite(value: Expr) -> Expr {
  flag(!(value.clone().gt_eq(lit(-f64::MAX)).and(value.lt_eq(lit(f64::MAX)))))
}

/// A derived column of `kind`, computed once per query over every readable row: `$did`, `$value` of the spec's kind, and
/// `$err`, true where the reference's evaluation of the row's value fails.
pub fn derived_column<'a>(
  snapshot: &'a Snapshot,
  owner: &'a Ctx,
  kind: &'a str,
  name: &'a str,
) -> BoxFuture<'a, Result<DataFrame, Failure>> {
  Box::pin(async move {
    let key = (kind.to_string(), name.to_string());
    let known = owner.columns.lock().await.get(&key).cloned();
    if let Some(frame) = known { return Ok(frame); }
    let spec = owner
      .derived
      .get(kind)
      .into_iter()
      .flatten()
      .find(|s| s.column == name)
      .ok_or_else(|| invalid(format!("Derived column {name} of {kind} is not defined")))?;
    let mut frame = base(snapshot, owner, kind).await?;
    let mut joined = 0usize;
    let (value, failed) = derived_expr(snapshot, owner, kind, &spec.expr, &mut frame, &mut joined).await?;
    let (typed, rejected) = typed_value(spec, value)?;
    let computed = frame
      .select(vec![column("$id").alias("$did"), typed.alias("$value"), failed.or(rejected).alias("$err")])
      .map_err(internal)?
      .cache()
      .await
      .map_err(internal)?;
    owner.columns.lock().await.insert(key, computed.clone());
    Ok(computed)
  })
}

/// The value as its property's kind, and whether the reference's validation against the property schema rejects it:
/// integers must be safe integers, and numbers must respect the schema's bounds.
fn typed_value(spec: &DerivedSpec, value: Expr) -> Result<(Expr, Expr), Failure> {
  let number = cast(value.clone(), DataType::Float64);
  let mut rejected = lit(false);
  let typed = match spec.kind {
    Kind::Integer => {
      let safe = number.clone().gt(lit(-SAFE_LIMIT)).and(number.clone().lt(lit(SAFE_LIMIT)));
      rejected = flag(!safe.clone());
      when(safe, cast(number.clone(), DataType::Int64))
        .otherwise(lit(ScalarValue::Int64(None)))
        .map_err(internal)?
    }
    Kind::Number => number.clone(),
    other => cast(value, data_type(other)),
  };
  if matches!(spec.kind, Kind::Integer | Kind::Number) {
    if let Some(bound) = spec.minimum { rejected = rejected.or(flag(number.clone().lt(lit(bound)))); }
    if let Some(bound) = spec.maximum { rejected = rejected.or(flag(number.clone().gt(lit(bound)))); }
    if let Some(bound) = spec.exclusive_minimum { rejected = rejected.or(flag(number.clone().lt_eq(lit(bound)))); }
    if let Some(bound) = spec.exclusive_maximum { rejected = rejected.or(flag(number.clone().gt_eq(lit(bound)))); }
  }
  Ok((typed, rejected))
}

/// Builds a derived expression over `frame` as `(value, failed)`, joining the relationship aggregations and other derived
/// columns it uses. `failed` holds where the reference's evaluation throws.
fn derived_expr<'a>(
  snapshot: &'a Snapshot,
  owner: &'a Ctx,
  kind: &'a str,
  expr: &'a Derived,
  frame: &'a mut DataFrame,
  joined: &'a mut usize,
) -> BoxFuture<'a, Result<(Expr, Expr), Failure>> {
  Box::pin(async move {
    let kinds = snapshot.kinds.get(kind).ok_or_else(|| invalid(format!("Type {kind} is not loaded")))?;
    let number = |e: Expr| cast(e, DataType::Float64);
    Ok(match expr {
      Derived::Literal { value } => (lit(*value), lit(false)),
      Derived::Field { column: name, hidden, policy } => {
        let field_kind = *kinds.get(name).ok_or_else(|| invalid(format!("Unknown column {name}")))?;
        let null = || ScalarValue::try_from(&data_type(field_kind)).map(lit).map_err(internal);
        let value = if *hidden {
          null()?
        } else if let Some(p) = policy {
          when(predicate(p, kinds)?, column(name)).otherwise(null()?).map_err(internal)?
        } else {
          column(name)
        };
        (value, lit(false))
      }
      Derived::Derived { column: name } => {
        let n = *joined;
        *joined += 1;
        let (key, value, error) = (format!("$r{n}"), format!("$rv{n}"), format!("$re{n}"));
        let values = derived_column(snapshot, owner, kind, name)
          .await?
          .select(vec![column("$did").alias(key.clone()), column("$value").alias(value.clone()), column("$err").alias(error.clone())])
          .map_err(internal)?;
        *frame = frame.clone().join(values, JoinType::Left, &["$id"], &[key.as_str()], None).map_err(internal)?;
        (column(&value), flag(column(&error)))
      }
      Derived::Arith { kind: op, left, right } => {
        let (l, left_failed) = derived_expr(snapshot, owner, kind, left, frame, joined).await?;
        let (r, right_failed) = derived_expr(snapshot, owner, kind, right, frame, joined).await?;
        let (l, r) = (number(l), number(r));
        let value = match op.as_str() {
          "add" => l + r,
          "subtract" => l - r,
          "multiply" => l * r,
          // Division by zero is null in the reference; null operands give null.
          "divide" => when(r.clone().eq(lit(0f64)), lit(ScalarValue::Float64(None)))
            .otherwise(l / r)
            .map_err(internal)?,
          other => return Err(invalid(format!("Unknown arithmetic {other}"))),
        };
        // The reference fails when an operand fails or the result is not a finite number.
        (value.clone(), left_failed.or(right_failed).or(not_finite(value)))
      }
      Derived::Linked { steps, aggregate, value } => {
        let n = *joined;
        *joined += 1;
        let (key, out, error) = (format!("$l{n}"), format!("$lv{n}"), format!("$le{n}"));
        let values = linked_frame(snapshot, owner, kind, steps, aggregate, value.as_deref())
          .await?
          .select(vec![column("$src").alias(key.clone()), column("$agg").alias(out.clone()), column("$aerr").alias(error.clone())])
          .map_err(internal)?;
        *frame = frame.clone().join(values, JoinType::Left, &["$id"], &[key.as_str()], None).map_err(internal)?;
        (
          if aggregate == "count" { coalesce(vec![column(&out), lit(0i64)]) } else { column(&out) },
          flag(column(&error)),
        )
      }
    })
  })
}

/// The value a linked aggregation reads on each readable row of `kind`: (`$vid`, `$v`, `$verr`).
async fn value_frame(snapshot: &Snapshot, owner: &Ctx, kind: &str, value: &Derived) -> Result<DataFrame, Failure> {
  let mut frame = base(snapshot, owner, kind).await?;
  let mut joined = 0usize;
  let (v, failed) = derived_expr(snapshot, owner, kind, value, &mut frame, &mut joined).await?;
  frame.select(vec![column("$id").alias("$vid"), v.alias("$v"), failed.alias("$verr")]).map_err(internal)
}

/// One row per readable source row (`$src`, `$agg`, `$aerr`): the aggregation over the distinct visible objects the path
/// reaches from it, each step deduplicated like the reference's traversal, and whether the reference fails for the row.
async fn linked_frame(
  snapshot: &Snapshot,
  owner: &Ctx,
  kind: &str,
  steps: &[LinkStep],
  aggregate: &str,
  value: Option<&Derived>,
) -> Result<DataFrame, Failure> {
  let sources = base(snapshot, owner, kind).await?.select(vec![column("$id").alias("$src")]).map_err(internal)?;
  let mut reach = sources.clone().select(vec![column("$src"), column("$src").alias("$node")]).map_err(internal)?;
  let mut crowded: Option<DataFrame> = None;
  let mut target = kind.to_string();
  for step in steps {
    if !step.visible {
      reach = reach.filter(lit(false)).map_err(internal)?;
      break;
    }
    if !snapshot.links.contains(&step.link) { return Err(invalid(format!("Link {} is not loaded", step.link))); }
    let (from, to) = if step.forward { ("from_id", "to_id") } else { ("to_id", "from_id") };
    let link_edges = edges(snapshot, owner, &step.link)?
      .select(vec![column(from).alias("$efrom"), column(to).alias("$eto")])
      .map_err(internal)?;
    let visible = base(snapshot, owner, &step.target).await?.select(vec![column("$id").alias("$visible")]).map_err(internal)?;
    reach = reach
      .join(link_edges, JoinType::Inner, &["$node"], &["$efrom"], None)
      .map_err(internal)?
      .select(vec![column("$src"), column("$eto").alias("$node")])
      .map_err(internal)?
      .join(visible, JoinType::LeftSemi, &["$node"], &["$visible"], None)
      .map_err(internal)?
      .distinct()
      .map_err(internal)?;
    let over = reach
      .clone()
      .aggregate(vec![column("$src")], vec![count(column("$node")).alias("$n")])
      .map_err(internal)?
      .filter(column("$n").gt(lit(DERIVED_REACH)))
      .map_err(internal)?
      .select(vec![column("$src").alias("$over")])
      .map_err(internal)?;
    crowded = Some(match crowded { None => over, Some(previous) => previous.union(over).map_err(internal)? });
    target = step.target.clone();
  }
  let grouped = if aggregate == "count" {
    reach
      .aggregate(vec![column("$src")], vec![count(column("$node")).alias("$gagg")])
      .map_err(internal)?
      .select(vec![column("$src").alias("$gsrc"), column("$gagg"), lit(false).alias("$gerr")])
      .map_err(internal)?
  } else if let Some(value) = value {
    let values = value_frame(snapshot, owner, &target, value).await?;
    let number = |e: Expr| cast(e, DataType::Float64);
    let agg = match aggregate {
      "select" => max(column("$v")),
      "max" => max(number(column("$v"))),
      "min" => min(number(column("$v"))),
      "sum" => sum(number(column("$v"))),
      "avg" => avg(number(column("$v"))),
      other => return Err(invalid(format!("Unknown linked aggregate {other}"))),
    };
    let grouped = reach
      .join(values, JoinType::Left, &["$node"], &["$vid"], None)
      .map_err(internal)?
      .aggregate(
        vec![column("$src")],
        vec![agg.alias("$gagg"), bool_or(column("$verr")).alias("$verr"), count(column("$node")).alias("$n")],
      )
      .map_err(internal)?;
    let mut failed = flag(column("$verr"));
    if aggregate == "select" { failed = failed.or(column("$n").gt(lit(1i64))); }
    if aggregate == "sum" || aggregate == "avg" { failed = failed.or(not_finite(column("$gagg"))); }
    grouped.select(vec![column("$src").alias("$gsrc"), column("$gagg"), failed.alias("$gerr")]).map_err(internal)?
  } else {
    // A path the principal cannot follow reaches nothing, so no value is read.
    if steps.iter().all(|s| s.visible) { return Err(invalid("A linked aggregation needs a value")); }
    reach
      .aggregate(vec![column("$src")], vec![count(column("$node")).alias("$n")])
      .map_err(internal)?
      .select(vec![column("$src").alias("$gsrc"), lit(ScalarValue::Float64(None)).alias("$gagg"), lit(false).alias("$gerr")])
      .map_err(internal)?
  };
  let mut result = sources.join(grouped, JoinType::Left, &["$src"], &["$gsrc"], None).map_err(internal)?;
  let mut failed = flag(column("$gerr"));
  if let Some(over) = crowded {
    result = result.join(over.distinct().map_err(internal)?, JoinType::Left, &["$src"], &["$over"], None).map_err(internal)?;
    failed = failed.or(column("$over").is_not_null());
  }
  result.select(vec![column("$src"), column("$gagg").alias("$agg"), failed.alias("$aerr")]).map_err(internal)
}

/// Records what evaluating the derived properties of every row the reference enriches reads, and fails over to the
/// reference when it would fail to evaluate one of them.
pub async fn enrich(snapshot: &Snapshot, owner: &Ctx) -> Result<(), Failure> {
  let enriched: Vec<(String, DataFrame)> = owner
    .reads
    .lock()
    .unwrap()
    .iter()
    .filter(|read| read.enrich && owner.derived.contains_key(&read.kind))
    .map(|read| (read.kind.clone(), read.ids.clone()))
    .collect();
  for (kind, ids) in enriched {
    let wanted = ids.clone().select(vec![column("$id").alias("$rid")]).map_err(internal)?;
    for spec in owner.derived.get(&kind).into_iter().flatten() {
      let failed = derived_column(snapshot, owner, &kind, &spec.column)
        .await?
        .filter(column("$err"))
        .map_err(internal)?
        .join(wanted.clone(), JoinType::LeftSemi, &["$did"], &["$rid"], None)
        .map_err(internal)?
        .limit(0, Some(1))
        .map_err(internal)?
        .count()
        .await
        .map_err(internal)?;
      if failed > 0 { return Err(fallback(&format!("the reference fails to evaluate {kind}.{}", spec.column))); }
      expression_reads(snapshot, owner, &kind, &spec.expr, ids.clone()).await?;
    }
  }
  Ok(())
}

/// Records the rows the reference reads to evaluate `expr` on the rows `ids` (one `$id` column) of `kind`.
fn expression_reads<'a>(
  snapshot: &'a Snapshot,
  owner: &'a Ctx,
  kind: &'a str,
  expr: &'a Derived,
  ids: DataFrame,
) -> BoxFuture<'a, Result<(), Failure>> {
  Box::pin(async move {
    match expr {
      Derived::Literal { .. } | Derived::Field { .. } => Ok(()),
      Derived::Derived { column: name } => {
        let spec = owner
          .derived
          .get(kind)
          .into_iter()
          .flatten()
          .find(|s| &s.column == name)
          .ok_or_else(|| invalid(format!("Derived column {name} is not defined")))?;
        expression_reads(snapshot, owner, kind, &spec.expr, ids).await
      }
      Derived::Arith { left, right, .. } => {
        expression_reads(snapshot, owner, kind, left, ids.clone()).await?;
        expression_reads(snapshot, owner, kind, right, ids).await
      }
      Derived::Linked { steps, aggregate, value } => {
        let mut frontier = ids;
        let mut target = kind;
        for step in steps {
          if !step.visible { return Ok(()); }
          let (from, to) = if step.forward { ("from_id", "to_id") } else { ("to_id", "from_id") };
          let sources = frontier.select(vec![column("$id").alias("$fid")]).map_err(internal)?;
          let link_edges = edges(snapshot, owner, &step.link)?
            .join(sources, JoinType::LeftSemi, &[from], &["$fid"], None)
            .map_err(internal)?
            .select(vec![column(to).alias("$tid")])
            .map_err(internal)?;
          frontier = base(snapshot, owner, &step.target)
            .await?
            .join(link_edges, JoinType::LeftSemi, &["$id"], &["$tid"], None)
            .map_err(internal)?
            .select(vec![column("$id")])
            .map_err(internal)?;
          owner.read(&step.target, frontier.clone(), false)?;
          target = &step.target;
        }
        match (aggregate.as_str(), value.as_deref()) {
          ("count", _) | (_, None) => Ok(()),
          (_, Some(value)) => expression_reads(snapshot, owner, target, value, frontier).await,
        }
      }
    }
  })
}
