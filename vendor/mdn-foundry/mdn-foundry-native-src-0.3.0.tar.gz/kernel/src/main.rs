//! EIGOS Ontology query kernel.
//!
//! Loads a snapshot of one publication projection from PostgreSQL (or restores it from a Parquet checkpoint) into
//! owner-partitioned per-type object tables and per-link edge tables, follows the commit log incrementally per owner,
//! and executes Object Set plans compiled by the TypeScript planner (`packages/runtime/kernel/`) on Apache DataFusion.

mod arrow_util;
mod checkpoint;
mod derived;
mod funnel;
mod overlay;
mod pg;
mod predicate;
mod query;
mod server;
mod store;
mod types;

#[cfg(test)]
mod tests;

use std::net::SocketAddr;
use std::time::Duration;

use serde_json::json;

use crate::checkpoint::{checkpoints, data_dir};
use crate::funnel::follow;
use crate::server::{router, shutdown, AppState};

#[tokio::main]
async fn main() {
  // Loopback only: the kernel holds every owner's data of the projection and has no authentication of its own.
  let port: u16 = std::env::var("EIGOS_KERNEL_PORT").ok().and_then(|p| p.parse().ok()).unwrap_or(0);
  let listener = tokio::net::TcpListener::bind(SocketAddr::from(([127, 0, 0, 1], port))).await.expect("bind loopback");
  println!("{}", json!({ "event": "kernel_listening", "port": listener.local_addr().unwrap().port() }));

  let state = AppState::new();
  // EIGOS_KERNEL_POLL_MS sets how often the Funnel looks for new commits; 0 leaves it to the queries.
  let poll_ms = std::env::var("EIGOS_KERNEL_POLL_MS").ok().and_then(|v| v.parse::<u64>().ok()).unwrap_or(1000);
  if poll_ms > 0 { tokio::spawn(follow(state.clone(), Duration::from_millis(poll_ms))); }

  // EIGOS_KERNEL_CHECKPOINT_S sets how often a changed version is written as a checkpoint; 0 writes them only after a
  // load, on request and at shutdown.
  let ckpt_s = std::env::var("EIGOS_KERNEL_CHECKPOINT_S").ok().and_then(|v| v.parse::<u64>().ok()).unwrap_or(300);
  if ckpt_s > 0 && data_dir().is_some() { tokio::spawn(checkpoints(state.clone(), Duration::from_secs(ckpt_s))); }

  let app = router(state.clone());
  axum::serve(listener, app).with_graceful_shutdown(shutdown(state)).await.expect("serve");
}
