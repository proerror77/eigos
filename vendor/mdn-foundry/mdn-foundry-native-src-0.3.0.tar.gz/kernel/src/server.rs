//! HTTP server routes, application state, observability metrics, and graceful shutdown.

use std::collections::HashMap;
use std::sync::atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering};
use std::sync::Arc;
use std::time::{Duration, Instant};

use axum::extract::rejection::JsonRejection;
use axum::extract::State;
use axum::http::StatusCode;
use axum::routing::{get, post};
use axum::{Json, Router};
use serde_json::{json, Value};
use tokio::sync::{Mutex, RwLock};

use crate::checkpoint::{checkpoint, data_dir, restore};
use crate::funnel::{catch_up, latest_commits};
use crate::overlay::{load_overlay, Overlay};
use crate::pg::PgPool;
use crate::query::query;
use crate::store::{load, max_bytes, Snapshot};
use crate::types::{failure, internal, stale, Failure, LoadRequest, QueryRequest, PROTOCOL};

/// Runtime observability counters exposed via `/health`.
#[derive(Default)]
pub struct Metrics {
  /// How many projections this process has loaded or restored.
  pub loads: AtomicUsize,
  /// Total `/query` requests received.
  pub queries: AtomicU64,
  /// Total queries returned as 422 fallback (reference evaluation or memory budget fallback).
  pub fallbacks: AtomicU64,
  /// Total queries returned as 409 stale (projection/commit/scenario mismatch or catch-up budget limit).
  pub stale: AtomicU64,
  /// True when the last load, catch-up, or overlay operation encountered `EIGOS_KERNEL_MAX_BYTES`.
  pub over_budget: AtomicBool,
}

/// Shared process state: current snapshot, writer serialization lock, pooled PG connections, checkpoint dedup,
/// runtime metrics, and Scenario overlay LRU cache.
pub struct AppState {
  pub snapshot: RwLock<Option<Arc<Snapshot>>>,
  /// Serializes snapshot mutations (`load_route` and `catch_up`) so commits are never lost.
  pub writer: Mutex<()>,
  /// Bounded async PostgreSQL connection pool shared by load, funnel, checkpoint, and overlay readers.
  pub pool: Arc<PgPool>,
  /// Last snapshot written as a checkpoint; lock serializes checkpoint writes.
  pub checkpointed: Mutex<Option<(Arc<Snapshot>, Value)>>,
  pub metrics: Metrics,
  /// Cached Scenario overlays by `(projection, owner, scenario_id)` with last-use timestamp.
  pub overlays: Mutex<HashMap<(String, String, String), (Arc<Overlay>, Instant)>>,
}

pub type Shared = Arc<AppState>;

impl AppState {
  pub fn new() -> Shared {
    Arc::new(Self {
      snapshot: RwLock::new(None),
      writer: Mutex::new(()),
      pool: PgPool::new(),
      checkpointed: Mutex::new(None),
      metrics: Metrics::default(),
      overlays: Default::default(),
    })
  }
}

pub async fn health(State(state): State<Shared>) -> Json<Value> {
  let snapshot = state.snapshot.read().await.clone();
  let (overlay_count, overlay_bytes) = {
    let overlays = state.overlays.lock().await;
    (overlays.len(), overlays.values().map(|(o, _)| o.bytes).sum::<usize>())
  };
  let limit = max_bytes();
  let queries = state.metrics.queries.load(Ordering::Relaxed);
  let fallbacks = state.metrics.fallbacks.load(Ordering::Relaxed);
  let stale_count = state.metrics.stale.load(Ordering::Relaxed);
  let pool_idle = state.pool.idle_count();

  Json(match snapshot {
    Some(s) => {
      let total_bytes = s.bytes.saturating_add(overlay_bytes);
      let over = state.metrics.over_budget.load(Ordering::Relaxed) || limit.is_some_and(|m| total_bytes > m);
      json!({
        "status": "ok",
        "protocol": PROTOCOL,
        "loaded": true,
        "loads": state.metrics.loads.load(Ordering::Relaxed),
        "projection": s.request.projection,
        "objects": s.objects,
        "edges": s.edge_count,
        "changed": s.changed_count(),
        "owners": s.owner_count(),
        "bytes": s.bytes,
        "overlayBytes": overlay_bytes,
        "maxBytes": limit,
        "overBudget": over,
        "queries": queries,
        "fallbacks": fallbacks,
        "stale": stale_count,
        "overlays": overlay_count,
        "poolIdle": pool_idle
      })
    }
    None => json!({
      "status": "ok",
      "protocol": PROTOCOL,
      "loaded": false,
      "loads": state.metrics.loads.load(Ordering::Relaxed),
      "owners": 0,
      "bytes": 0,
      "overlayBytes": overlay_bytes,
      "maxBytes": limit,
      "overBudget": state.metrics.over_budget.load(Ordering::Relaxed),
      "queries": queries,
      "fallbacks": fallbacks,
      "stale": stale_count,
      "overlays": overlay_count,
      "poolIdle": pool_idle
    }),
  })
}

/// The last commit applied for each owner.
pub async fn positions(State(state): State<Shared>) -> Json<Value> {
  let snapshot = state.snapshot.read().await.clone();
  Json(json!(snapshot.map(|s| s.applied.clone()).unwrap_or_default()))
}

/// Loads a projection: from its last checkpoint when that matches the database, otherwise from storage.
pub async fn load_route(State(state): State<Shared>, Json(request): Json<LoadRequest>) -> Result<Json<Value>, Failure> {
  let started = Instant::now();
  let (snapshot, restored) = {
    // The Funnel waits, so no commit is applied to the version this load replaces.
    let _writer = state.writer.lock().await;
    let restored_result = match restore(&state.pool, &request).await {
      Ok(Some(snapshot)) => Ok((snapshot, true)),
      Ok(None) => load(&state.pool, request).await.map(|s| (s, false)),
      Err(err) => Err(err),
    };
    let (snapshot, restored) = match restored_result {
      Ok(pair) => pair,
      Err(err) => {
        if err.0 == StatusCode::INSUFFICIENT_STORAGE {
          state.metrics.over_budget.store(true, Ordering::Relaxed);
        }
        return Err(err);
      }
    };
    state.metrics.over_budget.store(false, Ordering::Relaxed);
    state.overlays.lock().await.clear();
    let snapshot = Arc::new(snapshot);
    *state.snapshot.write().await = Some(snapshot.clone());
    state.metrics.loads.fetch_add(1, Ordering::Relaxed);
    (snapshot, restored)
  };

  if restored {
    // A restored version is as old as its checkpoint, so every owner's commits since are applied before the load answers.
    let found = latest_commits(&state.pool, &snapshot, 0).await?;
    for (owner, latest) in found {
      if latest > snapshot.position(&owner) {
        catch_up(&state, &owner, Some(latest)).await?;
      }
    }
  } else if data_dir().is_some() {
    // A checkpoint of the loaded version lets the next start skip the full load.
    let (state, snapshot) = (state.clone(), snapshot.clone());
    tokio::spawn(async move { let _ = checkpoint(&state, &snapshot).await; });
  }

  let current = state.snapshot.read().await.clone().unwrap_or(snapshot);
  Ok(Json(json!({
    "objects": current.objects,
    "edges": current.edge_count,
    "bytes": current.bytes,
    "owners": current.owner_count(),
    "restored": restored,
    "elapsedMs": started.elapsed().as_secs_f64() * 1000.0
  })))
}

/// Writes a checkpoint of the current version now.
pub async fn checkpoint_route(State(state): State<Shared>) -> Result<Json<Value>, Failure> {
  let snapshot = state
    .snapshot
    .read()
    .await
    .clone()
    .ok_or_else(|| failure(StatusCode::SERVICE_UNAVAILABLE, "No projection is loaded"))?;
  Ok(Json(checkpoint(&state, &snapshot).await?))
}

async fn execute_query(state: &Shared, request: QueryRequest) -> Result<Value, Failure> {
  let unloaded = || failure(StatusCode::SERVICE_UNAVAILABLE, "No projection is loaded");
  let mut snapshot = state.snapshot.read().await.clone().ok_or_else(unloaded)?;
  if request.projection.as_ref().is_some_and(|p| p != &snapshot.request.projection) {
    return Err(stale("the kernel holds another projection"));
  }
  if let Some(needed) = request.min_commit {
    if snapshot.position(&request.owner) < needed {
      // The owner's commits are applied in a task of their own, so a query that stops waiting does not interrupt them.
      let task = tokio::spawn({
        let state = state.clone();
        let owner = request.owner.clone();
        async move { catch_up(&state, &owner, Some(needed)).await }
      });
      match tokio::time::timeout(Duration::from_millis(request.wait_ms.unwrap_or(2000)), task).await {
        Ok(Ok(result)) => result?,
        Ok(Err(error)) => return Err(internal(error)),
        Err(_) => return Err(stale("the kernel is still applying the owner's commits")),
      }
      snapshot = state.snapshot.read().await.clone().ok_or_else(unloaded)?;
      if snapshot.position(&request.owner) < needed {
        return Err(stale("the kernel has not seen the commit"));
      }
    }
  }
  let commit = snapshot.position(&request.owner);
  let overlay = match &request.scenario {
    Some(scenario) => Some(load_overlay(state, &snapshot, &request.owner, scenario).await?),
    None => None,
  };
  let mut value = query(&snapshot, request, overlay).await?;
  value["commit"] = json!(commit);
  Ok(value)
}

pub async fn query_route(
  State(state): State<Shared>,
  payload: Result<Json<QueryRequest>, JsonRejection>,
) -> Result<Json<Value>, Failure> {
  state.metrics.queries.fetch_add(1, Ordering::Relaxed);
  let Json(request) = match payload {
    Ok(json) => json,
    Err(rejection) => {
      if rejection.status() == StatusCode::UNPROCESSABLE_ENTITY {
        state.metrics.fallbacks.fetch_add(1, Ordering::Relaxed);
      }
      return Err(failure(rejection.status(), rejection.body_text()));
    }
  };
  match execute_query(&state, request).await {
    Ok(value) => Ok(Json(value)),
    Err(err) => {
      match err.0 {
        StatusCode::UNPROCESSABLE_ENTITY => { state.metrics.fallbacks.fetch_add(1, Ordering::Relaxed); }
        StatusCode::CONFLICT => { state.metrics.stale.fetch_add(1, Ordering::Relaxed); }
        _ => {}
      }
      Err(err)
    }
  }
}

/// Waits for SIGTERM or SIGINT, then writes a last checkpoint so the next start restores the latest version.
pub async fn shutdown(state: Shared) {
  let terminate = async {
    if let Ok(mut signal) = tokio::signal::unix::signal(tokio::signal::unix::SignalKind::terminate()) {
      signal.recv().await;
    }
  };
  tokio::select! { _ = tokio::signal::ctrl_c() => {}, _ = terminate => {} }
  if data_dir().is_some() {
    if let Some(snapshot) = state.snapshot.read().await.clone() {
      let _ = checkpoint(&state, &snapshot).await;
    }
  }
}

pub fn router(state: Shared) -> Router {
  Router::new()
    .route("/health", get(health))
    .route("/positions", get(positions))
    .route("/load", post(load_route))
    .route("/query", post(query_route))
    .route("/checkpoint", post(checkpoint_route))
    .layer(axum::extract::DefaultBodyLimit::max(64 * 1024 * 1024))
    .with_state(state)
}
