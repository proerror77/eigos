//! Bounded asynchronous PostgreSQL connection pool with automatic reconnect and dirty-connection isolation.

use std::sync::{Arc, Mutex as StdMutex};

use futures_util::future::BoxFuture;
use tokio::sync::{OwnedSemaphorePermit, Semaphore};
use tokio_postgres::{Client, NoTls};

use crate::types::{internal, Failure};

const DEFAULT_POOL_MAX: usize = 8;

fn pool_max() -> usize {
  std::env::var("EIGOS_KERNEL_PG_POOL_MAX")
    .ok()
    .and_then(|v| v.parse::<usize>().ok())
    .filter(|&v| v > 0)
    .unwrap_or(DEFAULT_POOL_MAX)
}

pub async fn connect_raw(database: &str) -> Result<Client, tokio_postgres::Error> {
  let (client, connection) = tokio_postgres::connect(database, NoTls).await?;
  tokio::spawn(async move { let _ = connection.await; });
  Ok(client)
}

struct PoolInner {
  database: String,
  idle: Vec<Client>,
}

/// Lightweight bounded async pool of `tokio_postgres::Client` connections.
/// Connections are returned to the idle list ONLY when explicitly marked clean and still open,
/// so errors, timeouts, or cancelled transactions never return poisoned connections.
pub struct PgPool {
  max_conns: usize,
  permits: Arc<Semaphore>,
  inner: StdMutex<PoolInner>,
}

/// A checked-out PostgreSQL client. Returned to `PgPool` on drop only if `mark_clean()` was called
/// and the underlying connection is still open.
pub struct PooledClient {
  pool: Arc<PgPool>,
  database: String,
  client: Option<Client>,
  from_idle: bool,
  clean: bool,
  _permit: OwnedSemaphorePermit,
}

impl PooledClient {
  pub fn client_mut(&mut self) -> &mut Client {
    self.client.as_mut().expect("pooled client already taken")
  }

  /// Whether this connection was reused from the idle pool (eligible for one transparent reconnect retry).
  pub fn from_idle(&self) -> bool { self.from_idle }

  /// Marks this connection healthy and outside any open transaction so `Drop` returns it to the pool.
  pub fn mark_clean(&mut self) { self.clean = true; }

  /// Drops the underlying connection immediately instead of returning it to the pool.
  pub fn discard(&mut self) {
    self.clean = false;
    self.client = None;
  }
}

impl Drop for PooledClient {
  fn drop(&mut self) {
    if !self.clean { return; }
    let Some(client) = self.client.take() else { return };
    if client.is_closed() { return; }
    if let Ok(mut inner) = self.pool.inner.lock() {
      if inner.database == self.database && inner.idle.len() < self.pool.max_conns {
        inner.idle.push(client);
      }
    }
  }
}

/// Outcome of a pooled operation: distinguishes PostgreSQL transport/query errors (eligible for idle reconnect retry)
/// from application-level errors (e.g. `stale` or `over_budget`) that must NOT trigger a reconnect retry.
pub enum PgOpError {
  Pg(tokio_postgres::Error),
  App(Failure),
}

impl From<tokio_postgres::Error> for PgOpError {
  fn from(error: tokio_postgres::Error) -> Self { Self::Pg(error) }
}

impl From<Failure> for PgOpError {
  fn from(error: Failure) -> Self { Self::App(error) }
}

impl PgPool {
  pub fn new() -> Arc<Self> {
    let max_conns = pool_max();
    Arc::new(Self {
      max_conns,
      permits: Arc::new(Semaphore::new(max_conns)),
      inner: StdMutex::new(PoolInner { database: String::new(), idle: Vec::new() }),
    })
  }

  pub fn idle_count(&self) -> usize {
    self.inner.lock().map(|g| g.idle.iter().filter(|c| !c.is_closed()).count()).unwrap_or(0)
  }

  /// Checks out an idle connection for `database` (discarding closed ones), or establishes a new connection.
  pub async fn checkout(self: &Arc<Self>, database: &str) -> Result<PooledClient, Failure> {
    let permit = self.permits.clone().acquire_owned().await.map_err(internal)?;
    let reused = {
      let mut inner = self.inner.lock().unwrap_or_else(|e| e.into_inner());
      if inner.database != database {
        inner.idle.clear();
        inner.database = database.to_string();
        None
      } else {
        let mut found = None;
        while let Some(c) = inner.idle.pop() {
          if !c.is_closed() { found = Some(c); break; }
        }
        found
      }
    };
    let (client, from_idle) = match reused {
      Some(c) => (c, true),
      None => (connect_raw(database).await.map_err(internal)?, false),
    };
    Ok(PooledClient { pool: self.clone(), database: database.to_string(), client: Some(client), from_idle, clean: false, _permit: permit })
  }

  /// Runs a read-only, idempotent PostgreSQL operation using a pooled connection.
  /// If a reused idle connection fails with a PostgreSQL error (e.g. after server restart or idle disconnect),
  /// it discards the dead connection and transparently retries once on a fresh connection.
  pub async fn run<T, F>(self: &Arc<Self>, database: &str, mut op: F) -> Result<T, Failure>
  where
    F: for<'a> FnMut(&'a mut Client) -> BoxFuture<'a, Result<T, PgOpError>>,
  {
    let mut conn = self.checkout(database).await?;
    match op(conn.client_mut()).await {
      Ok(value) => {
        conn.mark_clean();
        Ok(value)
      }
      Err(PgOpError::App(failure)) => {
        // Application-level errors occur after tx commit or clean query; still do not return potentially mid-tx client.
        conn.discard();
        Err(failure)
      }
      Err(PgOpError::Pg(error)) => {
        let retry = conn.from_idle();
        conn.discard();
        if !retry {
          return Err(internal(error));
        }
        // Purge any other closed connections from the idle list and reconnect while keeping our permit.
        if let Ok(mut inner) = self.inner.lock() {
          inner.idle.retain(|c| !c.is_closed());
        }
        let fresh = connect_raw(database).await.map_err(internal)?;
        conn.client = Some(fresh);
        conn.from_idle = false;
        conn.clean = false;
        match op(conn.client_mut()).await {
          Ok(value) => {
            conn.mark_clean();
            Ok(value)
          }
          Err(PgOpError::App(failure)) => {
            conn.discard();
            Err(failure)
          }
          Err(PgOpError::Pg(err)) => {
            conn.discard();
            Err(internal(err))
          }
        }
      }
    }
  }
}
