//! Query execution: owner-scoped scans/traversals, single-pass materialization for Page/Query/Aggregate, and single-pass `read_stats`.

use std::cmp::Ordering;
use std::collections::{BTreeSet, HashMap, HashSet};
use std::sync::Arc;
use std::time::Instant;

use datafusion::arrow::array::{ArrayRef, RecordBatch, StringBuilder};
use datafusion::arrow::datatypes::{DataType, Field, Schema, SchemaRef};
use datafusion::common::ScalarValue;
use datafusion::functions_aggregate::expr_fn::{avg, count, max, min, sum};
use datafusion::logical_expr::{cast, lit, when, Expr, JoinType};
use datafusion::prelude::{DataFrame, SessionContext};
use futures_util::{future::BoxFuture, TryStreamExt};
use serde_json::{json, Map, Value};

use crate::arrow_util::{
  append_order_digest, array_value_to_json, bool_at, cmp_f64, collect_string_list_cell, f64_at, fnv1a, i64_at,
  req_str_at, str_at, strings_table,
};
use crate::derived::{derived_column, enrich};
use crate::overlay::Overlay;
use crate::predicate::predicate;
use crate::store::Snapshot;
use crate::types::{
  column, data_type, fallback, internal, invalid, ref_key, strings_schema, DerivedSpec, Failure, Kind, MemberSpec,
  Output, Part, Predicate, QueryRequest, SetNode, TRACKED,
};

/// One row set the evaluation reads, as the reference reads it: `ids` has one `$id` column, and `enrich` says whether the
/// reference evaluates the rows' derived properties.
pub struct Read {
  pub kind: String,
  pub ids: DataFrame,
  pub enrich: bool,
}

/// One query execution context: owner, row predicates, derived columns, cached derived frames, and recorded read sets.
pub struct Ctx {
  pub owner: String,
  pub rows: HashMap<String, Predicate>,
  pub derived: HashMap<String, Vec<DerivedSpec>>,
  pub columns: tokio::sync::Mutex<HashMap<(String, String), DataFrame>>,
  pub reads: std::sync::Mutex<Vec<Read>>,
  /// The Scenario the query reads, with the single-valued ends of each link.
  pub scenario: Option<(Arc<Overlay>, HashMap<String, (bool, bool)>)>,
}

impl Ctx {
  pub fn read(&self, kind: &str, frame: DataFrame, enrich: bool) -> Result<(), Failure> {
    let ids = frame.select(vec![column("$id")]).map_err(internal)?;
    self.reads.lock().unwrap().push(Read { kind: kind.to_string(), ids, enrich });
    Ok(())
  }
}

fn refs_frame(ctx: &SessionContext, refs: &[(String, String)]) -> Result<DataFrame, Failure> {
  let schema: SchemaRef = Arc::new(Schema::new(vec![
    Field::new("$type", DataType::Utf8, false),
    Field::new("$id", DataType::Utf8, false),
    Field::new("$key", DataType::Utf8, false),
  ]));
  let (mut t, mut i, mut k) = (StringBuilder::new(), StringBuilder::new(), StringBuilder::new());
  for (kind, id) in refs {
    t.append_value(kind);
    i.append_value(id);
    k.append_value(ref_key(kind, id));
  }
  let batch = RecordBatch::try_new(schema, vec![Arc::new(t.finish()) as ArrayRef, Arc::new(i.finish()), Arc::new(k.finish())])
    .map_err(internal)?;
  ctx.read_batch(batch).map_err(internal)
}

/// The rows of a type the query may read: directly scoped to the owner's partition (zero cross-tenant scan),
/// overlaid with Scenario edits if any, under the type's row predicate, without derived columns.
pub async fn base(snapshot: &Snapshot, owner: &Ctx, kind: &str) -> Result<DataFrame, Failure> {
  let kinds = snapshot.kinds.get(kind).ok_or_else(|| invalid(format!("Type {kind} is not loaded")))?;
  let mut frame = snapshot.object_rows_for(kind, &owner.owner)?;
  // In a Scenario, as its view: the live rows it does not stage, then its staged rows that exist.
  if let Some((changed, staged)) = owner.scenario.as_ref().and_then(|(overlay, _)| overlay.objects.get(kind)) {
    frame = frame
      .join(snapshot.ctx.read_table(changed.clone()).map_err(internal)?, JoinType::LeftAnti, &["$id"], &["$sid"], None)
      .map_err(internal)?
      .union(snapshot.ctx.read_table(staged.clone()).map_err(internal)?)
      .map_err(internal)?;
  }
  if let Some(rows) = owner.rows.get(kind) { frame = frame.filter(predicate(rows, kinds)?).map_err(internal)?; }
  Ok(frame)
}

/// A link's edges directly scoped to the owner's partition (zero cross-tenant scan).
/// In a Scenario, applies staged edge overrides and single-valued end replacements.
pub fn edges(snapshot: &Snapshot, owner: &Ctx, link: &str) -> Result<DataFrame, Failure> {
  let mut frame = snapshot.edge_rows_for(link, &owner.owner)?;
  let Some((overlay, single)) = owner.scenario.as_ref() else { return Ok(frame) };
  let Some(staged) = overlay.links.get(link) else { return Ok(frame) };
  let staged = snapshot.ctx.read_table(staged.clone()).map_err(internal)?;
  let added = staged.clone().filter(!column("$sremoved")).map_err(internal)?;
  frame = frame
    .join(
      staged.clone().select(vec![column("from_id").alias("$sfrom"), column("to_id").alias("$sto")]).map_err(internal)?,
      JoinType::LeftAnti,
      &["from_id", "to_id"],
      &["$sfrom", "$sto"],
      None,
    )
    .map_err(internal)?;
  let (single_from, single_to) = single.get(link).copied().unwrap_or((false, false));
  if single_from {
    frame = frame
      .join(
        added.clone().select(vec![column("from_id").alias("$sfrom")]).map_err(internal)?,
        JoinType::LeftAnti,
        &["from_id"],
        &["$sfrom"],
        None,
      )
      .map_err(internal)?;
  }
  if single_to {
    frame = frame
      .join(
        added.clone().select(vec![column("to_id").alias("$sto")]).map_err(internal)?,
        JoinType::LeftAnti,
        &["to_id"],
        &["$sto"],
        None,
      )
      .map_err(internal)?;
  }
  frame.union(added.select(vec![column("from_id"), column("to_id")]).map_err(internal)?).map_err(internal)
}

/// The column kinds a type's reads carry: its stored columns and the derived columns the query asked for.
pub fn kinds_of(snapshot: &Snapshot, owner: &Ctx, kind: &str) -> Result<HashMap<String, Kind>, Failure> {
  let mut kinds = snapshot.kinds.get(kind).ok_or_else(|| invalid(format!("Type {kind} is not loaded")))?.clone();
  for spec in owner.derived.get(kind).into_iter().flatten() { kinds.insert(spec.column.clone(), spec.kind); }
  Ok(kinds)
}

/// The readable rows of a type with its derived columns, under an optional filter.
pub async fn objects(snapshot: &Snapshot, owner: &Ctx, kind: &str, filter: Option<&Predicate>) -> Result<DataFrame, Failure> {
  let mut frame = base(snapshot, owner, kind).await?;
  for (i, spec) in owner.derived.get(kind).into_iter().flatten().enumerate() {
    let key = format!("$d{i}");
    let values = derived_column(snapshot, owner, kind, &spec.column)
      .await?
      .select(vec![column("$did").alias(key.clone()), column("$value").alias(spec.column.clone())])
      .map_err(internal)?;
    frame = frame.join(values, JoinType::Left, &["$id"], &[key.as_str()], None).map_err(internal)?;
  }
  if let Some(p) = filter { frame = frame.filter(predicate(p, &kinds_of(snapshot, owner, kind)?)?).map_err(internal)?; }
  Ok(frame)
}

fn as_refs(frame: DataFrame, kind: &str) -> Result<DataFrame, Failure> {
  frame.select(vec![lit(kind.to_string()).alias("$type"), column("$id"), column("$key")]).map_err(internal)
}

fn distinct_union(ctx: &SessionContext, frames: Vec<DataFrame>) -> Result<DataFrame, Failure> {
  let mut iter = frames.into_iter();
  let Some(first) = iter.next() else { return refs_frame(ctx, &[]) };
  iter.try_fold(first, |acc, next| acc.union(next)).map_err(internal)?.distinct().map_err(internal)
}

/// Per-owner cardinality estimates order work; authorization, membership and read evidence are evaluated for every operand.
fn estimated_rows(snapshot: &Snapshot, owner: &str, node: &SetNode) -> usize {
  let population = |kind: &str| {
    snapshot
      .types
      .get(kind)
      .and_then(|t| t.owners.get(owner))
      .map_or(0, |o| o.base_rows.saturating_add(o.changed.len()))
  };
  match node {
    SetNode::Empty => 0,
    SetNode::Refs { refs, .. } => refs.len(),
    SetNode::Scan { r#type, filter, .. } => match filter {
      Some(Predicate::Const { value: false }) => 0,
      Some(Predicate::Eq { column, .. }) if column == "$id" => 1,
      Some(Predicate::In { column, values }) if column == "$id" => values.len(),
      _ => population(r#type),
    },
    SetNode::Union { sets } => sets.iter().map(|s| estimated_rows(snapshot, owner, s)).fold(0, usize::saturating_add),
    SetNode::Intersect { sets } => sets.iter().map(|s| estimated_rows(snapshot, owner, s)).min().unwrap_or(0),
    SetNode::Except { left, .. } => estimated_rows(snapshot, owner, left),
    SetNode::Traverse { set, steps } | SetNode::BoundedTraverse { set, steps, .. } => {
      steps.iter().fold(estimated_rows(snapshot, owner, set), |current, step| {
        step
          .iter()
          .map(|m| {
            let link_edges = snapshot
              .edges
              .get(&m.link)
              .and_then(|link| link.owners.get(owner))
              .map_or(0, |o| o.base_rows.saturating_add(o.changed.len()));
            current.saturating_mul(link_edges).div_ceil(population(&m.source).max(1)).min(population(&m.target))
          })
          .fold(0, usize::saturating_add)
      })
    }
  }
}

/// Consume visible target batches only up to the first excess distinct identity. Never return a truncated complete set.
async fn bounded_frontier(ctx: &SessionContext, frames: Vec<DataFrame>, limit: usize) -> Result<DataFrame, Failure> {
  let mut seen = HashSet::new();
  for frame in frames {
    let frame = frame.select(vec![cast(column("$type"), DataType::Utf8), cast(column("$id"), DataType::Utf8)]).map_err(internal)?;
    let mut stream = frame.execute_stream().await.map_err(internal)?;
    while let Some(batch) = stream.try_next().await.map_err(internal)? {
      let types = batch.column(0).as_ref();
      let ids = batch.column(1).as_ref();
      for row in 0..batch.num_rows() {
        seen.insert((req_str_at(types, row)?.to_owned(), req_str_at(ids, row)?.to_owned()));
        if seen.len() > limit { return Err(fallback("traversal exceeds the selected frontier limit")); }
      }
    }
  }
  refs_frame(ctx, &seen.into_iter().collect::<Vec<_>>())
}

/// Evaluates a set node and records the rows the reference reads for it.
fn set_frame<'a>(snapshot: &'a Snapshot, owner: &'a Ctx, node: &'a SetNode) -> BoxFuture<'a, Result<DataFrame, Failure>> {
  Box::pin(async move {
    let ctx = &snapshot.ctx;
    match node {
      SetNode::Empty => refs_frame(ctx, &[]),
      SetNode::Scan { r#type, filter, candidates } => {
        let matched = objects(snapshot, owner, r#type, filter.as_ref()).await?;
        owner.read(r#type, if *candidates { base(snapshot, owner, r#type).await? } else { matched.clone() }, true)?;
        as_refs(matched, r#type)
      }
      SetNode::Refs { refs, enrich } => {
        // Only references to existing objects of loaded types remain.
        let mut by_type: HashMap<&str, Vec<(String, String)>> = HashMap::new();
        for r in refs {
          if snapshot.kinds.contains_key(&r.r#type) {
            by_type.entry(&r.r#type).or_default().push((r.r#type.clone(), r.id.clone()));
          }
        }
        let mut frames = Vec::new();
        for (kind, items) in by_type {
          let wanted = refs_frame(ctx, &items)?.select(vec![column("$id").alias("wanted")]).map_err(internal)?;
          let existing = objects(snapshot, owner, kind, None)
            .await?
            .join(wanted, JoinType::LeftSemi, &["$id"], &["wanted"], None)
            .map_err(internal)?;
          owner.read(kind, existing.clone(), *enrich)?;
          frames.push(as_refs(existing, kind)?);
        }
        distinct_union(ctx, frames)
      }
      SetNode::Union { sets } => {
        let mut frames = Vec::new();
        for s in sets { frames.push(set_frame(snapshot, owner, s).await?); }
        distinct_union(ctx, frames)
      }
      SetNode::Intersect { sets } => {
        let mut operands: Vec<_> = sets.iter().collect();
        operands.sort_by_cached_key(|s| estimated_rows(snapshot, &owner.owner, s));
        let mut iter = operands.into_iter();
        let first = iter.next().ok_or_else(|| invalid("Empty intersection"))?;
        let mut frame = set_frame(snapshot, owner, first).await?;
        for other in iter {
          frame = frame
            .join(set_frame(snapshot, owner, other).await?, JoinType::LeftSemi, &["$key"], &["$key"], None)
            .map_err(internal)?;
        }
        Ok(frame)
      }
      SetNode::Except { left, right } => {
        let left_small = estimated_rows(snapshot, &owner.owner, left) <= estimated_rows(snapshot, &owner.owner, right);
        if left_small {
          set_frame(snapshot, owner, left)
            .await?
            .except(set_frame(snapshot, owner, right).await?)
            .map_err(internal)?
            .distinct()
            .map_err(internal)
        } else {
          let exclusions = set_frame(snapshot, owner, right).await?;
          exclusions
            .join(set_frame(snapshot, owner, left).await?, JoinType::RightAnti, &["$key"], &["$key"], None)
            .map_err(internal)
        }
      }
      SetNode::Traverse { set, steps } | SetNode::BoundedTraverse { set, steps, .. } => {
        let mut current = set_frame(snapshot, owner, set).await?;
        for step in steps {
          let mut frames = Vec::new();
          for m in step {
            if !snapshot.links.contains(&m.link) { return Err(invalid(format!("Link {} is not loaded", m.link))); }
            let sources = current
              .clone()
              .filter(column("$type").eq(lit(m.source.clone())))
              .map_err(internal)?
              .select(vec![column("$id").alias("source")])
              .map_err(internal)?;
            let (from, to) = if m.forward { ("from_id", "to_id") } else { ("to_id", "from_id") };
            let link_edges = edges(snapshot, owner, &m.link)?
              .join(sources, JoinType::LeftSemi, &[from], &["source"], None)
              .map_err(internal)?
              .select(vec![column(to).alias("target")])
              .map_err(internal)?;
            let reached = objects(snapshot, owner, &m.target, None)
              .await?
              .join(link_edges, JoinType::LeftSemi, &["$id"], &["target"], None)
              .map_err(internal)?;
            let targets = match &m.filter {
              Some(p) => reached.clone().filter(predicate(p, &kinds_of(snapshot, owner, &m.target)?)?).map_err(internal)?,
              None => reached.clone(),
            };
            owner.read(&m.target, if m.candidates { reached } else { targets.clone() }, true)?;
            frames.push(as_refs(targets, &m.target)?);
          }
          current = match node {
            SetNode::BoundedTraverse { limit, .. } => bounded_frontier(ctx, frames, *limit).await?,
            _ => distinct_union(ctx, frames)?,
          };
        }
        Ok(current)
      }
    }
  })
}

/// Computes per-type read statistics in a SINGLE scan of `rows_frame` per type, avoiding repeated DataFusion executions
/// and JSON round-tripping while preserving exact `rank`, `compartments`, `ids`, `overLimit`, `markings`, and `enriched` semantics.
async fn read_stats(snapshot: &Snapshot, owner: &Ctx, specs: &[MemberSpec]) -> Result<Vec<Value>, Failure> {
  let mut by_type: HashMap<String, (Vec<DataFrame>, Vec<DataFrame>)> = HashMap::new();
  for read in owner.reads.lock().unwrap().iter() {
    let entry = by_type.entry(read.kind.clone()).or_default();
    entry.0.push(read.ids.clone());
    if read.enrich { entry.1.push(read.ids.clone()); }
  }

  let mut out = Vec::with_capacity(by_type.len());
  for (kind, (frames, enriched)) in by_type {
    let spec = specs.iter().find(|s| s.r#type == kind).ok_or_else(|| invalid(format!("The planner did not describe {kind}")))?;
    let frames_len = frames.len();
    let mut iter = frames.into_iter().map(|frame| frame.select(vec![column("$id").alias("$rid")]));
    let first = iter.next().ok_or_else(|| invalid("No reads"))?.map_err(internal)?;
    let ids = iter.try_fold(first, |acc, next| acc.union(next?)).map_err(internal)?;
    let rows_frame = base(snapshot, owner, &kind)
      .await?
      .join(ids, JoinType::LeftSemi, &["$id"], &["$rid"], None)
      .map_err(internal)?;

    let classified = snapshot.classified.contains(&kind);
    let markings_valid = spec
      .markings
      .as_ref()
      .map(|name| snapshot.kinds.get(&kind).and_then(|k| k.get(name)) == Some(&Kind::Strings));

    let mut total = 0usize;
    let mut max_rank: Option<i64> = None;
    let mut compartments = BTreeSet::new();
    let mut tracked_ids = Vec::new();
    let mut over_limit = false;
    let mut markings_set = BTreeSet::new();

    if !classified && !spec.track && spec.markings.is_none() {
      // Fast path: only row count is needed.
      total = rows_frame.count().await.map_err(internal)?;
    } else {
      // Single-pass projection of only the columns needed for this type's stats.
      let mut proj = Vec::new();
      let id_col = if spec.track {
        let idx = proj.len();
        proj.push(column("$id"));
        Some(idx)
      } else {
        None
      };
      let (rank_col, comp_col) = if classified {
        let r = proj.len();
        proj.push(column("$rank"));
        let c = proj.len();
        proj.push(column("$compartments"));
        (Some(r), Some(c))
      } else {
        (None, None)
      };
      let markings_col = if markings_valid == Some(true) {
        let m = proj.len();
        proj.push(column(spec.markings.as_deref().unwrap()));
        Some(m)
      } else {
        None
      };
      if proj.is_empty() {
        // Happens only if markings was specified with an invalid column kind and neither classified nor tracked.
        proj.push(column("$id"));
      }

      let projected = rows_frame.select(proj).map_err(internal)?;
      let mut stream = projected.execute_stream().await.map_err(internal)?;
      while let Some(batch) = stream.try_next().await.map_err(internal)? {
        let n = batch.num_rows();
        if n == 0 { continue; }
        total += n;

        if let Some(idx) = rank_col {
          let arr = batch.column(idx).as_ref();
          for row in 0..n {
            if let Some(v) = i64_at(arr, row)? {
              max_rank = Some(max_rank.map_or(v, |m| m.max(v)));
            }
          }
        }
        if let Some(idx) = comp_col {
          let arr = batch.column(idx).as_ref();
          for row in 0..n { collect_string_list_cell(arr, row, &mut compartments)?; }
        }
        if let Some(idx) = id_col {
          if !over_limit {
            if total > TRACKED {
              over_limit = true;
              tracked_ids.clear();
              tracked_ids.shrink_to_fit();
            } else {
              let arr = batch.column(idx).as_ref();
              tracked_ids.reserve(n);
              for row in 0..n { tracked_ids.push(req_str_at(arr, row)?.to_owned()); }
            }
          }
        }
        if let Some(idx) = markings_col {
          let arr = batch.column(idx).as_ref();
          for row in 0..n { collect_string_list_cell(arr, row, &mut markings_set)?; }
        }
      }
    }

    if total == 0 { continue; }
    if markings_valid == Some(false) {
      let name = spec.markings.as_deref().unwrap();
      return Err(invalid(format!("{name} is not a string list")));
    }

    let mut entry = Map::new();
    entry.insert("type".into(), json!(kind));
    entry.insert("count".into(), json!(total));
    if classified {
      entry.insert("rank".into(), match max_rank { Some(r) => json!(r), None => Value::Null });
      entry.insert("compartments".into(), json!(compartments.into_iter().collect::<Vec<_>>()));
    }
    if spec.track {
      if over_limit {
        entry.insert("overLimit".into(), json!(true));
      } else {
        entry.insert("ids".into(), json!(tracked_ids));
      }
    }
    if spec.markings.is_some() {
      entry.insert("markings".into(), json!(markings_set.into_iter().collect::<Vec<_>>()));
    }
    // Whether the reference reads some of these rows with their derived values, and so checks their visibility.
    if owner.derived.contains_key(&kind) && !enriched.is_empty() {
      if enriched.len() == frames_len {
        // Every recorded read for this type is enriched and already sourced from `base`, so `total > 0` implies enriched > 0.
        entry.insert("enriched".into(), json!(true));
      } else {
        let mut iter = enriched.into_iter();
        let first = iter.next().ok_or_else(|| invalid("No reads"))?;
        let any = iter
          .try_fold(first, |acc, next| acc.union(next))
          .map_err(internal)?
          .limit(0, Some(1))
          .map_err(internal)?
          .count()
          .await
          .map_err(internal)?;
        if any > 0 { entry.insert("enriched".into(), json!(true)); }
      }
    }
    out.push(Value::Object(entry));
  }
  Ok(out)
}

/// Validates a `Part`'s types, fields, columns, and cell policies, and constructs the DataFusion projection list.
fn validate_part_projection(
  snapshot: &Snapshot,
  owner: &Ctx,
  part: &Part,
  kinds: &HashMap<String, Kind>,
  leading: Vec<Expr>,
) -> Result<Vec<Expr>, Failure> {
  let local = kinds_of(snapshot, owner, &part.r#type)?;
  let mut projection = leading;
  for field in &part.fields {
    let kind = *kinds.get(&field.name).ok_or_else(|| invalid(format!("No kind for {}", field.name)))?;
    let null = || ScalarValue::try_from(&data_type(kind)).map(lit).map_err(internal);
    let value = match &field.column {
      None => null()?,
      Some(_) if field.hidden => null()?,
      Some(name) => {
        if !local.contains_key(name) { return Err(invalid(format!("Unknown column {name} of {}", part.r#type))); }
        let value = cast(column(name), data_type(kind));
        match &field.policy {
          Some(policy) => when(predicate(policy, &local)?, value).otherwise(null()?).map_err(internal)?,
          None => value,
        }
      }
    };
    projection.push(value.alias(field.name.clone()));
  }
  Ok(projection)
}

/// Builds a member `DataFrame` for one type using only that type's matched IDs.
async fn part_frame_for_ids(
  snapshot: &Snapshot,
  owner: &Ctx,
  part: &Part,
  ids: &[String],
  projection: Vec<Expr>,
) -> Result<DataFrame, Failure> {
  let mut builder = StringBuilder::with_capacity(ids.len(), ids.iter().map(String::len).sum());
  for id in ids { builder.append_value(id); }
  let (member_table, _) = strings_table(strings_schema(&["member"]), vec![builder])?;
  let members = snapshot.ctx.read_table(member_table).map_err(internal)?;
  let rows = objects(snapshot, owner, &part.r#type, None)
    .await?
    .join(members, JoinType::LeftSemi, &["$id"], &["member"], None)
    .map_err(internal)?;
  rows.select(projection).map_err(internal)
}

fn format_membership(count: u64, sum: u64) -> String { format!("{count:x}-{sum:016x}") }

/// Compares two rows `(batch_a, row_a)` and `(batch_b, row_b)` across `order_cols`, then JSON-encoded `$type` and `$id`.
fn compare_query_rows(
  batches: &[RecordBatch],
  order_cols: &[(usize, Kind, bool)],
  jtypes: &HashMap<String, String>,
  a: (usize, usize),
  b: (usize, usize),
) -> Result<Ordering, Failure> {
  let (ba, ra) = (&batches[a.0], a.1);
  let (bb, rb) = (&batches[b.0], b.1);
  for &(col_idx, kind, desc) in order_cols {
    let ca = ba.column(col_idx).as_ref();
    let cb = bb.column(col_idx).as_ref();
    let ord = match (ca.is_null(ra), cb.is_null(rb)) {
      (true, true) => Ordering::Equal,
      // Nulls come last in both ascending and descending directions.
      (true, false) => Ordering::Greater,
      (false, true) => Ordering::Less,
      (false, false) => {
        let base_ord = match kind {
          Kind::String => {
            let sa = req_str_at(ca, ra)?;
            let sb = req_str_at(cb, rb)?;
            sa.encode_utf16().cmp(sb.encode_utf16())
          }
          Kind::Integer => i64_at(ca, ra)?.unwrap().cmp(&i64_at(cb, rb)?.unwrap()),
          Kind::Number => cmp_f64(f64_at(ca, ra)?.unwrap(), f64_at(cb, rb)?.unwrap()),
          Kind::Boolean => bool_at(ca, ra)?.unwrap().cmp(&bool_at(cb, rb)?.unwrap()),
          Kind::Strings => return Err(internal("Cannot order by string list")),
        };
        if desc { base_ord.reverse() } else { base_ord }
      }
    };
    if ord != Ordering::Equal { return Ok(ord); }
  }
  // Tie-breakers: JSON-encoded type, then JSON-encoded id (ascending by byte).
  let ta = req_str_at(ba.column(1).as_ref(), ra)?;
  let tb = req_str_at(bb.column(1).as_ref(), rb)?;
  if ta != tb {
    let ja = jtypes.get(ta).map(String::as_str);
    let jb = jtypes.get(tb).map(String::as_str);
    let ord = match (ja, jb) {
      (Some(x), Some(y)) => x.cmp(y),
      _ => serde_json::to_string(ta).unwrap().cmp(&serde_json::to_string(tb).unwrap()),
    };
    if ord != Ordering::Equal { return Ok(ord); }
  }
  let ida = req_str_at(ba.column(2).as_ref(), ra)?;
  let idb = req_str_at(bb.column(2).as_ref(), rb)?;
  if ida != idb {
    return Ok(serde_json::to_string(ida).unwrap().cmp(&serde_json::to_string(idb).unwrap()));
  }
  Ok(Ordering::Equal)
}

pub async fn query(snapshot: &Snapshot, request: QueryRequest, overlay: Option<Arc<Overlay>>) -> Result<Value, Failure> {
  let started = Instant::now();
  let owner = Ctx {
    owner: request.owner.clone(),
    rows: request.rows,
    derived: request.derived,
    columns: Default::default(),
    reads: Default::default(),
    scenario: overlay.map(|o| (o, request.scenario.map(|s| s.single).unwrap_or_default())),
  };

  // Materialize the set ONCE into Arrow batches in memory, eliminating repeated DataFusion executions.
  let set_batches = set_frame(snapshot, &owner, &request.set).await?.collect().await.map_err(internal)?;
  enrich(snapshot, &owner).await?;
  let reads = read_stats(snapshot, &owner, &request.members).await?;

  match request.output {
    Output::Page { offset, limit } => {
      // Single in-memory scan computes total, distinct types, FNV-1a membership, and borrows refs for page slicing.
      let approx: usize = set_batches.iter().map(RecordBatch::num_rows).sum();
      let mut total = 0u64;
      let mut sum = 0u64;
      let mut distinct_types: HashSet<String> = HashSet::new();
      let mut entries: Vec<(&str, &str, &str)> = Vec::with_capacity(approx);

      for batch in &set_batches {
        let n = batch.num_rows();
        if n == 0 { continue; }
        let types_col = batch.column(0).as_ref();
        let ids_col = batch.column(1).as_ref();
        let keys_col = batch.column(2).as_ref();
        for row in 0..n {
          let t = req_str_at(types_col, row)?;
          let id = req_str_at(ids_col, row)?;
          let key = req_str_at(keys_col, row)?;
          total += 1;
          sum = sum.wrapping_add(fnv1a(key));
          if !distinct_types.contains(t) { distinct_types.insert(t.to_owned()); }
          entries.push((key, t, id));
        }
      }

      let refs: Vec<Value> = if offset < entries.len() && limit > 0 {
        let end = offset.saturating_add(limit).min(entries.len());
        if end < entries.len() {
          entries.select_nth_unstable_by(end - 1, |a, b| a.0.cmp(b.0));
        }
        entries[..end].sort_unstable_by(|a, b| a.0.cmp(b.0));
        entries[offset..end].iter().map(|(_, t, id)| json!({ "type": t, "id": id })).collect()
      } else {
        Vec::new()
      };
      let types: Vec<Value> = distinct_types.into_iter().map(Value::String).collect();
      Ok(json!({
        "total": total,
        "refs": refs,
        "types": types,
        "membership": format_membership(total, sum),
        "reads": reads,
        "elapsedMs": started.elapsed().as_secs_f64() * 1000.0
      }))
    }

    Output::Query { offset, limit, parts, kinds, order } => {
      // Single in-memory scan computes total, distinct types, set membership, and per-type matched IDs.
      let mut total = 0u64;
      let mut set_sum = 0u64;
      let mut ids_by_type: HashMap<String, Vec<String>> = HashMap::new();
      for batch in &set_batches {
        let n = batch.num_rows();
        if n == 0 { continue; }
        let types_col = batch.column(0).as_ref();
        let ids_col = batch.column(1).as_ref();
        let keys_col = batch.column(2).as_ref();
        for row in 0..n {
          let t = req_str_at(types_col, row)?;
          let id = req_str_at(ids_col, row)?;
          let key = req_str_at(keys_col, row)?;
          total += 1;
          set_sum = set_sum.wrapping_add(fnv1a(key));
          ids_by_type.entry(t.to_owned()).or_default().push(id.to_owned());
        }
      }

      let covered: HashSet<&str> = parts.iter().map(|part| part.r#type.as_str()).collect();
      for t in ids_by_type.keys() {
        if !covered.contains(t.as_str()) {
          return Err(invalid(format!("No order part for members of \"{t}\"")));
        }
      }

      // Validate all parts and order keys even when total == 0 so invalid plans fail consistently.
      let mut validated_parts = Vec::with_capacity(parts.len());
      for part in &parts {
        let leading = vec![column("$key"), lit(part.r#type.clone()).alias("$type"), column("$id")];
        let projection = validate_part_projection(snapshot, &owner, part, &kinds, leading)?;
        validated_parts.push((part, projection));
      }
      if !parts.is_empty() {
        for key in &order {
          match kinds.get(&key.name) {
            Some(Kind::String | Kind::Integer | Kind::Number | Kind::Boolean) => {}
            _ => return Err(invalid(format!("Cannot order by {}", key.name))),
          }
        }
      }

      let (refs, membership) = if parts.is_empty() || total == 0 {
        (Vec::new(), format_membership(total, set_sum))
      } else {
        let mut frames = Vec::new();
        for (part, projection) in validated_parts {
          let Some(ids) = ids_by_type.get(&part.r#type) else { continue };
          if ids.is_empty() { continue; }
          frames.push(part_frame_for_ids(snapshot, &owner, part, ids, projection).await?);
        }
        let mut iter = frames.into_iter();
        match iter.next() {
          None => (Vec::new(), format_membership(total, set_sum)),
          Some(first) => {
            let members = iter.try_fold(first, |acc, next| acc.union(next)).map_err(internal)?;
            let member_batches = members.collect().await.map_err(internal)?;
            let member_rows: usize = member_batches.iter().map(RecordBatch::num_rows).sum();
            let mut order_cols: Vec<(usize, Kind, bool)> = Vec::with_capacity(order.len());
            if let Some(first_batch) = member_batches.first() {
              let schema = first_batch.schema();
              for key in &order {
                let col_idx = schema.index_of(&key.name).map_err(internal)?;
                let kind = *kinds.get(&key.name).ok_or_else(|| invalid(format!("Cannot order by {}", key.name)))?;
                order_cols.push((col_idx, kind, key.desc));
              }
            }

            // Single in-memory scan computes membership digest (key + order values) and builds row-index list.
            let mut m_count = 0u64;
            let mut m_sum = 0u64;
            let mut buf = String::with_capacity(128);
            let mut positions: Vec<(usize, usize)> = if offset < member_rows && limit > 0 {
              Vec::with_capacity(member_rows)
            } else {
              Vec::new()
            };

            for (b_idx, batch) in member_batches.iter().enumerate() {
              let n = batch.num_rows();
              if n == 0 { continue; }
              let keys_col = batch.column(0).as_ref();
              for row in 0..n {
                let key = req_str_at(keys_col, row)?;
                buf.clear();
                buf.push_str(key);
                for &(col_idx, kind, _) in &order_cols {
                  buf.push('\u{0}');
                  append_order_digest(&mut buf, batch.column(col_idx).as_ref(), row, kind)?;
                }
                m_count += 1;
                m_sum = m_sum.wrapping_add(fnv1a(&buf));
                if offset < member_rows && limit > 0 { positions.push((b_idx, row)); }
              }
            }

            let refs = if offset < positions.len() && limit > 0 {
              let jtypes: HashMap<String, String> =
                parts.iter().map(|p| (p.r#type.clone(), serde_json::to_string(&p.r#type).unwrap())).collect();
              let mut cmp_err: Option<Failure> = None;
              let mut cmp = |a: &(usize, usize), b: &(usize, usize)| -> Ordering {
                if cmp_err.is_some() { return Ordering::Equal; }
                match compare_query_rows(&member_batches, &order_cols, &jtypes, *a, *b) {
                  Ok(ord) => ord,
                  Err(err) => {
                    cmp_err = Some(err);
                    Ordering::Equal
                  }
                }
              };
              let end = offset.saturating_add(limit).min(positions.len());
              if end < positions.len() {
                positions.select_nth_unstable_by(end - 1, &mut cmp);
              }
              positions[..end].sort_unstable_by(&mut cmp);
              if let Some(err) = cmp_err { return Err(err); }

              let mut out_refs = Vec::with_capacity(end - offset);
              for &(b_idx, row) in &positions[offset..end] {
                let batch = &member_batches[b_idx];
                let t = req_str_at(batch.column(1).as_ref(), row)?;
                let id = req_str_at(batch.column(2).as_ref(), row)?;
                out_refs.push(json!({ "type": t, "id": id }));
              }
              out_refs
            } else {
              Vec::new()
            };

            (refs, format_membership(m_count, m_sum))
          }
        }
      };

      Ok(json!({
        "total": total,
        "refs": refs,
        "membership": membership,
        "reads": reads,
        "elapsedMs": started.elapsed().as_secs_f64() * 1000.0
      }))
    }

    Output::Aggregate { parts, kinds, group_by, metrics } => {
      if parts.is_empty() { return Err(invalid("An aggregation needs a member type")); }
      // Validate all parts, metrics, and group_by upfront.
      let mut validated_parts = Vec::with_capacity(parts.len());
      for part in &parts {
        let projection = validate_part_projection(snapshot, &owner, part, &kinds, vec![column("$key")])?;
        validated_parts.push((part, projection));
      }
      let mut aggregates = vec![min(column("$key")).alias("$first"), count(lit(1i64)).alias("$count")];
      for m in &metrics {
        let target = || {
          m.column
            .as_ref()
            .filter(|c| kinds.contains_key(*c))
            .map(|c| column(c))
            .ok_or_else(|| invalid(format!("Metric {} needs a loaded column", m.name)))
        };
        aggregates.push(
          match (m.op.as_str(), &m.column) {
            ("count", None) => count(lit(1i64)),
            ("count", Some(_)) => count(target()?),
            ("sum", _) => sum(target()?),
            ("min", _) => min(target()?),
            ("max", _) => max(target()?),
            ("avg", _) => avg(target()?),
            (other, _) => return Err(invalid(format!("Unknown metric {other}"))),
          }
          .alias(format!("m:{}", m.name)),
        );
      }
      for g in &group_by {
        if !kinds.contains_key(g) { return Err(invalid(format!("Unknown group column {g}"))); }
      }

      // Partition matched IDs by type in one scan of `set_batches`.
      let mut ids_by_type: HashMap<String, Vec<String>> = HashMap::new();
      let mut total_members = 0usize;
      for batch in &set_batches {
        let n = batch.num_rows();
        if n == 0 { continue; }
        let types_col = batch.column(0).as_ref();
        let ids_col = batch.column(1).as_ref();
        for row in 0..n {
          let t = req_str_at(types_col, row)?;
          let id = req_str_at(ids_col, row)?;
          total_members += 1;
          ids_by_type.entry(t.to_owned()).or_default().push(id.to_owned());
        }
      }

      if total_members == 0 {
        let items = if group_by.is_empty() {
          let values: Map<String, Value> = metrics
            .iter()
            .map(|m| (m.name.clone(), if m.op == "count" { json!(0) } else { Value::Null }))
            .collect();
          vec![json!({ "group": {}, "metrics": values })]
        } else {
          Vec::new()
        };
        return Ok(json!({
          "count": 0,
          "items": items,
          "reads": reads,
          "elapsedMs": started.elapsed().as_secs_f64() * 1000.0
        }));
      }

      let mut frames = Vec::new();
      for (part, projection) in validated_parts {
        let Some(ids) = ids_by_type.get(&part.r#type) else { continue };
        if ids.is_empty() { continue; }
        frames.push(part_frame_for_ids(snapshot, &owner, part, ids, projection).await?);
      }
      let mut iter = frames.into_iter();
      let Some(first) = iter.next() else {
        let items = if group_by.is_empty() {
          let values: Map<String, Value> = metrics
            .iter()
            .map(|m| (m.name.clone(), if m.op == "count" { json!(0) } else { Value::Null }))
            .collect();
          vec![json!({ "group": {}, "metrics": values })]
        } else {
          Vec::new()
        };
        return Ok(json!({
          "count": 0,
          "items": items,
          "reads": reads,
          "elapsedMs": started.elapsed().as_secs_f64() * 1000.0
        }));
      };
      let objects = iter.try_fold(first, |acc, next| acc.union(next)).map_err(internal)?;
      let grouped = objects
        .aggregate(group_by.iter().map(|g| column(g)).collect(), aggregates)
        .map_err(internal)?
        .sort(vec![column("$first").sort(true, false)])
        .map_err(internal)?;

      let batches = grouped.collect().await.map_err(internal)?;
      let mut total = 0i64;
      let mut items = Vec::with_capacity(batches.iter().map(RecordBatch::num_rows).sum());
      for batch in &batches {
        let n = batch.num_rows();
        if n == 0 { continue; }
        let schema = batch.schema();
        let count_idx = schema.index_of("$count").map_err(internal)?;
        let group_indices: Vec<(&str, usize)> = group_by
          .iter()
          .map(|g| Ok((g.as_str(), schema.index_of(g).map_err(internal)?)))
          .collect::<Result<_, Failure>>()?;
        let metric_indices: Vec<(&str, usize)> = metrics
          .iter()
          .map(|m| Ok((m.name.as_str(), schema.index_of(&format!("m:{}", m.name)).map_err(internal)?)))
          .collect::<Result<_, Failure>>()?;

        let count_col = batch.column(count_idx).as_ref();
        for row in 0..n {
          total += i64_at(count_col, row)?.unwrap_or(0);
          let mut group = Map::with_capacity(group_indices.len());
          for &(name, idx) in &group_indices {
            group.insert(name.to_owned(), array_value_to_json(batch.column(idx).as_ref(), row)?);
          }
          let mut values = Map::with_capacity(metric_indices.len());
          for &(name, idx) in &metric_indices {
            let col = batch.column(idx).as_ref();
            if !col.is_null(row) && matches!(col.data_type(), DataType::Float64 | DataType::Float32) {
              if let Some(v) = f64_at(col, row)? {
                if !v.is_finite() {
                  return Err(fallback("numeric aggregation overflow"));
                }
              }
            }
            values.insert(name.to_owned(), array_value_to_json(col, row)?);
          }
          items.push(json!({ "group": group, "metrics": values }));
        }
      }
      Ok(json!({
        "count": total,
        "items": items,
        "reads": reads,
        "elapsedMs": started.elapsed().as_secs_f64() * 1000.0
      }))
    }
  }
}

/// Helper kept for compatibility with any caller needing optional string extraction.
#[allow(dead_code)]
pub fn optional_str<'a>(array: &'a dyn datafusion::arrow::array::Array, row: usize) -> Result<Option<&'a str>, Failure> {
  str_at(array, row)
}
