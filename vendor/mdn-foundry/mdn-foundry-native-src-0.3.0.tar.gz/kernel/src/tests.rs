use std::collections::{HashMap, HashSet};
use std::sync::Arc;
use std::time::Instant;

use datafusion::arrow::array::{
  ArrayRef, BooleanArray, Float64Array, Int64Array, ListBuilder, RecordBatch, StringArray, StringBuilder,
  StringViewArray,
};
use datafusion::arrow::datatypes::{DataType, Field, Schema};
use datafusion::datasource::MemTable;
use datafusion::prelude::{SessionConfig, SessionContext};
use serde_json::{json, Value};

use crate::arrow_util::{
  array_value_to_json, batches_to_json_rows, empty_table, table_of, ObjectBuilder,
};
use crate::checkpoint::{read_matching_manifest, restore_from_dir, write_checkpoint_files, Manifest, Position, FORMAT};
use crate::overlay::Overlay;
use crate::query::query;
use crate::store::{
  check_budget, compact_link_owner, compact_type_owner, LinkStore, OwnerLinkStore, OwnerTypeStore, Snapshot, TypeStore,
};
use crate::types::{
  edge_schema, object_schema, scenario_link_schema, strings_schema, ColumnDef, Kind, LoadRequest, MemberSpec, Metric,
  OrderKey, Output, Part, PartField, Predicate, QueryRequest, ScenarioRequest, SetNode, TypeDef,
};

fn sample_def() -> TypeDef {
  TypeDef {
    name: "Item".into(),
    columns: vec![
      ColumnDef { name: "name".into(), kind: Kind::String },
      ColumnDef { name: "score".into(), kind: Kind::Integer },
      ColumnDef { name: "ratio".into(), kind: Kind::Number },
      ColumnDef { name: "active".into(), kind: Kind::Boolean },
      ColumnDef { name: "tags".into(), kind: Kind::Strings },
    ],
    classification: Some("cls".into()),
  }
}

fn empty_def() -> TypeDef {
  TypeDef {
    name: "EmptyType".into(),
    columns: vec![ColumnDef { name: "label".into(), kind: Kind::String }],
    classification: None,
  }
}

fn build_snapshot(
  rows_by_owner: HashMap<&str, Vec<(&str, Value)>>,
  edges_by_owner: HashMap<&str, Vec<(&str, &str)>>,
) -> Snapshot {
  let def = sample_def();
  let empty_t = empty_def();
  let mut ranks = HashMap::new();
  ranks.insert("PUBLIC".into(), 0);
  ranks.insert("INTERNAL".into(), 1);
  ranks.insert("CONFIDENTIAL".into(), 2);

  let request = Arc::new(LoadRequest {
    database: "postgres://unused".into(),
    schema: "eigos".into(),
    projection: "proj-test".into(),
    types: vec![def.clone(), empty_t.clone()],
    links: vec!["Rel".into(), "EmptyRel".into()],
    ranks: ranks.clone(),
  });

  let ctx = SessionContext::new_with_config(SessionConfig::new().with_target_partitions(2));
  let schema = object_schema(&def);
  let mut owner_stores = HashMap::new();
  let mut objects = 0usize;
  let mut bytes = 0usize;

  for (owner, rows) in rows_by_owner {
    let mut builder = ObjectBuilder::new(&def);
    for (id, props) in rows { builder.push(&def, id, &props, &ranks); }
    let batch = builder.finish(schema.clone()).unwrap();
    let n = batch.num_rows();
    let b = batch.get_array_memory_size();
    objects += n;
    bytes += b;
    if n > 0 {
      owner_stores.insert(owner.to_string(), OwnerTypeStore {
        base: table_of(schema.clone(), vec![batch]).unwrap(),
        base_rows: n,
        base_bytes: b,
        changed: Arc::default(),
        overlay: None,
        overlay_bytes: 0,
      });
    }
  }

  let mut types = HashMap::new();
  types.insert(
    def.name.clone(),
    Arc::new(TypeStore {
      def: Arc::new(def.clone()),
      empty: empty_table(schema.clone()).unwrap(),
      schema,
      owners: owner_stores,
    }),
  );
  let empty_schema = object_schema(&empty_t);
  types.insert(
    empty_t.name.clone(),
    Arc::new(TypeStore {
      def: Arc::new(empty_t.clone()),
      empty: empty_table(empty_schema.clone()).unwrap(),
      schema: empty_schema,
      owners: HashMap::new(),
    }),
  );

  let e_schema = edge_schema();
  let mut link_owners = HashMap::new();
  let mut edge_count = 0usize;
  for (owner, list) in edges_by_owner {
    let (mut froms, mut tos) = (StringBuilder::new(), StringBuilder::new());
    for (f, t) in list { froms.append_value(f); tos.append_value(t); }
    let batch = RecordBatch::try_new(
      e_schema.clone(),
      vec![Arc::new(froms.finish()) as ArrayRef, Arc::new(tos.finish())],
    )
    .unwrap();
    let n = batch.num_rows();
    let b = batch.get_array_memory_size();
    edge_count += n;
    bytes += b;
    if n > 0 {
      link_owners.insert(owner.to_string(), OwnerLinkStore {
        base: table_of(e_schema.clone(), vec![batch]).unwrap(),
        base_rows: n,
        base_bytes: b,
        changed: Arc::default(),
        overlay: None,
        overlay_bytes: 0,
      });
    }
  }
  let mut edges = HashMap::new();
  edges.insert(
    "Rel".into(),
    Arc::new(LinkStore { empty: empty_table(e_schema.clone()).unwrap(), owners: link_owners }),
  );
  edges.insert(
    "EmptyRel".into(),
    Arc::new(LinkStore { empty: empty_table(e_schema).unwrap(), owners: HashMap::new() }),
  );

  let mut kinds = HashMap::new();
  kinds.insert(def.name.clone(), def.columns.iter().map(|c| (c.name.clone(), c.kind)).collect());
  kinds.insert(empty_t.name.clone(), empty_t.columns.iter().map(|c| (c.name.clone(), c.kind)).collect());
  let mut classified = HashSet::new();
  classified.insert(def.name.clone());

  Snapshot {
    ctx,
    request,
    kinds,
    classified,
    links: vec!["Rel".into(), "EmptyRel".into()],
    types,
    edges,
    applied: HashMap::from([("alice".into(), 10), ("bob".into(), 5)]),
    objects,
    edge_count,
    bytes,
  }
}

#[test]
fn direct_arrow_to_json_handles_all_types_and_nulls() {
  let mut list_builder = ListBuilder::new(StringBuilder::new());
  list_builder.values().append_value("a");
  list_builder.values().append_null();
  list_builder.values().append_value("b");
  list_builder.append(true);
  list_builder.append(false);

  let schema = Arc::new(Schema::new(vec![
    Field::new("s", DataType::Utf8, true),
    Field::new("sv", DataType::Utf8View, true),
    Field::new("i", DataType::Int64, true),
    Field::new("f", DataType::Float64, true),
    Field::new("b", DataType::Boolean, true),
    Field::new("l", DataType::List(Arc::new(Field::new("item", DataType::Utf8, true))), true),
  ]));
  let batch = RecordBatch::try_new(
    schema,
    vec![
      Arc::new(StringArray::from(vec![Some("hello"), None])),
      Arc::new(StringViewArray::from(vec![Some("view"), None])),
      Arc::new(Int64Array::from(vec![Some(42), None])),
      Arc::new(Float64Array::from(vec![Some(-0.0), Some(f64::NAN)])),
      Arc::new(BooleanArray::from(vec![Some(true), None])),
      Arc::new(list_builder.finish()),
    ],
  )
  .unwrap();

  let rows = batches_to_json_rows(&[batch.clone()]).unwrap();
  assert_eq!(rows.len(), 2);
  assert_eq!(rows[0]["s"], json!("hello"));
  assert_eq!(rows[0]["sv"], json!("view"));
  assert_eq!(rows[0]["i"], json!(42));
  assert_eq!(rows[0]["f"], json!(0.0));
  assert_eq!(rows[0]["b"], json!(true));
  assert_eq!(rows[0]["l"], json!(["a", null, "b"]));

  assert_eq!(rows[1]["s"], Value::Null);
  assert_eq!(rows[1]["sv"], Value::Null);
  assert_eq!(rows[1]["i"], Value::Null);
  assert_eq!(rows[1]["f"], Value::Null);
  assert_eq!(rows[1]["b"], Value::Null);
  assert_eq!(rows[1]["l"], Value::Null);
  assert_eq!(array_value_to_json(batch.column(3).as_ref(), 1).unwrap(), Value::Null);
}

#[tokio::test]
async fn owner_partition_isolation_delta_and_targeted_compaction() {
  let mut snap = build_snapshot(
    HashMap::from([
      (
        "alice",
        vec![
          ("a1", json!({"name": "A1", "score": 10, "active": true, "tags": ["t1"], "cls": {"sensitivity": "INTERNAL", "compartments": ["C1"]}})),
          ("a2", json!({"name": "A2", "score": 20, "active": false, "tags": ["t2"]})),
        ],
      ),
      (
        "bob",
        vec![
          ("b1", json!({"name": "B1", "score": 99, "active": true, "tags": ["secret"]})),
        ],
      ),
    ]),
    HashMap::from([("alice", vec![("a1", "a2")]), ("bob", vec![("b1", "b1")])]),
  );
  assert_eq!(snap.owner_count(), 2);

  // Query alice: must never see bob's rows or tags.
  let req = QueryRequest {
    owner: "alice".into(),
    set: SetNode::Scan { r#type: "Item".into(), filter: None, candidates: false },
    output: Output::Page { offset: 0, limit: 10 },
    members: vec![MemberSpec { r#type: "Item".into(), track: true, markings: Some("tags".into()) }],
    rows: HashMap::new(),
    derived: HashMap::new(),
    projection: Some("proj-test".into()),
    min_commit: None,
    wait_ms: None,
    scenario: None,
  };
  let res = query(&snap, req, None).await.unwrap();
  assert_eq!(res["total"], json!(2));
  assert_eq!(res["reads"][0]["rank"], json!(1));
  assert_eq!(res["reads"][0]["compartments"], json!(["C1"]));
  assert_eq!(res["reads"][0]["markings"], json!(["t1", "t2"]));
  let mut ids: Vec<&str> = res["reads"][0]["ids"].as_array().unwrap().iter().map(|v| v.as_str().unwrap()).collect();
  ids.sort();
  assert_eq!(ids, vec!["a1", "a2"]);

  // Query unknown owner: empty result without error.
  let req_empty = QueryRequest {
    owner: "charlie".into(),
    set: SetNode::Scan { r#type: "Item".into(), filter: None, candidates: false },
    output: Output::Page { offset: 0, limit: 10 },
    members: vec![MemberSpec { r#type: "Item".into(), track: true, markings: None }],
    rows: HashMap::new(),
    derived: HashMap::new(),
    projection: None,
    min_commit: None,
    wait_ms: None,
    scenario: None,
  };
  let res_empty = query(&snap, req_empty, None).await.unwrap();
  assert_eq!(res_empty["total"], json!(0));
  assert_eq!(res_empty["refs"], json!([]));

  // Mutate ONLY alice's delta (edit a1, delete a2, add a3) and check bob's base Arc pointer is untouched!
  let bob_base_ptr = Arc::as_ptr(&snap.types["Item"].owners["bob"].base);
  {
    let ranks = snap.request.ranks.clone();
    let store = Arc::make_mut(snap.types.get_mut("Item").unwrap());
    let def = store.def.clone();
    let schema = store.schema.clone();
    let alice = store.owners.get_mut("alice").unwrap();
    let changed = Arc::make_mut(&mut alice.changed);
    changed.insert("a1".into(), Some(json!({"name": "A1-edited", "score": 15})));
    changed.insert("a2".into(), None);
    changed.insert("a3".into(), Some(json!({"name": "A3", "score": 30})));
    alice.refresh(&def, &schema, &ranks).unwrap();
  }
  assert_eq!(Arc::as_ptr(&snap.types["Item"].owners["bob"].base), bob_base_ptr);

  // Force-compact ONLY alice; bob stays untouched.
  compact_type_owner(&mut snap, "Item", "alice", true).await.unwrap();
  assert_eq!(Arc::as_ptr(&snap.types["Item"].owners["bob"].base), bob_base_ptr);
  assert_eq!(snap.types["Item"].owners["alice"].base_rows, 2);
  assert!(snap.types["Item"].owners["alice"].changed.is_empty());

  // Link delta + compaction for alice only.
  {
    let store = Arc::make_mut(snap.edges.get_mut("Rel").unwrap());
    let alice = store.owners.get_mut("alice").unwrap();
    let changed = Arc::make_mut(&mut alice.changed);
    changed.insert(("a1".into(), "a2".into()), false);
    changed.insert(("a1".into(), "a3".into()), true);
    alice.refresh().unwrap();
  }
  compact_link_owner(&mut snap, "Rel", "alice", true).await.unwrap();
  assert_eq!(snap.edges["Rel"].owners["alice"].base_rows, 1);
  assert_eq!(snap.edges["Rel"].owners["bob"].base_rows, 1);
}

#[tokio::test]
async fn checkpoint_format_2_roundtrip_and_format_1_fallback() {
  let mut snap = build_snapshot(
    HashMap::from([
      ("alice", vec![("a1", json!({"name": "A1", "score": 1, "tags": ["x"]})), ("a2", json!({"name": "A2", "score": 2}))]),
      ("bob", vec![("b1", json!({"name": "B1", "score": 3, "cls": {"sensitivity": "CONFIDENTIAL", "compartments": ["TOP"]}}))]),
    ]),
    HashMap::from([("alice", vec![("a1", "a2")])]),
  );
  // Add an uncompacted edit & delete to alice before writing checkpoint.
  {
    let ranks = snap.request.ranks.clone();
    let store = Arc::make_mut(snap.types.get_mut("Item").unwrap());
    let def = store.def.clone();
    let schema = store.schema.clone();
    let alice = store.owners.get_mut("alice").unwrap();
    let changed = Arc::make_mut(&mut alice.changed);
    changed.insert("a2".into(), None);
    changed.insert("a3".into(), Some(json!({"name": "A3", "score": 30})));
    alice.refresh(&def, &schema, &ranks).unwrap();
  }

  let dir = std::env::temp_dir().join(format!("eigos-kernel-ckpt-test-{}", std::process::id()));
  let _ = std::fs::remove_dir_all(&dir);
  let positions = vec![
    Position { owner: "alice".into(), commit: 10, xact: "100".into() },
    Position { owner: "bob".into(), commit: 5, xact: "101".into() },
  ];
  write_checkpoint_files(&snap, &dir, positions, Instant::now()).await.unwrap();

  let (ckpt_dir, manifest) = read_matching_manifest(&snap.request, &dir).expect("format 2 manifest must match");
  assert_eq!(manifest.format, FORMAT);
  assert_eq!(manifest.objects, 3);
  assert_eq!(manifest.edges, 1);

  let restored = restore_from_dir(&snap.request, &ckpt_dir, manifest).await.unwrap().expect("must restore");
  assert_eq!(restored.objects, 3);
  assert_eq!(restored.edge_count, 1);
  assert_eq!(restored.owner_count(), 2);
  assert_eq!(restored.position("alice"), 10);
  assert_eq!(restored.position("bob"), 5);
  assert_eq!(restored.types["Item"].owners["alice"].base_rows, 2);
  assert_eq!(restored.types["Item"].owners["bob"].base_rows, 1);
  assert!(restored.types["EmptyType"].owners.is_empty());

  // Verify old FORMAT = 1 manifest is rejected (falls back to PG load).
  let old_manifest = Manifest {
    format: 1,
    schema: snap.request.schema.clone(),
    projection: snap.request.projection.clone(),
    types: snap.request.types.clone(),
    links: snap.request.links.clone(),
    ranks: snap.request.ranks.clone(),
    positions: vec![],
    objects: 0,
    edges: 0,
  };
  std::fs::write(ckpt_dir.join("manifest.json"), serde_json::to_vec(&old_manifest).unwrap()).unwrap();
  assert!(read_matching_manifest(&snap.request, &dir).is_none());

  let _ = std::fs::remove_dir_all(&dir);
}

#[tokio::test]
async fn query_ordering_utf16_nulls_last_json_tiebreak_and_aggregate_empty() {
  // UTF-16 ordering check: U+E000 (0xE000) > U+1F600 (surrogate pair 0xD83D 0xDE00) in UTF-16,
  // whereas in UTF-8 U+E000 (EF 80 80) < U+1F600 (F0 9F 98 80)!
  // JSON tiebreak check: "a!" -> "\"a!\"" (0x21) < "a" -> "\"a\"" (0x22)!
  let snap = build_snapshot(
    HashMap::from([(
      "alice",
      vec![
        ("id-e000", json!({"name": "\u{e000}", "score": 1})),
        ("id-emoji", json!({"name": "\u{1f600}", "score": 2})),
        ("id-null", json!({"score": 3})),
        ("a", json!({"name": "same", "score": 10})),
        ("a!", json!({"name": "same", "score": 10})),
      ],
    )]),
    HashMap::new(),
  );

  let part = Part {
    r#type: "Item".into(),
    fields: vec![
      PartField { name: "name".into(), column: Some("name".into()), hidden: false, policy: None },
      PartField { name: "score".into(), column: Some("score".into()), hidden: false, policy: None },
    ],
  };
  let kinds = HashMap::from([("name".into(), Kind::String), ("score".into(), Kind::Integer)]);

  // Ascending by name: "same" ("a!" before "a"), then U+1F600 (0xD83D), then U+E000 (0xE000), then NULL last!
  let asc = query(
    &snap,
    QueryRequest {
      owner: "alice".into(),
      set: SetNode::Scan { r#type: "Item".into(), filter: None, candidates: false },
      output: Output::Query {
        offset: 0,
        limit: 10,
        parts: vec![part],
        kinds: kinds.clone(),
        order: vec![OrderKey { name: "name".into(), desc: false }],
      },
      members: vec![MemberSpec { r#type: "Item".into(), track: false, markings: None }],
      rows: HashMap::new(),
      derived: HashMap::new(),
      projection: None,
      min_commit: None,
      wait_ms: None,
      scenario: None,
    },
    None,
  )
  .await
  .unwrap();
  let asc_ids: Vec<&str> = asc["refs"].as_array().unwrap().iter().map(|r| r["id"].as_str().unwrap()).collect();
  assert_eq!(asc_ids, vec!["a!", "a", "id-emoji", "id-e000", "id-null"]);

  // Descending by name: U+E000, U+1F600, "same" (still "a!" before "a"), and NULL still LAST!
  let part2 = Part {
    r#type: "Item".into(),
    fields: vec![PartField { name: "name".into(), column: Some("name".into()), hidden: false, policy: None }],
  };
  let desc = query(
    &snap,
    QueryRequest {
      owner: "alice".into(),
      set: SetNode::Scan { r#type: "Item".into(), filter: None, candidates: false },
      output: Output::Query {
        offset: 0,
        limit: 10,
        parts: vec![part2],
        kinds: HashMap::from([("name".into(), Kind::String)]),
        order: vec![OrderKey { name: "name".into(), desc: true }],
      },
      members: vec![MemberSpec { r#type: "Item".into(), track: false, markings: None }],
      rows: HashMap::new(),
      derived: HashMap::new(),
      projection: None,
      min_commit: None,
      wait_ms: None,
      scenario: None,
    },
    None,
  )
  .await
  .unwrap();
  let desc_ids: Vec<&str> = desc["refs"].as_array().unwrap().iter().map(|r| r["id"].as_str().unwrap()).collect();
  assert_eq!(desc_ids, vec!["id-e000", "id-emoji", "a!", "a", "id-null"]);

  // Empty ungrouped aggregate must return 1 item with count=0 and sum=null.
  let empty_agg = query(
    &snap,
    QueryRequest {
      owner: "nobody".into(),
      set: SetNode::Scan { r#type: "Item".into(), filter: None, candidates: false },
      output: Output::Aggregate {
        parts: vec![Part {
          r#type: "Item".into(),
          fields: vec![PartField { name: "score".into(), column: Some("score".into()), hidden: false, policy: None }],
        }],
        kinds: HashMap::from([("score".into(), Kind::Integer)]),
        group_by: vec![],
        metrics: vec![
          Metric { name: "n".into(), op: "count".into(), column: None },
          Metric { name: "total".into(), op: "sum".into(), column: Some("score".into()) },
        ],
      },
      members: vec![MemberSpec { r#type: "Item".into(), track: false, markings: None }],
      rows: HashMap::new(),
      derived: HashMap::new(),
      projection: None,
      min_commit: None,
      wait_ms: None,
      scenario: None,
    },
    None,
  )
  .await
  .unwrap();
  assert_eq!(empty_agg["count"], json!(0));
  assert_eq!(empty_agg["items"], json!([{ "group": {}, "metrics": { "n": 0, "total": null } }]));
}

#[tokio::test]
async fn scenario_overlay_and_budget_guard() {
  let snap = build_snapshot(
    HashMap::from([("alice", vec![("a1", json!({"name": "live", "score": 1})), ("a2", json!({"name": "gone", "score": 2}))])]),
    HashMap::from([("alice", vec![("a1", "a2")])]),
  );
  let def = sample_def();
  let schema = object_schema(&def);
  let changed = RecordBatch::try_new(
    strings_schema(&["$sid"]),
    vec![Arc::new(StringArray::from(vec!["a1", "a2", "a3"])) as ArrayRef],
  )
  .unwrap();
  let mut builder = ObjectBuilder::new(&def);
  builder.push(&def, "a1", &json!({"name": "staged-a1", "score": 100}), &snap.request.ranks);
  builder.push(&def, "a3", &json!({"name": "staged-a3", "score": 300}), &snap.request.ranks);
  let live = builder.finish(schema.clone()).unwrap();

  let link_batch = RecordBatch::try_new(
    scenario_link_schema(),
    vec![
      Arc::new(StringArray::from(vec!["a1"])) as ArrayRef,
      Arc::new(StringArray::from(vec!["a3"])),
      Arc::new(BooleanArray::from(vec![false])),
    ],
  )
  .unwrap();

  let overlay = Arc::new(Overlay {
    revision: 7,
    objects: HashMap::from([(
      "Item".into(),
      (
        Arc::new(MemTable::try_new(changed.schema(), vec![vec![changed]]).unwrap()),
        Arc::new(MemTable::try_new(schema, vec![vec![live]]).unwrap()),
      ),
    )]),
    links: HashMap::from([("Rel".into(), Arc::new(MemTable::try_new(scenario_link_schema(), vec![vec![link_batch]]).unwrap()))]),
    bytes: 1024,
  });

  // Single-from link replacement: live a1->a2 is shadowed by staged a1->a3; a2 is deleted in scenario!
  let res = query(
    &snap,
    QueryRequest {
      owner: "alice".into(),
      set: SetNode::Traverse {
        set: Box::new(SetNode::Scan {
          r#type: "Item".into(),
          filter: Some(Predicate::Eq { column: "name".into(), value: json!("staged-a1") }),
          candidates: false,
        }),
        steps: vec![vec![crate::types::Move {
          source: "Item".into(),
          link: "Rel".into(),
          forward: true,
          target: "Item".into(),
          filter: None,
          candidates: false,
        }]],
      },
      output: Output::Page { offset: 0, limit: 10 },
      members: vec![MemberSpec { r#type: "Item".into(), track: true, markings: None }],
      rows: HashMap::new(),
      derived: HashMap::new(),
      projection: None,
      min_commit: None,
      wait_ms: None,
      scenario: Some(ScenarioRequest {
        id: "scn-1".into(),
        revision: 7,
        single: HashMap::from([("Rel".into(), (true, false))]),
      }),
    },
    Some(overlay),
  )
  .await
  .unwrap();
  assert_eq!(res["total"], json!(1));
  assert_eq!(res["refs"], json!([{ "type": "Item", "id": "a3" }]));

  // Memory budget guard check.
  assert!(check_budget(100, Some(200)).is_ok());
  let err = check_budget(201, Some(200)).unwrap_err();
  assert_eq!(err.0, axum::http::StatusCode::INSUFFICIENT_STORAGE);
}

#[tokio::test]
async fn read_stats_over_limit_and_aggregate_overflow_fallback() {
  // 10,001 tracked rows must report `overLimit: true` without `ids`.
  let owned_ids: Vec<String> = (0..10_001).map(|i| format!("row-{i:05}")).collect();
  let rows: Vec<(&str, Value)> = owned_ids.iter().map(|id| (id.as_str(), json!({"name": "n", "ratio": 1e308}))).collect();
  let snap = build_snapshot(HashMap::from([("alice", rows)]), HashMap::new());

  let page = query(
    &snap,
    QueryRequest {
      owner: "alice".into(),
      set: SetNode::Scan { r#type: "Item".into(), filter: None, candidates: false },
      output: Output::Page { offset: 0, limit: 2 },
      members: vec![MemberSpec { r#type: "Item".into(), track: true, markings: None }],
      rows: HashMap::new(),
      derived: HashMap::new(),
      projection: None,
      min_commit: None,
      wait_ms: None,
      scenario: None,
    },
    None,
  )
  .await
  .unwrap();
  assert_eq!(page["total"], json!(10_001));
  assert_eq!(page["reads"][0]["overLimit"], json!(true));
  assert!(page["reads"][0].get("ids").is_none());

  // Numeric aggregation overflow (sum of 10,001 * 1e308 -> +inf) must return 422 fallback so Reference throws Conflict.
  let err = query(
    &snap,
    QueryRequest {
      owner: "alice".into(),
      set: SetNode::Scan { r#type: "Item".into(), filter: None, candidates: false },
      output: Output::Aggregate {
        parts: vec![Part {
          r#type: "Item".into(),
          fields: vec![PartField { name: "ratio".into(), column: Some("ratio".into()), hidden: false, policy: None }],
        }],
        kinds: HashMap::from([("ratio".into(), Kind::Number)]),
        group_by: vec![],
        metrics: vec![Metric { name: "s".into(), op: "sum".into(), column: Some("ratio".into()) }],
      },
      members: vec![MemberSpec { r#type: "Item".into(), track: false, markings: None }],
      rows: HashMap::new(),
      derived: HashMap::new(),
      projection: None,
      min_commit: None,
      wait_ms: None,
      scenario: None,
    },
    None,
  )
  .await
  .unwrap_err();
  assert_eq!(err.0, axum::http::StatusCode::UNPROCESSABLE_ENTITY);
}
