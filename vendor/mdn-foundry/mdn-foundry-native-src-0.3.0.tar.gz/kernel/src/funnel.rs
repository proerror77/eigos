//! Commit-log ingestion (the Funnel): per-owner delta application, targeted compaction, and background polling.

use std::collections::HashSet;
use std::sync::atomic::Ordering;
use std::sync::Arc;
use std::time::Duration;

use serde_json::Value;
use tokio_postgres::IsolationLevel;

use crate::pg::{PgOpError, PgPool};
use crate::server::{AppState, Shared};
use crate::store::{compact_link_owner, compact_type_owner, max_bytes, OwnerLinkStore, OwnerTypeStore, Snapshot};
use crate::types::{internal, quote, stale, Failure};

/// One owner's commits after `applied`: the latest commit, and in commit order each object's stored value after an edit
/// (none when deleted) and each link change.
pub struct Commits {
  pub latest: i64,
  pub edits: Vec<(String, String, Option<String>)>,
  pub links: Vec<(String, String, String, String)>,
}

pub async fn read_commits(
  pool: &Arc<PgPool>,
  snapshot: &Snapshot,
  owner: &str,
  applied: i64,
) -> Result<Commits, Failure> {
  let req = snapshot.request.clone();
  let owner_owned = owner.to_string();
  pool
    .run(&snapshot.request.database, move |client| {
      let req = req.clone();
      let owner_owned = owner_owned.clone();
      Box::pin(async move {
        let schema = quote(&req.schema);
        let tx = client
          .build_transaction()
          .isolation_level(IsolationLevel::RepeatableRead)
          .read_only(true)
          .start()
          .await?;
        let owner_ref = owner_owned.as_str();
        // Owner isolation admits this owner's rows.
        tx.execute("SELECT set_config('eigos.owner', $1, true)", &[&owner_ref]).await?;
        let latest: i64 = tx
          .query_one(
            format!("SELECT coalesce(max(commit_seq), 0)::bigint FROM {schema}.change_commits WHERE owner=$1").as_str(),
            &[&owner_ref],
          )
          .await?
          .get(0);
        if latest <= applied {
          tx.commit().await?;
          return Ok(Commits { latest, edits: Vec::new(), links: Vec::new() });
        }
        let projection = &req.projection;
        let edits = tx
          .query(
            format!(
              "SELECT h.type, h.id, h.after_values::text FROM {schema}.change_commits c
               JOIN {schema}.edit_history h ON h.xact=c.xact AND h.owner=c.owner
               WHERE c.owner=$1 AND c.commit_seq>$2 AND c.commit_seq<=$3 AND h.projection::text=$4
               ORDER BY c.commit_seq, h.sequence"
            )
            .as_str(),
            &[&owner_ref, &applied, &latest, projection],
          )
          .await?
          .into_iter()
          .map(|row| (row.get(0), row.get(1), row.get(2)))
          .collect();
        let links = tx
          .query(
            format!(
              "SELECT l.type, l.from_id, l.to_id, l.operation FROM {schema}.change_commits c
               JOIN {schema}.link_history l ON l.xact=c.xact AND l.owner=c.owner
               WHERE c.owner=$1 AND c.commit_seq>$2 AND c.commit_seq<=$3 AND l.projection::text=$4
               ORDER BY c.commit_seq, l.sequence"
            )
            .as_str(),
            &[&owner_ref, &applied, &latest, projection],
          )
          .await?
          .into_iter()
          .map(|row| (row.get(0), row.get(1), row.get(2), row.get(3)))
          .collect();
        tx.commit().await?;
        Ok::<_, PgOpError>(Commits { latest, edits, links })
      })
    })
    .await
}

/// Applies ONE owner's commits after the last one applied, up to its latest committed one, as a new snapshot version.
/// Only the target owner's partitions and deltas are mutated, refreshed, or compacted.
/// When `needed` is `Some(n)` and the snapshot already includes commit `n`, returns immediately without querying PostgreSQL.
pub async fn catch_up(state: &AppState, owner: &str, needed: Option<i64>) -> Result<(), Failure> {
  let _writer = state.writer.lock().await;
  let Some(current) = state.snapshot.read().await.clone() else { return Ok(()) };
  let applied = current.position(owner);
  if needed.is_some_and(|n| applied >= n) { return Ok(()); }

  let commits = read_commits(&state.pool, &current, owner, applied).await?;
  if commits.latest <= applied { return Ok(()); }

  let mut next = (*current).clone();
  let (mut touched_types, mut touched_links) = (HashSet::new(), HashSet::new());

  for (kind, id, after) in commits.edits {
    let Some(store_arc) = next.types.get_mut(&kind) else { continue };
    let row = match after {
      Some(text) => Some(serde_json::from_str::<Value>(&text).map_err(internal)?),
      None => None,
    };
    let store = Arc::make_mut(store_arc);
    let empty = store.empty.clone();
    let owner_store = store.owners.entry(owner.to_string()).or_insert_with(|| OwnerTypeStore::empty(empty));
    Arc::make_mut(&mut owner_store.changed).insert(id, row);
    touched_types.insert(kind);
  }

  for (link, from, to, operation) in commits.links {
    let Some(store_arc) = next.edges.get_mut(&link) else { continue };
    let store = Arc::make_mut(store_arc);
    let empty = store.empty.clone();
    let owner_store = store.owners.entry(owner.to_string()).or_insert_with(|| OwnerLinkStore::empty(empty));
    Arc::make_mut(&mut owner_store.changed).insert((from, to), operation == "link");
    touched_links.insert(link);
  }

  let ranks = next.request.ranks.clone();
  for kind in &touched_types {
    let (old_bytes, new_bytes) = {
      let store = Arc::make_mut(next.types.get_mut(kind).unwrap());
      let def = store.def.clone();
      let schema = store.schema.clone();
      let owner_store = store.owners.get_mut(owner).unwrap();
      let old = owner_store.bytes();
      owner_store.refresh(&def, &schema, &ranks)?;
      (old, owner_store.bytes())
    };
    next.bytes = next.bytes.saturating_sub(old_bytes).saturating_add(new_bytes);
    compact_type_owner(&mut next, kind, owner, false).await?;
  }

  for link in &touched_links {
    let (old_bytes, new_bytes) = {
      let store = Arc::make_mut(next.edges.get_mut(link).unwrap());
      let owner_store = store.owners.get_mut(owner).unwrap();
      let old = owner_store.bytes();
      owner_store.refresh()?;
      (old, owner_store.bytes())
    };
    next.bytes = next.bytes.saturating_sub(old_bytes).saturating_add(new_bytes);
    compact_link_owner(&mut next, link, owner, false).await?;
  }

  if let Some(limit) = max_bytes() {
    if next.bytes > limit {
      // Reclaim memory by force-compacting touched owner partitions that have base rows to deduplicate,
      // and clearing cached Scenario overlays.
      for kind in &touched_types {
        if next.types.get(kind).and_then(|t| t.owners.get(owner)).is_some_and(|o| o.base_rows > 0) {
          compact_type_owner(&mut next, kind, owner, true).await?;
        }
      }
      for link in &touched_links {
        if next.edges.get(link).and_then(|l| l.owners.get(owner)).is_some_and(|o| o.base_rows > 0) {
          compact_link_owner(&mut next, link, owner, true).await?;
        }
      }
      state.overlays.lock().await.clear();
      if next.bytes > limit {
        state.metrics.over_budget.store(true, Ordering::Relaxed);
        return Err(stale("memory budget exceeded"));
      }
    }
    state.metrics.over_budget.store(false, Ordering::Relaxed);
  }

  next.applied.insert(owner.to_string(), commits.latest);
  *state.snapshot.write().await = Some(Arc::new(next));
  Ok(())
}

/// The latest commit of every owner that committed after `floor`.
pub async fn latest_commits(pool: &Arc<PgPool>, snapshot: &Snapshot, floor: i64) -> Result<Vec<(String, i64)>, Failure> {
  let req = snapshot.request.clone();
  pool
    .run(&snapshot.request.database, move |client| {
      let req = req.clone();
      Box::pin(async move {
        let schema = quote(&req.schema);
        let rows = client
          .query(
            format!("SELECT owner, max(commit_seq) FROM {schema}.change_commits WHERE commit_seq>$1 GROUP BY owner").as_str(),
            &[&floor],
          )
          .await?;
        Ok::<_, PgOpError>(rows.iter().map(|row| (row.get(0), row.get(1))).collect())
      })
    })
    .await
}

/// Keeps every owner's rows current between queries. Queries do not rely on it: each one first applies its owner's
/// commits up to the version it needs.
pub async fn follow(state: Shared, every: Duration) {
  let mut floor: Option<i64> = None;
  let mut seen_loads = 0usize;
  loop {
    tokio::time::sleep(every).await;
    let Some(snapshot) = state.snapshot.read().await.clone() else { continue };
    let loads = state.metrics.loads.load(Ordering::Relaxed);
    if loads != seen_loads {
      seen_loads = loads;
      floor = None;
    }
    let from = floor.unwrap_or_else(|| (snapshot.applied.values().copied().max().unwrap_or(0) - 1000).max(0));
    let Ok(found) = latest_commits(&state.pool, &snapshot, from).await else { continue };
    let mut highest = from;
    for (owner, latest) in found {
      highest = highest.max(latest);
      if latest > snapshot.position(&owner) {
        let _ = catch_up(&state, &owner, Some(latest)).await;
      }
    }
    // Commits of different owners can become visible out of number order, so the next poll looks back over a margin.
    floor = Some((highest - 1000).max(0));
  }
}
