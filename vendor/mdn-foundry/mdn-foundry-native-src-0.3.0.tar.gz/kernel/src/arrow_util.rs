//! Arrow array/batch builders, direct typed extraction (without JSON round-tripping), and hashing/comparison helpers.

use std::cmp::Ordering;
use std::collections::{BTreeSet, HashMap};
use std::fmt::Write as _;
use std::sync::Arc;

use datafusion::arrow::array::{
  Array, ArrayRef, AsArray, BooleanBuilder, Float64Builder, Int64Builder, ListBuilder, RecordBatch, StringBuilder,
};
use datafusion::arrow::datatypes::{
  DataType, Float32Type, Float64Type, Int16Type, Int32Type, Int64Type, Int8Type, SchemaRef, UInt16Type, UInt32Type,
  UInt64Type, UInt8Type,
};
use datafusion::datasource::MemTable;
use serde_json::{Map, Number, Value};

use crate::types::{internal, partitions, ref_key, Failure, Kind, TypeDef};

/// Spreads batches over the given number of partitions so scans run in parallel without empty-partition overhead.
pub fn spread(batches: Vec<RecordBatch>, parts: usize) -> Vec<Vec<RecordBatch>> {
  let count = parts.max(1);
  let mut out = vec![Vec::new(); count];
  for (i, batch) in batches.into_iter().enumerate() { out[i % count].push(batch); }
  out
}

/// A table of string columns (single partition).
pub fn strings_table(schema: SchemaRef, columns: Vec<StringBuilder>) -> Result<(Arc<MemTable>, usize), Failure> {
  let arrays = columns.into_iter().map(|mut b| Arc::new(b.finish()) as ArrayRef).collect();
  let batch = RecordBatch::try_new(schema.clone(), arrays).map_err(internal)?;
  let bytes = batch.get_array_memory_size();
  Ok((Arc::new(MemTable::try_new(schema, vec![vec![batch]]).map_err(internal)?), bytes))
}

/// An empty MemTable of a schema.
pub fn empty_table(schema: SchemaRef) -> Result<Arc<MemTable>, Failure> {
  let batch = RecordBatch::new_empty(schema.clone());
  Ok(Arc::new(MemTable::try_new(schema, vec![vec![batch]]).map_err(internal)?))
}

/// A table over batches, which may be empty. Uses at most `min(batches.len(), partitions())` partitions.
pub fn table_of(schema: SchemaRef, mut batches: Vec<RecordBatch>) -> Result<Arc<MemTable>, Failure> {
  if batches.is_empty() {
    batches.push(RecordBatch::new_empty(schema.clone()));
    return Ok(Arc::new(MemTable::try_new(schema, vec![batches]).map_err(internal)?));
  }
  let parts = batches.len().min(partitions()).max(1);
  Ok(Arc::new(MemTable::try_new(schema, spread(batches, parts)).map_err(internal)?))
}

/// Columnar builder for one owner's rows of an object type.
enum ValueBuilder {
  String(StringBuilder),
  Integer(Int64Builder),
  Number(Float64Builder),
  Boolean(BooleanBuilder),
  Strings(ListBuilder<StringBuilder>),
}

pub struct ObjectBuilder {
  id: StringBuilder,
  key: StringBuilder,
  values: Vec<ValueBuilder>,
  label: Option<(Int64Builder, ListBuilder<StringBuilder>)>,
  pub len: usize,
}

impl ObjectBuilder {
  pub fn new(def: &TypeDef) -> Self {
    let values = def.columns.iter().map(|c| match c.kind {
      Kind::String => ValueBuilder::String(StringBuilder::new()),
      Kind::Integer => ValueBuilder::Integer(Int64Builder::new()),
      Kind::Number => ValueBuilder::Number(Float64Builder::new()),
      Kind::Boolean => ValueBuilder::Boolean(BooleanBuilder::new()),
      Kind::Strings => ValueBuilder::Strings(ListBuilder::new(StringBuilder::new())),
    }).collect();
    Self {
      id: StringBuilder::new(),
      key: StringBuilder::new(),
      values,
      label: def.classification.is_some().then(|| (Int64Builder::new(), ListBuilder::new(StringBuilder::new()))),
      len: 0,
    }
  }

  pub fn push(&mut self, def: &TypeDef, id: &str, properties: &Value, ranks: &HashMap<String, i64>) {
    self.id.append_value(id);
    self.key.append_value(ref_key(&def.name, id));
    for (builder, c) in self.values.iter_mut().zip(&def.columns) {
      let value = properties.get(&c.name);
      // The published schema validated stored values, so a value of another kind cannot occur; it reads as null.
      match builder {
        ValueBuilder::String(b) => b.append_option(value.and_then(Value::as_str)),
        ValueBuilder::Integer(b) => b.append_option(value.and_then(Value::as_i64)),
        ValueBuilder::Number(b) => b.append_option(value.and_then(Value::as_f64)),
        ValueBuilder::Boolean(b) => b.append_option(value.and_then(Value::as_bool)),
        ValueBuilder::Strings(b) => match value.and_then(Value::as_array) {
          Some(items) => {
            for item in items { b.values().append_option(item.as_str()); }
            b.append(true);
          }
          None => b.append(false),
        },
      }
    }
    if let (Some((rank, compartments)), Some(name)) = (self.label.as_mut(), def.classification.as_deref()) {
      // A row classification is `{sensitivity, compartments}`; a missing one adds nothing to the observed label.
      let label = properties.get(name).filter(|v| !v.is_null());
      rank.append_option(label.and_then(|l| l.get("sensitivity")).and_then(Value::as_str).and_then(|s| ranks.get(s).copied()));
      match label {
        Some(l) => {
          if let Some(items) = l.get("compartments").and_then(Value::as_array) {
            for tag in items.iter().filter_map(Value::as_str) { compartments.values().append_value(tag); }
          }
          compartments.append(true);
        }
        None => compartments.append(false),
      }
    }
    self.len += 1;
  }

  pub fn finish(mut self, schema: SchemaRef) -> Result<RecordBatch, Failure> {
    let mut arrays: Vec<ArrayRef> = vec![Arc::new(self.id.finish()), Arc::new(self.key.finish())];
    for builder in self.values.iter_mut() {
      arrays.push(match builder {
        ValueBuilder::String(b) => Arc::new(b.finish()),
        ValueBuilder::Integer(b) => Arc::new(b.finish()),
        ValueBuilder::Number(b) => Arc::new(b.finish()),
        ValueBuilder::Boolean(b) => Arc::new(b.finish()),
        ValueBuilder::Strings(b) => Arc::new(b.finish()),
      });
    }
    if let Some((rank, compartments)) = self.label.as_mut() {
      arrays.push(Arc::new(rank.finish()));
      arrays.push(Arc::new(compartments.finish()));
    }
    RecordBatch::try_new(schema, arrays).map_err(internal)
  }
}

/// FNV-1a 64-bit hash: stable across processes and builds.
pub fn fnv1a(text: &str) -> u64 {
  let mut hash = 0xcbf2_9ce4_8422_2325u64;
  for byte in text.bytes() {
    hash ^= byte as u64;
    hash = hash.wrapping_mul(0x0000_0100_0000_01b3);
  }
  hash
}

/// Compares two finite or non-finite floats identically to Arrow Float64 ordering, normalizing -0.0 to 0.0.
pub fn cmp_f64(a: f64, b: f64) -> Ordering {
  let a = if a == 0.0 { 0.0 } else { a };
  let b = if b == 0.0 { 0.0 } else { b };
  a.total_cmp(&b)
}

/// Reads an optional `&str` from any Arrow string array (`Utf8`, `LargeUtf8`, `Utf8View`).
pub fn str_at(array: &dyn Array, row: usize) -> Result<Option<&str>, Failure> {
  if array.is_null(row) { return Ok(None); }
  match array.data_type() {
    DataType::Utf8 => Ok(Some(array.as_string::<i32>().value(row))),
    DataType::LargeUtf8 => Ok(Some(array.as_string::<i64>().value(row))),
    DataType::Utf8View => Ok(Some(array.as_string_view().value(row))),
    other => Err(internal(format!("Expected string array, got {other:?}"))),
  }
}

/// Reads a required `&str` from any Arrow string array (`Utf8`, `LargeUtf8`, `Utf8View`).
pub fn req_str_at(array: &dyn Array, row: usize) -> Result<&str, Failure> {
  str_at(array, row)?.ok_or_else(|| internal("Unexpected null in non-null string column"))
}

/// Reads an optional `i64` from any Arrow signed integer array.
pub fn i64_at(array: &dyn Array, row: usize) -> Result<Option<i64>, Failure> {
  if array.is_null(row) { return Ok(None); }
  match array.data_type() {
    DataType::Int64 => Ok(Some(array.as_primitive::<Int64Type>().value(row))),
    DataType::Int32 => Ok(Some(array.as_primitive::<Int32Type>().value(row) as i64)),
    DataType::Int16 => Ok(Some(array.as_primitive::<Int16Type>().value(row) as i64)),
    DataType::Int8 => Ok(Some(array.as_primitive::<Int8Type>().value(row) as i64)),
    DataType::UInt64 => Ok(Some(array.as_primitive::<UInt64Type>().value(row) as i64)),
    DataType::UInt32 => Ok(Some(array.as_primitive::<UInt32Type>().value(row) as i64)),
    other => Err(internal(format!("Expected integer array, got {other:?}"))),
  }
}

/// Reads an optional `f64` from an Arrow float or integer array.
pub fn f64_at(array: &dyn Array, row: usize) -> Result<Option<f64>, Failure> {
  if array.is_null(row) { return Ok(None); }
  match array.data_type() {
    DataType::Float64 => Ok(Some(array.as_primitive::<Float64Type>().value(row))),
    DataType::Float32 => Ok(Some(array.as_primitive::<Float32Type>().value(row) as f64)),
    DataType::Int64 => Ok(Some(array.as_primitive::<Int64Type>().value(row) as f64)),
    DataType::Int32 => Ok(Some(array.as_primitive::<Int32Type>().value(row) as f64)),
    other => Err(internal(format!("Expected numeric array, got {other:?}"))),
  }
}

/// Reads an optional `bool` from a `BooleanArray`.
pub fn bool_at(array: &dyn Array, row: usize) -> Result<Option<bool>, Failure> {
  if array.is_null(row) { return Ok(None); }
  match array.data_type() {
    DataType::Boolean => Ok(Some(array.as_boolean().value(row))),
    other => Err(internal(format!("Expected boolean array, got {other:?}"))),
  }
}

/// Collects all non-null strings from a `List<Utf8>` / `LargeList<Utf8>` cell into `out`.
pub fn collect_string_list_cell(array: &dyn Array, row: usize, out: &mut BTreeSet<String>) -> Result<(), Failure> {
  if array.is_null(row) { return Ok(()); }
  let values: ArrayRef = match array.data_type() {
    DataType::List(_) => array.as_list::<i32>().value(row),
    DataType::LargeList(_) => array.as_list::<i64>().value(row),
    other => return Err(internal(format!("Expected string list array, got {other:?}"))),
  };
  for i in 0..values.len() {
    if let Some(s) = str_at(values.as_ref(), i)? {
      if !out.contains(s) { out.insert(s.to_owned()); }
    }
  }
  Ok(())
}

/// Appends a deterministic string representation of an order-key cell to `buf` for membership digesting.
pub fn append_order_digest(buf: &mut String, array: &dyn Array, row: usize, kind: Kind) -> Result<(), Failure> {
  if array.is_null(row) {
    buf.push('\u{1}');
    return Ok(());
  }
  match kind {
    Kind::String => {
      if let Some(s) = str_at(array, row)? { buf.push_str(s); }
    }
    Kind::Integer => {
      if let Some(v) = i64_at(array, row)? { let _ = write!(buf, "{v}"); }
    }
    Kind::Number => {
      if let Some(v) = f64_at(array, row)? {
        let v = if v == 0.0 { 0.0 } else { v };
        let _ = write!(buf, "{v}");
      }
    }
    Kind::Boolean => {
      if let Some(b) = bool_at(array, row)? { buf.push_str(if b { "true" } else { "false" }); }
    }
    Kind::Strings => return Err(internal("Cannot digest string list as order key")),
  }
  Ok(())
}

/// Directly converts a single Arrow cell at `row` into a `serde_json::Value` without JSON text round-tripping.
pub fn array_value_to_json(array: &dyn Array, row: usize) -> Result<Value, Failure> {
  if array.is_null(row) { return Ok(Value::Null); }
  match array.data_type() {
    DataType::Null => Ok(Value::Null),
    DataType::Boolean => Ok(Value::Bool(array.as_boolean().value(row))),
    DataType::Int8 => Ok(Value::Number(Number::from(array.as_primitive::<Int8Type>().value(row)))),
    DataType::Int16 => Ok(Value::Number(Number::from(array.as_primitive::<Int16Type>().value(row)))),
    DataType::Int32 => Ok(Value::Number(Number::from(array.as_primitive::<Int32Type>().value(row)))),
    DataType::Int64 => Ok(Value::Number(Number::from(array.as_primitive::<Int64Type>().value(row)))),
    DataType::UInt8 => Ok(Value::Number(Number::from(array.as_primitive::<UInt8Type>().value(row)))),
    DataType::UInt16 => Ok(Value::Number(Number::from(array.as_primitive::<UInt16Type>().value(row)))),
    DataType::UInt32 => Ok(Value::Number(Number::from(array.as_primitive::<UInt32Type>().value(row)))),
    DataType::UInt64 => Ok(Value::Number(Number::from(array.as_primitive::<UInt64Type>().value(row)))),
    DataType::Float32 => {
      let v = array.as_primitive::<Float32Type>().value(row) as f64;
      let v = if v == 0.0 { 0.0 } else { v };
      Ok(Number::from_f64(v).map(Value::Number).unwrap_or(Value::Null))
    }
    DataType::Float64 => {
      let v = array.as_primitive::<Float64Type>().value(row);
      let v = if v == 0.0 { 0.0 } else { v };
      Ok(Number::from_f64(v).map(Value::Number).unwrap_or(Value::Null))
    }
    DataType::Utf8 => Ok(Value::String(array.as_string::<i32>().value(row).to_owned())),
    DataType::LargeUtf8 => Ok(Value::String(array.as_string::<i64>().value(row).to_owned())),
    DataType::Utf8View => Ok(Value::String(array.as_string_view().value(row).to_owned())),
    DataType::List(_) => {
      let values = array.as_list::<i32>().value(row);
      let mut items = Vec::with_capacity(values.len());
      for i in 0..values.len() { items.push(array_value_to_json(values.as_ref(), i)?); }
      Ok(Value::Array(items))
    }
    DataType::LargeList(_) => {
      let values = array.as_list::<i64>().value(row);
      let mut items = Vec::with_capacity(values.len());
      for i in 0..values.len() { items.push(array_value_to_json(values.as_ref(), i)?); }
      Ok(Value::Array(items))
    }
    other => Err(internal(format!("Unsupported Arrow data type for JSON conversion: {other:?}"))),
  }
}

/// Converts Arrow `RecordBatch` slices directly into JSON object rows without `ArrayWriter` + `serde_json::from_slice`.
#[allow(dead_code)]
pub fn batches_to_json_rows(batches: &[RecordBatch]) -> Result<Vec<Value>, Failure> {
  let total_rows: usize = batches.iter().map(RecordBatch::num_rows).sum();
  let mut out = Vec::with_capacity(total_rows);
  for batch in batches {
    let schema = batch.schema();
    let fields = schema.fields();
    let cols = batch.columns();
    for row in 0..batch.num_rows() {
      let mut map = Map::with_capacity(fields.len());
      for (field, col) in fields.iter().zip(cols.iter()) {
        map.insert(field.name().clone(), array_value_to_json(col.as_ref(), row)?);
      }
      out.push(Value::Object(map));
    }
  }
  Ok(out)
}
