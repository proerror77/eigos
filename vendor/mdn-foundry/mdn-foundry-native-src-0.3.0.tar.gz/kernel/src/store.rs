//! Owner-partitioned in-memory storage, initial projection loading, per-owner compaction, and memory budget enforcement.

use std::collections::{BTreeMap, HashMap, HashSet};
use std::sync::Arc;

use datafusion::arrow::array::{ArrayRef, RecordBatch, StringBuilder};
use datafusion::arrow::datatypes::SchemaRef;
use datafusion::datasource::MemTable;
use datafusion::logical_expr::JoinType;
use datafusion::prelude::{DataFrame, SessionConfig, SessionContext};
use futures_util::{pin_mut, TryStreamExt};
use serde_json::Value;
use tokio_postgres::IsolationLevel;

use crate::arrow_util::{empty_table, strings_table, table_of, ObjectBuilder};
use crate::pg::{PgOpError, PgPool};
use crate::types::{
  edge_schema, internal, invalid, object_schema, over_budget, partitions, quote, strings_schema, Failure, Kind,
  LoadRequest, TypeDef, BATCH,
};

/// Estimated heap overhead per `changed` entry (BTreeMap node + key + optional JSON value).
const CHANGED_ENTRY_OVERHEAD: usize = 96;

/// Changed rows past which an owner's changes for a type or link are folded into its base rows:
/// at least this many, or a sixteenth of that owner's base rows. `EIGOS_KERNEL_COMPACT` overrides it.
pub fn compact_limit() -> usize {
  std::env::var("EIGOS_KERNEL_COMPACT").ok().and_then(|v| v.parse().ok()).unwrap_or(4096)
}

/// Optional memory budget in bytes from `EIGOS_KERNEL_MAX_BYTES`.
pub fn max_bytes() -> Option<usize> {
  std::env::var("EIGOS_KERNEL_MAX_BYTES")
    .ok()
    .and_then(|v| v.parse::<usize>().ok())
    .filter(|&v| v > 0)
}

/// One owner's rows of one object type: base batches plus incremental changes since last load/compaction.
#[derive(Clone)]
pub struct OwnerTypeStore {
  pub base: Arc<MemTable>,
  pub base_rows: usize,
  pub base_bytes: usize,
  /// Changed rows since last compaction, keyed by object `$id`; `None` represents a deletion.
  pub changed: Arc<BTreeMap<String, Option<Value>>>,
  /// The changed keys (`$cid`) and the changed rows that currently exist; `None` while `changed` is empty.
  pub overlay: Option<(Arc<MemTable>, Arc<MemTable>)>,
  pub overlay_bytes: usize,
}

impl OwnerTypeStore {
  pub fn empty(empty_base: Arc<MemTable>) -> Self {
    Self { base: empty_base, base_rows: 0, base_bytes: 0, changed: Arc::default(), overlay: None, overlay_bytes: 0 }
  }

  pub fn bytes(&self) -> usize { self.base_bytes.saturating_add(self.overlay_bytes) }

  /// Rebuilds ONLY this owner's overlay tables from its `changed` delta map.
  pub fn refresh(&mut self, def: &TypeDef, schema: &SchemaRef, ranks: &HashMap<String, i64>) -> Result<(), Failure> {
    if self.changed.is_empty() {
      self.overlay = None;
      self.overlay_bytes = 0;
      return Ok(());
    }
    let mut ids = StringBuilder::new();
    let mut builder = ObjectBuilder::new(def);
    for (id, row) in self.changed.iter() {
      ids.append_value(id);
      if let Some(properties) = row { builder.push(def, id, properties, ranks); }
    }
    let live = builder.finish(schema.clone())?;
    let live_bytes = live.get_array_memory_size();
    let (keys_table, keys_bytes) = strings_table(strings_schema(&["$cid"]), vec![ids])?;
    let live_table = Arc::new(MemTable::try_new(schema.clone(), vec![vec![live]]).map_err(internal)?);
    self.overlay = Some((keys_table, live_table));
    self.overlay_bytes = keys_bytes
      .saturating_add(live_bytes)
      .saturating_add(self.changed.len().saturating_mul(CHANGED_ENTRY_OVERHEAD));
    Ok(())
  }
}

/// One type's rows partitioned strictly by owner.
#[derive(Clone)]
pub struct TypeStore {
  pub def: Arc<TypeDef>,
  pub schema: SchemaRef,
  pub empty: Arc<MemTable>,
  pub owners: HashMap<String, OwnerTypeStore>,
}

/// One owner's edges of one link type.
#[derive(Clone)]
pub struct OwnerLinkStore {
  pub base: Arc<MemTable>,
  pub base_rows: usize,
  pub base_bytes: usize,
  /// Changed edges `(from_id, to_id)` -> `true` (linked) or `false` (unlinked).
  pub changed: Arc<BTreeMap<(String, String), bool>>,
  /// Changed keys (`$cfrom`, `$cto`) and live changed edges (`from_id`, `to_id`).
  pub overlay: Option<(Arc<MemTable>, Arc<MemTable>)>,
  pub overlay_bytes: usize,
}

impl OwnerLinkStore {
  pub fn empty(empty_base: Arc<MemTable>) -> Self {
    Self { base: empty_base, base_rows: 0, base_bytes: 0, changed: Arc::default(), overlay: None, overlay_bytes: 0 }
  }

  pub fn bytes(&self) -> usize { self.base_bytes.saturating_add(self.overlay_bytes) }

  /// Rebuilds ONLY this owner's link overlay tables from its `changed` delta map.
  pub fn refresh(&mut self) -> Result<(), Failure> {
    if self.changed.is_empty() {
      self.overlay = None;
      self.overlay_bytes = 0;
      return Ok(());
    }
    let (mut froms, mut tos) = (StringBuilder::new(), StringBuilder::new());
    let (mut live_froms, mut live_tos) = (StringBuilder::new(), StringBuilder::new());
    for ((from, to), present) in self.changed.iter() {
      froms.append_value(from);
      tos.append_value(to);
      if *present {
        live_froms.append_value(from);
        live_tos.append_value(to);
      }
    }
    let (keys_table, keys_bytes) = strings_table(strings_schema(&["$cfrom", "$cto"]), vec![froms, tos])?;
    let (live_table, live_bytes) = strings_table(edge_schema(), vec![live_froms, live_tos])?;
    self.overlay = Some((keys_table, live_table));
    self.overlay_bytes = keys_bytes
      .saturating_add(live_bytes)
      .saturating_add(self.changed.len().saturating_mul(CHANGED_ENTRY_OVERHEAD));
    Ok(())
  }
}

/// One link's edges partitioned strictly by owner.
#[derive(Clone)]
pub struct LinkStore {
  pub empty: Arc<MemTable>,
  pub owners: HashMap<String, OwnerLinkStore>,
}

/// One immutable version of a loaded projection.
/// Applying commits clones only the touched type/link `Arc`s and the single touched owner's delta map.
#[derive(Clone)]
pub struct Snapshot {
  pub ctx: SessionContext,
  pub request: Arc<LoadRequest>,
  pub kinds: HashMap<String, HashMap<String, Kind>>,
  pub classified: HashSet<String>,
  pub links: Vec<String>,
  pub types: HashMap<String, Arc<TypeStore>>,
  pub edges: HashMap<String, Arc<LinkStore>>,
  /// The last commit applied for each owner: the rows reflect it and every earlier commit of that owner.
  pub applied: HashMap<String, i64>,
  pub objects: usize,
  pub edge_count: usize,
  pub bytes: usize,
}

impl Snapshot {
  /// Returns ONE owner's current rows of `kind`, directly addressing that owner's partition with zero cross-tenant scanning.
  pub fn object_rows_for(&self, kind: &str, owner: &str) -> Result<DataFrame, Failure> {
    let store = self.types.get(kind).ok_or_else(|| invalid(format!("Type {kind} is not loaded")))?;
    let Some(owner_store) = store.owners.get(owner) else {
      return self.ctx.read_table(store.empty.clone()).map_err(internal);
    };
    if owner_store.base_rows == 0 {
      return match &owner_store.overlay {
        Some((_, live)) => self.ctx.read_table(live.clone()).map_err(internal),
        None => self.ctx.read_table(store.empty.clone()).map_err(internal),
      };
    }
    let mut frame = self.ctx.read_table(owner_store.base.clone()).map_err(internal)?;
    if let Some((keys, live)) = &owner_store.overlay {
      frame = frame
        .join(self.ctx.read_table(keys.clone()).map_err(internal)?, JoinType::LeftAnti, &["$id"], &["$cid"], None)
        .map_err(internal)?
        .union(self.ctx.read_table(live.clone()).map_err(internal)?)
        .map_err(internal)?;
    }
    Ok(frame)
  }

  /// Returns ONE owner's current edges of `link`, directly addressing that owner's partition with zero cross-tenant scanning.
  pub fn edge_rows_for(&self, link: &str, owner: &str) -> Result<DataFrame, Failure> {
    let store = self.edges.get(link).ok_or_else(|| invalid(format!("Link {link} is not loaded")))?;
    let Some(owner_store) = store.owners.get(owner) else {
      return self.ctx.read_table(store.empty.clone()).map_err(internal);
    };
    if owner_store.base_rows == 0 {
      return match &owner_store.overlay {
        Some((_, live)) => self.ctx.read_table(live.clone()).map_err(internal),
        None => self.ctx.read_table(store.empty.clone()).map_err(internal),
      };
    }
    let mut frame = self.ctx.read_table(owner_store.base.clone()).map_err(internal)?;
    if let Some((keys, live)) = &owner_store.overlay {
      frame = frame
        .join(
          self.ctx.read_table(keys.clone()).map_err(internal)?,
          JoinType::LeftAnti,
          &["from_id", "to_id"],
          &["$cfrom", "$cto"],
          None,
        )
        .map_err(internal)?
        .union(self.ctx.read_table(live.clone()).map_err(internal)?)
        .map_err(internal)?;
    }
    Ok(frame)
  }

  pub fn position(&self, owner: &str) -> i64 { self.applied.get(owner).copied().unwrap_or(0) }

  /// Total number of distinct owner partitions holding data in this snapshot.
  pub fn owner_count(&self) -> usize {
    let mut owners: HashSet<&str> = HashSet::new();
    for store in self.types.values() {
      for owner in store.owners.keys() { owners.insert(owner.as_str()); }
    }
    for store in self.edges.values() {
      for owner in store.owners.keys() { owners.insert(owner.as_str()); }
    }
    owners.len()
  }

  /// Total number of uncompacted delta entries across all owner partitions.
  pub fn changed_count(&self) -> usize {
    let type_changes: usize = self.types.values().flat_map(|t| t.owners.values()).map(|o| o.changed.len()).sum();
    let link_changes: usize = self.edges.values().flat_map(|l| l.owners.values()).map(|o| o.changed.len()).sum();
    type_changes + link_changes
  }
}

/// Folds ONLY ONE owner's changed rows for `kind` into that owner's base rows once they pass the threshold (or `force` is set).
pub async fn compact_type_owner(snapshot: &mut Snapshot, kind: &str, owner: &str, force: bool) -> Result<(), Failure> {
  let Some(store) = snapshot.types.get(kind) else { return Ok(()) };
  let Some(owner_store) = store.owners.get(owner) else { return Ok(()) };
  if owner_store.changed.is_empty() { return Ok(()); }
  if !force && owner_store.changed.len() <= compact_limit().max(owner_store.base_rows / 16) { return Ok(()); }

  let old_bytes = owner_store.bytes();
  let old_rows = owner_store.base_rows;
  let schema = store.schema.clone();
  let batches: Vec<RecordBatch> = snapshot
    .object_rows_for(kind, owner)?
    .collect()
    .await
    .map_err(internal)?
    .into_iter()
    .filter(|b| b.num_rows() > 0)
    .collect();
  let new_rows: usize = batches.iter().map(RecordBatch::num_rows).sum();
  let new_bytes: usize = batches.iter().map(RecordBatch::get_array_memory_size).sum();

  let store_mut = Arc::make_mut(snapshot.types.get_mut(kind).unwrap());
  if new_rows == 0 {
    store_mut.owners.remove(owner);
  } else {
    let entry = store_mut.owners.get_mut(owner).unwrap();
    entry.base = table_of(schema, batches)?;
    entry.base_rows = new_rows;
    entry.base_bytes = new_bytes;
    entry.changed = Arc::default();
    entry.overlay = None;
    entry.overlay_bytes = 0;
  }
  snapshot.objects = snapshot.objects.saturating_sub(old_rows).saturating_add(new_rows);
  snapshot.bytes = snapshot.bytes.saturating_sub(old_bytes).saturating_add(new_bytes);
  Ok(())
}

/// Folds ONLY ONE owner's changed edges for `link` into that owner's base edges once they pass the threshold (or `force` is set).
pub async fn compact_link_owner(snapshot: &mut Snapshot, link: &str, owner: &str, force: bool) -> Result<(), Failure> {
  let Some(store) = snapshot.edges.get(link) else { return Ok(()) };
  let Some(owner_store) = store.owners.get(owner) else { return Ok(()) };
  if owner_store.changed.is_empty() { return Ok(()); }
  if !force && owner_store.changed.len() <= compact_limit().max(owner_store.base_rows / 16) { return Ok(()); }

  let old_bytes = owner_store.bytes();
  let old_rows = owner_store.base_rows;
  let batches: Vec<RecordBatch> = snapshot
    .edge_rows_for(link, owner)?
    .collect()
    .await
    .map_err(internal)?
    .into_iter()
    .filter(|b| b.num_rows() > 0)
    .collect();
  let new_rows: usize = batches.iter().map(RecordBatch::num_rows).sum();
  let new_bytes: usize = batches.iter().map(RecordBatch::get_array_memory_size).sum();

  let store_mut = Arc::make_mut(snapshot.edges.get_mut(link).unwrap());
  if new_rows == 0 {
    store_mut.owners.remove(owner);
  } else {
    let entry = store_mut.owners.get_mut(owner).unwrap();
    entry.base = table_of(edge_schema(), batches)?;
    entry.base_rows = new_rows;
    entry.base_bytes = new_bytes;
    entry.changed = Arc::default();
    entry.overlay = None;
    entry.overlay_bytes = 0;
  }
  snapshot.edge_count = snapshot.edge_count.saturating_sub(old_rows).saturating_add(new_rows);
  snapshot.bytes = snapshot.bytes.saturating_sub(old_bytes).saturating_add(new_bytes);
  Ok(())
}

/// Checks memory budget during loading/restoring and aborts early before OOM.
pub fn check_budget(bytes: usize, limit: Option<usize>) -> Result<(), Failure> {
  if let Some(max) = limit {
    if bytes > max {
      return Err(over_budget(&format!("projection size {bytes} bytes exceeds EIGOS_KERNEL_MAX_BYTES ({max})")));
    }
  }
  Ok(())
}

/// Loads a projection and its commit positions from one RepeatableRead snapshot of PostgreSQL,
/// bucketing rows directly into per-owner partitions.
pub async fn load(pool: &Arc<PgPool>, request: LoadRequest) -> Result<Snapshot, Failure> {
  let budget = max_bytes();
  let request = Arc::new(request);
  let req = request.clone();
  pool
    .run(&request.database, move |client| {
      let req = req.clone();
      Box::pin(async move {
        let tx = client
          .build_transaction()
          .isolation_level(IsolationLevel::RepeatableRead)
          .read_only(true)
          .start()
          .await?;
        let parts = partitions();
        let ctx = SessionContext::new_with_config(SessionConfig::new().with_target_partitions(parts));
        let schema = quote(&req.schema);
        let (mut kinds, mut classified, mut types) = (HashMap::new(), HashSet::new(), HashMap::new());
        let (mut objects, mut edge_count, mut bytes) = (0usize, 0usize, 0usize);

        for def in &req.types {
          let table = object_schema(def);
          let sql = format!("SELECT owner, id, properties::text FROM {schema}.objects WHERE projection::text=$1 AND type=$2");
          let params: Vec<&(dyn tokio_postgres::types::ToSql + Sync)> = vec![&req.projection, &def.name];
          let rows = tx.query_raw(sql.as_str(), params).await?;
          pin_mut!(rows);
          let mut by_owner: HashMap<String, (ObjectBuilder, Vec<RecordBatch>, usize, usize)> = HashMap::new();
          while let Some(row) = rows.try_next().await? {
            let owner: &str = row.get(0);
            let id: &str = row.get(1);
            let properties: Value = serde_json::from_str(row.get::<_, &str>(2)).map_err(internal)?;
            let entry = by_owner.entry(owner.to_string()).or_insert_with(|| (ObjectBuilder::new(def), Vec::new(), 0, 0));
            entry.0.push(def, id, &properties, &req.ranks);
            objects += 1;
            if entry.0.len == BATCH {
              let batch = std::mem::replace(&mut entry.0, ObjectBuilder::new(def)).finish(table.clone())?;
              let batch_bytes = batch.get_array_memory_size();
              let batch_rows = batch.num_rows();
              bytes = bytes.saturating_add(batch_bytes);
              check_budget(bytes, budget)?;
              entry.2 += batch_rows;
              entry.3 += batch_bytes;
              entry.1.push(batch);
            }
          }
          let mut owner_stores = HashMap::with_capacity(by_owner.len());
          for (owner, (builder, mut batches, mut base_rows, mut base_bytes)) in by_owner {
            if builder.len > 0 {
              let batch = builder.finish(table.clone())?;
              let batch_bytes = batch.get_array_memory_size();
              let batch_rows = batch.num_rows();
              bytes = bytes.saturating_add(batch_bytes);
              check_budget(bytes, budget)?;
              base_rows += batch_rows;
              base_bytes += batch_bytes;
              batches.push(batch);
            }
            if base_rows > 0 {
              owner_stores.insert(owner, OwnerTypeStore {
                base: table_of(table.clone(), batches)?,
                base_rows,
                base_bytes,
                changed: Arc::default(),
                overlay: None,
                overlay_bytes: 0,
              });
            }
          }
          if def.classification.is_some() { classified.insert(def.name.clone()); }
          kinds.insert(def.name.clone(), def.columns.iter().map(|c| (c.name.clone(), c.kind)).collect());
          types.insert(
            def.name.clone(),
            Arc::new(TypeStore {
              def: Arc::new(def.clone()),
              empty: empty_table(table.clone())?,
              schema: table,
              owners: owner_stores,
            }),
          );
        }

        let e_schema = edge_schema();
        let mut by_link: HashMap<String, HashMap<String, (StringBuilder, StringBuilder, Vec<RecordBatch>, usize, usize, usize)>> =
          HashMap::new();
        for link in &req.links { by_link.insert(link.clone(), HashMap::new()); }
        let sql = format!("SELECT owner, type, from_id, to_id FROM {schema}.links WHERE projection::text=$1");
        let params: Vec<&(dyn tokio_postgres::types::ToSql + Sync)> = vec![&req.projection];
        let rows = tx.query_raw(sql.as_str(), params).await?;
        pin_mut!(rows);
        while let Some(row) = rows.try_next().await? {
          let link: &str = row.get(1);
          let Some(link_owners) = by_link.get_mut(link) else { continue };
          let owner: &str = row.get(0);
          let entry = link_owners
            .entry(owner.to_string())
            .or_insert_with(|| (StringBuilder::new(), StringBuilder::new(), Vec::new(), 0, 0, 0));
          entry.0.append_value(row.get::<_, &str>(2));
          entry.1.append_value(row.get::<_, &str>(3));
          entry.3 += 1;
          edge_count += 1;
          if entry.3 == BATCH {
            let batch = RecordBatch::try_new(
              e_schema.clone(),
              vec![Arc::new(entry.0.finish()) as ArrayRef, Arc::new(entry.1.finish())],
            )
            .map_err(internal)?;
            let batch_bytes = batch.get_array_memory_size();
            let batch_rows = batch.num_rows();
            bytes = bytes.saturating_add(batch_bytes);
            check_budget(bytes, budget)?;
            entry.4 += batch_rows;
            entry.5 += batch_bytes;
            entry.2.push(batch);
            entry.3 = 0;
          }
        }
        let mut edges = HashMap::with_capacity(by_link.len());
        for (link, link_owners) in by_link {
          let mut owner_stores = HashMap::with_capacity(link_owners.len());
          for (owner, (mut froms, mut tos, mut batches, pending, mut base_rows, mut base_bytes)) in link_owners {
            if pending > 0 {
              let batch = RecordBatch::try_new(
                e_schema.clone(),
                vec![Arc::new(froms.finish()) as ArrayRef, Arc::new(tos.finish())],
              )
              .map_err(internal)?;
              let batch_bytes = batch.get_array_memory_size();
              let batch_rows = batch.num_rows();
              bytes = bytes.saturating_add(batch_bytes);
              check_budget(bytes, budget)?;
              base_rows += batch_rows;
              base_bytes += batch_bytes;
              batches.push(batch);
            }
            if base_rows > 0 {
              owner_stores.insert(owner, OwnerLinkStore {
                base: table_of(e_schema.clone(), batches)?,
                base_rows,
                base_bytes,
                changed: Arc::default(),
                overlay: None,
                overlay_bytes: 0,
              });
            }
          }
          edges.insert(
            link,
            Arc::new(LinkStore { empty: empty_table(e_schema.clone())?, owners: owner_stores }),
          );
        }

        // Each owner's commits become visible in commit order, so the latest one this snapshot sees marks every change it holds.
        let positions = tx
          .query(format!("SELECT owner, max(commit_seq) FROM {schema}.change_commits GROUP BY owner").as_str(), &[])
          .await?;
        let applied = positions.iter().map(|row| (row.get::<_, String>(0), row.get::<_, i64>(1))).collect();
        tx.commit().await?;
        let links = req.links.clone();
        Ok::<_, PgOpError>(Snapshot {
          ctx,
          request: req,
          kinds,
          classified,
          links,
          types,
          edges,
          applied,
          objects,
          edge_count,
          bytes,
        })
      })
    })
    .await
}
