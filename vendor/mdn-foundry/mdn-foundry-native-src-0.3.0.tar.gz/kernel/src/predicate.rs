//! Predicate translation with two-valued ontology semantics (missing values are null, `ne` holds for null, `not` never sees unknown).

use std::collections::HashMap;

use datafusion::functions::core::expr_fn::coalesce;
use datafusion::functions::unicode::expr_fn::strpos;
use datafusion::functions_nested::expr_fn::{array_has_all, array_has_any, cardinality, make_array};
use datafusion::logical_expr::{lit, Expr};
use serde_json::Value;

use crate::types::{column, invalid, Failure, Kind, Predicate};

pub fn literal(kind: Kind, value: &Value) -> Result<Expr, Failure> {
  Ok(match (kind, value) {
    (Kind::String, Value::String(s)) => lit(s.clone()),
    (Kind::Boolean, Value::Bool(b)) => lit(*b),
    (Kind::Integer, Value::Number(n)) if n.is_i64() => lit(n.as_i64().unwrap()),
    (Kind::Integer | Kind::Number, Value::Number(n)) => lit(n.as_f64().ok_or_else(|| invalid("Number out of range"))?),
    _ => return Err(invalid("The planner sent a literal of another kind")),
  })
}

pub fn string_list(values: &[String]) -> Expr {
  make_array(values.iter().map(|v| lit(v.clone())).collect())
}

pub fn predicate(p: &Predicate, kinds: &HashMap<String, Kind>) -> Result<Expr, Failure> {
  // `$rank` and `$compartments` hold a classified type's row classification.
  let kind_of = |name: &str| match name {
    "$rank" => Ok(Kind::Integer),
    "$compartments" => Ok(Kind::Strings),
    _ => kinds.get(name).copied().ok_or_else(|| invalid(format!("Unknown column {name}"))),
  };
  Ok(match p {
    Predicate::All { predicates } => predicates
      .iter()
      .map(|q| predicate(q, kinds))
      .collect::<Result<Vec<_>, _>>()?
      .into_iter()
      .reduce(Expr::and)
      .unwrap_or(lit(true)),
    Predicate::Any { predicates } => predicates
      .iter()
      .map(|q| predicate(q, kinds))
      .collect::<Result<Vec<_>, _>>()?
      .into_iter()
      .reduce(Expr::or)
      .unwrap_or(lit(false)),
    Predicate::Not { predicate: q } => !predicate(q, kinds)?,
    Predicate::Const { value } => lit(*value),
    Predicate::Eq { column: name, value } if value.is_null() => {
      kind_of(name)?;
      column(name).is_null()
    }
    Predicate::Eq { column: name, value } => {
      coalesce(vec![column(name).eq(literal(kind_of(name)?, value)?), lit(false)])
    }
    Predicate::Ne { column: name, value } if value.is_null() => {
      kind_of(name)?;
      column(name).is_not_null()
    }
    Predicate::Ne { column: name, value } => {
      coalesce(vec![column(name).not_eq(literal(kind_of(name)?, value)?), lit(true)])
    }
    Predicate::Gt { column: name, value } => {
      kind_of(name)?;
      coalesce(vec![column(name).gt(lit(*value)), lit(false)])
    }
    Predicate::Gte { column: name, value } => {
      kind_of(name)?;
      coalesce(vec![column(name).gt_eq(lit(*value)), lit(false)])
    }
    Predicate::Lt { column: name, value } => {
      kind_of(name)?;
      coalesce(vec![column(name).lt(lit(*value)), lit(false)])
    }
    Predicate::Lte { column: name, value } => {
      kind_of(name)?;
      coalesce(vec![column(name).lt_eq(lit(*value)), lit(false)])
    }
    Predicate::In { column: name, values } => {
      let kind = kind_of(name)?;
      let present = values.iter().filter(|v| !v.is_null()).map(|v| literal(kind, v)).collect::<Result<Vec<_>, _>>()?;
      let matches = if present.is_empty() {
        lit(false)
      } else {
        coalesce(vec![column(name).in_list(present, false), lit(false)])
      };
      if values.iter().any(Value::is_null) { matches.or(column(name).is_null()) } else { matches }
    }
    Predicate::Contains { column: name, value } => {
      kind_of(name)?;
      coalesce(vec![strpos(column(name), lit(value.clone())).gt(lit(0i64)), lit(false)])
    }
    Predicate::Subset { column: name, values } => {
      if kind_of(name)? != Kind::Strings { return Err(invalid(format!("{name} is not a string list"))); }
      let empty = column(name).is_null().or(cardinality(column(name)).eq(lit(0u64)));
      if values.is_empty() {
        empty
      } else {
        empty.or(coalesce(vec![array_has_all(string_list(values), column(name)), lit(false)]))
      }
    }
    Predicate::HasAny { column: name, values } => {
      if kind_of(name)? != Kind::Strings { return Err(invalid(format!("{name} is not a string list"))); }
      if values.is_empty() {
        lit(false)
      } else {
        coalesce(vec![array_has_any(column(name), string_list(values)), lit(false)])
      }
    }
  })
}
