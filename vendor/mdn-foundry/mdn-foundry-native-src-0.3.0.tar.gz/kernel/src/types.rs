//! Core request/response types, schemas, constants, and error helpers for the EIGOS query kernel.

use std::collections::HashMap;
use std::sync::Arc;

use axum::http::StatusCode;
use axum::Json;
use datafusion::arrow::datatypes::{DataType, Field, Schema, SchemaRef};
use datafusion::common::Column;
use datafusion::logical_expr::Expr;
use serde::{Deserialize, Serialize};
use serde_json::{json, Value};

/// Protocol level answered by this kernel:
/// 1: Object Set pages and aggregations;
/// 2: query pages (C4b) and Scenario overlays (C5a).
pub const PROTOCOL: u32 = 2;

/// Number of rows accumulated before flushing a batch during initial load.
pub const BATCH: usize = 65536;

/// Maximum cached Scenario overlays kept in memory.
pub const OVERLAYS: usize = 64;

/// Maximum row IDs reported for a tracked type (matches the reference complete-evaluation limit).
pub const TRACKED: usize = 10000;

/// Maximum objects one step of a derived relationship may reach from one object.
pub const DERIVED_REACH: i64 = 10000;

/// Zod's integers are IEEE-754 safe integers.
pub const SAFE_LIMIT: f64 = 9007199254740992.0;

pub type Failure = (StatusCode, Json<Value>);

pub fn failure(status: StatusCode, message: impl ToString) -> Failure {
  (status, Json(json!({ "error": message.to_string() })))
}
pub fn internal(error: impl ToString) -> Failure { failure(StatusCode::INTERNAL_SERVER_ERROR, error) }
pub fn invalid(error: impl ToString) -> Failure { failure(StatusCode::BAD_REQUEST, error) }
/// The kernel cannot answer from what it has applied; the caller evaluates the query with the reference.
pub fn stale(reason: &str) -> Failure { failure(StatusCode::CONFLICT, format!("stale: {reason}")) }
/// The reference fails these evaluations or memory budget forbids serving them; caller falls back to reference.
pub fn fallback(reason: &str) -> Failure { failure(StatusCode::UNPROCESSABLE_ENTITY, format!("fallback: {reason}")) }
/// Hard memory limit reached while loading or restoring a projection.
pub fn over_budget(reason: &str) -> Failure { failure(StatusCode::INSUFFICIENT_STORAGE, format!("over_budget: {reason}")) }

#[derive(Deserialize, Serialize, Clone, Copy, PartialEq, Eq, Debug)]
#[serde(rename_all = "lowercase")]
pub enum Kind { String, Integer, Number, Boolean, Strings }

#[derive(Deserialize, Serialize, Clone, PartialEq, Eq, Debug)]
pub struct ColumnDef { pub name: String, pub kind: Kind }

#[derive(Deserialize, Serialize, Clone, PartialEq, Eq, Debug)]
pub struct TypeDef { pub name: String, pub columns: Vec<ColumnDef>, pub classification: Option<String> }

#[derive(Deserialize, Clone, Debug)]
pub struct LoadRequest {
  pub database: String,
  pub schema: String,
  pub projection: String,
  pub types: Vec<TypeDef>,
  pub links: Vec<String>,
  pub ranks: HashMap<String, i64>,
}

#[derive(Deserialize, Debug)]
#[serde(tag = "op", rename_all = "camelCase")]
pub enum Predicate {
  All { predicates: Vec<Predicate> },
  Any { predicates: Vec<Predicate> },
  Not { predicate: Box<Predicate> },
  Const { value: bool },
  Eq { column: String, value: Value },
  Ne { column: String, value: Value },
  Gt { column: String, value: f64 },
  Gte { column: String, value: f64 },
  Lt { column: String, value: f64 },
  Lte { column: String, value: f64 },
  In { column: String, values: Vec<Value> },
  Contains { column: String, value: String },
  /// Every element of a string list is one of `values`; a missing list is empty.
  Subset { column: String, values: Vec<String> },
  /// A string list holds at least one of `values`.
  HasAny { column: String, values: Vec<String> },
}

#[derive(Deserialize, Debug)]
pub struct Reference { pub r#type: String, pub id: String }

pub fn yes() -> bool { true }

/// One move of a traversal step. `candidates`: the move's filter reads derived values, so the reference reads every visible
/// target before it filters them.
#[derive(Deserialize, Debug)]
pub struct Move {
  pub source: String,
  pub link: String,
  pub forward: bool,
  pub target: String,
  pub filter: Option<Predicate>,
  #[serde(default)]
  pub candidates: bool,
}

#[derive(Deserialize, Debug)]
#[serde(tag = "op", rename_all = "camelCase")]
pub enum SetNode {
  Empty,
  /// `candidates`: the filter reads derived values, so the reference reads every readable row of the type.
  Scan { r#type: String, filter: Option<Predicate>, #[serde(default)] candidates: bool },
  /// `enrich` is false for the source of a relationship query, which the reference reads without its derived values.
  Refs { refs: Vec<Reference>, #[serde(default = "yes")] enrich: bool },
  Union { sets: Vec<SetNode> },
  Intersect { sets: Vec<SetNode> },
  Except { left: Box<SetNode>, right: Box<SetNode> },
  /// Each step lists one move per possible source type; a set's objects of other types do not continue.
  Traverse { set: Box<SetNode>, steps: Vec<Vec<Move>> },
  BoundedTraverse { set: Box<SetNode>, steps: Vec<Vec<Move>>, limit: usize },
}

#[derive(Deserialize, Debug)]
pub struct Metric { pub name: String, pub op: String, pub column: Option<String> }

/// A field an aggregation or query order reads on one member type.
#[derive(Deserialize, Debug)]
pub struct PartField {
  pub name: String,
  pub column: Option<String>,
  #[serde(default)]
  pub hidden: bool,
  pub policy: Option<Predicate>,
}

/// One member type of an aggregation or query order and the fields it contributes.
#[derive(Deserialize, Debug)]
pub struct Part { pub r#type: String, pub fields: Vec<PartField> }

/// One key of a query's order: an output field, descending or not; nulls come last either way.
#[derive(Deserialize, Debug)]
pub struct OrderKey { pub name: String, #[serde(default)] pub desc: bool }

#[derive(Deserialize, Debug)]
#[serde(tag = "kind", rename_all = "camelCase")]
pub enum Output {
  Page { offset: usize, limit: usize },
  #[serde(rename_all = "camelCase")]
  Query { offset: usize, limit: usize, parts: Vec<Part>, kinds: HashMap<String, Kind>, order: Vec<OrderKey> },
  #[serde(rename_all = "camelCase")]
  Aggregate { parts: Vec<Part>, kinds: HashMap<String, Kind>, group_by: Vec<String>, metrics: Vec<Metric> },
}

/// How to report one type the evaluation reads.
#[derive(Deserialize, Debug)]
pub struct MemberSpec { pub r#type: String, #[serde(default)] pub track: bool, pub markings: Option<String> }

/// A Scenario a query reads.
#[derive(Deserialize, Clone, Debug)]
pub struct ScenarioRequest {
  pub id: String,
  pub revision: i64,
  #[serde(default)]
  pub single: HashMap<String, (bool, bool)>,
}

/// A derived value over one type's rows.
#[derive(Deserialize, Debug)]
#[serde(tag = "op", rename_all = "camelCase")]
pub enum Derived {
  Literal { value: f64 },
  Field { column: String, #[serde(default)] hidden: bool, policy: Option<Predicate> },
  Derived { column: String },
  Arith { kind: String, left: Box<Derived>, right: Box<Derived> },
  Linked { steps: Vec<LinkStep>, aggregate: String, value: Option<Box<Derived>> },
}

/// One step of a derived relationship path.
#[derive(Deserialize, Debug)]
pub struct LinkStep { pub link: String, pub forward: bool, pub target: String, #[serde(default = "yes")] pub visible: bool }

/// A derived column and the bounds its property schema puts on its numbers.
#[derive(Deserialize, Debug)]
#[serde(rename_all = "camelCase")]
pub struct DerivedSpec {
  pub column: String,
  pub kind: Kind,
  pub expr: Derived,
  pub minimum: Option<f64>,
  pub maximum: Option<f64>,
  pub exclusive_minimum: Option<f64>,
  pub exclusive_maximum: Option<f64>,
}

/// Unknown fields are refused (422, so the client answers from the reference).
#[derive(Deserialize, Debug)]
#[serde(deny_unknown_fields)]
pub struct QueryRequest {
  pub owner: String,
  pub set: SetNode,
  pub output: Output,
  #[serde(default)]
  pub members: Vec<MemberSpec>,
  #[serde(default)]
  pub rows: HashMap<String, Predicate>,
  #[serde(default)]
  pub derived: HashMap<String, Vec<DerivedSpec>>,
  pub projection: Option<String>,
  #[serde(rename = "minCommit")]
  pub min_commit: Option<i64>,
  #[serde(rename = "waitMs")]
  pub wait_ms: Option<u64>,
  #[serde(default)]
  pub scenario: Option<ScenarioRequest>,
}

pub fn column(name: &str) -> Expr { Expr::Column(Column::new_unqualified(name)) }

pub fn data_type(kind: Kind) -> DataType {
  match kind {
    Kind::String => DataType::Utf8,
    Kind::Integer => DataType::Int64,
    Kind::Number => DataType::Float64,
    Kind::Boolean => DataType::Boolean,
    Kind::Strings => DataType::List(Arc::new(Field::new("item", DataType::Utf8, true))),
  }
}

/// The canonical reference key: `canonical({type,id})` orders by the JSON-encoded id, then the JSON-encoded type.
pub fn ref_key(kind: &str, id: &str) -> String {
  format!("{}{}", serde_json::to_string(id).unwrap(), serde_json::to_string(kind).unwrap())
}

pub fn quote(identifier: &str) -> String { format!("\"{}\"", identifier.replace('"', "\"\"")) }

/// Per-owner object table schema (no `$owner` column since storage is partitioned by owner).
pub fn object_schema(def: &TypeDef) -> SchemaRef {
  let mut fields = vec![
    Field::new("$id", DataType::Utf8, false),
    Field::new("$key", DataType::Utf8, false),
  ];
  for c in &def.columns { fields.push(Field::new(&c.name, data_type(c.kind), true)); }
  if def.classification.is_some() {
    fields.push(Field::new("$rank", DataType::Int64, true));
    fields.push(Field::new("$compartments", data_type(Kind::Strings), true));
  }
  Arc::new(Schema::new(fields))
}

/// Checkpoint object Parquet schema: `$owner` prepended to `object_schema`.
pub fn checkpoint_object_schema(def: &TypeDef) -> SchemaRef {
  let inner = object_schema(def);
  let mut fields = Vec::with_capacity(inner.fields().len() + 1);
  fields.push(Field::new("$owner", DataType::Utf8, false));
  for f in inner.fields() { fields.push((**f).clone()); }
  Arc::new(Schema::new(fields))
}

pub fn strings_schema(names: &[&str]) -> SchemaRef {
  Arc::new(Schema::new(names.iter().map(|name| Field::new(*name, DataType::Utf8, false)).collect::<Vec<_>>()))
}

/// Per-owner edge table schema (no `$owner` column since storage is partitioned by owner).
pub fn edge_schema() -> SchemaRef { strings_schema(&["from_id", "to_id"]) }

/// Checkpoint edge Parquet schema: `$owner` prepended to `edge_schema`.
pub fn checkpoint_edge_schema() -> SchemaRef { strings_schema(&["$owner", "from_id", "to_id"]) }

/// Scenario staged link schema for one owner.
pub fn scenario_link_schema() -> SchemaRef {
  Arc::new(Schema::new(vec![
    Field::new("from_id", DataType::Utf8, false),
    Field::new("to_id", DataType::Utf8, false),
    Field::new("$sremoved", DataType::Boolean, false),
  ]))
}

/// Target DataFusion parallelism.
pub fn partitions() -> usize { std::thread::available_parallelism().map(|n| n.get()).unwrap_or(4) }
