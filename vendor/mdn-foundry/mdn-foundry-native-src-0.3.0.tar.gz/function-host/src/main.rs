//! The EIGOS function host (F1). It runs user Functions compiled to WebAssembly components of the world
//! `eigos:function/handler@0.2.0` in `wit/handler.wit`, whose one export is
//! `invoke: func(input: string) -> result<string, failure>`.
//!
//! - **Calls:** each call runs asynchronously in a fresh store within the limits the caller gives, capped by the
//!   host's maxima:
//!   - fuel for compute;
//!   - memory, summed over all of the component's memories;
//!   - a deadline, enforced by cooperative epoch interruption and async timeouts across callbacks;
//!   - the input and output sizes.
//! - **Concurrency:** CPU-bound WASM execution is bounded by `compute_slots` (`EIGOS_FUNCTION_HOST_SLOTS`), while
//!   awaiting runtime callbacks releases the compute slot and re-acquires it before resuming WASM, allowing many
//!   I/O-bound calls to progress concurrently up to `call_slots` (`EIGOS_FUNCTION_HOST_MAX_CALLS`).
//! - **Components:** uploaded once, checked, precompiled and kept by SHA-256 in a bounded LRU cache (default 64)
//!   protected by per-SHA-256 singleflight locks, and persisted on disk when a data directory is set.
//! - **Imports:** a component may import only command-line I/O, clocks, randomness, streams, a filesystem with
//!   nothing opened, and the declared EIGOS interfaces. One that imports sockets, HTTP or anything else is refused.
//!
//! The host listens on the loopback interface only. It holds no credentials and no Ontology data: the runtime sends
//! it inputs that it has validated for the caller, and validates every output against the Function's contract.

mod cache;
mod callback_pool;

use std::net::SocketAddr;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicU64, Ordering};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

use axum::body::Bytes;
use axum::extract::{DefaultBodyLimit, State};
use axum::http::{HeaderMap, StatusCode};
use axum::routing::{get, post};
use axum::{Json, Router};
use cache::{KeyLocks, LruCache};
use callback_pool::{CallbackError, CallbackPool};
use serde::Deserialize;
use serde_json::{Value, json};
use sha2::{Digest, Sha256};
use tokio::sync::{OwnedSemaphorePermit, Semaphore, TryAcquireError};
use wasmtime::component::{Component, Linker, ResourceTable};
use wasmtime::{Config, Engine, ResourceLimiter, Store, Trap, UpdateDeadline};
use wasmtime_wasi::p2::pipe::MemoryOutputPipe;
use wasmtime_wasi::{WasiCtx, WasiCtxBuilder, WasiCtxView, WasiView};

mod world {
    wasmtime::component::bindgen!({
        world: "handler",
        path: "wit",
        imports: { default: async | trappable },
        exports: { default: async },
    });
}
use world::HandlerPre;
use world::eigos::function::types::Failure;

/// Protocol 1 runs components, 2 adds Ontology callbacks, 3 adds declared HTTP Sources, and 4 adds models and streamed output.
const PROTOCOL: u32 = 4;
const WORLD: &str = "eigos:function/handler@0.2.0";
/// Default capacity of the in-memory precompiled component LRU cache.
const DEFAULT_COMPONENTS: usize = 64;
/// The most a callback answer may hold.
const MAX_CALLBACK: usize = 16 << 20;
/// The host's maxima for the limits a call may ask for.
const MAX_FUEL: u64 = 200_000_000_000;
const MAX_MEMORY_MB: u64 = 512;
const MAX_DEADLINE_MS: u64 = 30_000;
const MAX_INPUT: usize = 1 << 20;
const MAX_OUTPUT: usize = 1 << 20;
const MAX_COMPONENT: usize = 16 << 20;
/// Table elements a call may create, over all of its tables.
const MAX_TABLE_ELEMENTS: usize = 1 << 20;
/// Standard error a call may write; the stream is closed beyond it.
const STDERR_BYTES: usize = 64 << 10;
/// How often the epoch advances, which is the granularity of cooperative yields and deadlines.
const EPOCH_MS: u64 = 10;
/// The WASI interfaces a component may import, by package prefix.
const ALLOWED_IMPORTS: &[&str] = &[
    "wasi:cli/",
    "wasi:clocks/",
    "wasi:random/",
    "wasi:io/",
    "wasi:filesystem/",
    "eigos:function/",
    "eigos:http/outgoing@0.1.0",
    "eigos:models/language-model@0.1.0",
];

type Refusal = (StatusCode, Json<Value>);
fn refuse(status: StatusCode, message: impl ToString) -> Refusal {
    (status, Json(json!({ "error": message.to_string() })))
}

#[derive(Default)]
struct Metrics {
    active_calls: AtomicU64,
    in_flight_callbacks: AtomicU64,
    cache_hits: AtomicU64,
    cache_misses: AtomicU64,
    slot_wait_us_total: AtomicU64,
}

impl Metrics {
    fn add_slot_wait(&self, elapsed: Duration) {
        let micros = elapsed.as_micros().min(u64::MAX as u128) as u64;
        if micros > 0 {
            self.slot_wait_us_total.fetch_add(micros, Ordering::Relaxed);
        }
    }
}

struct CounterGuard<'a>(&'a AtomicU64);
impl<'a> CounterGuard<'a> {
    fn new(counter: &'a AtomicU64) -> Self {
        counter.fetch_add(1, Ordering::Relaxed);
        Self(counter)
    }
}
impl Drop for CounterGuard<'_> {
    fn drop(&mut self) {
        self.0.fetch_sub(1, Ordering::Relaxed);
    }
}

/// One call's store data: WASI with no network, no environment and nothing opened, the call's limits,
/// its compute permit (released while awaiting callbacks), and the runtime's loopback callback.
struct Call {
    wasi: WasiCtx,
    table: ResourceTable,
    limiter: Limiter,
    callback: Option<Callback>,
    deadline: Instant,
    callbacks: Arc<CallbackPool>,
    compute_slots: Arc<Semaphore>,
    compute_permit: Option<OwnedSemaphorePermit>,
    metrics: Arc<Metrics>,
}

/// The runtime's endpoint for one call: on the loopback interface, with a token that names the call.
struct Callback {
    port: u16,
    path: String,
    token: String,
}

impl Call {
    /// Asks the runtime to run an Ontology operation for this call. Releases the CPU compute slot while
    /// awaiting the callback and re-acquires it before returning to WASM, strictly respecting `deadline`.
    async fn ontology(&mut self, operation: &str, arguments: Value) -> wasmtime::Result<Result<Option<String>, Failure>> {
        if Instant::now() >= self.deadline {
            return Err(Trap::Interrupt.into());
        }
        let failure = |code: &str, message: String| Failure { code: code.into(), message };
        let Some(callback) = &self.callback else {
            return Ok(Err(failure("unavailable", "This call has no Ontology to read".into())));
        };
        let port = callback.port;
        let path = callback.path.clone();
        let body = json!({ "token": callback.token, "operation": operation, "arguments": arguments }).to_string();

        // Release CPU compute slot during external I/O so other WASM calls can execute concurrently.
        self.compute_permit.take();

        let post_result = {
            let _in_flight = CounterGuard::new(&self.metrics.in_flight_callbacks);
            self.callbacks.post(port, &path, body, self.deadline).await
        };

        if matches!(post_result, Err(CallbackError::Deadline)) || Instant::now() >= self.deadline {
            return Err(Trap::Interrupt.into());
        }

        // Re-acquire a CPU compute slot before resuming WASM execution, strictly bounded by deadline.
        let permit = match self.compute_slots.clone().try_acquire_owned() {
            Ok(permit) => permit,
            Err(TryAcquireError::NoPermits) => {
                let wait_started = Instant::now();
                let acquired = tokio::time::timeout_at(
                    tokio::time::Instant::from_std(self.deadline),
                    self.compute_slots.clone().acquire_owned(),
                )
                .await
                .map_err(|_| wasmtime::Error::from(Trap::Interrupt))?
                .map_err(|e| wasmtime::Error::msg(format!("compute slot closed: {e}")))?;
                self.metrics.add_slot_wait(wait_started.elapsed());
                acquired
            }
            Err(TryAcquireError::Closed) => {
                return Err(wasmtime::Error::msg("compute slot closed"));
            }
        };
        self.compute_permit = Some(permit);

        if Instant::now() >= self.deadline {
            return Err(Trap::Interrupt.into());
        }

        let response = match post_result {
            Ok(response) => response,
            Err(CallbackError::Deadline) => return Err(Trap::Interrupt.into()),
            Err(CallbackError::Transport(e)) => {
                return Ok(Err(failure("unavailable", format!("The runtime did not answer: {e}"))));
            }
        };

        let value: Value = match serde_json::from_str(&response) {
            Ok(value) => value,
            Err(_) => return Ok(Err(failure("unavailable", "The runtime answered malformed JSON".into()))),
        };
        if let Some(error) = value.get("error") {
            return Ok(Err(failure(
                error["code"].as_str().unwrap_or("failed"),
                error["message"].as_str().unwrap_or_default().to_string(),
            )));
        }
        Ok(Ok(match value.get("result") {
            None | Some(Value::Null) => None,
            Some(result) => Some(result.to_string()),
        }))
    }

    async fn required(&mut self, operation: &str, arguments: Value) -> wasmtime::Result<Result<String, Failure>> {
        match self.ontology(operation, arguments).await? {
            Ok(Some(value)) => Ok(Ok(value)),
            Ok(None) => Ok(Err(Failure {
                code: "unavailable".into(),
                message: format!("{operation} returned nothing"),
            })),
            Err(failure) => Ok(Err(failure)),
        }
    }
}

/// The JSON an argument holds, or the Function's failure.
fn argument(name: &str, text: &str) -> Result<Value, Failure> {
    serde_json::from_str(text).map_err(|e| Failure { code: "invalid".into(), message: format!("{name} is not JSON: {e}") })
}

impl world::eigos::function::types::Host for Call {}

impl world::eigos::function::ontology::Host for Call {
    async fn get(&mut self, object_type: String, id: String) -> wasmtime::Result<Result<Option<String>, Failure>> {
        self.ontology("get", json!({ "type": object_type, "id": id })).await
    }
    async fn follow(&mut self, object: String, link: String) -> wasmtime::Result<Result<String, Failure>> {
        let object = match argument("object", &object) { Ok(v) => v, Err(f) => return Ok(Err(f)) };
        self.required("follow", json!({ "object": object, "link": link })).await
    }
    async fn query(&mut self, query: String) -> wasmtime::Result<Result<String, Failure>> {
        let query = match argument("query", &query) { Ok(v) => v, Err(f) => return Ok(Err(f)) };
        self.required("query", json!({ "query": query })).await
    }
    async fn evaluate(&mut self, request: String) -> wasmtime::Result<Result<String, Failure>> {
        let request = match argument("request", &request) { Ok(v) => v, Err(f) => return Ok(Err(f)) };
        self.required("evaluate", request).await
    }
    async fn aggregate(&mut self, request: String) -> wasmtime::Result<Result<String, Failure>> {
        let request = match argument("request", &request) { Ok(v) => v, Err(f) => return Ok(Err(f)) };
        self.required("aggregate", request).await
    }
    async fn create(&mut self, object_type: String, id: String, properties: String) -> wasmtime::Result<Result<(), Failure>> {
        let properties = match argument("properties", &properties) { Ok(v) => v, Err(f) => return Ok(Err(f)) };
        Ok(self.ontology("create", json!({ "type": object_type, "id": id, "properties": properties })).await?.map(|_| ()))
    }
    async fn update(&mut self, object: String, properties: String) -> wasmtime::Result<Result<(), Failure>> {
        let object = match argument("object", &object) { Ok(v) => v, Err(f) => return Ok(Err(f)) };
        let properties = match argument("properties", &properties) { Ok(v) => v, Err(f) => return Ok(Err(f)) };
        Ok(self.ontology("update", json!({ "object": object, "properties": properties })).await?.map(|_| ()))
    }
    async fn delete(&mut self, object: String) -> wasmtime::Result<Result<(), Failure>> {
        let object = match argument("object", &object) { Ok(v) => v, Err(f) => return Ok(Err(f)) };
        Ok(self.ontology("delete", json!({ "object": object })).await?.map(|_| ()))
    }
    async fn link(&mut self, link_type: String, from: String, to: String) -> wasmtime::Result<Result<(), Failure>> {
        let from = match argument("from", &from) { Ok(v) => v, Err(f) => return Ok(Err(f)) };
        let to = match argument("to", &to) { Ok(v) => v, Err(f) => return Ok(Err(f)) };
        Ok(self.ontology("link", json!({ "type": link_type, "from": from, "to": to })).await?.map(|_| ()))
    }
    async fn unlink(&mut self, link_type: String, from: String, to: String) -> wasmtime::Result<Result<(), Failure>> {
        let from = match argument("from", &from) { Ok(v) => v, Err(f) => return Ok(Err(f)) };
        let to = match argument("to", &to) { Ok(v) => v, Err(f) => return Ok(Err(f)) };
        Ok(self.ontology("unlink", json!({ "type": link_type, "from": from, "to": to })).await?.map(|_| ()))
    }
}

impl world::eigos::function::streaming::Host for Call {
    async fn emit(&mut self, chunk: String) -> wasmtime::Result<Result<(), Failure>> {
        Ok(self.ontology("emit", json!({ "chunk": chunk })).await?.map(|_| ()))
    }
}

type ModelFailure = world::eigos::models::language_model::Failure;
fn model_failure(failure: Failure) -> ModelFailure {
    ModelFailure { code: failure.code, message: failure.message }
}

impl world::eigos::models::language_model::Host for Call {
    async fn generate(&mut self, alias: String, messages: String) -> wasmtime::Result<Result<(), ModelFailure>> {
        let messages = match argument("messages", &messages) {
            Ok(v) => v,
            Err(f) => return Ok(Err(model_failure(f))),
        };
        Ok(self.ontology("generate", json!({ "alias": alias, "messages": messages })).await?.map(|_| ()).map_err(model_failure))
    }
    async fn next(&mut self) -> wasmtime::Result<Result<Option<String>, ModelFailure>> {
        match self.ontology("modelNext", json!({})).await? {
            Err(f) => Ok(Err(model_failure(f))),
            Ok(opt) => Ok(opt
                .map(|json| {
                    serde_json::from_str::<String>(&json).map_err(|_| ModelFailure {
                        code: "invalid".into(),
                        message: "Invalid model chunk".into(),
                    })
                })
                .transpose()),
        }
    }
}

impl world::eigos::http::outgoing::Host for Call {
    async fn send(&mut self, request: String) -> wasmtime::Result<Result<String, world::eigos::http::outgoing::Failure>> {
        let request = match argument("request", &request) {
            Ok(v) => v,
            Err(failure) => {
                return Ok(Err(world::eigos::http::outgoing::Failure {
                    code: failure.code,
                    message: failure.message,
                }));
            }
        };
        Ok(self.required("outgoing", json!({ "request": request })).await?.map_err(|failure| {
            world::eigos::http::outgoing::Failure {
                code: failure.code,
                message: failure.message,
            }
        }))
    }
}

impl WasiView for Call {
    fn ctx(&mut self) -> WasiCtxView<'_> {
        WasiCtxView { ctx: &mut self.wasi, table: &mut self.table }
    }
}

/// Memory and table limits over everything one call creates. It remembers whether it refused to grow, so that the
/// trap that usually follows reads as running out of memory.
struct Limiter {
    memory: usize,
    memory_used: usize,
    table_elements: usize,
    refused: bool,
}
impl ResourceLimiter for Limiter {
    fn memory_growing(&mut self, current: usize, desired: usize, maximum: Option<usize>) -> wasmtime::Result<bool> {
        // Beyond the memory's own maximum, wasmtime refuses the growth anyway; it is not a limit of the call.
        if maximum.is_some_and(|maximum| desired > maximum) {
            return Ok(false);
        }
        let used = self.memory_used.saturating_sub(current) + desired;
        if used > self.memory {
            self.refused = true;
            return Ok(false);
        }
        self.memory_used = used;
        Ok(true)
    }
    fn table_growing(&mut self, current: usize, desired: usize, maximum: Option<usize>) -> wasmtime::Result<bool> {
        if maximum.is_some_and(|maximum| desired > maximum) {
            return Ok(false);
        }
        let used = self.table_elements.saturating_sub(current) + desired;
        if used > MAX_TABLE_ELEMENTS {
            self.refused = true;
            return Ok(false);
        }
        self.table_elements = used;
        Ok(true)
    }
    fn instances(&self) -> usize { 64 }
    fn tables(&self) -> usize { 64 }
    fn memories(&self) -> usize { 64 }
}

struct Host {
    engine: Engine,
    linker: Linker<Call>,
    cache: Mutex<LruCache<Arc<HandlerPre<Call>>>>,
    singleflight: Arc<KeyLocks>,
    callbacks: Arc<CallbackPool>,
    /// Where precompiled components are kept across restarts. Only this host writes it.
    data: Option<PathBuf>,
    /// CPU-bound WASM execution slots, released while awaiting external callbacks.
    compute_slots: Arc<Semaphore>,
    /// Total concurrent in-flight calls (CPU + I/O wait), bounding store & fiber memory.
    call_slots: Arc<Semaphore>,
    slot_count: usize,
    metrics: Arc<Metrics>,
}
type Shared = Arc<Host>;

fn env(name: &str) -> Option<String> {
    std::env::var(name).ok().filter(|value| !value.is_empty())
}
fn sha256_hex(bytes: &[u8]) -> String {
    Sha256::digest(bytes).iter().map(|b| format!("{b:02x}")).collect()
}
fn is_digest(value: &str) -> bool {
    value.len() == 64 && value.bytes().all(|b| b.is_ascii_digit() || (b'a'..=b'f').contains(&b))
}
fn milliseconds(elapsed: Duration) -> f64 {
    (elapsed.as_secs_f64() * 10_000.0).round() / 10.0
}
fn clip(text: &str, chars: usize) -> String {
    text.chars().take(chars).collect()
}
fn tail(text: &str, chars: usize) -> String {
    text.chars().skip(text.chars().count().saturating_sub(chars)).collect()
}
fn precompiled(dir: &Path, sha256: &str) -> PathBuf {
    dir.join(format!("{sha256}.cwasm"))
}

/// Checks a compiled component: it imports only allowed interfaces and exports `invoke` with the world's type.
fn check(host: &Host, component: &Component) -> Result<(HandlerPre<Call>, Vec<String>), String> {
    let imports: Vec<String> = component
        .component_type()
        .imports(&host.engine)
        .map(|(name, _)| name.to_string())
        .collect();
    if let Some(refused) = imports
        .iter()
        .find(|name| !ALLOWED_IMPORTS.iter().any(|prefix| name.starts_with(prefix)))
    {
        return Err(format!("The component imports {refused}, which Functions may not use"));
    }
    let pre = host
        .linker
        .instantiate_pre(component)
        .map_err(|e| format!("The component cannot be linked: {e:#}"))?;
    let pre = HandlerPre::new(pre).map_err(|e| {
        format!("The component does not export invoke: func(input: string) -> result<string, failure>: {e:#}")
    })?;
    Ok((pre, imports))
}

/// Loads a precompiled component from the data directory. Caller must hold the per-`sha256` singleflight lock.
fn load_from_disk_locked(host: &Host, sha256: &str) -> Option<Arc<HandlerPre<Call>>> {
    let file = precompiled(host.data.as_deref()?, sha256);
    if !file.exists() {
        return None;
    }
    // SAFETY: only this host writes its data directory, and wasmtime refuses files of another build or configuration.
    let loaded = unsafe { Component::deserialize_file(&host.engine, &file) }
        .map_err(|e| e.to_string())
        .and_then(|component| check(host, &component));
    match loaded {
        Ok((pre, _)) => {
            let pre = Arc::new(pre);
            host.cache.lock().unwrap().insert(sha256.to_string(), pre.clone());
            Some(pre)
        }
        Err(_) => {
            let _ = std::fs::remove_file(&file);
            None
        }
    }
}

/// A checked component, from memory or else from the data directory via per-SHA-256 singleflight.
async fn find_or_load(host: &Shared, sha256: &str) -> Result<Option<Arc<HandlerPre<Call>>>, Refusal> {
    if let Some(pre) = host.cache.lock().unwrap().get(sha256) {
        host.metrics.cache_hits.fetch_add(1, Ordering::Relaxed);
        return Ok(Some(pre));
    }
    let guard = host.singleflight.lock(sha256).await;
    if let Some(pre) = host.cache.lock().unwrap().get(sha256) {
        host.metrics.cache_hits.fetch_add(1, Ordering::Relaxed);
        return Ok(Some(pre));
    }
    host.metrics.cache_misses.fetch_add(1, Ordering::Relaxed);
    if host.data.is_none() {
        return Ok(None);
    }
    let host = host.clone();
    let sha256 = sha256.to_string();
    tokio::task::spawn_blocking(move || {
        let _guard = guard;
        load_from_disk_locked(&host, &sha256)
    })
    .await
    .map_err(|e| refuse(StatusCode::INTERNAL_SERVER_ERROR, e))
}

static PARTIAL: AtomicU64 = AtomicU64::new(0);

async fn upload(State(host): State<Shared>, headers: HeaderMap, body: Bytes) -> Result<Json<Value>, Refusal> {
    let sha256 = headers
        .get("x-eigos-sha256")
        .and_then(|v| v.to_str().ok())
        .unwrap_or_default()
        .to_string();
    if !is_digest(&sha256) {
        return Err(refuse(StatusCode::BAD_REQUEST, "Give the component's SHA-256 in x-eigos-sha256"));
    }
    if body.len() > MAX_COMPONENT {
        return Err(refuse(
            StatusCode::PAYLOAD_TOO_LARGE,
            format!("A component is at most {MAX_COMPONENT} bytes"),
        ));
    }
    if sha256_hex(&body) != sha256 {
        return Err(refuse(StatusCode::BAD_REQUEST, "The component does not match its SHA-256"));
    }
    if host.cache.lock().unwrap().get(&sha256).is_some() {
        host.metrics.cache_hits.fetch_add(1, Ordering::Relaxed);
        return Ok(Json(json!({ "sha256": sha256, "cached": true })));
    }
    let guard = host.singleflight.lock(&sha256).await;
    tokio::task::spawn_blocking(move || {
        let _guard = guard;
        if host.cache.lock().unwrap().get(&sha256).is_some() {
            host.metrics.cache_hits.fetch_add(1, Ordering::Relaxed);
            return Ok(Json(json!({ "sha256": sha256, "cached": true })));
        }
        host.metrics.cache_misses.fetch_add(1, Ordering::Relaxed);
        if load_from_disk_locked(&host, &sha256).is_some() {
            return Ok(Json(json!({ "sha256": sha256, "cached": true })));
        }
        let started = Instant::now();
        let component = Component::new(&host.engine, &body)
            .map_err(|e| refuse(StatusCode::BAD_REQUEST, format!("Not a WebAssembly component: {e:#}")))?;
        let compile_ms = milliseconds(started.elapsed());
        let (pre, imports) = check(&host, &component).map_err(|message| refuse(StatusCode::UNPROCESSABLE_ENTITY, message))?;
        let bytes = component
            .serialize()
            .map_err(|e| refuse(StatusCode::INTERNAL_SERVER_ERROR, e))?;
        if let Some(dir) = &host.data {
            let partial = dir.join(format!(
                "{sha256}.{}.{}.partial",
                std::process::id(),
                PARTIAL.fetch_add(1, Ordering::Relaxed)
            ));
            std::fs::write(&partial, &bytes)
                .and_then(|()| std::fs::rename(&partial, precompiled(dir, &sha256)))
                .map_err(|e| refuse(StatusCode::INTERNAL_SERVER_ERROR, e))?;
        }
        host.cache.lock().unwrap().insert(sha256.clone(), Arc::new(pre));
        Ok(Json(json!({
            "sha256": sha256,
            "cached": false,
            "bytes": body.len(),
            "precompiledBytes": bytes.len(),
            "compileMs": compile_ms,
            "imports": imports
        })))
    })
    .await
    .map_err(|e| refuse(StatusCode::INTERNAL_SERVER_ERROR, e))?
}

fn max_input() -> usize { MAX_INPUT }
fn max_output() -> usize { MAX_OUTPUT }

#[derive(Deserialize)]
#[serde(deny_unknown_fields, rename_all = "camelCase")]
struct Limits {
    fuel: u64,
    memory_mb: u64,
    deadline_ms: u64,
    #[serde(default = "max_input")]
    input_bytes: usize,
    #[serde(default = "max_output")]
    output_bytes: usize,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct CallbackSpec {
    url: String,
    token: String,
}

#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
struct Invoke {
    sha256: String,
    input: String,
    limits: Limits,
    #[serde(default)]
    callback: Option<CallbackSpec>,
}

/// The callback of a call, which must be on the loopback interface: the host reaches nothing else.
fn callback(spec: &CallbackSpec) -> Result<Callback, String> {
    let rest = spec
        .url
        .strip_prefix("http://127.0.0.1:")
        .ok_or("The callback must be http://127.0.0.1:<port>/<path>")?;
    let (port, path) = rest.split_once('/').ok_or("The callback needs a path")?;
    let port: u16 = port.parse().map_err(|_| "The callback port is not a number")?;
    if spec.token.len() < 32 || !spec.token.bytes().all(|b| b.is_ascii_alphanumeric() || b == b'-' || b == b'_') {
        return Err("The callback token is malformed".into());
    }
    if !path.bytes().all(|b| b.is_ascii_alphanumeric() || b"-_/".contains(&b)) {
        return Err("The callback path is malformed".into());
    }
    Ok(Callback { port, path: format!("/{path}"), token: spec.token.clone() })
}

/// Runs one call asynchronously in a fresh store and describes how it ended.
async fn run(
    host: &Host,
    pre: &HandlerPre<Call>,
    call: &Invoke,
    callback: Option<Callback>,
    compute_permit: OwnedSemaphorePermit,
) -> Value {
    let limits = &call.limits;
    let stderr = MemoryOutputPipe::new(STDERR_BYTES);
    let wasi = WasiCtxBuilder::new()
        .stderr(stderr.clone())
        .allow_tcp(false)
        .allow_udp(false)
        .allow_ip_name_lookup(false)
        .build();
    let limiter = Limiter {
        memory: (limits.memory_mb as usize) << 20,
        memory_used: 0,
        table_elements: 0,
        refused: false,
    };
    let deadline = Instant::now() + Duration::from_millis(limits.deadline_ms);
    let mut store = Store::new(
        &host.engine,
        Call {
            wasi,
            table: ResourceTable::new(),
            limiter,
            callback,
            deadline,
            callbacks: host.callbacks.clone(),
            compute_slots: host.compute_slots.clone(),
            compute_permit: Some(compute_permit),
            metrics: host.metrics.clone(),
        },
    );
    store.limiter(|call| &mut call.limiter);
    store.set_fuel(limits.fuel).expect("fuel is enabled");
    // Yield cooperatively on each epoch tick so CPU-bound WASM never starves async I/O,
    // and trap immediately once the wall-clock deadline has been reached.
    store.set_epoch_deadline(1);
    store.epoch_deadline_callback(move |_| {
        if Instant::now() >= deadline {
            Ok(UpdateDeadline::Interrupt)
        } else {
            Ok(UpdateDeadline::YieldCustom(1, Box::pin(tokio::task::yield_now())))
        }
    });

    let started = Instant::now();
    let execution = tokio::time::timeout_at(tokio::time::Instant::from_std(deadline), async {
        let handler = pre.instantiate_async(&mut store).await?;
        handler.call_invoke(&mut store, &call.input).await
    })
    .await;
    let elapsed = started.elapsed();

    let mut outcome = match execution {
        Err(_elapsed) => json!({ "error": { "kind": "deadline", "message": Trap::Interrupt.to_string() } }),
        Ok(Ok(Ok(output))) if output.len() > limits.output_bytes => json!({
            "error": { "kind": "output", "message": format!("The output exceeds {} bytes", limits.output_bytes) }
        }),
        Ok(Ok(Ok(output))) => json!({ "output": output }),
        Ok(Ok(Err(Failure { code, message }))) => json!({
            "error": { "kind": "failure", "code": clip(&code, 100), "message": clip(&message, 2000) }
        }),
        Ok(Err(error)) => {
            let trap = error.downcast_ref::<Trap>();
            let kind = match trap {
                Some(Trap::OutOfFuel) => "fuel",
                Some(Trap::Interrupt) => "deadline",
                _ if store.data().limiter.refused => "memory",
                _ => "trap",
            };
            // A trap says what stopped the call; otherwise the innermost cause does.
            let message = trap.map(Trap::to_string).unwrap_or_else(|| error.root_cause().to_string());
            json!({ "error": { "kind": kind, "message": clip(&message, 500) } })
        }
    };
    outcome["fuelUsed"] = json!(limits.fuel - store.get_fuel().unwrap_or(0));
    outcome["ms"] = json!(milliseconds(elapsed));
    let stderr = String::from_utf8_lossy(&stderr.contents()).into_owned();
    if !stderr.is_empty() {
        outcome["stderr"] = json!(tail(&stderr, 2000));
    }
    outcome
}

async fn invoke(State(host): State<Shared>, Json(call): Json<Invoke>) -> Result<Json<Value>, Refusal> {
    let limits = &call.limits;
    if !(1..=MAX_FUEL).contains(&limits.fuel)
        || !(1..=MAX_MEMORY_MB).contains(&limits.memory_mb)
        || !(1..=MAX_DEADLINE_MS).contains(&limits.deadline_ms)
        || limits.input_bytes > MAX_INPUT
        || limits.output_bytes > MAX_OUTPUT
    {
        return Err(refuse(
            StatusCode::BAD_REQUEST,
            format!(
                "Limits are positive and at most fuel {MAX_FUEL}, memoryMb {MAX_MEMORY_MB}, \
                 deadlineMs {MAX_DEADLINE_MS}, inputBytes {MAX_INPUT} and outputBytes {MAX_OUTPUT}"
            ),
        ));
    }
    if !is_digest(&call.sha256) {
        return Err(refuse(StatusCode::BAD_REQUEST, "sha256 is 64 lowercase hexadecimal characters"));
    }
    let reach = match &call.callback {
        Some(spec) => Some(callback(spec).map_err(|message| refuse(StatusCode::BAD_REQUEST, message))?),
        None => None,
    };
    if call.input.len() > limits.input_bytes {
        return Err(refuse(
            StatusCode::PAYLOAD_TOO_LARGE,
            format!("The input exceeds {} bytes", limits.input_bytes),
        ));
    }
    let pre = find_or_load(&host, &call.sha256)
        .await?
        .ok_or_else(|| refuse(StatusCode::NOT_FOUND, "Unknown component; upload it first"))?;

    let _call_permit = host
        .call_slots
        .clone()
        .acquire_owned()
        .await
        .map_err(|e| refuse(StatusCode::SERVICE_UNAVAILABLE, e))?;
    let _active = CounterGuard::new(&host.metrics.active_calls);

    let compute_permit = match host.compute_slots.clone().try_acquire_owned() {
        Ok(permit) => permit,
        Err(TryAcquireError::NoPermits) => {
            let wait_started = Instant::now();
            let permit = host
                .compute_slots
                .clone()
                .acquire_owned()
                .await
                .map_err(|e| refuse(StatusCode::SERVICE_UNAVAILABLE, e))?;
            host.metrics.add_slot_wait(wait_started.elapsed());
            permit
        }
        Err(TryAcquireError::Closed) => {
            return Err(refuse(StatusCode::SERVICE_UNAVAILABLE, "compute slots closed"));
        }
    };

    Ok(Json(run(&host, &pre, &call, reach, compute_permit).await))
}

async fn health(State(host): State<Shared>) -> Json<Value> {
    let (components, capacity) = {
        let cache = host.cache.lock().unwrap();
        (cache.len(), cache.capacity())
    };
    let slot_wait_us = host.metrics.slot_wait_us_total.load(Ordering::Relaxed);
    Json(json!({
        "status": "ok",
        "protocol": PROTOCOL,
        "world": WORLD,
        "components": components,
        "capacity": capacity,
        "slots": host.slot_count,
        "persistent": host.data.is_some(),
        "maxima": {
            "fuel": MAX_FUEL,
            "memoryMb": MAX_MEMORY_MB,
            "deadlineMs": MAX_DEADLINE_MS,
            "inputBytes": MAX_INPUT,
            "outputBytes": MAX_OUTPUT,
            "componentBytes": MAX_COMPONENT
        },
        "activeCalls": host.metrics.active_calls.load(Ordering::Relaxed),
        "inFlightCallbacks": host.metrics.in_flight_callbacks.load(Ordering::Relaxed),
        "cacheHits": host.metrics.cache_hits.load(Ordering::Relaxed),
        "cacheMisses": host.metrics.cache_misses.load(Ordering::Relaxed),
        "slotWaitMsTotal": milliseconds(Duration::from_micros(slot_wait_us))
    }))
}

async fn shutdown() {
    let mut terminate = tokio::signal::unix::signal(tokio::signal::unix::SignalKind::terminate()).expect("SIGTERM handler");
    tokio::select! { _ = tokio::signal::ctrl_c() => {}, _ = terminate.recv() => {} }
}

fn build_host(data: Option<PathBuf>, slot_count: usize, max_calls: usize, capacity: usize) -> Shared {
    let mut config = Config::new();
    // Wasmtime 50 enables async execution by default; async host/guest entrypoints are wired via
    // `add_to_linker_async`, async `bindgen!`, `instantiate_async`, and `epoch_deadline_callback`.
    config.wasm_component_model(true).consume_fuel(true).epoch_interruption(true);
    let engine = Engine::new(&config).expect("engine");
    let ticker = engine.clone();
    std::thread::spawn(move || loop {
        std::thread::sleep(Duration::from_millis(EPOCH_MS));
        ticker.increment_epoch();
    });
    let mut linker = Linker::<Call>::new(&engine);
    wasmtime_wasi::p2::add_to_linker_async(&mut linker).expect("WASI");
    world::Handler::add_to_linker::<Call, wasmtime::component::HasSelf<Call>>(&mut linker, |call| call)
        .expect("Ontology imports");
    Arc::new(Host {
        engine,
        linker,
        cache: Mutex::new(LruCache::new(capacity)),
        singleflight: Arc::new(KeyLocks::new()),
        callbacks: Arc::new(CallbackPool::new(MAX_CALLBACK)),
        data,
        compute_slots: Arc::new(Semaphore::new(slot_count)),
        call_slots: Arc::new(Semaphore::new(max_calls)),
        slot_count,
        metrics: Arc::new(Metrics::default()),
    })
}

fn router(host: Shared) -> Router {
    Router::new()
        .route("/health", get(health))
        .route("/components", post(upload))
        .route("/invoke", post(invoke))
        .layer(DefaultBodyLimit::max(MAX_COMPONENT + (1 << 20)))
        .with_state(host)
}

#[tokio::main]
async fn main() {
    let data = env("EIGOS_FUNCTION_HOST_DATA").map(PathBuf::from);
    if let Some(dir) = &data {
        std::fs::create_dir_all(dir).expect("data directory");
        // Writes that an earlier run did not finish.
        for entry in std::fs::read_dir(dir).expect("data directory").flatten() {
            if entry.file_name().to_string_lossy().ends_with(".partial") {
                let _ = std::fs::remove_file(entry.path());
            }
        }
    }
    let slot_count = env("EIGOS_FUNCTION_HOST_SLOTS")
        .and_then(|v| v.parse().ok())
        .filter(|n| *n > 0)
        .unwrap_or_else(|| std::thread::available_parallelism().map(|n| n.get()).unwrap_or(2));
    let max_calls = env("EIGOS_FUNCTION_HOST_MAX_CALLS")
        .and_then(|v| v.parse().ok())
        .filter(|n: &usize| *n >= slot_count)
        .unwrap_or_else(|| slot_count.saturating_mul(16).max(64));
    let capacity = env("EIGOS_FUNCTION_HOST_COMPONENTS")
        .and_then(|v| v.parse().ok())
        .filter(|n| *n > 0)
        .unwrap_or(DEFAULT_COMPONENTS);
    let host = build_host(data, slot_count, max_calls, capacity);
    let port: u16 = env("EIGOS_FUNCTION_HOST_PORT").and_then(|p| p.parse().ok()).unwrap_or(0);
    // Loopback only: the host runs code that definition editors publish, and it has no authentication of its own.
    let listener = tokio::net::TcpListener::bind(SocketAddr::from(([127, 0, 0, 1], port)))
        .await
        .expect("bind loopback");
    println!(
        "{}",
        json!({ "event": "function_host_listening", "port": listener.local_addr().expect("address").port(), "protocol": PROTOCOL })
    );
    axum::serve(listener, router(host))
        .with_graceful_shutdown(shutdown())
        .await
        .expect("serve");
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn callback_validation_enforces_loopback_and_token() {
        let token = "a".repeat(32);
        let ok = callback(&CallbackSpec {
            url: "http://127.0.0.1:4321/ontology".into(),
            token: token.clone(),
        })
        .unwrap();
        assert_eq!(ok.port, 4321);
        assert_eq!(ok.path, "/ontology");

        assert!(callback(&CallbackSpec { url: "http://localhost:4321/ontology".into(), token: token.clone() }).is_err());
        assert!(callback(&CallbackSpec { url: "http://169.254.169.254:80/latest".into(), token: token.clone() }).is_err());
        assert!(callback(&CallbackSpec { url: "https://127.0.0.1:4321/ontology".into(), token: token.clone() }).is_err());
        assert!(callback(&CallbackSpec { url: "http://127.0.0.1:4321/bad?q=1".into(), token: token.clone() }).is_err());
        assert!(callback(&CallbackSpec { url: "http://127.0.0.1:4321/ontology".into(), token: "short".into() }).is_err());
    }

    #[tokio::test]
    async fn health_exposes_backward_compatible_and_new_metrics() {
        let host = build_host(None, 2, 32, DEFAULT_COMPONENTS);
        let Json(body) = health(State(host)).await;
        assert_eq!(body["status"], "ok");
        assert_eq!(body["protocol"], PROTOCOL);
        assert_eq!(body["world"], WORLD);
        assert_eq!(body["capacity"], 64);
        assert_eq!(body["slots"], 2);
        assert_eq!(body["activeCalls"], 0);
        assert_eq!(body["inFlightCallbacks"], 0);
        assert_eq!(body["cacheHits"], 0);
        assert_eq!(body["cacheMisses"], 0);
        assert_eq!(body["slotWaitMsTotal"], 0.0);
    }
}
