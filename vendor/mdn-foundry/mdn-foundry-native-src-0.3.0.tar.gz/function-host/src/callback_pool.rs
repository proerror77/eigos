//! Loopback-only HTTP/1.1 Keep-Alive connection pool for runtime callbacks.
//!
//! Security and isolation invariants:
//! - Only connects to `127.0.0.1:<port>` (never parses arbitrary hosts or follows redirects).
//! - Each connection is popped exclusively before sending and only returned to the pool after
//!   a `200 OK` response body is completely read within `max_response_bytes` and the connection
//!   remains open without `Connection: close`.
//! - Any timeout, cancellation, non-200 status, oversize response, or I/O failure drops the
//!   connection immediately so no half-read response can ever leak into another call/token.
//! - Retries on a pooled connection ONLY when `hyper::client::conn::http1::SendRequest::try_send_request`
//!   returns the unsent request before serialization (guaranteeing zero duplicate side effects).

use std::collections::{HashMap, VecDeque};
use std::net::SocketAddr;
use std::sync::Mutex;
use std::time::{Duration, Instant};

use axum::body::Bytes;
use axum::http::{HeaderValue, Method, Request, StatusCode, Version, header};
use http_body_util::{BodyExt, Full, Limited};
use hyper::client::conn::http1::{self, SendRequest};
use hyper_util::rt::TokioIo;
use tokio::net::TcpStream;

const MAX_IDLE_PER_PORT: usize = 32;
const MAX_POOLED_PORTS: usize = 64;
const MAX_IDLE_AGE: Duration = Duration::from_secs(15);

#[derive(Debug)]
pub enum CallbackError {
    Deadline,
    Transport(String),
}

struct IdleConn {
    sender: SendRequest<Full<Bytes>>,
    idle_since: Instant,
}

pub struct CallbackPool {
    idle: Mutex<HashMap<u16, VecDeque<IdleConn>>>,
    max_idle_per_port: usize,
    max_idle_age: Duration,
    max_response_bytes: usize,
}

impl CallbackPool {
    pub fn new(max_response_bytes: usize) -> Self {
        Self::with_limits(max_response_bytes, MAX_IDLE_PER_PORT, MAX_IDLE_AGE)
    }

    pub fn with_limits(max_response_bytes: usize, max_idle_per_port: usize, max_idle_age: Duration) -> Self {
        Self {
            idle: Mutex::new(HashMap::new()),
            max_idle_per_port: max_idle_per_port.max(1),
            max_idle_age,
            max_response_bytes,
        }
    }

    /// Sends an HTTP/1.1 POST to `http://127.0.0.1:<port><path>` strictly bounded by `deadline`.
    pub async fn post(&self, port: u16, path: &str, body: String, deadline: Instant) -> Result<String, CallbackError> {
        if Instant::now() >= deadline {
            return Err(CallbackError::Deadline);
        }
        let body = Bytes::from(body);
        tokio::time::timeout_at(
            tokio::time::Instant::from_std(deadline),
            self.post_inner(port, path, body),
        )
        .await
        .map_err(|_| CallbackError::Deadline)?
    }

    async fn post_inner(&self, port: u16, path: &str, body: Bytes) -> Result<String, CallbackError> {
        let (sender, response) = self.send_with_reuse(port, path, body).await?;

        if response.status() != StatusCode::OK {
            // Drop `sender` without returning it to the pool so unread error bodies cannot desync keep-alive.
            return Err(CallbackError::Transport(format!("HTTP/1.1 {}", response.status())));
        }

        let server_wants_close = response.version() == Version::HTTP_10
            || response
                .headers()
                .get_all(header::CONNECTION)
                .iter()
                .any(|v| v.to_str().is_ok_and(|s| s.split(',').any(|tok| tok.trim().eq_ignore_ascii_case("close"))));

        if let Some(len) = response
            .headers()
            .get(header::CONTENT_LENGTH)
            .and_then(|v| v.to_str().ok())
            .and_then(|s| s.parse::<usize>().ok())
            && len > self.max_response_bytes
        {
            return Err(CallbackError::Transport(format!(
                "callback response exceeds {} bytes",
                self.max_response_bytes
            )));
        }

        let collected = Limited::new(response.into_body(), self.max_response_bytes)
            .collect()
            .await
            .map_err(|e| CallbackError::Transport(e.to_string()))?;

        let text = String::from_utf8(collected.to_bytes().to_vec())
            .map_err(|e| CallbackError::Transport(e.to_string()))?;

        // Return connection to the pool only after full framing succeeded and peer kept it alive.
        // Note: `send_with_reuse` awaits `sender.ready()` before reusing, so we do not require
        // `is_ready()` synchronously before the background connection task ticks.
        if !server_wants_close && !sender.is_closed() {
            self.put_idle(port, sender);
        }
        Ok(text)
    }

    async fn send_with_reuse(
        &self,
        port: u16,
        path: &str,
        body: Bytes,
    ) -> Result<(SendRequest<Full<Bytes>>, hyper::Response<hyper::body::Incoming>), CallbackError> {
        // Try idle pooled connections first (LIFO: freshest connection first).
        while let Some(mut sender) = self.pop_idle(port) {
            if sender.ready().await.is_err() {
                continue;
            }
            let req = build_request(port, path, body.clone())?;
            match sender.try_send_request(req).await {
                Ok(response) => return Ok((sender, response)),
                Err(err) => {
                    // Retry ONLY if hyper guarantees the request was never serialized on the socket.
                    if err.message().is_some() {
                        continue;
                    }
                    return Err(CallbackError::Transport(err.into_error().to_string()));
                }
            }
        }

        // No usable idle connection: establish a fresh loopback TCP connection.
        let stream = TcpStream::connect(SocketAddr::from(([127, 0, 0, 1], port)))
            .await
            .map_err(|e| CallbackError::Transport(e.to_string()))?;
        let _ = stream.set_nodelay(true);
        let (mut sender, conn) = http1::handshake(TokioIo::new(stream))
            .await
            .map_err(|e| CallbackError::Transport(e.to_string()))?;
        tokio::spawn(async move {
            let _ = conn.await;
        });
        sender
            .ready()
            .await
            .map_err(|e| CallbackError::Transport(e.to_string()))?;
        let req = build_request(port, path, body)?;
        let response = sender
            .send_request(req)
            .await
            .map_err(|e| CallbackError::Transport(e.to_string()))?;
        Ok((sender, response))
    }

    fn pop_idle(&self, port: u16) -> Option<SendRequest<Full<Bytes>>> {
        let now = Instant::now();
        let mut map = self.idle.lock().unwrap_or_else(|e| e.into_inner());
        let queue = map.get_mut(&port)?;
        while let Some(conn) = queue.pop_back() {
            if !conn.sender.is_closed() && now.saturating_duration_since(conn.idle_since) < self.max_idle_age {
                if queue.is_empty() {
                    map.remove(&port);
                }
                return Some(conn.sender);
            }
        }
        map.remove(&port);
        None
    }

    fn put_idle(&self, port: u16, sender: SendRequest<Full<Bytes>>) {
        let now = Instant::now();
        let mut map = self.idle.lock().unwrap_or_else(|e| e.into_inner());
        // Opportunistically purge stale/closed entries across ports when pool grows.
        if map.len() >= MAX_POOLED_PORTS && !map.contains_key(&port) {
            map.retain(|_, q| {
                q.retain(|c| !c.sender.is_closed() && now.saturating_duration_since(c.idle_since) < self.max_idle_age);
                !q.is_empty()
            });
            if map.len() >= MAX_POOLED_PORTS {
                if let Some(&evict_port) = map.keys().next() {
                    map.remove(&evict_port);
                }
            }
        }
        let queue = map.entry(port).or_default();
        queue.retain(|c| !c.sender.is_closed() && now.saturating_duration_since(c.idle_since) < self.max_idle_age);
        while queue.len() >= self.max_idle_per_port {
            queue.pop_front();
        }
        queue.push_back(IdleConn { sender, idle_since: now });
    }
}

fn build_request(port: u16, path: &str, body: Bytes) -> Result<Request<Full<Bytes>>, CallbackError> {
    let host = HeaderValue::from_str(&format!("127.0.0.1:{port}"))
        .map_err(|e| CallbackError::Transport(e.to_string()))?;
    let content_len = HeaderValue::from(body.len());
    Request::builder()
        .method(Method::POST)
        .uri(path)
        .version(Version::HTTP_11)
        .header(header::HOST, host)
        .header(header::CONTENT_TYPE, HeaderValue::from_static("application/json"))
        .header(header::CONTENT_LENGTH, content_len)
        .header(header::CONNECTION, HeaderValue::from_static("keep-alive"))
        .body(Full::new(body))
        .map_err(|e| CallbackError::Transport(e.to_string()))
}

#[cfg(test)]
mod tests {
    use std::sync::Arc;
    use std::sync::atomic::{AtomicUsize, Ordering};

    use tokio::io::{AsyncReadExt, AsyncWriteExt};
    use tokio::net::TcpListener;

    use super::*;

    async fn spawn_http_server(
        close_after_first: bool,
        delay: Duration,
        body_override: Option<String>,
        status: &'static str,
    ) -> (u16, Arc<AtomicUsize>, Arc<AtomicUsize>) {
        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let port = listener.local_addr().unwrap().port();
        let connections = Arc::new(AtomicUsize::new(0));
        let requests = Arc::new(AtomicUsize::new(0));
        let conns_bg = connections.clone();
        let reqs_bg = requests.clone();

        tokio::spawn(async move {
            loop {
                let Ok((mut socket, _)) = listener.accept().await else { break };
                conns_bg.fetch_add(1, Ordering::SeqCst);
                let reqs = reqs_bg.clone();
                let body_override = body_override.clone();
                tokio::spawn(async move {
                    let mut buf = Vec::new();
                    let mut tmp = [0u8; 4096];
                    loop {
                        // Read until headers end.
                        let header_end = loop {
                            if let Some(pos) = buf.windows(4).position(|w| w == b"\r\n\r\n") {
                                break pos + 4;
                            }
                            let n = match socket.read(&mut tmp).await {
                                Ok(0) | Err(_) => return,
                                Ok(n) => n,
                            };
                            buf.extend_from_slice(&tmp[..n]);
                        };
                        let headers = String::from_utf8_lossy(&buf[..header_end]);
                        let content_len: usize = headers
                            .lines()
                            .find_map(|line| {
                                let (k, v) = line.split_once(':')?;
                                k.trim().eq_ignore_ascii_case("content-length").then(|| v.trim().parse().ok()).flatten()
                            })
                            .unwrap_or(0);
                        while buf.len() < header_end + content_len {
                            let n = match socket.read(&mut tmp).await {
                                Ok(0) | Err(_) => return,
                                Ok(n) => n,
                            };
                            buf.extend_from_slice(&tmp[..n]);
                        }
                        let req_body = String::from_utf8_lossy(&buf[header_end..header_end + content_len]).into_owned();
                        buf.drain(..header_end + content_len);

                        reqs.fetch_add(1, Ordering::SeqCst);
                        if !delay.is_zero() {
                            tokio::time::sleep(delay).await;
                        }
                        let resp_body = body_override.clone().unwrap_or(req_body);
                        let conn_hdr = if close_after_first { "close" } else { "keep-alive" };
                        let resp = format!(
                            "HTTP/1.1 {status}\r\nContent-Type: application/json\r\nContent-Length: {}\r\nConnection: {conn_hdr}\r\n\r\n{resp_body}",
                            resp_body.len()
                        );
                        if socket.write_all(resp.as_bytes()).await.is_err() {
                            return;
                        }
                        if close_after_first {
                            return;
                        }
                    }
                });
            }
        });
        (port, connections, requests)
    }

    #[tokio::test]
    async fn reuses_keep_alive_connection_across_many_callbacks() {
        let (port, connections, requests) = spawn_http_server(false, Duration::ZERO, None, "200 OK").await;
        let pool = CallbackPool::new(1 << 20);
        let deadline = Instant::now() + Duration::from_secs(5);
        for i in 0..25 {
            let payload = format!(r#"{{"token":"tok-{i}","op":"get"}}"#);
            let answer = pool.post(port, "/ontology", payload.clone(), deadline).await.unwrap();
            assert_eq!(answer, payload);
        }
        assert_eq!(requests.load(Ordering::SeqCst), 25);
        assert_eq!(connections.load(Ordering::SeqCst), 1);
    }

    #[tokio::test]
    async fn handles_server_connection_close_cleanly() {
        let (port, connections, requests) = spawn_http_server(true, Duration::ZERO, None, "200 OK").await;
        let pool = CallbackPool::new(1 << 20);
        let deadline = Instant::now() + Duration::from_secs(5);
        for i in 0..4 {
            let payload = format!(r#"{{"i":{i}}}"#);
            let answer = pool.post(port, "/ontology", payload.clone(), deadline).await.unwrap();
            assert_eq!(answer, payload);
        }
        assert_eq!(requests.load(Ordering::SeqCst), 4);
        assert_eq!(connections.load(Ordering::SeqCst), 4);
    }

    #[tokio::test]
    async fn timeout_drops_socket_without_dirty_reads_on_next_request() {
        // First request times out on slow response; second request with fast deadline gets clean response.
        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let port = listener.local_addr().unwrap().port();
        let call_num = Arc::new(AtomicUsize::new(0));
        let call_bg = call_num.clone();
        tokio::spawn(async move {
            while let Ok((mut socket, _)) = listener.accept().await {
                let n = call_bg.fetch_add(1, Ordering::SeqCst);
                tokio::spawn(async move {
                    let mut buf = [0u8; 4096];
                    let _ = socket.read(&mut buf).await;
                    if n == 0 {
                        tokio::time::sleep(Duration::from_millis(200)).await;
                        let body = r#"{"result":"stale"}"#;
                        let _ = socket.write_all(format!(
                            "HTTP/1.1 200 OK\r\nContent-Length: {}\r\nConnection: keep-alive\r\n\r\n{body}",
                            body.len()
                        ).as_bytes()).await;
                    } else {
                        let body = r#"{"result":"fresh"}"#;
                        let _ = socket.write_all(format!(
                            "HTTP/1.1 200 OK\r\nContent-Length: {}\r\nConnection: keep-alive\r\n\r\n{body}",
                            body.len()
                        ).as_bytes()).await;
                    }
                });
            }
        });

        let pool = CallbackPool::new(1 << 20);
        let err = pool.post(port, "/ontology", "{}".into(), Instant::now() + Duration::from_millis(40)).await.unwrap_err();
        assert!(matches!(err, CallbackError::Deadline));

        let fresh = pool.post(port, "/ontology", "{}".into(), Instant::now() + Duration::from_secs(2)).await.unwrap();
        assert_eq!(fresh, r#"{"result":"fresh"}"#);
    }

    #[tokio::test]
    async fn recovers_when_server_closes_idle_connection_between_requests() {
        let listener = TcpListener::bind("127.0.0.1:0").await.unwrap();
        let port = listener.local_addr().unwrap().port();
        let connections = Arc::new(AtomicUsize::new(0));
        let conns_bg = connections.clone();
        tokio::spawn(async move {
            while let Ok((mut socket, _)) = listener.accept().await {
                let n = conns_bg.fetch_add(1, Ordering::SeqCst);
                tokio::spawn(async move {
                    let mut buf = [0u8; 4096];
                    let read = socket.read(&mut buf).await.unwrap_or(0);
                    if read == 0 {
                        return;
                    }
                    let body = format!(r#"{{"conn":{n}}}"#);
                    let resp = format!(
                        "HTTP/1.1 200 OK\r\nContent-Length: {}\r\nConnection: keep-alive\r\n\r\n{body}",
                        body.len()
                    );
                    let _ = socket.write_all(resp.as_bytes()).await;
                    if n == 0 {
                        // Simulate server-side keepAliveTimeout expiring while client holds idle socket.
                        tokio::time::sleep(Duration::from_millis(15)).await;
                        drop(socket);
                    }
                });
            }
        });

        let pool = CallbackPool::new(1 << 20);
        let first = pool.post(port, "/ontology", "{}".into(), Instant::now() + Duration::from_secs(2)).await.unwrap();
        assert_eq!(first, r#"{"conn":0}"#);
        // Wait for server to close the idle socket.
        tokio::time::sleep(Duration::from_millis(40)).await;
        let second = pool.post(port, "/ontology", "{}".into(), Instant::now() + Duration::from_secs(2)).await.unwrap();
        assert_eq!(second, r#"{"conn":1}"#);
        assert_eq!(connections.load(Ordering::SeqCst), 2);
    }

    #[tokio::test]
    async fn concurrent_requests_never_mix_responses_across_tokens() {
        let (port, _, requests) = spawn_http_server(false, Duration::from_millis(10), None, "200 OK").await;
        let pool = Arc::new(CallbackPool::new(1 << 20));
        let mut tasks = Vec::new();
        for i in 0..16 {
            let pool = pool.clone();
            tasks.push(tokio::spawn(async move {
                let payload = format!(r#"{{"token":"tok-{i:02}","seq":{i}}}"#);
                let answer = pool
                    .post(port, "/ontology", payload.clone(), Instant::now() + Duration::from_secs(5))
                    .await
                    .unwrap();
                assert_eq!(answer, payload);
            }));
        }
        for task in tasks {
            task.await.unwrap();
        }
        assert_eq!(requests.load(Ordering::SeqCst), 16);
    }

    #[tokio::test]
    async fn rejects_oversize_response_and_non_200() {
        let (port_big, _, _) = spawn_http_server(false, Duration::ZERO, Some("x".repeat(2048)), "200 OK").await;
        let pool = CallbackPool::new(1024);
        let err = pool.post(port_big, "/ontology", "{}".into(), Instant::now() + Duration::from_secs(2)).await.unwrap_err();
        assert!(matches!(err, CallbackError::Transport(_)));

        let (port_err, _, _) = spawn_http_server(false, Duration::ZERO, Some(r#"{"error":"bad"}"#.into()), "500 Internal Server Error").await;
        let err = pool.post(port_err, "/ontology", "{}".into(), Instant::now() + Duration::from_secs(2)).await.unwrap_err();
        assert!(matches!(err, CallbackError::Transport(_)));
    }
}
