//! O(1) bounded LRU cache and per-key async singleflight locks for component loading and compilation.

use std::collections::HashMap;
use std::sync::{Arc, Mutex};

use tokio::sync::{Mutex as AsyncMutex, OwnedMutexGuard};

struct Node<V> {
    key: String,
    value: V,
    prev: Option<usize>,
    next: Option<usize>,
}

/// Bounded LRU cache with O(1) lookup, insertion and eviction.
pub struct LruCache<V> {
    index: HashMap<String, usize>,
    nodes: Vec<Option<Node<V>>>,
    free: Vec<usize>,
    head: Option<usize>,
    tail: Option<usize>,
    capacity: usize,
}

impl<V: Clone> LruCache<V> {
    pub fn new(capacity: usize) -> Self {
        let capacity = capacity.max(1);
        Self {
            index: HashMap::with_capacity(capacity),
            nodes: Vec::with_capacity(capacity),
            free: Vec::new(),
            head: None,
            tail: None,
            capacity,
        }
    }

    pub fn len(&self) -> usize {
        self.index.len()
    }

    pub fn capacity(&self) -> usize {
        self.capacity
    }

    pub fn get(&mut self, key: &str) -> Option<V> {
        let &slot = self.index.get(key)?;
        self.move_to_front(slot);
        Some(self.nodes[slot].as_ref().expect("indexed node exists").value.clone())
    }

    pub fn insert(&mut self, key: String, value: V) {
        if let Some(&slot) = self.index.get(&key) {
            self.nodes[slot].as_mut().expect("indexed node exists").value = value;
            self.move_to_front(slot);
            return;
        }
        while self.index.len() >= self.capacity {
            if !self.evict_tail() {
                break;
            }
        }
        let slot = self.alloc_node(Node { key: key.clone(), value, prev: None, next: None });
        self.index.insert(key, slot);
        self.push_front(slot);
    }

    fn alloc_node(&mut self, node: Node<V>) -> usize {
        if let Some(slot) = self.free.pop() {
            self.nodes[slot] = Some(node);
            slot
        } else {
            let slot = self.nodes.len();
            self.nodes.push(Some(node));
            slot
        }
    }

    fn unlink(&mut self, slot: usize) {
        let (prev, next) = {
            let node = self.nodes[slot].as_mut().expect("linked node exists");
            (node.prev.take(), node.next.take())
        };
        match prev {
            Some(p) => self.nodes[p].as_mut().expect("prev node exists").next = next,
            None => self.head = next,
        }
        match next {
            Some(n) => self.nodes[n].as_mut().expect("next node exists").prev = prev,
            None => self.tail = prev,
        }
    }

    fn push_front(&mut self, slot: usize) {
        let old_head = self.head;
        {
            let node = self.nodes[slot].as_mut().expect("node exists");
            node.prev = None;
            node.next = old_head;
        }
        match old_head {
            Some(h) => self.nodes[h].as_mut().expect("head exists").prev = Some(slot),
            None => self.tail = Some(slot),
        }
        self.head = Some(slot);
    }

    fn move_to_front(&mut self, slot: usize) {
        if self.head == Some(slot) {
            return;
        }
        self.unlink(slot);
        self.push_front(slot);
    }

    fn evict_tail(&mut self) -> bool {
        let Some(slot) = self.tail else { return false };
        self.unlink(slot);
        if let Some(node) = self.nodes[slot].take() {
            self.index.remove(&node.key);
            self.free.push(slot);
            true
        } else {
            false
        }
    }
}

struct LockEntry {
    mutex: Arc<AsyncMutex<()>>,
    refs: usize,
}

/// Per-key async singleflight lock table that automatically reclaims unused key entries.
pub struct KeyLocks {
    entries: Arc<Mutex<HashMap<String, LockEntry>>>,
}

/// Holds exclusive per-key ownership; drops the mutex permit before releasing the key refcount.
pub struct KeyLockGuard {
    _permit: OwnedMutexGuard<()>,
    _ref: KeyRefGuard,
}

struct KeyRefGuard {
    entries: Arc<Mutex<HashMap<String, LockEntry>>>,
    key: String,
}

impl Drop for KeyRefGuard {
    fn drop(&mut self) {
        let mut map = self.entries.lock().unwrap_or_else(|e| e.into_inner());
        if let Some(entry) = map.get_mut(&self.key) {
            entry.refs -= 1;
            if entry.refs == 0 {
                map.remove(&self.key);
            }
        }
    }
}

impl KeyLocks {
    pub fn new() -> Self {
        Self { entries: Arc::new(Mutex::new(HashMap::new())) }
    }

    pub async fn lock(&self, key: &str) -> KeyLockGuard {
        let (mutex, ref_guard) = {
            let mut map = self.entries.lock().unwrap_or_else(|e| e.into_inner());
            let entry = map.entry(key.to_string()).or_insert_with(|| LockEntry {
                mutex: Arc::new(AsyncMutex::new(())),
                refs: 0,
            });
            entry.refs += 1;
            (
                entry.mutex.clone(),
                KeyRefGuard { entries: self.entries.clone(), key: key.to_string() },
            )
        };
        let permit = mutex.lock_owned().await;
        KeyLockGuard { _permit: permit, _ref: ref_guard }
    }

    #[cfg(test)]
    pub fn tracked_keys(&self) -> usize {
        self.entries.lock().unwrap_or_else(|e| e.into_inner()).len()
    }
}

#[cfg(test)]
mod tests {
    use std::sync::atomic::{AtomicUsize, Ordering};
    use std::time::Duration;

    use super::*;

    #[test]
    fn lru_evicts_least_recently_used_and_reuses_slots() {
        let mut cache = LruCache::new(3);
        cache.insert("a".into(), 1);
        cache.insert("b".into(), 2);
        cache.insert("c".into(), 3);
        assert_eq!(cache.len(), 3);

        // Touch "a" so "b" becomes least recently used.
        assert_eq!(cache.get("a"), Some(1));
        cache.insert("d".into(), 4);

        assert_eq!(cache.len(), 3);
        assert_eq!(cache.get("b"), None);
        assert_eq!(cache.get("a"), Some(1));
        assert_eq!(cache.get("c"), Some(3));
        assert_eq!(cache.get("d"), Some(4));

        // Overwrite existing key does not grow or evict.
        cache.insert("c".into(), 30);
        assert_eq!(cache.len(), 3);
        assert_eq!(cache.get("c"), Some(30));
        // Now order MRU->LRU is c, d, a. Inserting e evicts a.
        cache.insert("e".into(), 5);
        assert_eq!(cache.get("a"), None);
        assert_eq!(cache.get("c"), Some(30));
        assert_eq!(cache.get("d"), Some(4));
        assert_eq!(cache.get("e"), Some(5));
        assert_eq!(cache.nodes.len(), 3);
    }

    #[test]
    fn lru_capacity_one() {
        let mut cache = LruCache::new(1);
        cache.insert("a".into(), 1);
        assert_eq!(cache.get("a"), Some(1));
        cache.insert("b".into(), 2);
        assert_eq!(cache.get("a"), None);
        assert_eq!(cache.get("b"), Some(2));
        assert_eq!(cache.len(), 1);
    }

    #[tokio::test]
    async fn singleflight_serializes_same_key_and_runs_distinct_keys_in_parallel() {
        let locks = Arc::new(KeyLocks::new());
        let loads = Arc::new(AtomicUsize::new(0));
        let value = Arc::new(Mutex::new(None::<u32>));

        let mut tasks = Vec::new();
        for _ in 0..8 {
            let locks = locks.clone();
            let loads = loads.clone();
            let value = value.clone();
            tasks.push(tokio::spawn(async move {
                let _guard = locks.lock("same").await;
                if let Some(existing) = *value.lock().unwrap() {
                    return existing;
                }
                tokio::time::sleep(Duration::from_millis(25)).await;
                loads.fetch_add(1, Ordering::SeqCst);
                *value.lock().unwrap() = Some(42);
                42
            }));
        }
        for task in tasks {
            assert_eq!(task.await.unwrap(), 42);
        }
        assert_eq!(loads.load(Ordering::SeqCst), 1);
        assert_eq!(locks.tracked_keys(), 0);

        // Distinct keys run concurrently.
        let started = std::time::Instant::now();
        let (a, b) = tokio::join!(
            async {
                let _g = locks.lock("k1").await;
                tokio::time::sleep(Duration::from_millis(40)).await;
            },
            async {
                let _g = locks.lock("k2").await;
                tokio::time::sleep(Duration::from_millis(40)).await;
            }
        );
        let _ = (a, b);
        assert!(started.elapsed() < Duration::from_millis(75), "distinct keys serialized: {:?}", started.elapsed());
        assert_eq!(locks.tracked_keys(), 0);
    }

    #[tokio::test]
    async fn singleflight_cleans_up_on_waiter_cancellation() {
        let locks = Arc::new(KeyLocks::new());
        let first = locks.lock("cancel-me").await;
        let locks_clone = locks.clone();
        let waiter = tokio::spawn(async move {
            let _g = locks_clone.lock("cancel-me").await;
        });
        tokio::time::sleep(Duration::from_millis(10)).await;
        waiter.abort();
        let _ = waiter.await;
        drop(first);
        assert_eq!(locks.tracked_keys(), 0);
    }
}
