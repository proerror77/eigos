import { type ClientOptions } from './client.js';
import type { OntologyBindings as OntologyBindingsForPA } from './typed-client.js';
import type { ActionCall } from '../ontology/invocation.js';
export interface AgentTask<T = unknown> {
    id: string;
    contextId: string;
    status: {
        state: string;
        timestamp?: string;
    };
    artifacts?: {
        parts: {
            data?: T;
        }[];
    }[];
    metadata?: {
        error?: string;
    };
}
export declare class PersonalAgentClient<B extends OntologyBindingsForPA = OntologyBindingsForPA> {
    private readonly options;
    private readonly http;
    constructor(options: ClientOptions);
    private rpc;
    private send;
    submit(messageId: string, text: string, contextId?: string, signal?: AbortSignal): Promise<AgentTask<unknown>>;
    submitAction<K extends keyof B['actions'] & string>(messageId: string, action: K, input: B['actions'][NoInfer<K>], contextId?: string, signal?: AbortSignal): Promise<AgentTask<unknown>>;
    completeWithAction(messageId: string, action: ActionCall, read: {
        function: string;
        resultParameter: string;
    }, contextId?: string, signal?: AbortSignal): Promise<AgentTask<unknown>>;
    get<T = unknown>(id: string, signal?: AbortSignal): Promise<AgentTask<T>>;
    respond(task: Pick<AgentTask, 'id' | 'contextId'>, messageId: string, requestId: string, response: Record<string, unknown>, signal?: AbortSignal): Promise<AgentTask<unknown>>;
    cancel(id: string, signal?: AbortSignal): Promise<AgentTask<unknown>>;
    /** Member credentials use the permission-filtered MCP surface for Ontology reads. */
    query<K extends keyof B['objects'] & string>(type: K, where?: Record<string, string | number | boolean | null>): Promise<{
        items: {
            ref: {
                type: K;
                id: string;
            };
            revision: number;
            properties: Partial<B['objects'][K]>;
        }[];
        cursor?: string;
    }>;
}
