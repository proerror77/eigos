import { Client, StreamableHTTPClientTransport } from '@modelcontextprotocol/client';
import { OntologyClient } from './client.js';
export class PersonalAgentClient {
    options;
    http;
    constructor(options) {
        this.options = options;
        this.http = new OntologyClient(options);
    }
    async rpc(method, params, signal) {
        const id = crypto.randomUUID();
        const body = await this.http.request('a2a', { jsonrpc: '2.0', id, method, params }, signal, { 'A2A-Version': '1.0' });
        if (body.id !== id || body.error || body.result === undefined)
            throw new Error(body.error?.message ?? 'Invalid Agent response');
        return body.result;
    }
    async send(messageId, contextId, parts, taskId, signal) {
        return (await this.rpc('SendMessage', {
            message: { messageId, role: 'ROLE_USER', contextId, taskId, parts },
        }, signal)).task;
    }
    submit(messageId, text, contextId, signal) {
        return this.send(messageId, contextId, [{ text }], undefined, signal);
    }
    submitAction(messageId, action, input, contextId, signal) {
        return this.send(messageId, contextId, [{ data: { action: { action, input } } }], undefined, signal);
    }
    completeWithAction(messageId, action, read, contextId, signal) {
        return this.send(messageId, contextId, [{ data: { action, read } }], undefined, signal);
    }
    get(id, signal) { return this.rpc('GetTask', { id }, signal); }
    respond(task, messageId, requestId, response, signal) {
        return this.send(messageId, task.contextId, [{ data: { paResponse: { requestId, response } } }], task.id, signal);
    }
    cancel(id, signal) { return this.rpc('CancelTask', { id }, signal); }
    /** Member credentials use the permission-filtered MCP surface for Ontology reads. */
    async query(type, where = {}) {
        const mcp = new Client({ name: 'mdn-foundry-sdk', version: '0.1.0' });
        const token = typeof this.options.token === 'function' ? await this.options.token() : this.options.token;
        try {
            await mcp.connect(new StreamableHTTPClientTransport(new URL('mcp', this.options.baseUrl.replace(/\/?$/, '/')), {
                requestInit: { headers: { Authorization: 'Bearer ' + token } }, fetch: this.options.fetch,
            }));
            const res = await mcp.callTool({ name: 'query_ontology', arguments: { query: { type, where } } });
            const first = res.content[0];
            if (res.isError || first?.type !== 'text')
                throw new Error(first?.type === 'text' ? first.text : 'Invalid query response');
            return JSON.parse(first.text);
        }
        finally {
            await mcp.close();
        }
    }
}
