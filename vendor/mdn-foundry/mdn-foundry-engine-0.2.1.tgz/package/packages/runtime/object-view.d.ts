import type { ObjectData } from '../ontology/schema.js';
import type { Access } from './access.js';
import type { PublishedOntology } from './metadata.js';
/** An object as `view` shows it, as Object Set evaluation and aggregation project each member. */
export declare function projectView(access: Access, model: PublishedOntology, object: ObjectData, view?: string): ObjectData;
