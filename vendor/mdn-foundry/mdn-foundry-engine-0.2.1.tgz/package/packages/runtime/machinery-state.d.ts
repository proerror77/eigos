import { Ontology } from '../ontology/model.js';
import type { Database } from './database.js';
type StateFields = Record<string, {
    values: string[];
    required: boolean;
}>;
type StateContract = Record<string, StateFields>;
/** Compile the same stored state properties that the published ProcessLog types observe. */
export declare function machineryStateContract(model: Ontology): StateContract;
export declare function initializeMachineryStates(db: Database): Promise<void>;
export {};
