import { z } from 'zod';
import { type ObjectRef } from '../ontology/schema.js';
import { Access } from './access.js';
import type { Database, Sql } from './database.js';
import type { Metadata } from './metadata.js';
import { processTriggerSchema } from './process-automation.js';
/**
 * Notifications of process rules (Machinery plan, "状态与停留超时通知"). A notification rule is a process rule whose
 * reaction is a message to its owner instead of a workflow or an Action. Its scan queues one notification per committed
 * transition, due when the transition happens or, for a dwell rule, once the dwell has passed. The Indexer delivers due
 * notifications to the owner's inbox, which the workbench and the owner's PA read, if the instance is still where the
 * transition left it; otherwise it drops them. A transition never notifies twice: the queue is unique per rule, revision
 * and transition, like workflow runs.
 */
export declare const notifySchema: z.ZodObject<{
    message: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export declare const notificationsSchema: z.ZodObject<{
    unread: z.ZodDefault<z.ZodBoolean>;
    cursor: z.ZodOptional<z.ZodString>;
    limit: z.ZodDefault<z.ZodNumber>;
}, z.core.$strict>;
export declare const readNotificationSchema: z.ZodObject<{
    id: z.ZodUUID;
}, z.core.$strict>;
export declare function initializeProcessNotifications(db: Database): Promise<void>;
export type QueuedNotification = {
    owner: string;
    ontology: string;
    ruleId: string;
    requestId: string;
    object: ObjectRef;
    trigger: z.output<typeof processTriggerSchema>;
    scopes: readonly string[];
    message: string | undefined;
    availableAt: Date;
};
/** Queues a notification in the transaction of the rule scan that found its transition. */
export declare function queueNotification(db: Database, client: Sql, item: QueuedNotification): Promise<void>;
export declare class ProcessNotifications {
    private readonly db;
    private readonly metadata;
    constructor(db: Database, metadata: Metadata);
    /**
     * Delivers one due notification, or drops it: when the rule's owner can no longer read the instance, or a dwell rule's
     * instance left the state before the dwell passed. Returns whether there was one.
     */
    deliverOne(): Promise<boolean>;
    /** The caller's delivered notifications, newest first. */
    list(access: Access, raw: unknown): Promise<{
        items: {
            id: string;
            rule: string;
            object: {
                type: string;
                id: string;
            };
            process: {
                type: string;
                from?: string | null | undefined;
                to?: string | undefined;
                dwellSeconds?: number | undefined;
            };
            sequence: string;
            message: string | null;
            dueAt: Date;
            deliveredAt: Date | null;
            readAt: Date | null;
        }[];
        cursor: string | null;
    }>;
    /** Marks one of the caller's notifications as read. */
    read(access: Access, raw: unknown): Promise<{
        id: string;
        read: boolean;
    }>;
}
