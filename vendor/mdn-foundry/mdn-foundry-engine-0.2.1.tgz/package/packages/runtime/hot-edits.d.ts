import type { ObjectRef } from '../ontology/schema.js';
import type { Access } from './access.js';
import type { Sql } from './database.js';
export type PriorEdits = Map<string, {
    digest: string;
    result: ObjectRef;
}>;
export type HotEdit = {
    requestId: string;
    access: Access;
    signal: AbortSignal;
    fields: string[];
    revision: number;
    buffered: boolean;
    verify(client: Sql): Promise<void>;
    run(client?: Sql, prior?: PriorEdits): Promise<ObjectRef>;
};
type Batch = (items: readonly HotEdit[]) => Promise<ObjectRef[]>;
/** Let synchronous arrivals share the next event-loop turn, then drain bounded commits by object. */
export declare class HotEdits {
    private readonly lanes;
    submit(key: string, edit: HotEdit, batch: Batch): Promise<ObjectRef>;
    private drain;
}
export {};
