import type { Ontology } from '../ontology/model.js';
import type { Database, Sql } from './database.js';
import type { ProjectionTransform } from './metadata.js';
/** Migrate the reconstructable source/edit layers, then verify they reproduce the prepared object. */
export declare function migrateProjectionState(db: Database, from: string, to: string, model: Ontology, transform: ProjectionTransform, client: Sql): Promise<void>;
