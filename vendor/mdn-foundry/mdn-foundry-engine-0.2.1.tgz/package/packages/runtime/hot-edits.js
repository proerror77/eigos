import { AsyncLocalStorage } from 'node:async_hooks';
import { recordOperationEvent } from '../core/operation-timing.js';
/** Let synchronous arrivals share the next event-loop turn, then drain bounded commits by object. */
export class HotEdits {
    lanes = new Map();
    submit(key, edit, batch) {
        const existing = this.lanes.get(key), lane = existing ?? [];
        const context = AsyncLocalStorage.snapshot();
        const result = new Promise((resolve, reject) => {
            edit.signal.throwIfAborted();
            const abort = () => {
                const index = lane.indexOf(item);
                if (index >= 0)
                    lane.splice(index, 1);
                reject(edit.signal.reason);
            };
            const item = { ...edit, resolve, reject, verify: client => context(edit.verify, client),
                run: (client, prior) => context(edit.run, client, prior), begin: () => edit.signal.removeEventListener('abort', abort) };
            lane.push(item);
            edit.signal.addEventListener('abort', abort, { once: true });
        });
        if (!existing && lane.length) {
            this.lanes.set(key, lane);
            setImmediate(() => { void this.drain(key, lane, batch); });
        }
        return result;
    }
    async drain(key, lane, batch) {
        while (lane.length) {
            const group = [lane.shift()], fields = new Set(group[0].fields);
            while (lane.length && group.length < 32) {
                const next = lane[0];
                if (next.fields.some(field => fields.has(field)) && next.revision !== group.at(-1).revision + 1)
                    break;
                group.push(lane.shift());
                for (const field of next.fields)
                    fields.add(field);
            }
            for (const item of group)
                item.begin();
            if (group.length > 1) {
                try {
                    const results = await batch(group);
                    group.forEach((item, index) => item.resolve(results[index]));
                    recordOperationEvent('hot_edit_batch', { requests: group.length });
                    continue;
                }
                catch {
                    // The transaction rolled back. Recheck each original request and deliver its own outcome.
                }
            }
            for (const item of group) {
                try {
                    item.resolve(await item.run());
                }
                catch (error) {
                    item.reject(error);
                }
            }
        }
        this.lanes.delete(key);
    }
}
