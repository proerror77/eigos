import type { ObjectData } from '../ontology/schema.js';
import type { Objects } from './objects.js';
/** One evaluation shares authorized reads and detects cycles across linked and local properties. */
export declare class DerivedProperties {
    private readonly graph;
    private readonly objects;
    private readonly values;
    private readonly visibility;
    private readonly linked;
    private operations;
    constructor(graph: Objects);
    private linkKey;
    /**
     * Reads ahead what these objects' derived properties need, in a few statements instead of a few per object:
     * the visibility of each derived property, and each linked step for all objects together. Evaluation then
     * uses these reads and falls back to its per-object reads for anything they do not cover.
     */
    prefetch(objects: readonly ObjectData[]): Promise<void>;
    private consume;
    enrich(object: ObjectData): Promise<ObjectData>;
    private base;
    private field;
    private calculate;
}
