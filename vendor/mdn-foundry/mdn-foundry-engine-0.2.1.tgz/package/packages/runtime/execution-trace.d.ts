import { z } from 'zod';
import { Access, type Requirement } from './access.js';
import type { Database, Sql } from './database.js';
import type { Metadata } from './metadata.js';
declare const events: z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"source">;
    source: z.ZodString;
    callId: z.ZodOptional<z.ZodString>;
    receipt: z.ZodObject<{
        type: z.ZodString;
        id: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"action-read">;
    function: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"document">;
    ref: z.ZodObject<{
        type: z.ZodString;
        id: z.ZodString;
    }, z.core.$strict>;
    revision: z.ZodNumber;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"model">;
    state: z.ZodEnum<{
        canceled: "canceled";
        completed: "completed";
        failed: "failed";
        paused: "paused";
        started: "started";
    }>;
    model: z.ZodString;
    attempt: z.ZodOptional<z.ZodString>;
    durationMs: z.ZodOptional<z.ZodNumber>;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"egress">;
    state: z.ZodEnum<{
        allowed: "allowed";
        blocked: "blocked";
    }>;
    policyDigest: z.ZodString;
    documentRefs: z.ZodOptional<z.ZodArray<z.ZodObject<{
        type: z.ZodString;
        id: z.ZodString;
    }, z.core.$strict>>>;
    code: z.ZodOptional<z.ZodEnum<{
        access_revoked: "access_revoked";
        egress_policy_denied: "egress_policy_denied";
        invalid_context: "invalid_context";
        tool_permission_denied: "tool_permission_denied";
    }>>;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"proposal">;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"workflow">;
    runId: z.ZodUUID;
    state: z.ZodEnum<{
        expired: "expired";
        failed: "failed";
        "waiting-approval": "waiting-approval";
    }>;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"approval">;
    revision: z.ZodNumber;
    snapshot: z.ZodString;
    reviewer: z.ZodOptional<z.ZodString>;
    decision: z.ZodOptional<z.ZodLiteral<"rejected">>;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"merge">;
    revision: z.ZodNumber;
    approvalSnapshot: z.ZodOptional<z.ZodString>;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"map-place-correction">;
    side: z.ZodEnum<{
        destination: "destination";
        origin: "origin";
    }>;
    previousRelease: z.ZodString;
    previousState: z.ZodEnum<{
        canceled: "canceled";
        "input-required": "input-required";
    }>;
}, z.core.$strict>], "kind">;
export type TraceEvent = z.infer<typeof events>;
declare const traceAnchor: z.ZodObject<{
    owner: z.ZodString;
    release: z.ZodString;
    projection: z.ZodString;
    taskId: z.ZodOptional<z.ZodUUID>;
    scenarioId: z.ZodOptional<z.ZodUUID>;
    requestId: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type TraceAnchor = z.infer<typeof traceAnchor>;
export declare const executionTraceSchema: z.ZodObject<{
    taskId: z.ZodOptional<z.ZodUUID>;
    requestId: z.ZodOptional<z.ZodString>;
    after: z.ZodDefault<z.ZodString>;
    limit: z.ZodDefault<z.ZodNumber>;
}, z.core.$strict>;
export declare function initializeExecutionTrace(db: Database): Promise<void>;
/** Add causal evidence to the owning transaction without copying the operation's payload. */
export declare function appendTrace(db: Database, anchor: TraceAnchor, data: TraceEvent, client?: Sql, requirements?: readonly Requirement[]): Promise<void>;
export declare class ExecutionTrace {
    private readonly db;
    private readonly metadata;
    constructor(db: Database, metadata: Metadata);
    read(access: Access, ontology: string, raw: unknown): Promise<{
        taskId: string | null;
        state: string | undefined;
        release: string;
        projection: string;
        events: ({
            kind: "source";
            source: string;
            callId?: string | undefined;
            receipt: {
                type: string;
                id: string;
            };
            sequence: string;
            at: Date;
            release: string;
            projection: string;
            taskId: string | null;
            scenarioId: string | null;
            requestId: string | null;
            evidence?: string | undefined;
        } | {
            kind: "action-read";
            function: string;
            sequence: string;
            at: Date;
            release: string;
            projection: string;
            taskId: string | null;
            scenarioId: string | null;
            requestId: string | null;
            evidence?: string | undefined;
        } | {
            kind: "document";
            ref: {
                type: string;
                id: string;
            };
            revision: number;
            sequence: string;
            at: Date;
            release: string;
            projection: string;
            taskId: string | null;
            scenarioId: string | null;
            requestId: string | null;
            evidence?: string | undefined;
        } | {
            kind: "model";
            state: "canceled" | "completed" | "failed" | "paused" | "started";
            model: string;
            attempt?: string | undefined;
            durationMs?: number | undefined;
            sequence: string;
            at: Date;
            release: string;
            projection: string;
            taskId: string | null;
            scenarioId: string | null;
            requestId: string | null;
            evidence?: string | undefined;
        } | {
            kind: "egress";
            state: "allowed" | "blocked";
            policyDigest: string;
            documentRefs?: {
                type: string;
                id: string;
            }[] | undefined;
            code?: "access_revoked" | "egress_policy_denied" | "invalid_context" | "tool_permission_denied" | undefined;
            sequence: string;
            at: Date;
            release: string;
            projection: string;
            taskId: string | null;
            scenarioId: string | null;
            requestId: string | null;
            evidence?: string | undefined;
        } | {
            kind: "proposal";
            sequence: string;
            at: Date;
            release: string;
            projection: string;
            taskId: string | null;
            scenarioId: string | null;
            requestId: string | null;
            evidence?: string | undefined;
        } | {
            kind: "workflow";
            runId: string;
            state: "expired" | "failed" | "waiting-approval";
            sequence: string;
            at: Date;
            release: string;
            projection: string;
            taskId: string | null;
            scenarioId: string | null;
            requestId: string | null;
            evidence?: string | undefined;
        } | {
            kind: "approval";
            revision: number;
            snapshot: string;
            reviewer?: string | undefined;
            decision?: "rejected" | undefined;
            sequence: string;
            at: Date;
            release: string;
            projection: string;
            taskId: string | null;
            scenarioId: string | null;
            requestId: string | null;
            evidence?: string | undefined;
        } | {
            kind: "merge";
            revision: number;
            approvalSnapshot?: string | undefined;
            sequence: string;
            at: Date;
            release: string;
            projection: string;
            taskId: string | null;
            scenarioId: string | null;
            requestId: string | null;
            evidence?: string | undefined;
        } | {
            kind: "map-place-correction";
            side: "destination" | "origin";
            previousRelease: string;
            previousState: "canceled" | "input-required";
            sequence: string;
            at: Date;
            release: string;
            projection: string;
            taskId: string | null;
            scenarioId: string | null;
            requestId: string | null;
            evidence?: string | undefined;
        })[];
        actions: {
            requestId: string;
            taskId: string | null;
            action: string;
            release: string;
            projection: string;
            executorKind: string | null;
            executorId: string | null;
            appliedAt: Date;
            journaled: boolean;
            resultRef?: {
                type: string;
                id: string;
            } | undefined;
        }[];
        editHistory: {
            requestId: string;
            sequence: string;
        }[];
        sourceCalls: {
            callId: string;
            state: string;
        }[];
        effects: {
            id: string;
            requestId: string;
            state: string;
            attempts: number;
        }[];
        external: {
            receiptId: string;
            requestId: string | null;
            effectId: string | null;
            state: string;
            dispatchedAt: Date;
            updatedAt: Date;
        }[];
        next?: string | undefined;
    }>;
    private root;
    private actions;
    private outcomes;
    private referencesVisible;
    private visibleObject;
}
export {};
