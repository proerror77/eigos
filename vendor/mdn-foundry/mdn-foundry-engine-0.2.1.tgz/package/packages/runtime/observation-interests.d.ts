import { z } from 'zod';
import { type ObjectRef } from '../ontology/schema.js';
import { Access } from './access.js';
import type { Database } from './database.js';
import { Metadata, type PublishedOntology } from './metadata.js';
import { Objects } from './objects.js';
import type { Task } from './tasks.js';
export declare const startInterestSchema: z.ZodObject<{
    requestId: z.ZodString;
    object: z.ZodObject<{
        type: z.ZodString;
        id: z.ZodString;
    }, z.core.$strict>;
    deadline: z.ZodISODateTime;
    phases: z.ZodArray<z.ZodObject<{
        process: z.ZodString;
        evidenceProperty: z.ZodOptional<z.ZodString>;
        complete: z.ZodArray<z.ZodString>;
        stop: z.ZodDefault<z.ZodArray<z.ZodString>>;
        name: z.ZodString;
        action: z.ZodOptional<z.ZodString>;
        wait: z.ZodOptional<z.ZodObject<{
            maxSilenceSeconds: z.ZodNumber;
        }, z.core.$strict>>;
        parameters: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
        maxSilenceSeconds: z.ZodOptional<z.ZodNumber>;
        intervalSeconds: z.ZodDefault<z.ZodNumber>;
        attach: z.ZodOptional<z.ZodObject<{
            process: z.ZodString;
            evidenceProperty: z.ZodOptional<z.ZodString>;
            complete: z.ZodArray<z.ZodString>;
            stop: z.ZodDefault<z.ZodArray<z.ZodString>>;
            link: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const listInterestsSchema: z.ZodObject<{
    object: z.ZodOptional<z.ZodObject<{
        type: z.ZodString;
        id: z.ZodString;
    }, z.core.$strict>>;
    cursor: z.ZodOptional<z.ZodUUID>;
}, z.core.$strict>;
export declare const cancelInterestSchema: z.ZodObject<{
    id: z.ZodUUID;
}, z.core.$strict>;
export declare function initializeObservationInterests(db: Database): Promise<void>;
export declare class ObservationInterests {
    private readonly db;
    private readonly metadata;
    private readonly schedules;
    constructor(db: Database, metadata?: Metadata);
    private validate;
    private checkStates;
    private arguments;
    start(access: Access, model: PublishedOntology, raw: unknown): Promise<{
        id: string;
        object: {
            type: string;
            id: string;
        };
        phases: {
            name: string;
            process: string;
            action: string | undefined;
            complete: string[];
            stop: string[];
            attach?: {
                process: string;
                evidenceProperty?: string | undefined;
                complete: string[];
                stop: string[];
                link: string;
            } | undefined;
            wait?: {
                maxSilenceSeconds: number;
            } | undefined;
            intervalSeconds: number;
            evidenceProperty: string | undefined;
            maxSilenceSeconds: number | undefined;
            limits: {
                sources?: string[] | undefined;
                maxChecks?: number | undefined;
                monitorUntil?: string | undefined;
            };
        }[];
        phaseIndex: number;
        status: string;
        reason: string | null;
        action: string | undefined;
        attached: {
            type: string;
            id: string;
        } | null;
        nextCheckAt: any;
        nextReviewAt: Date | null;
        checkDeadline: any;
        deadline: Date;
        lastObservedAt: Date | null;
        lastState: string | null;
    }>;
    private schedule;
    private readRow;
    private unavailable;
    list(access: Access, model: PublishedOntology, raw: unknown): Promise<{
        items: ({
            id: string;
            object: {
                type: string;
                id: string;
            };
            phases: {
                name: string;
                process: string;
                action: string | undefined;
                complete: string[];
                stop: string[];
                attach?: {
                    process: string;
                    evidenceProperty?: string | undefined;
                    complete: string[];
                    stop: string[];
                    link: string;
                } | undefined;
                wait?: {
                    maxSilenceSeconds: number;
                } | undefined;
                intervalSeconds: number;
                evidenceProperty: string | undefined;
                maxSilenceSeconds: number | undefined;
                limits: {
                    sources?: string[] | undefined;
                    maxChecks?: number | undefined;
                    monitorUntil?: string | undefined;
                };
            }[];
            phaseIndex: number;
            status: string;
            reason: string | null;
            action: string | undefined;
            attached: {
                type: string;
                id: string;
            } | null;
            nextCheckAt: any;
            nextReviewAt: Date | null;
            checkDeadline: any;
            deadline: Date;
            lastObservedAt: Date | null;
            lastState: string | null;
        } | {
            id: string;
            object: {
                type: string;
                id: string;
            };
            phases: never[];
            phaseIndex: number;
            status: string;
            reason: string;
            action: null;
            attached: null;
            nextCheckAt: null;
            nextReviewAt: null;
            checkDeadline: null;
            deadline: Date;
            lastObservedAt: null;
            lastState: null;
        })[];
        cursor: string | null;
    }>;
    private finish;
    cancel(access: Access, model: PublishedOntology, raw: unknown): Promise<{
        id: string;
        status: string;
        object: {
            type: string;
            id: string;
        };
    }>;
    private stateEvidence;
    private stopOwned;
    private drive;
    private defer;
    scanOne(): Promise<boolean>;
    assertScheduled(graph: Objects, task: Task): Promise<{
        id: string;
        deadline: string;
    }>;
    attach(graph: Objects, id: string, task: Task, attachment: {
        target: ObjectRef;
        scheduleId: string;
    }): Promise<void>;
    assertActive(graph: Objects, id: string, target: ObjectRef): Promise<{
        id: string;
        deadline: string;
    }>;
}
