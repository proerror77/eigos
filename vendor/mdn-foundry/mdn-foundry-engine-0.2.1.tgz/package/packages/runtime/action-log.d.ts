import { z } from 'zod';
import type { Access } from './access.js';
import type { Database } from './database.js';
import type { Metadata } from './metadata.js';
export declare const actionLogSchema: z.ZodObject<{
    action: z.ZodOptional<z.ZodString>;
    release: z.ZodOptional<z.ZodString>;
    cursor: z.ZodOptional<z.ZodString>;
    limit: z.ZodDefault<z.ZodNumber>;
}, z.core.$strict>;
export type ActionLogInput = z.input<typeof actionLogSchema>;
export type ActionLogEntry = {
    requestId: string;
    action: string;
    appliedAt: string;
    executorKind: string | null;
};
export declare function listActionLog(db: Database, metadata: Metadata, access: Access, ontology: string, input: ActionLogInput): Promise<{
    release: string;
    items: ActionLogEntry[];
    cursor?: string | undefined;
}>;
