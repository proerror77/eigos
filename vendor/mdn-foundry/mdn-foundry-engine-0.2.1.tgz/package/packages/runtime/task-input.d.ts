import { z } from 'zod';
export declare const routeInputSchema: z.ZodObject<{
    city: z.ZodString;
    origin: z.ZodString;
    destination: z.ZodString;
    serviceClass: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type RouteInput = z.infer<typeof routeInputSchema>;
export declare const submitSchema: z.ZodObject<{
    requestId: z.ZodString;
    message: z.ZodString;
    route: z.ZodOptional<z.ZodObject<{
        city: z.ZodString;
        origin: z.ZodString;
        destination: z.ZodString;
        serviceClass: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    classification: z.ZodOptional<z.ZodObject<{
        sensitivity: z.ZodEnum<{
            CONFIDENTIAL: "CONFIDENTIAL";
            INTERNAL: "INTERNAL";
            PUBLIC: "PUBLIC";
            RESTRICTED: "RESTRICTED";
        }>;
        compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>>;
    learnHotelWorkflow: z.ZodOptional<z.ZodLiteral<true>>;
    replayHotelWorkflow: z.ZodOptional<z.ZodObject<{
        workflowId: z.ZodUUID;
        checkIn: z.ZodISODate;
    }, z.core.$strict>>;
    conversationId: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export declare const taskActionSchema: z.ZodObject<{
    action: z.ZodObject<{
        scenarioId: z.ZodOptional<z.ZodUUID>;
        input: z.ZodRecord<z.ZodString, z.ZodUnknown>;
        action: z.ZodOptional<z.ZodString>;
        interface: z.ZodOptional<z.ZodObject<{
            object: z.ZodOptional<z.ZodObject<{
                type: z.ZodString;
                id: z.ZodString;
            }, z.core.$strict>>;
            implementation: z.ZodOptional<z.ZodString>;
            type: z.ZodString;
            action: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    read: z.ZodOptional<z.ZodObject<{
        function: z.ZodString;
        resultParameter: z.ZodString;
        input: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const storedInputSchema: z.ZodObject<{
    requestId: z.ZodString;
    message: z.ZodString;
    route: z.ZodOptional<z.ZodObject<{
        city: z.ZodString;
        origin: z.ZodString;
        destination: z.ZodString;
        serviceClass: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    classification: z.ZodOptional<z.ZodObject<{
        sensitivity: z.ZodEnum<{
            CONFIDENTIAL: "CONFIDENTIAL";
            INTERNAL: "INTERNAL";
            PUBLIC: "PUBLIC";
            RESTRICTED: "RESTRICTED";
        }>;
        compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>>;
    learnHotelWorkflow: z.ZodOptional<z.ZodLiteral<true>>;
    replayHotelWorkflow: z.ZodOptional<z.ZodObject<{
        workflowId: z.ZodUUID;
        checkIn: z.ZodISODate;
    }, z.core.$strict>>;
    conversationId: z.ZodOptional<z.ZodString>;
    memberAccess: z.ZodOptional<z.ZodLiteral<true>>;
    paClient: z.ZodOptional<z.ZodString>;
    actionInvocation: z.ZodOptional<z.ZodObject<{
        action: z.ZodObject<{
            scenarioId: z.ZodOptional<z.ZodUUID>;
            input: z.ZodRecord<z.ZodString, z.ZodUnknown>;
            action: z.ZodOptional<z.ZodString>;
            interface: z.ZodOptional<z.ZodObject<{
                object: z.ZodOptional<z.ZodObject<{
                    type: z.ZodString;
                    id: z.ZodString;
                }, z.core.$strict>>;
                implementation: z.ZodOptional<z.ZodString>;
                type: z.ZodString;
                action: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
        read: z.ZodOptional<z.ZodObject<{
            function: z.ZodString;
            resultParameter: z.ZodString;
            input: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    places: z.ZodOptional<z.ZodObject<{
        origin: z.ZodOptional<z.ZodObject<{
            type: z.ZodString;
            id: z.ZodString;
        }, z.core.$strict>>;
        destination: z.ZodOptional<z.ZodObject<{
            type: z.ZodString;
            id: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    placeAmendments: z.ZodOptional<z.ZodObject<{
        origin: z.ZodOptional<z.ZodObject<{
            address: z.ZodOptional<z.ZodString>;
            landmark: z.ZodOptional<z.ZodString>;
            name: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        destination: z.ZodOptional<z.ZodObject<{
            address: z.ZodOptional<z.ZodString>;
            landmark: z.ZodOptional<z.ZodString>;
            name: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    mapPlaceCorrections: z.ZodOptional<z.ZodObject<{
        origin: z.ZodOptional<z.ZodObject<{
            requestId: z.ZodUUID;
            fingerprint: z.ZodString;
            placeId: z.ZodString;
            name: z.ZodString;
            city: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        destination: z.ZodOptional<z.ZodObject<{
            requestId: z.ZodUUID;
            fingerprint: z.ZodString;
            placeId: z.ZodString;
            name: z.ZodString;
            city: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    rideCity: z.ZodOptional<z.ZodString>;
    rideOrigin: z.ZodOptional<z.ZodString>;
    rideDestination: z.ZodOptional<z.ZodString>;
    placeContinuation: z.ZodOptional<z.ZodObject<{
        requestId: z.ZodString;
        action: z.ZodString;
        input: z.ZodRecord<z.ZodString, z.ZodUnknown>;
        read: z.ZodOptional<z.ZodObject<{
            function: z.ZodString;
            resultParameter: z.ZodString;
            input: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
        }, z.core.$strict>>;
        pending: z.ZodOptional<z.ZodObject<{
            id: z.ZodUUID;
            capability: z.ZodString;
            purpose: z.ZodEnum<{
                authorization: "authorization";
                "execution-result": "execution-result";
                input: "input";
                observation: "observation";
            }>;
        }, z.core.$strict>>;
        waitingFor: z.ZodOptional<z.ZodEnum<{
            city: "city";
            destination: "destination";
            origin: "origin";
            "pa-request": "pa-request";
            "retry-source": "retry-source";
        }>>;
        receipts: z.ZodOptional<z.ZodObject<{
            origin: z.ZodObject<{
                type: z.ZodString;
                id: z.ZodString;
            }, z.core.$strict>;
            destination: z.ZodObject<{
                type: z.ZodString;
                id: z.ZodString;
            }, z.core.$strict>;
        }, z.core.$strict>>;
        pickup: z.ZodOptional<z.ZodObject<{
            provider: z.ZodLiteral<"Amap">;
            fetchedAt: z.ZodISODateTime;
            inputCoordinateSystem: z.ZodEnum<{
                gcj02: "gcj02";
                wgs84: "wgs84";
            }>;
            coordinateSystem: z.ZodLiteral<"gcj02">;
            conversion: z.ZodEnum<{
                already_gcj02: "already_gcj02";
                converted_by_amap: "converted_by_amap";
            }>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare function parseSubmission(raw: unknown): {
    requestId: string;
    message: string;
    route?: {
        city: string;
        origin: string;
        destination: string;
        serviceClass?: string | undefined;
    } | undefined;
    classification?: {
        sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
        compartments: string[];
    } | undefined;
    learnHotelWorkflow?: true | undefined;
    replayHotelWorkflow?: {
        workflowId: string;
        checkIn: string;
    } | undefined;
    conversationId?: string | undefined;
};
export declare const taskOptions: z.ZodObject<{
    route: z.ZodOptional<z.ZodObject<{
        city: z.ZodString;
        origin: z.ZodString;
        destination: z.ZodString;
        serviceClass: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    classification: z.ZodOptional<z.ZodObject<{
        sensitivity: z.ZodEnum<{
            CONFIDENTIAL: "CONFIDENTIAL";
            INTERNAL: "INTERNAL";
            PUBLIC: "PUBLIC";
            RESTRICTED: "RESTRICTED";
        }>;
        compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>>;
    learnHotelWorkflow: z.ZodOptional<z.ZodLiteral<true>>;
    replayHotelWorkflow: z.ZodOptional<z.ZodObject<{
        workflowId: z.ZodUUID;
        checkIn: z.ZodISODate;
    }, z.core.$strict>>;
}, z.core.$strip>;
