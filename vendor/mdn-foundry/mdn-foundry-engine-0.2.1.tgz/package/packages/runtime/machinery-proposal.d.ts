import type { z } from 'zod';
import type { MachineryModel } from '../ontology/process-definition.js';
import type { Access, Requirement } from './access.js';
import type { Database } from './database.js';
import { analyzeMachinery, machineryAnalysisSchema } from './machinery-analysis.js';
import type { PublishedOntology } from './metadata.js';
type Query = z.output<typeof machineryAnalysisSchema>;
type Report = Awaited<ReturnType<typeof analyzeMachinery>>;
declare function summarize(report: Report, proposed: MachineryModel): {
    cases: number;
    deviationCases: number;
    candidateDeviationCases: number;
    bottlenecks: {
        state: string;
        completedP95Ms: number | null;
    }[];
    affectedEdges: {
        from: string | null;
        to: string | null;
        observedCases: number;
    }[];
};
export type ProposalEvidence = {
    release: string;
    process: string;
    modelDigest: string;
    owner: string;
    contributors: string[];
    query: Query;
    visibility: string;
    requirements: Requirement[];
    summary: ReturnType<typeof summarize>;
};
export declare function analyzeProposal(db: Database, access: Access, model: PublishedOntology, query: Query, type: string, proposed: MachineryModel): Promise<ProposalEvidence>;
export declare function visibleProposalEvidence(db: Database, access: Access, model: PublishedOntology, evidence: ProposalEvidence, current?: MachineryModel): Promise<{
    process: string;
    release: string;
    from: string;
    to: string;
    scope: 'earlier_revision';
} | {
    process: string;
    release: string;
    from: string;
    to: string;
    scope: 'recorded';
    summary: {
        cases: number;
        deviationCases: number;
        candidateDeviationCases: number;
        bottlenecks: {
            state: string;
            completedP95Ms: number | null;
        }[];
        affectedEdges: {
            from: string | null;
            to: string | null;
            observedCases: number;
        }[];
    };
} | {
    process: string;
    release: string;
    from: string;
    to: string;
    scope: 'restricted';
} | {
    process: string;
    release: string;
    from: string;
    to: string;
    scope: 'reviewer';
    summary: {
        cases: number;
        deviationCases: number;
        candidateDeviationCases: number;
        bottlenecks: {
            state: string;
            completedP95Ms: number | null;
        }[];
        affectedEdges: {
            from: string | null;
            to: string | null;
            observedCases: number;
        }[];
    };
} | {
    process: string;
    release: string;
    from: string;
    to: string;
    scope: 'unavailable';
}>;
export {};
