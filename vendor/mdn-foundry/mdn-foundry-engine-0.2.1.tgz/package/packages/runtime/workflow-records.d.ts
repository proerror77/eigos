import type { Database, Sql } from './database.js';
interface WorkflowIdentity {
    id: string;
    owner: string;
    ontology: string;
}
export declare function readWorkflowRecord(db: Database, identity: WorkflowIdentity, client?: Sql, kind?: string | null, lock?: boolean): Promise<{
    body: unknown;
    revision: string;
} | undefined>;
export declare function insertWorkflowRecord(db: Database, client: Sql, record: WorkflowIdentity & {
    name: string;
    body: unknown;
}): Promise<import("pg").default.QueryResult<{
    revision: string;
}>>;
export {};
