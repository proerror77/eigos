import { implementationDigest } from './implementation.js';
import { Database } from './database.js';
import { Metadata } from './metadata.js';
export function openInstallation(installation) {
    if (!process.env.DATABASE_URL)
        throw new Error('DATABASE_URL is required');
    const db = new Database(process.env.DATABASE_URL, process.env.EIGOS_PG_SCHEMA, installation.runtimeId(implementationDigest()), process.env.QUERY_DATABASE_URL);
    return { installation, db, metadata: new Metadata(db, installation.model.document.id) };
}
export async function checkInstallation(installation, metadata, runtime) {
    const active = await metadata.active();
    if (installation.expectedDefinition && active.digest !== installation.expectedDefinition &&
        !(installation.allowReviewedDefinitions && await metadata.reviewedFrom(active, installation.expectedDefinition)))
        throw new Error('Activate the definition selected in the installation manifest before starting this role');
    metadata.checkBindings(active, runtime);
}
