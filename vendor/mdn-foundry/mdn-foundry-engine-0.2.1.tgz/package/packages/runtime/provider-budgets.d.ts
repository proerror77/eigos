import { z } from 'zod';
import type { Database, Sql } from './database.js';
export declare const providerRatesSchema: z.ZodRecord<z.ZodString, z.ZodObject<{
    perMinute: z.ZodNumber;
    burst: z.ZodNumber;
}, z.core.$strict>>;
export type ProviderRates = z.output<typeof providerRatesSchema>;
declare const providerQuotasSchema: z.ZodRecord<z.ZodString, z.ZodObject<{
    period: z.ZodEnum<{
        day: "day";
        month: "month";
    }>;
    calls: z.ZodNumber;
}, z.core.$strict>>;
type ProviderQuotas = z.output<typeof providerQuotasSchema>;
/** The rates of EIGOS_PROVIDER_RATES, a JSON object by source name; providers not named are not limited. */
export declare function configuredProviderRates(text?: string | undefined): ProviderRates;
/** A provider call over its owner's budget. A Worker defers the task until `until`; a request answers 429. */
export declare class ProviderBudgetExceeded extends Error {
    readonly provider: string;
    readonly until: string;
    constructor(provider: string, until: string);
}
export declare function initializeProviderBudgets(db: Database): Promise<void>;
export declare class ProviderBudgets {
    private readonly db;
    private readonly rates;
    private readonly quotas;
    constructor(db: Database, rates?: ProviderRates, quotas?: ProviderQuotas);
    /** Admits one attempt across the configured budgets, or throws with the time to try again. */
    take(owner: string, provider: string): Promise<void>;
    /** Storing the current UTC window per period bounds the table to two rows per owner and provider. */
    private takeQuota;
}
export declare function withActionWriteBudget<T>(ontology: string, action: string, run: () => Promise<T>): Promise<T>;
/** Source reads and external Action writes use independent buckets. */
export declare class ActionWriteBudgets {
    private readonly db;
    private readonly rates;
    constructor(db: Database, text?: string | undefined);
    take(owner: string, client?: Sql, action?: string | undefined): Promise<void>;
}
export {};
