import { z } from 'zod';
import { type ObjectRef } from '../ontology/schema.js';
import { type FunctionHandler } from './functions.js';
import { Access } from './access.js';
import { Database } from './database.js';
import type { PublishedOntology } from './metadata.js';
import type { Actions } from './actions.js';
export declare const objectViewSchema: z.ZodObject<{
    type: z.ZodString;
    title: z.ZodString;
    properties: z.ZodArray<z.ZodString>;
    links: z.ZodArray<z.ZodString>;
    actions: z.ZodArray<z.ZodString>;
    revision: z.ZodNumber;
}, z.core.$strict>;
export declare const graphSchema: z.ZodObject<{
    object: z.ZodObject<{
        type: z.ZodString;
        id: z.ZodString;
    }, z.core.$strict>;
    depth: z.ZodDefault<z.ZodNumber>;
    limit: z.ZodDefault<z.ZodNumber>;
}, z.core.$strict>;
export declare const mapSchema: z.ZodObject<{
    query: z.ZodObject<{
        type: z.ZodString;
        where: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodNumber, z.ZodBoolean, z.ZodNull]>>>;
        filter: z.ZodOptional<z.ZodPipe<z.ZodUnknown, z.ZodType<import("./query-filter.js").Predicate, unknown, z.core.$ZodTypeInternals<import("./query-filter.js").Predicate, unknown>>>>;
        orderBy: z.ZodOptional<z.ZodArray<z.ZodObject<{
            property: z.ZodString;
            direction: z.ZodDefault<z.ZodEnum<{
                asc: "asc";
                desc: "desc";
            }>>;
        }, z.core.$strict>>>;
        intervalOverlap: z.ZodOptional<z.ZodObject<{
            start: z.ZodString;
            end: z.ZodString;
            from: z.ZodISODateTime;
            until: z.ZodISODateTime;
            includeUnknown: z.ZodOptional<z.ZodBoolean>;
        }, z.core.$strict>>;
        select: z.ZodOptional<z.ZodArray<z.ZodString>>;
        limit: z.ZodDefault<z.ZodNumber>;
        cursor: z.ZodOptional<z.ZodString>;
        from: z.ZodOptional<z.ZodObject<{
            object: z.ZodObject<{
                type: z.ZodString;
                id: z.ZodString;
            }, z.core.$strict>;
            link: z.ZodString;
            as: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    property: z.ZodDefault<z.ZodString>;
}, z.core.$strict>;
export declare function initializeApplications(db: Database): Promise<void>;
export declare class Applications {
    private readonly db;
    constructor(db: Database);
    saveView(access: Access, model: PublishedOntology, raw: unknown): Promise<{
        type: string;
        title: string;
        properties: string[];
        links: string[];
        actions: string[];
        revision: any;
    }>;
    view(access: Access, model: PublishedOntology, type: string): Promise<{
        type: string;
        title: string;
        revision: number;
        properties: string[];
        links: string[];
        actions: string[];
    }>;
    graph(access: Access, model: PublishedOntology, raw: unknown): Promise<{
        nodes: import("../ontology/schema.js").ObjectData[];
        edges: unknown[];
    }>;
    map(access: Access, model: PublishedOntology, raw: unknown): Promise<{
        cursor?: string;
        items: {
            ref: ObjectRef;
            revision: number;
            properties: Record<string, unknown>;
            latitude: number;
            longitude: number;
            coordinateSystem: {};
        }[];
    }>;
    upload(access: Access, model: PublishedOntology, actions: Actions, bytes: Buffer, raw: unknown): Promise<{
        type: string;
        id: string;
    }>;
    download(access: Access, model: PublishedOntology, id: string): Promise<import("pg").QueryResultRow>;
}
export declare function applicationFunctions(db: Database): ReadonlyMap<string, FunctionHandler>;
