import { z } from 'zod';
declare const grantValue: z.ZodObject<{
    accessToken: z.ZodString;
    refreshToken: z.ZodString;
    validUntil: z.ZodNumber;
}, z.core.$strict>;
export type SourceOAuthGrant = z.infer<typeof grantValue>;
/** Produces a versioned encrypted bundle for local Source credential provisioning. */
export declare function sealSourceSecrets(raw: unknown, key: Uint8Array): {
    format: "eigos-component-source-secrets-v1";
    nonce: string;
    tag: string;
    ciphertext: string;
};
/** Decrypts only for one use. The files and key remain outside the Function host and Ontology definition. */
export declare class ComponentSourceSecrets {
    private readonly bundleFile;
    private readonly keyFile;
    constructor(bundleFile: string, keyFile: string);
    get(name: string): Promise<string>;
    sealGrant(identity: string, grant: SourceOAuthGrant): Promise<Buffer<ArrayBuffer>>;
    openGrant(identity: string, stored: Buffer): Promise<{
        accessToken: string;
        refreshToken: string;
        validUntil: number;
    }>;
    private withKey;
}
export {};
