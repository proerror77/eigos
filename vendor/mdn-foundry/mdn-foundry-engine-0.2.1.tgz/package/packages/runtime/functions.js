import { Conflict, FunctionFailed, InvalidInput, NotFound, ServiceUnavailable, SourceReadFailure, digest } from '../core/identity.js';
import { timeOperation } from '../core/operation-timing.js';
import { validator } from '../ontology/model.js';
import { objectRefSchema } from '../ontology/schema.js';
import { legacySourceEvidence } from '../ontology/source-evidence.js';
export const withScenarioPARead = (handler) => Object.assign(handler, { scenarioPARead: true });
export const withScenarioEvaluation = (handler) => Object.assign(handler, { scenarioEvaluation: true });
const contract = ({ parameters, returns, source, edits, dependencies, kind }) => digest({ parameters, returns, source, edits, ...(dependencies ? { dependencies } : {}), ...(kind ? { kind } : {}) });
const key = (definition) => JSON.stringify([definition.apiName, definition.version ?? null]);
/** The result an Action's component edit Function stages before it runs; its commit replaces it with the real one. */
const pendingResult = { type: 'PendingFunctionResult', id: 'pending' };
/** A component Function's binding follows from its definition, so every runtime with a function host agrees on it. */
const componentBinding = (definition, sourceBinding, modelBinding) => digest({ contract: contract(definition), version: definition.version, implementation: definition.implementation,
    ...(sourceBinding ? { sourceBinding } : {}), ...(modelBinding ? { modelBinding } : {}) });
export class Functions {
    components;
    budgets;
    invocations;
    registered = new Map();
    constructor(handlers, definitions, versions = [], components, budgets, invocations) {
        this.components = components;
        this.budgets = budgets;
        this.invocations = invocations;
        for (const definition of definitions) {
            if (definition.version)
                continue;
            const handler = handlers.get(definition.apiName);
            if (handler) {
                const current = contract(definition), legacyReturns = legacySourceEvidence(definition.returns);
                this.registered.set(key(definition), { contract: current, binding: current, handler,
                    ...(legacyReturns !== definition.returns ? { legacy: contract({ ...definition, returns: legacyReturns }) } : {}) });
            }
        }
        for (const entry of versions) {
            const identity = key(entry.definition);
            if (!entry.implementationId || this.registered.has(identity))
                throw new Error('Function versions require unique immutable implementation identities');
            this.registered.set(identity, { contract: contract(entry.definition), binding: digest({ contract: contract(entry.definition), version: entry.definition.version, implementation: entry.implementationId }), handler: entry.handler });
        }
    }
    versions() {
        return [...this.registered].map(([identity, entry]) => {
            const [name, version] = JSON.parse(identity);
            return { name, version, binding: entry.binding };
        });
    }
    bindings(model) {
        return Object.fromEntries(model.resolvedDocument.functionTypes.map(fn => {
            if (fn.implementation) {
                const sourceBinding = fn.source ? this.componentSourceBinding(fn.source) : undefined;
                return [fn.apiName, componentBinding(fn, sourceBinding, this.components?.modelBinding(fn.implementation.models))];
            }
            const entry = this.registered.get(key(fn));
            const reply = contract(fn);
            if (!entry || entry.contract !== reply && entry.legacy !== reply)
                throw new Error(`Function implementation is unavailable or incompatible: ${fn.apiName}`);
            return [fn.apiName, entry.legacy === reply ? reply : entry.binding];
        }));
    }
    /** Checks a release's component Functions before it is prepared. */
    async checkRelease(model) {
        if (!model.resolvedDocument.functionTypes.some(fn => fn.implementation))
            return;
        if (!this.components)
            throw new Conflict('Component Functions are unavailable in this runtime');
        await this.components.check(model);
    }
    async formatWebhook(model, name, input, access, signal) {
        access.function(model, name);
        const definition = model.functions.get(name);
        if (!this.components || !definition?.implementation || definition.source || definition.edits ||
            model.bindings.functions[name] !== componentBinding(definition))
            throw new Conflict('Published webhook formatter is unavailable');
        const parameters = validator(definition.parameters).parse(input);
        // A formatter receives only the Action's mapped input. There is no callback session.
        const output = await this.components.invoke(name, definition.implementation, parameters, signal);
        signal.throwIfAborted();
        return validator(definition.returns).parse(output);
    }
    supportsScenarioEvaluation(model, name) {
        const definition = model.functions.get(name);
        // A component Function reads its input and, through its call's own Objects, the evaluated Scenario.
        if (definition?.implementation)
            return !definition.source;
        return Boolean(definition && !definition.source && this.registered.get(key(definition))?.handler.scenarioEvaluation);
    }
    requireScenarioEvaluation(model, name) {
        if (!this.supportsScenarioEvaluation(model, name))
            throw new Conflict(`Function is unavailable for offline Scenario evaluation: ${name}`);
    }
    async invoke(model, name, input, context) {
        const access = context.objects.access;
        access.function(model, name);
        const definition = model.functions.get(name), entry = definition && this.registered.get(key(definition));
        if (!definition)
            throw new NotFound(`Function is unavailable: ${name}`);
        if (definition.implementation)
            return await this.invokeComponent(model, definition, input, context);
        if (!entry)
            throw new Error(`Published Function implementation is unavailable: ${name}`);
        const reply = contract(definition), binding = entry.legacy === reply ? reply : entry.binding;
        if ((!definition.version && model.runtimeId !== access.runtimeId) || model.bindings.functions[name] !== binding ||
            reply !== entry.contract && reply !== entry.legacy)
            throw new Conflict('Historical Function implementation is unavailable in this runtime');
        if (context.scenarioEvaluation)
            this.requireScenarioEvaluation(model, name);
        if (model.scenario && definition.source && !(entry.handler.scenarioPARead && definition.edits && context.edit &&
            context.execution?.task.cognitive_context?.scenarioId === model.scenario))
            throw new Conflict('Read external sources before opening a scenario; scenario Functions only use Ontology data');
        if (definition.edits && !context.edit)
            throw new InvalidInput('Ontology edit Functions must be invoked through an Action');
        if (definition.source) {
            await access.refresh();
            access.source(model, definition.source);
        }
        context.signal.throwIfAborted();
        const parameters = validator(definition.parameters).parse(input);
        if (definition.source && this.budgets) {
            await this.budgets.take(access.principal.owner, definition.source);
            context.signal.throwIfAborted();
        }
        return this.measure(model, definition, context, async () => {
            const output = await timeOperation('function', async () => entry.handler(parameters, definition.edits ? context : {
                ...context, edit: undefined, validateScenarioAction: undefined, assertDispatch: undefined, deferEffect: undefined,
            }), name);
            context.signal.throwIfAborted();
            await access.refresh(context.scenarioEvaluation?.client);
            const result = validator(definition.returns).safeParse(output);
            if (result.success)
                return result.data;
            if (definition.source)
                throw new SourceReadFailure('Source result does not match its published contract', { cause: result.error });
            throw new Error('Function result does not match its published contract', { cause: result.error });
        });
    }
    measure(model, definition, context, run) {
        return this.invocations
            ? this.invocations.measure(model, definition.apiName, definition.version, context.objects.access.principal, context.signal, run)
            : run();
    }
    componentSourceBinding(source) {
        if (!this.components)
            throw new ServiceUnavailable('Component HTTP Sources are unavailable');
        return this.components.sourceBinding(source);
    }
    /** A Function implemented by a WebAssembly component: the function host runs it on the validated parameters. */
    async invokeComponent(model, definition, input, context) {
        const name = definition.apiName;
        const source = definition.source ? { name: definition.source, binding: this.componentSourceBinding(definition.source) } : undefined;
        if (model.bindings.functions[name] !== componentBinding(definition, source?.binding, this.components?.modelBinding(definition.implementation?.models)))
            throw new Conflict('Historical Function implementation is unavailable in this runtime');
        if (!this.components)
            throw new ServiceUnavailable(`Component Functions are unavailable in this runtime: ${name}`);
        if (definition.edits && !context.edit)
            throw new InvalidInput('Ontology edit Functions must be invoked through an Action');
        context.signal.throwIfAborted();
        const parameters = validator(definition.parameters).parse(input);
        if (definition.edits) {
            // As Palantir's staged writes: the Function runs inside the Action's commit, so its reads, queries and aggregations
            // see its own edits, and all of them commit with the Action or not at all.
            return context.edit(pendingResult, objects => this.measure(model, definition, context, async (metrics) => {
                const output = await timeOperation('function', () => this.components.invoke(name, definition.implementation, parameters, context.signal, { ...context, objects }, { writer: objects, metrics }), name);
                const result = validator(definition.returns).safeParse(output);
                if (!result.success)
                    throw new FunctionFailed(`${name} returned a result that does not match its published contract`, 'contract', { cause: result.error });
                return objectRefSchema.parse(result.data);
            }));
        }
        if (source) {
            if (model.scenario || context.scenarioEvaluation)
                throw new Conflict('Read external sources before opening a scenario');
            const access = context.objects.access;
            await access.refresh();
            access.source(model, source.name);
            await this.budgets?.take(access.principal.owner, source.name);
            context.signal.throwIfAborted();
        }
        return this.measure(model, definition, context, async (metrics) => {
            const output = await timeOperation('function', () => this.components.invoke(name, definition.implementation, parameters, context.signal, context, { source, metrics }), name);
            context.signal.throwIfAborted();
            await context.objects.access.refresh(context.scenarioEvaluation?.client);
            const result = validator(definition.returns).safeParse(output);
            if (result.success)
                return result.data;
            throw new FunctionFailed(`${name} returned a result that does not match its published contract`, 'contract', { cause: result.error });
        });
    }
}
