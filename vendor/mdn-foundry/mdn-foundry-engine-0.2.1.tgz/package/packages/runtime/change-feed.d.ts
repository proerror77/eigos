import type { Ontology } from '../ontology/model.js';
import type { ObjectRef } from '../ontology/schema.js';
import type { Database, Sql } from './database.js';
import { queryFields } from './objects.js';
/**
 * Commit-ordered reads of an owner's committed changes for consumers that keep their own position.
 *
 * A position is a commit number of `change_commits`. An owner's commits are numbered in the order they become visible,
 * so a consumer that has read every commit up to N has seen everything the owner committed before N; a commit
 * still in progress is numbered later. Each read is bounded by a window of commits, and the caller stores the
 * returned end as its next position in the same transaction as the work it did.
 */
/** The owner's last numbered commit visible to this transaction, `'0'` when none. */
export declare function latestCommit(db: Database, owner: string, client: Sql): Promise<string>;
/** What a consumer's answer depends on: changes outside it cannot change the answer. */
export type ChangeFootprint = {
    /** Object types whose committed edits can change the answer. */
    types: string[];
    /** Link types whose committed link or unlink changes can change the answer. */
    links: string[];
    /** True when only an object's own stored properties decide its answer, so a change can affect only the changed object. */
    local: boolean;
};
type FootprintQuery = Parameters<typeof queryFields>[0] & {
    type: string;
    from?: {
        object: ObjectRef;
        link: string;
        as?: string;
    };
};
/**
 * The footprint of an object-set query and optional watched relationship paths. Derived properties add the links and
 * object types their expressions navigate. Interface queries and relationship sources are never local.
 */
export declare function queryFootprint(model: Ontology, query: FootprintQuery, watches?: readonly {
    path: readonly string[];
}[]): ChangeFootprint;
/**
 * The distinct objects of `types` that commits after `after` (through `through`, at most `commits` commits) edited.
 * `refs` is undefined when more than `objects` objects changed; the caller then re-evaluates from the full state.
 * `end` is the last commit read, or `through` when the window reached it.
 */
export declare function changedObjects(db: Database, owner: string, projection: string, types: readonly string[], client: Sql, after: string, through: string, limits?: {
    commits?: number;
    objects?: number;
}): Promise<{
    refs: {
        type: string;
        id: string;
    }[] | undefined;
    end: string;
}>;
/**
 * Whether commits after `after` (through `through`, at most `commits` commits) changed anything in `footprint`.
 * `end` is the last commit read, or `through` when the window reached it.
 */
export declare function footprintChanged(db: Database, owner: string, footprint: ChangeFootprint, client: Sql, after: string, through: string, commits?: number): Promise<{
    changed: boolean;
    end: string;
}>;
/**
 * What commits after `after` (through `through`, at most `commits` commits) changed in `footprint`: its object types
 * that were edited and its link types that were linked or unlinked. `end` is the last commit read, or `through` when the
 * window reached it.
 */
export declare function footprintChanges(db: Database, owner: string, footprint: ChangeFootprint, client: Sql, after: string, through: string, ontology: string, commits?: number): Promise<{
    types: string[];
    links: string[];
    end: string;
}>;
export {};
