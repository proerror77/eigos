import type { Ontology } from '../ontology/model.js';
import type { Database, Sql } from './database.js';
/** Compare saved definitions without reading any owner's business data. */
export declare function checkSavedObjectSets(db: Database, client: Sql, current: Ontology, candidate: Ontology): Promise<void>;
