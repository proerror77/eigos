import { Database } from './database.js';
/** Offline, in-place upgrade of the existing schema. No database or task store is created. */
export declare function upgradePublicationStorage(db: Database): Promise<void>;
