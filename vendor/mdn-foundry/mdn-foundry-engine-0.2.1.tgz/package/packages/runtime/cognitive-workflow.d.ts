import { z } from 'zod';
import { type ObjectRef } from '../ontology/schema.js';
import type { Access } from './access.js';
import type { PublishedOntology } from './metadata.js';
import type { Database, Sql } from './database.js';
import type { Functions, FunctionContext } from './functions.js';
export declare const cognitiveStepSchema: z.ZodObject<{
    name: z.ZodString;
    mergeAction: z.ZodString;
    mergeObjectParameter: z.ZodString;
    goal: z.ZodString;
    actions: z.ZodArray<z.ZodString>;
    functions: z.ZodDefault<z.ZodArray<z.ZodString>>;
    validation: z.ZodObject<{
        function: z.ZodString;
        objectParameter: z.ZodString;
    }, z.core.$strict>;
    reviewers: z.ZodArray<z.ZodString>;
    timeoutSeconds: z.ZodDefault<z.ZodNumber>;
    maxToolCalls: z.ZodDefault<z.ZodNumber>;
}, z.core.$strict>;
export declare const cognitiveContextSchema: z.ZodObject<{
    name: z.ZodString;
    goal: z.ZodString;
    actions: z.ZodArray<z.ZodString>;
    functions: z.ZodDefault<z.ZodArray<z.ZodString>>;
    validation: z.ZodObject<{
        function: z.ZodString;
        objectParameter: z.ZodString;
    }, z.core.$strict>;
    maxToolCalls: z.ZodDefault<z.ZodNumber>;
    runId: z.ZodUUID;
    scenarioId: z.ZodUUID;
    object: z.ZodObject<{
        type: z.ZodString;
        id: z.ZodString;
    }, z.core.$strict>;
    revision: z.ZodNumber;
    evidenceVersion: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type CognitiveStep = z.output<typeof cognitiveStepSchema>;
export type CognitiveContext = z.output<typeof cognitiveContextSchema>;
export declare function authorizeCognitive(access: Access, model: PublishedOntology, step: CognitiveStep): void;
export declare const cognitiveResultSchema: z.ZodObject<{
    scenarioId: z.ZodUUID;
    revision: z.ZodNumber;
}, z.core.$strict>;
export declare function workflowMerge(model: PublishedOntology, step: CognitiveStep, object: ObjectRef, scenarioId: string, revision: number): {
    action: string;
    input: Record<string, unknown>;
    effects: import("./effects.js").ActionEffect[];
};
export declare function validateCognitive(functions: Functions, context: FunctionContext, validation: CognitiveStep['validation'], object: ObjectRef): Promise<void>;
/** Keep the original version check for proposals already created with an owner-wide snapshot. */
export declare function decisionVersion(db: Database, model: PublishedOntology, owner: string, client?: Sql): Promise<string>;
export declare function requireDecisionVersion(db: Database, model: PublishedOntology, owner: string, version: string, client?: Sql): Promise<void>;
