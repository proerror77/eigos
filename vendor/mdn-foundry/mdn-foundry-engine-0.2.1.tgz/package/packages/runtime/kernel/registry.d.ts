import type { Database } from '../database.js';
import type { PublishedOntology } from '../metadata.js';
import { KernelClient } from './client.js';
/**
 * How Object Sets use the query kernel, from EIGOS_KERNEL: `off`; `route`, so the kernel answers what it can and the
 * reference the rest; or `shadow`, so the reference answers and the kernel's answer is compared with it.
 */
export type KernelMode = 'off' | 'route' | 'shadow';
export declare function kernelMode(): KernelMode;
/**
 * The query kernels this process uses, each holding one projection that it loads on first use and then keeps current.
 * - With EIGOS_KERNEL_URL, one kernel service, which loads whichever projection a query needs.
 * - With EIGOS_KERNEL_BIN, local kernel processes, at most EIGOS_KERNEL_INSTANCES (default 2); the least recently used
 *   one stops when another projection needs one.
 * The kernel reads the database at EIGOS_KERNEL_DATABASE_URL, or at the runtime's own connection string.
 */
export declare class KernelRegistry {
    private readonly url;
    private readonly binary;
    private readonly limit;
    private readonly database;
    private readonly retryAfterMs;
    private readonly instances;
    /** `retryAfterMs` is how long a projection whose kernel failed to load it, or was lost, stays on the reference path. */
    constructor(url?: string | undefined, binary?: string | undefined, limit?: number, database?: string | undefined, retryAfterMs?: number);
    /**
     * A kernel holding the model's projection of `db`, or undefined while it loads (unless `wait`), after it failed to
     * load, or when no kernel is configured.
     */
    kernelFor(db: Database, model: PublishedOntology, wait: boolean): Promise<KernelClient | undefined>;
    /**
     * Registers the instance before anything is awaited, so concurrent queries for one projection share one kernel; a
     * kernel started for an instance set aside meanwhile is stopped.
     */
    private open;
    /** Loads the model's projection again, from storage, into the kernel that holds it. */
    reload(db: Database, model: PublishedOntology): Promise<void>;
    /**
     * Sets aside the kernel of the model's projection after it was lost, for example because the kernel service
     * restarted: queries go to the reference until the retry delay passes, and the next query then opens it again.
     */
    lost(db: Database, model: PublishedOntology): void;
    private databaseOf;
    private key;
    private close;
    /** Stops every kernel process this registry started. */
    stop(): Promise<void>;
}
/** The process's kernels, configured from the environment. */
export declare function defaultKernels(): KernelRegistry;
