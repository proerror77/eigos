import type { ObjectData, ObjectRef } from '../../ontology/schema.js';
import type { Access } from '../access.js';
import type { Database } from '../database.js';
import type { PublishedOntology } from '../metadata.js';
import type { Objects } from '../objects.js';
import type { z } from 'zod';
import type { querySchema } from '../objects.js';
import { compileAggregate, compileQueryOrder, compileSet, type KernelPlan } from './plan.js';
/** What the kernel read of one type: the rows the reference reads to evaluate the same set. */
type Reads = {
    type: string;
    count: number;
    rank?: number | null;
    compartments?: string[];
    ids?: string[];
    overLimit?: true;
    markings?: string[];
    /** Some rows read are rows the reference reads with their derived values. */
    enriched?: true;
}[];
/** `commit` is the owner's last commit the answer reflects. */
/** `membership` digests the members, so a cursor can tell whether they changed between pages. */
type PageResponse = {
    total: number;
    refs: ObjectRef[];
    types: string[];
    membership: string;
    reads: Reads;
    commit: number;
    elapsedMs: number;
};
type AggregateResponse = {
    count: number;
    items: {
        group: Record<string, unknown>;
        metrics: Record<string, number | null>;
    }[];
    reads: Reads;
    commit: number;
    elapsedMs: number;
};
/** `membership` digests the members and the values they are ordered by. */
type QueryResponse = {
    total: number;
    refs: ObjectRef[];
    membership: string;
    reads: Reads;
    commit: number;
    elapsedMs: number;
};
/**
 * The version a query needs: the projection it was compiled for, and the owner's latest commit when it started, which
 * the kernel applies before it answers, waiting at most `waitMs`.
 */
export type KernelVersion = {
    projection: string;
    minCommit: number;
    waitMs?: number;
    /** In a Scenario: its id, its revision when the query started, and whether each link's source and target end are single-valued. */
    scenario?: {
        id: string;
        revision: number;
        single: Record<string, [boolean, boolean]>;
    };
};
/**
 * The kernel could not answer: it could not be reached, holds no projection, or failed on the query. The reference
 * answers instead. `lost` means the kernel can answer nothing until it loads the projection again.
 */
export declare class KernelFailed extends Error {
    readonly lost: boolean;
    constructor(message: string, lost: boolean);
}
/** A running query kernel on the loopback interface. */
export declare class KernelClient {
    readonly url: string;
    private readonly child?;
    private constructor();
    /** Starts the kernel binary on a free loopback port, with extra environment settings. */
    static start(binary: string, env?: Record<string, string>): Promise<KernelClient>;
    /** A client for a kernel service already running at `url`. */
    static connect(url: string): KernelClient;
    private protocol?;
    /**
     * Whether the kernel answers protocol `level`: 2 adds query pages and Scenario overlays. A kernel that predates them
     * would ignore a Scenario and answer from the live data, so a Scenario goes to the reference instead. A restarted
     * kernel is reached through a new client, which asks again.
     */
    supports(level: number): Promise<boolean>;
    /** The kernel process ID, when this client started it. */
    get pid(): number | undefined;
    /** Asks the kernel process this client started to stop, without waiting for it. */
    kill(): void;
    stop(): Promise<void>;
    /**
     * Undefined when the kernel leaves the query to the reference: the reference's evaluation fails, or the kernel cannot
     * read the request (422); or the kernel cannot answer from the version the query needs (409). Throws `KernelFailed`
     * when the kernel cannot be reached or fails.
     */
    private post;
    /**
     * Loads the projection of `model` from the database the kernel can reach at `database`, or restores the kernel's last
     * checkpoint of it when that belongs to the database; `restored` says which.
     */
    load(db: Database, model: PublishedOntology, database: string): Promise<{
        objects: number;
        edges: number;
        bytes: number;
        restored: boolean;
        elapsedMs: number;
    }>;
    page(owner: string, plan: KernelPlan, offset: number, limit: number, version?: KernelVersion): Promise<PageResponse | undefined>;
    aggregate(owner: string, plan: KernelPlan, output: NonNullable<ReturnType<typeof compileAggregate>>, version?: KernelVersion): Promise<AggregateResponse | undefined>;
    query(owner: string, plan: KernelPlan, output: NonNullable<ReturnType<typeof compileQueryOrder>>, version?: KernelVersion): Promise<QueryResponse | undefined>;
    health(): Promise<{
        loaded: boolean;
        protocol?: number;
        loads?: number;
        projection?: string;
        objects?: number;
        edges?: number;
        changed?: number;
    }>;
    /** The last commit the kernel has applied for each owner. */
    positions(): Promise<Record<string, number>>;
    /** Writes a checkpoint of the kernel's current version to its data directory. */
    checkpoint(): Promise<{
        checkpoint: string;
        elapsedMs: number;
    }>;
}
/**
 * Evaluates one page of an Object Set with the kernel and reads the page's objects through `graph`, shown in `view`.
 * Undefined means the set has no kernel plan, or the reference's evaluation would fail, so the caller evaluates it with
 * the reference.
 */
export declare function evaluateWithKernel(kernel: KernelClient, model: PublishedOntology, access: Access, graph: Objects, input: {
    set: Parameters<typeof compileSet>[3];
    view?: string;
    offset?: number;
    limit: number;
}): Promise<{
    items: ObjectData[];
    total: number;
    elapsedMs: number;
    membership?: undefined;
    commit?: undefined;
} | {
    items: ObjectData[];
    total: number;
    membership: string;
    commit: number;
    elapsedMs: number;
} | undefined>;
/** Aggregates an Object Set with the kernel. Undefined means the reference aggregates it, as for `evaluateWithKernel`. */
export declare function aggregateWithKernel(kernel: KernelClient, model: PublishedOntology, access: Access, graph: Objects, input: {
    set: Parameters<typeof compileSet>[3];
} & Parameters<typeof compileAggregate>[3]): Promise<{
    commit?: undefined;
    count: number;
    elapsedMs: number;
    items: {
        group: {};
        metrics: {
            [k: string]: number | null;
        };
    }[];
} | {
    count: number;
    items: {
        group: Record<string, unknown>;
        metrics: Record<string, number | null>;
    }[];
    commit: number;
    elapsedMs: number;
} | undefined>;
/**
 * One page of a query with the kernel, as `Objects.query` gives a query the reference evaluates completely: the members
 * in the reference's order, read through `graph`, each projected into the query's type and its selected fields.
 * Undefined leaves the query to the reference: it has no kernel plan; the reference's evaluation would fail; a member
 * is gone or hidden; or the owner committed after the kernel answered, so the objects read could be newer than the
 * order.
 */
export declare function queryWithKernel(kernel: KernelClient, model: PublishedOntology, access: Access, graph: Objects, input: {
    query: z.output<typeof querySchema>;
    offset: number;
}): Promise<{
    items: {
        ref: ObjectRef;
        revision: number;
        properties: {
            [k: string]: unknown;
        };
    }[];
    total: number;
    membership: string;
    commit: number;
    elapsedMs: number;
} | undefined>;
/**
 * One object's relationship with the kernel, as `Objects.follow` reads it: the targets in id order, byte by byte, read
 * through `graph`. Undefined leaves it to the reference: there is no kernel plan, the reference's evaluation would fail,
 * there are more targets than `maximum` (the reference reports that), a target is gone or hidden, or the owner committed
 * or the Scenario changed while the targets were read.
 */
export declare function followWithKernel(kernel: KernelClient, model: PublishedOntology, access: Access, graph: Objects, input: {
    ref: ObjectRef;
    link: string;
    view: string;
    maximum: number;
}): Promise<ObjectData[] | undefined>;
export {};
