import { KernelClient } from './client.js';
export function kernelMode() {
    const mode = process.env.EIGOS_KERNEL ?? 'off';
    if (mode !== 'off' && mode !== 'route' && mode !== 'shadow')
        throw new Error('EIGOS_KERNEL must be off, route or shadow');
    return mode;
}
/**
 * The query kernels this process uses, each holding one projection that it loads on first use and then keeps current.
 * - With EIGOS_KERNEL_URL, one kernel service, which loads whichever projection a query needs.
 * - With EIGOS_KERNEL_BIN, local kernel processes, at most EIGOS_KERNEL_INSTANCES (default 2); the least recently used
 *   one stops when another projection needs one.
 * The kernel reads the database at EIGOS_KERNEL_DATABASE_URL, or at the runtime's own connection string.
 */
export class KernelRegistry {
    url;
    binary;
    limit;
    database;
    retryAfterMs;
    instances = new Map();
    /** `retryAfterMs` is how long a projection whose kernel failed to load it, or was lost, stays on the reference path. */
    constructor(url = process.env.EIGOS_KERNEL_URL, binary = process.env.EIGOS_KERNEL_BIN, limit = Number(process.env.EIGOS_KERNEL_INSTANCES ?? 2), database = process.env.EIGOS_KERNEL_DATABASE_URL, retryAfterMs = 60_000) {
        this.url = url;
        this.binary = binary;
        this.limit = limit;
        this.database = database;
        this.retryAfterMs = retryAfterMs;
    }
    /**
     * A kernel holding the model's projection of `db`, or undefined while it loads (unless `wait`), after it failed to
     * load, or when no kernel is configured.
     */
    async kernelFor(db, model, wait) {
        const database = this.databaseOf(db);
        if (!database || !this.url && !this.binary)
            return undefined;
        const key = this.key(db, model);
        let instance = this.instances.get(key);
        if (instance?.state === 'failed' && Date.now() - instance.failedAt >= this.retryAfterMs) {
            this.close(key);
            instance = undefined;
        }
        instance ??= this.open(key, db, model, database);
        instance.used = Date.now();
        if (wait)
            await instance.ready;
        return instance.state === 'ready' ? instance.client : undefined;
    }
    /**
     * Registers the instance before anything is awaited, so concurrent queries for one projection share one kernel; a
     * kernel started for an instance set aside meanwhile is stopped.
     */
    open(key, db, model, database) {
        if (this.url) {
            // A kernel service holds one projection, so loading another replaces it.
            for (const other of [...this.instances.keys()])
                this.instances.delete(other);
        }
        else {
            while (this.instances.size >= Math.max(1, this.limit)) {
                const [oldest] = [...this.instances.entries()].sort(([, a], [, b]) => a.used - b.used)[0];
                this.close(oldest);
            }
        }
        const instance = { state: 'loading', used: Date.now(), ready: Promise.resolve() };
        this.instances.set(key, instance);
        const start = async () => {
            const client = this.url ? KernelClient.connect(this.url) : await KernelClient.start(this.binary);
            instance.client = client;
            if (instance.closed) {
                await client.stop();
                throw new Error('Kernel set aside while it started');
            }
            // A kernel service may already hold the projection, loaded by another process of this deployment; it keeps it
            // current itself, so loading it again would only repeat the work.
            if (this.url && (await client.health()).projection === model.projection)
                return;
            await client.load(db, model, database);
        };
        instance.ready = start().then(() => { instance.state = 'ready'; }, () => { instance.state = 'failed'; instance.failedAt = Date.now(); });
        return instance;
    }
    /** Loads the model's projection again, from storage, into the kernel that holds it. */
    async reload(db, model) {
        const instance = this.instances.get(this.key(db, model));
        if (instance?.state === 'ready')
            await instance.client.load(db, model, this.databaseOf(db));
    }
    /**
     * Sets aside the kernel of the model's projection after it was lost, for example because the kernel service
     * restarted: queries go to the reference until the retry delay passes, and the next query then opens it again.
     */
    lost(db, model) {
        const instance = this.instances.get(this.key(db, model));
        if (instance?.state === 'ready') {
            instance.state = 'failed';
            instance.failedAt = Date.now();
        }
    }
    databaseOf(db) { return this.database ?? db.pool.options.connectionString; }
    key(db, model) { return JSON.stringify([this.databaseOf(db), db.schema, model.projection]); }
    close(key) {
        const instance = this.instances.get(key);
        this.instances.delete(key);
        if (!instance)
            return;
        instance.closed = true;
        if (instance.client && !this.url)
            void instance.client.stop();
    }
    /** Stops every kernel process this registry started. */
    async stop() {
        const instances = [...this.instances.keys()];
        for (const key of instances)
            this.close(key);
    }
}
let shared;
/** The process's kernels, configured from the environment. */
export function defaultKernels() { return shared ??= new KernelRegistry(); }
