import { unprofiled } from '../../core/database-profile.js';
import { canonical } from '../../core/identity.js';
import { latestCommit } from '../change-feed.js';
import { KernelFailed } from './client.js';
import { defaultKernels, kernelMode } from './registry.js';
/** The process's kernel use, from EIGOS_KERNEL and the process's kernels. */
export const defaultKernelUse = () => ({ mode: kernelMode(), registry: defaultKernels() });
export const encodeKernelCursor = (cursor) => Buffer.from(JSON.stringify({ kernel: cursor })).toString('base64url');
export function kernelCursor(cursor) {
    try {
        const value = JSON.parse(Buffer.from(cursor, 'base64url').toString()).kernel;
        return value && typeof value.identity === 'string' && Number.isInteger(value.offset) && value.offset >= 0 && typeof value.membership === 'string'
            ? value : undefined;
    }
    catch {
        return undefined;
    }
}
/** Where a reference cursor's page starts. */
export function referenceOffset(cursor) {
    try {
        return Math.max(0, Number(JSON.parse(Buffer.from(cursor, 'base64url').toString()).offset) || 0);
    }
    catch {
        return 0;
    }
}
/** Runs an operation with a fork of the principal's access in its own egress scope, and reports what it recorded. */
async function isolated(access, operation) {
    const fork = await access.fork();
    const measured = await fork.measureEgress(() => operation(fork));
    return { result: measured.result, classification: measured.classification, requirements: measured.requirements, markings: fork.readMarkingsSnapshot() };
}
/** Ontology values of objects: a missing value and null are the same value. */
export const ontologyValues = (items) => items.map(item => ({ ref: item.ref, revision: item.revision,
    properties: Object.fromEntries(Object.entries(item.properties).filter(([, value]) => value !== null && value !== undefined)) }));
/**
 * How the kernel's answer differs from the reference's, or undefined: the results; the rows, markings and classification
 * recorded; and the type-level dependencies, of which the kernel may record more (it checks types while planning, also
 * for inputs that turn out empty).
 */
function shadowMismatch(expected, actual) {
    if (canonical(expected.result) !== canonical(actual.result))
        return 'result';
    const rows = (recorded) => recorded.requirements.flatMap(item => item.row ? [item.row.type + '/' + item.row.id] : []).sort();
    if (canonical(rows(expected)) !== canonical(rows(actual)))
        return 'row dependencies';
    if (canonical(expected.markings) !== canonical(actual.markings))
        return 'read markings';
    if (canonical(expected.classification) !== canonical(actual.classification))
        return 'classification';
    const typeLevel = (recorded) => new Set(recorded.requirements.filter(item => !item.row && item.permission !== 'view_property').map(item => canonical(item)));
    const recorded = typeLevel(actual);
    if ([...typeLevel(expected)].some(item => !recorded.has(item)))
        return 'type-level dependencies';
    return undefined;
}
function reportShadow(mismatch, input) {
    const message = `Query kernel shadow mismatch (${mismatch}): ${JSON.stringify(input).slice(0, 2000)}`;
    if (process.env.EIGOS_KERNEL_SHADOW_STRICT === 'true')
        throw new Error(message);
    console.warn(message);
}
const emptyShadowCounts = () => ({ compared: 0, declined: 0, skipped: 0, stale: 0, aborted: 0, unavailable: 0 });
const shadowCounts = emptyShadowCounts();
const shadowOperations = new Map();
let shadowReport = false;
function countShadow(outcome, operation) {
    shadowCounts[outcome]++;
    const counts = shadowOperations.get(operation) ?? emptyShadowCounts();
    counts[outcome]++;
    shadowOperations.set(operation, counts);
    if (!shadowReport && process.env.EIGOS_KERNEL_SHADOW_REPORT === 'true') {
        shadowReport = true;
        process.once('exit', () => {
            console.error(JSON.stringify({ event: 'kernel_shadow', ...shadowCounts }));
            for (const [operation, outcomes] of shadowOperations)
                console.error(JSON.stringify({ event: 'kernel_shadow_operation', operation, ...outcomes }));
        });
    }
}
/** The owner's latest commit and, in a Scenario, its revision: a comparison that sees either change is skipped. */
async function versionStamp(db, model, owner) {
    const commit = await latestCommit(db, owner, db.pool);
    if (!model.scenario)
        return String(commit);
    const row = (await db.query(`SELECT revision FROM ${db.schema}.scenarios WHERE id=$1 AND owner=$2`, [model.scenario, owner])).rows[0];
    return `${commit}:${row?.revision ?? ''}`;
}
/**
 * Compares the kernel's answer with the reference's, each on a fork of the principal's access, outside every database
 * profile. With EIGOS_KERNEL_SHADOW_STRICT=true the comparison finishes before the request answers, so a mismatch
 * fails it; otherwise it runs after the request answers, adding no latency.
 */
export async function compareWithKernel(db, registry, access, model, operation, input, reference, kernel) {
    const compare = async () => {
        const client = await registry.kernelFor(db, model, true);
        if (!client)
            return countShadow('unavailable', operation);
        const before = await versionStamp(db, model, access.principal.owner);
        const expected = await isolated(access, reference);
        const viaKernel = () => isolated(access, fork => kernel(client, fork));
        let actual = await viaKernel();
        if (actual.result === undefined)
            return countShadow('declined', operation);
        if (await versionStamp(db, model, access.principal.owner) !== before)
            return countShadow('skipped', operation);
        let mismatch = shadowMismatch(expected, actual);
        if (mismatch && registry.reload) {
            // Writes outside the commit log are invisible to the kernel until it loads the projection again.
            await registry.reload(db, model);
            actual = await viaKernel();
            if (actual.result !== undefined && !shadowMismatch(expected, actual))
                return countShadow('stale', operation);
            mismatch = actual.result === undefined ? undefined : shadowMismatch(expected, actual);
        }
        countShadow('compared', operation);
        if (mismatch)
            reportShadow(mismatch, input);
    };
    if (process.env.EIGOS_KERNEL_SHADOW_STRICT === 'true') {
        const counted = db.queries;
        try {
            await unprofiled(compare);
        }
        finally {
            db.queries = counted;
        }
        return;
    }
    void unprofiled(compare).catch(() => countShadow('aborted', operation));
}
/**
 * The kernel's answer, or undefined when the kernel failed, so that the reference answers. A routed query never fails
 * because of the kernel: a lost kernel is set aside until its registry opens it again.
 */
export async function kernelAnswer(db, registry, model, answer) {
    try {
        return await answer();
    }
    catch (error) {
        if (!(error instanceof KernelFailed))
            throw error;
        console.warn(`Query kernel failed, so the reference answers: ${error.message}`);
        if (error.lost)
            registry.lost?.(db, model);
        return undefined;
    }
}
