import { Conflict } from '../core/identity.js';
import { Database, type Sql } from './database.js';
import type { Objects } from './objects.js';
type Reader = Pick<Objects, 'access' | 'read'>;
/** Observation Actions may reconcile an existing operation, but cannot claim a new supplier mutation. */
export declare function withoutExternalDispatch<T>(operation: () => Promise<T>): Promise<T>;
export declare class UnknownExternalOperation extends Conflict {
}
/** Provider mutations are recorded before dispatch. A lost response is an
 * unresolved original operation, never permission to submit another order. */
export declare class ExternalOperations {
    private readonly db;
    private readonly writeBudgets;
    constructor(db: Database);
    inspect(owner: string, key: string, client?: Sql): Promise<{
        state: any;
        createdAt: any;
        updatedAt: any;
    } | null>;
    private original;
    recover<T>(owner: string, key: string, scope: unknown, reader?: Reader): Promise<T | undefined>;
    /** Promote an existing dispatch only with independent evidence for the original request. */
    reconcile<T>(owner: string, key: string, scope: unknown, guard: (client: Sql) => Promise<void>, readback: () => Promise<T | undefined>, reader?: Reader): Promise<T | undefined>;
    run<T>(owner: string, key: string, scope: unknown, guard: (client: Sql) => Promise<void>, invoke: () => Promise<T>, reader?: Reader, origin?: {
        requestId?: string;
        taskId?: string;
    }): Promise<T>;
    /** Claim an external operation in the same transaction that makes it dispatchable. */
    claimDispatch(client: Sql, owner: string, key: string, scope: unknown, reader?: Reader, origin?: {
        requestId?: string;
        taskId?: string;
    }): Promise<void>;
}
export {};
