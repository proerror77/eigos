import { SourceReadFailure } from '../core/identity.js';
import type { ComponentSourceSecrets, SourceOAuthGrant } from './component-source-secrets.js';
import type { Database } from './database.js';
export declare class SourceOAuthReauthorization extends SourceReadFailure {
    constructor();
}
/** A verified pre-dispatch failure or an explicit rejection that issued no token. */
export declare class SourceOAuthRejection extends SourceReadFailure {
    constructor(cause?: unknown);
}
export declare function initializeComponentOAuthGrants(db: Database): Promise<void>;
/**
 * An authorization server may revoke an old token as soon as it issues its replacement.
 * Reserve a refresh durably before dispatch; an ambiguous result must never replay that old token.
 */
export declare class ComponentOAuthGrants {
    private readonly db;
    private readonly secrets;
    constructor(db: Database, secrets: Pick<ComponentSourceSecrets, 'openGrant' | 'sealGrant'>);
    token(identity: string, seed: () => Promise<string>, exchange: (refreshToken: string) => Promise<SourceOAuthGrant>, signal: AbortSignal): Promise<string>;
    private claim;
}
