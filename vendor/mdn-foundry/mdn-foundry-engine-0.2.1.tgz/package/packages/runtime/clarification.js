import { z } from 'zod';
import { actionResultReadSchema } from '../ontology/invocation.js';
import { pickupCoordinateEvidence, placeDetailInput } from '../ontology/pickup-evidence.js';
import { objectRefSchema } from '../ontology/schema.js';
export const placeSelectionSchema = z.strictObject({ origin: objectRefSchema, destination: objectRefSchema });
const placeClueFields = {
    address: z.string().trim().min(5).max(300).optional(),
    landmark: z.string().trim().min(3).max(200).optional(),
    name: z.string().trim().min(1).max(200).optional(),
};
const hasPlaceClue = (input) => Boolean(input.address || input.landmark);
export const placeClueSchema = z.strictObject(placeClueFields).refine(hasPlaceClue, 'Provide an address or landmark');
export const placeAmendmentSchema = z.strictObject({
    ...placeClueFields,
    side: z.enum(['origin', 'destination']),
    keep: objectRefSchema.optional(),
}).refine(hasPlaceClue, 'Provide an address or landmark');
export const unresolvedMapPlace = '高德未能唯一匹配所需精度的地点，请补充城市或完整地址。';
export const amapPlaceAmendmentSchema = z.strictObject({
    source: z.literal('Amap'),
    side: z.enum(['origin', 'destination']),
    placeId: placeDetailInput.shape.id,
    requestId: z.uuid(),
    expectedUpdatedAt: z.iso.datetime({ offset: true }),
    restoreCanceled: z.literal(true).optional(),
});
export const taskPlaceAmendmentSchema = z.union([amapPlaceAmendmentSchema, placeAmendmentSchema]);
const mapPlaceCorrectionSchema = z.strictObject({
    requestId: z.uuid(),
    fingerprint: z.string(),
    placeId: placeDetailInput.shape.id,
    name: z.string(),
    city: z.string().optional(),
});
export const mapPlaceCorrectionsSchema = z.strictObject({
    origin: mapPlaceCorrectionSchema.optional(),
    destination: mapPlaceCorrectionSchema.optional(),
});
export const placeAmendmentsSchema = z.strictObject({
    origin: placeClueSchema.optional(),
    destination: placeClueSchema.optional(),
});
export const cityInputSchema = z.string().trim().min(2).max(100);
export const rideEndpointSchema = z.string().trim().min(1).max(500);
export const taskInputAnswerSchema = z.discriminatedUnion('kind', [
    z.strictObject({ kind: z.literal('city'), city: cityInputSchema }),
    z.strictObject({ kind: z.literal('origin'), place: rideEndpointSchema }),
    z.strictObject({ kind: z.literal('destination'), place: rideEndpointSchema }),
    z.strictObject({ kind: z.literal('retry-source') }),
]);
export const placeChoicesSchema = z.object({
    origin: z.array(z.object({ ref: objectRefSchema })),
    destination: z.array(z.object({ ref: objectRefSchema })),
});
export const actionInputPurpose = z.enum(['input', 'observation', 'authorization', 'execution-result']);
export const actionWaitSchema = z.strictObject({
    id: z.uuid(), capability: z.string().min(1).max(200), purpose: actionInputPurpose,
});
export const actionContinuationSchema = z.strictObject({
    requestId: z.string().min(1),
    action: z.string().min(1),
    input: z.record(z.string(), z.unknown()),
    read: actionResultReadSchema.optional(),
    pending: actionWaitSchema.optional(),
    // Legacy place clients still use these compatibility fields.
    waitingFor: z.enum(['city', 'origin', 'destination', 'pa-request', 'retry-source']).optional(),
    receipts: placeSelectionSchema.optional(),
    pickup: pickupCoordinateEvidence.optional(),
}).refine(input => !input.waitingFor ? Boolean(input.pending || input.receipts) :
    input.waitingFor === 'retry-source' || !input.receipts);
export class Clarification extends Error {
    choices;
    permissions;
    continuation;
    constructor(message, choices, permissions = [], continuation) {
        super(message);
        this.choices = choices;
        this.permissions = permissions;
        this.continuation = continuation;
    }
}
export class ActionInputRequired extends Clarification {
    wait;
    constructor(message, choices, permissions, wait) {
        super(message, choices, permissions);
        this.wait = wait;
    }
}
/** Raised by an edit Function before staging a write when the sources do not establish a confirmed endpoint. */
export class PlaceConfirmationRequired extends ActionInputRequired {
    constructor(message, choices, receipts, pickup) { super(message, choices, [], { receipts, pickup }); }
}
/** The selected Action lacks a city, so no supplier lookup has been authorized yet. */
export class CityConfirmationRequired extends ActionInputRequired {
    constructor() { super('请提供这段行程所在的城市。', { kind: 'city' }, [], { waitingFor: 'city' }); }
}
export class RideEndpointRequired extends ActionInputRequired {
    side;
    constructor(side, message) {
        super(message, { kind: side }, [], { waitingFor: side });
        this.side = side;
    }
}
export class PARequestRequired extends Clarification {
}
export class ActionPARequestRequired extends ActionInputRequired {
    constructor(message, choices, permissions, purpose) {
        const request = z.object({ requestId: z.uuid(), capability: z.string(), purpose: actionInputPurpose.optional() }).parse(choices);
        super(message, choices, permissions, { waitingFor: 'pa-request',
            pending: { id: request.requestId, capability: request.capability, purpose: purpose ?? request.purpose ?? 'observation' } });
    }
}
export class SourceRetryRequired extends ActionInputRequired {
    receipts;
    constructor(stage, receipts) {
        super('滴滴查询失败，可以重试原任务。', { kind: 'retry-source', source: 'DiDi', stage }, [], { waitingFor: 'retry-source', receipts });
        this.receipts = receipts;
    }
}
