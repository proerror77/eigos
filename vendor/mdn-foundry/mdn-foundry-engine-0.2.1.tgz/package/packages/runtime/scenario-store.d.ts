import type { ObjectRef, LinkData } from '../ontology/schema.js';
import { Database, type Sql } from './database.js';
import type { PublishedOntology } from './metadata.js';
import type { Objects } from './objects.js';
export type ScenarioMutation = {
    op: 'create' | 'edit';
    ref: ObjectRef;
    fields: string[];
    values: Record<string, unknown>;
} | {
    op: 'delete';
    ref: ObjectRef;
} | {
    op: 'link' | 'unlink';
    edge: LinkData;
};
type ObjectCapture = {
    op: 'create' | 'edit' | 'delete';
    journal?: ScenarioMutation[];
};
/** Shared by live and scenario edits, including source ingestion and scenario merge. */
export declare function lockEdits(db: Database, model: PublishedOntology, owner: string, client: Sql): Promise<void>;
export declare function checkScenario(db: Database, model: PublishedOntology, owner: string, client?: Sql, lock?: boolean): Promise<void>;
/** Changed links shadow competing live single-valued links in the view. Merge checks the live links separately. */
export declare function viewTables(db: Database, model: PublishedOntology, owner: string, values: unknown[], types?: readonly string[], inline?: boolean): {
    prefix: string;
    objects: string;
    links: string;
};
export declare function stageObject(db: Database, model: PublishedOntology, owner: string, ref: ObjectRef, revision: number, properties: Record<string, unknown> | null, client: Sql, editedFields?: readonly string[], capture?: ObjectCapture): Promise<void>;
export declare function objectLinks(db: Database, model: PublishedOntology, owner: string, ref: ObjectRef, client: Sql): Promise<import("pg").QueryResultRow[]>;
/** Preserve the same per-object relationship snapshot in one query for the Action journal. */
export declare function objectLinksBatch(db: Database, model: PublishedOntology, owner: string, refs: readonly ObjectRef[], client: Sql): Promise<Map<string, unknown[]>>;
export declare function stageLink(db: Database, model: PublishedOntology, owner: string, edge: LinkData, removed: boolean, client: Sql, journal?: ScenarioMutation[]): Promise<void>;
export declare function bumpScenario(db: Database, model: PublishedOntology, owner: string, client: Sql, recordedStep?: boolean): Promise<string>;
export declare function recordScenarioAction(graph: Objects, action: string, input: Record<string, unknown>, result: ObjectRef, requestId: string): Promise<void>;
export {};
