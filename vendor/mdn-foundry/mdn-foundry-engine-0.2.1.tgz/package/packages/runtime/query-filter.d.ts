import { z } from 'zod';
import type { ObjectData } from '../ontology/schema.js';
export { propertyPathSchema } from '../ontology/property-path.js';
export type Predicate = {
    op: 'all';
    predicates: Predicate[];
} | {
    op: 'any';
    predicates: Predicate[];
} | {
    op: 'not';
    predicate: Predicate;
} | {
    op: 'eq' | 'ne' | 'gt' | 'gte' | 'lt' | 'lte' | 'contains' | 'text' | 'regex';
    property: string;
    value: string | number | boolean | null;
} | {
    op: 'in';
    property: string;
    values: (string | number | boolean | null)[];
};
export declare const predicateSchema: z.ZodPipe<z.ZodUnknown, z.ZodType<Predicate, unknown, z.core.$ZodTypeInternals<Predicate, unknown>>>;
export declare const orderSchema: z.ZodArray<z.ZodObject<{
    property: z.ZodString;
    direction: z.ZodDefault<z.ZodEnum<{
        asc: "asc";
        desc: "desc";
    }>>;
}, z.core.$strict>>;
export declare function predicateFields(predicate?: Predicate): string[];
export declare function nestedValue(properties: Record<string, unknown>, path: string): unknown;
/** User regexes execute in a worker with a deadline so pathological patterns cannot block the server. */
export declare function regexMatches(predicate: Predicate | undefined, objects: ObjectData[]): Promise<Map<string, boolean>>;
export declare function matchesPredicate(predicate: Predicate, properties: Record<string, unknown>, regex: Map<string, boolean>): boolean;
export declare function compareValues(left: unknown, right: unknown): number;
