import { z } from 'zod';
import { pickupCoordinateEvidence } from '../ontology/pickup-evidence.js';
import type { Requirement } from './access.js';
export declare const placeSelectionSchema: z.ZodObject<{
    origin: z.ZodObject<{
        type: z.ZodString;
        id: z.ZodString;
    }, z.core.$strict>;
    destination: z.ZodObject<{
        type: z.ZodString;
        id: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const placeClueSchema: z.ZodObject<{
    address: z.ZodOptional<z.ZodString>;
    landmark: z.ZodOptional<z.ZodString>;
    name: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export declare const placeAmendmentSchema: z.ZodObject<{
    address: z.ZodOptional<z.ZodString>;
    landmark: z.ZodOptional<z.ZodString>;
    name: z.ZodOptional<z.ZodString>;
    side: z.ZodEnum<{
        destination: "destination";
        origin: "origin";
    }>;
    keep: z.ZodOptional<z.ZodObject<{
        type: z.ZodString;
        id: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const unresolvedMapPlace = "\u9AD8\u5FB7\u672A\u80FD\u552F\u4E00\u5339\u914D\u6240\u9700\u7CBE\u5EA6\u7684\u5730\u70B9\uFF0C\u8BF7\u8865\u5145\u57CE\u5E02\u6216\u5B8C\u6574\u5730\u5740\u3002";
export declare const amapPlaceAmendmentSchema: z.ZodObject<{
    source: z.ZodLiteral<"Amap">;
    side: z.ZodEnum<{
        destination: "destination";
        origin: "origin";
    }>;
    placeId: z.ZodString;
    requestId: z.ZodUUID;
    expectedUpdatedAt: z.ZodISODateTime;
    restoreCanceled: z.ZodOptional<z.ZodLiteral<true>>;
}, z.core.$strict>;
export declare const taskPlaceAmendmentSchema: z.ZodUnion<readonly [z.ZodObject<{
    source: z.ZodLiteral<"Amap">;
    side: z.ZodEnum<{
        destination: "destination";
        origin: "origin";
    }>;
    placeId: z.ZodString;
    requestId: z.ZodUUID;
    expectedUpdatedAt: z.ZodISODateTime;
    restoreCanceled: z.ZodOptional<z.ZodLiteral<true>>;
}, z.core.$strict>, z.ZodObject<{
    address: z.ZodOptional<z.ZodString>;
    landmark: z.ZodOptional<z.ZodString>;
    name: z.ZodOptional<z.ZodString>;
    side: z.ZodEnum<{
        destination: "destination";
        origin: "origin";
    }>;
    keep: z.ZodOptional<z.ZodObject<{
        type: z.ZodString;
        id: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>]>;
export declare const mapPlaceCorrectionsSchema: z.ZodObject<{
    origin: z.ZodOptional<z.ZodObject<{
        requestId: z.ZodUUID;
        fingerprint: z.ZodString;
        placeId: z.ZodString;
        name: z.ZodString;
        city: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    destination: z.ZodOptional<z.ZodObject<{
        requestId: z.ZodUUID;
        fingerprint: z.ZodString;
        placeId: z.ZodString;
        name: z.ZodString;
        city: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const placeAmendmentsSchema: z.ZodObject<{
    origin: z.ZodOptional<z.ZodObject<{
        address: z.ZodOptional<z.ZodString>;
        landmark: z.ZodOptional<z.ZodString>;
        name: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    destination: z.ZodOptional<z.ZodObject<{
        address: z.ZodOptional<z.ZodString>;
        landmark: z.ZodOptional<z.ZodString>;
        name: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const cityInputSchema: z.ZodString;
export declare const rideEndpointSchema: z.ZodString;
export declare const taskInputAnswerSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"city">;
    city: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"origin">;
    place: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"destination">;
    place: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"retry-source">;
}, z.core.$strict>], "kind">;
export declare const placeChoicesSchema: z.ZodObject<{
    origin: z.ZodArray<z.ZodObject<{
        ref: z.ZodObject<{
            type: z.ZodString;
            id: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strip>>;
    destination: z.ZodArray<z.ZodObject<{
        ref: z.ZodObject<{
            type: z.ZodString;
            id: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export declare const actionInputPurpose: z.ZodEnum<{
    authorization: "authorization";
    "execution-result": "execution-result";
    input: "input";
    observation: "observation";
}>;
export type ActionInputPurpose = z.infer<typeof actionInputPurpose>;
export declare const actionWaitSchema: z.ZodObject<{
    id: z.ZodUUID;
    capability: z.ZodString;
    purpose: z.ZodEnum<{
        authorization: "authorization";
        "execution-result": "execution-result";
        input: "input";
        observation: "observation";
    }>;
}, z.core.$strict>;
export declare const actionContinuationSchema: z.ZodObject<{
    requestId: z.ZodString;
    action: z.ZodString;
    input: z.ZodRecord<z.ZodString, z.ZodUnknown>;
    read: z.ZodOptional<z.ZodObject<{
        function: z.ZodString;
        resultParameter: z.ZodString;
        input: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    }, z.core.$strict>>;
    pending: z.ZodOptional<z.ZodObject<{
        id: z.ZodUUID;
        capability: z.ZodString;
        purpose: z.ZodEnum<{
            authorization: "authorization";
            "execution-result": "execution-result";
            input: "input";
            observation: "observation";
        }>;
    }, z.core.$strict>>;
    waitingFor: z.ZodOptional<z.ZodEnum<{
        city: "city";
        destination: "destination";
        origin: "origin";
        "pa-request": "pa-request";
        "retry-source": "retry-source";
    }>>;
    receipts: z.ZodOptional<z.ZodObject<{
        origin: z.ZodObject<{
            type: z.ZodString;
            id: z.ZodString;
        }, z.core.$strict>;
        destination: z.ZodObject<{
            type: z.ZodString;
            id: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    pickup: z.ZodOptional<z.ZodObject<{
        provider: z.ZodLiteral<"Amap">;
        fetchedAt: z.ZodISODateTime;
        inputCoordinateSystem: z.ZodEnum<{
            gcj02: "gcj02";
            wgs84: "wgs84";
        }>;
        coordinateSystem: z.ZodLiteral<"gcj02">;
        conversion: z.ZodEnum<{
            already_gcj02: "already_gcj02";
            converted_by_amap: "converted_by_amap";
        }>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type PlaceSelection = z.infer<typeof placeSelectionSchema>;
export type ActionContinuation = z.infer<typeof actionContinuationSchema>;
export type LegacyActionWait = Pick<ActionContinuation, 'waitingFor' | 'receipts' | 'pickup'>;
export declare class Clarification extends Error {
    readonly choices?: unknown;
    readonly permissions: Requirement[];
    readonly continuation?: ActionContinuation | undefined;
    constructor(message: string, choices?: unknown, permissions?: Requirement[], continuation?: ActionContinuation | undefined);
}
export declare class ActionInputRequired extends Clarification {
    readonly wait: LegacyActionWait & {
        pending?: z.infer<typeof actionWaitSchema>;
    };
    constructor(message: string, choices: unknown, permissions: Requirement[], wait: LegacyActionWait & {
        pending?: z.infer<typeof actionWaitSchema>;
    });
}
/** Raised by an edit Function before staging a write when the sources do not establish a confirmed endpoint. */
export declare class PlaceConfirmationRequired extends ActionInputRequired {
    constructor(message: string, choices: unknown, receipts: PlaceSelection, pickup?: z.infer<typeof pickupCoordinateEvidence>);
}
/** The selected Action lacks a city, so no supplier lookup has been authorized yet. */
export declare class CityConfirmationRequired extends ActionInputRequired {
    constructor();
}
export declare class RideEndpointRequired extends ActionInputRequired {
    readonly side: 'origin' | 'destination';
    constructor(side: 'origin' | 'destination', message: string);
}
export declare class PARequestRequired extends Clarification {
}
export declare class ActionPARequestRequired extends ActionInputRequired {
    constructor(message: string, choices: unknown, permissions: Requirement[], purpose?: ActionInputPurpose);
}
export declare class SourceRetryRequired extends ActionInputRequired {
    readonly receipts?: PlaceSelection | undefined;
    constructor(stage: 'places' | 'estimate', receipts?: PlaceSelection | undefined);
}
