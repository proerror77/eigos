import { z } from 'zod';
import { type Principal } from '../core/identity.js';
import type { Access } from './access.js';
import type { Database } from './database.js';
import type { PublishedOntology } from './metadata.js';
export type FunctionInvocationMetrics = {
    modelUsage?: {
        alias: string;
        provider: string;
        model: string;
        calls: number;
        reportedCalls: number;
        inputTokens: number;
        outputTokens: number;
    }[];
    fuelUsed?: number;
    hostMs?: number;
    callbacks: Record<string, {
        count: number;
        durationMs: number;
    }>;
};
export declare const functionInvocationsQuery: z.ZodObject<{
    ontology: z.ZodDefault<z.ZodString>;
    function: z.ZodString;
    before: z.ZodOptional<z.ZodString>;
    limit: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
}, z.core.$strict>;
export declare function initializeFunctionInvocations(db: Database): Promise<void>;
/** Drains records requested before the caller closes or removes a database. */
export declare function flushFunctionInvocations(db: Database): Promise<void>;
export declare class FunctionInvocations {
    private readonly db;
    constructor(db: Database);
    measure<T>(model: PublishedOntology, name: string, version: string | undefined, principal: Principal, signal: AbortSignal, run: (metrics: FunctionInvocationMetrics) => Promise<T>): Promise<T>;
    list(access: Access, model: PublishedOntology, input: z.infer<typeof functionInvocationsQuery>): Promise<{
        items: {
            id: string;
            function: string;
            version: string | null;
            release: string;
            owner: string;
            startedAt: Date;
            durationMs: number;
            hostMs: number | null;
            fuelUsed: number | null;
            modelUsage?: {
                alias: string;
                provider: string;
                model: string;
                calls: number;
                reportedCalls: number;
                inputTokens: number;
                outputTokens: number;
            }[] | undefined;
            callbacks: Record<string, {
                count: number;
                durationMs: number;
            }>;
            status: string;
            errorCode: string | null;
        }[];
        cursor?: string | undefined;
    }>;
    prune(): Promise<number | null>;
}
