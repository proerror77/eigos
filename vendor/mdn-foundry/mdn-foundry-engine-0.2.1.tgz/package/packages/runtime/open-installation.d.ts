import type { Installation, InstalledRuntime } from './installation.js';
import { Database } from './database.js';
import { Metadata } from './metadata.js';
export declare function openInstallation(installation: Installation): {
    installation: Installation;
    db: Database;
    metadata: Metadata;
};
export declare function checkInstallation(installation: Installation, metadata: Metadata, runtime: InstalledRuntime): Promise<void>;
