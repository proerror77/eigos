import type { LinkData, ObjectRef } from '../ontology/schema.js';
import type { Database } from './database.js';
import { Objects, type ScenarioObjectWrite } from './objects.js';
type Snapshot = {
    revision: number;
    properties: Record<string, unknown>;
} | null;
export interface ObjectChange {
    ref: ObjectRef;
    before: Snapshot;
    after: Snapshot;
    afterLinks: unknown[];
}
export interface LinkChange {
    edge: LinkData;
    before: boolean;
    after: boolean;
}
export declare function initializeActionUndo(db: Database): Promise<void>;
/** Records only touched objects and links on the Action's existing transaction. */
export declare class JournalObjects extends Objects {
    private readonly beforeObjects;
    private readonly beforeLinks;
    private snapshot;
    private remember;
    private linkPresent;
    private rememberLink;
    create(ref: ObjectRef, properties: Record<string, unknown>): Promise<void>;
    edit(ref: ObjectRef, revision: number, fields: Record<string, unknown>, expected?: Record<string, unknown>): Promise<void>;
    remove(ref: ObjectRef, revision: number): Promise<void>;
    writeScenarioObjects(edits: readonly ScenarioObjectWrite[]): Promise<void>;
    ingestBatch(rows: readonly {
        ref: ObjectRef;
        properties: Record<string, unknown> | null;
    }[], source?: string, observedAt?: string): Promise<void>;
    private liveLinks;
    private rememberScenarioLinks;
    linkBatch(edges: readonly LinkData[], scenarioMerge?: boolean): Promise<void>;
    unlinkScenarioLinks(edges: readonly LinkData[]): Promise<void>;
    unlink(edge: LinkData): Promise<void>;
    changes(): Promise<{
        objects: ObjectChange[];
        links: LinkChange[];
    }>;
}
export declare function compensate(graph: Objects, objects: ObjectChange[], links: LinkChange[]): Promise<void>;
export {};
