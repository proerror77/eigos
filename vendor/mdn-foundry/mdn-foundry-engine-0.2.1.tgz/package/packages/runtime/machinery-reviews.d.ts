import { z } from 'zod';
import { Access } from './access.js';
import type { Database } from './database.js';
import type { Metadata, PublishedOntology } from './metadata.js';
import { type ScenarioEvaluations } from './scenario-evaluation.js';
export declare const machineryReviewSchema: z.ZodObject<{
    id: z.ZodOptional<z.ZodUUID>;
    revision: z.ZodDefault<z.ZodNumber>;
    name: z.ZodString;
    type: z.ZodString;
    periodDays: z.ZodDefault<z.ZodNumber>;
    durationClock: z.ZodDefault<z.ZodEnum<{
        observedAt: "observedAt";
        recordedAt: "recordedAt";
    }>>;
    minCases: z.ZodDefault<z.ZodNumber>;
    enabled: z.ZodDefault<z.ZodBoolean>;
    evaluation: z.ZodOptional<z.ZodObject<{
        id: z.ZodUUID;
        revision: z.ZodNumber;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare class MachineryReviews {
    private readonly db;
    private readonly metadata;
    private readonly evaluations?;
    constructor(db: Database, metadata: Metadata, evaluations?: ScenarioEvaluations | undefined);
    private definition;
    save(access: Access, model: PublishedOntology, input: z.output<typeof machineryReviewSchema>): Promise<{
        name: string;
        type: string;
        periodDays: number;
        durationClock: "observedAt" | "recordedAt";
        minCases: number;
        evaluation?: {
            id: string;
            revision: number;
        } | undefined;
        id: string;
        revision: number;
        enabled: boolean;
    }>;
    list(access: Access, model: PublishedOntology): Promise<{
        items: {
            name: string;
            type: string;
            periodDays: number;
            durationClock: "observedAt" | "recordedAt";
            minCases: number;
            evaluation?: {
                id: string;
                revision: number;
            } | undefined;
            id: string;
            revision: number;
            enabled: boolean;
            lastScan: Date | null;
            checkpoint: {
                release: string;
                from: string;
                to: string;
                evaluation?: {
                    run: string;
                    rejected: number;
                    completed: number;
                } | undefined;
            } | null;
            error: string | null;
            status: string;
        }[];
        hasMore: boolean;
    }>;
    private report;
    private compute;
    read(access: Access, model: PublishedOntology, id: string, run: boolean): Promise<{
        states: {
            name: string;
            ever: number;
            current: number;
            historical: {
                count: number;
                totalMs: number;
                p50Ms: number | null;
                p95Ms: number | null;
                maxMs: number | null;
                distribution: {
                    fromMs: number;
                    toMs: number | null;
                    count: number;
                }[];
            };
            currentDuration: {
                count: number;
                totalMs: number;
                p50Ms: number | null;
                p95Ms: number | null;
                maxMs: number | null;
                distribution: {
                    fromMs: number;
                    toMs: number | null;
                    count: number;
                }[];
            };
            unknownDuration: number;
            priorToWindow: number;
            dwellSeconds: number | null;
            breaches: number;
            terminal: boolean;
        }[];
        transitions: {
            from: string | null;
            to: string | null;
            count: number;
            cases: number;
            last: number;
            expected: boolean | null;
            action?: string;
            observedActions: Record<string, number>;
            observedSources: Record<string, number>;
        }[];
        paths: {
            id: string;
            states: string[];
            partial: boolean;
            count: number;
        }[];
        pathsTotal: number;
        conformance: {
            conforming: number;
            deviation: number;
            unknown: number;
        };
        findings: {
            bottlenecks: {
                state: string;
                totalMs: number;
                completedP95Ms: number | null;
                currentMaxMs: number | null;
                breaches: number;
            }[];
            observedOnly: {
                from: string | null;
                to: string | null;
                count: number;
                cases: number;
                last: number;
                expected: boolean | null;
                action?: string;
                observedActions: Record<string, number>;
                observedSources: Record<string, number>;
            }[];
            expectedOnly: {
                from: string | null;
                to: string | null;
                count: number;
                cases: number;
                last: number;
                expected: boolean | null;
                action?: string;
                observedActions: Record<string, number>;
                observedSources: Record<string, number>;
            }[];
        };
        release: string;
        type: string;
        objectType: string;
        from: string;
        to: string;
        windowClock: string;
        durationClock: "observedAt" | "recordedAt";
        members?: {
            type: string;
            id: string;
        }[] | undefined;
        reference: {
            states: {
                name: string;
                terminal?: boolean | undefined;
                dwellSeconds?: number | undefined;
            }[];
            transitions: {
                from: string | null;
                to: string | null;
                execution?: {
                    subject: string;
                    parameters?: Record<string, string> | undefined;
                    requires?: {
                        process: string;
                        link?: string | undefined;
                        states: string[];
                        match: "all" | "any";
                    }[] | undefined;
                } | undefined;
                action?: string | undefined;
            }[];
            subprocesses: {
                link: string;
                process: string;
            }[];
        } | null;
        mined: {
            states: {
                name: string;
                cases: number;
            }[];
            transitions: {
                from: string | null;
                to: string | null;
                count: number;
                cases: number;
                last: number;
                expected: boolean | null;
                action?: string;
                observedActions: Record<string, number>;
                observedSources: Record<string, number>;
            }[];
        };
        comparison: {
            baseline: {
                conforming: number;
                deviation: number;
                unknown: number;
            };
            candidate: {
                conforming: number;
                deviation: number;
                unknown: number;
            };
            evidence: string;
        } | undefined;
        parallel?: {
            process: string;
            property: string;
            states: {
                state: string;
                with: {
                    state: string | null;
                    count: number;
                }[];
            }[];
        }[] | undefined;
        alignment?: {
            link: string;
            process: string;
            property: string;
            states: {
                state: string;
                with: {
                    state: string | null;
                    count: number;
                }[];
            }[];
        }[] | undefined;
        casesTotal: number;
        nextOffset: number | null;
        cases: {
            object: import("../ontology/schema.js").ObjectRef;
            states: string[];
            path: string;
            partial: boolean;
            current: string | null;
            conformance: "conforming" | "deviation" | "unknown";
            transitions: number;
            timeline?: {
                caseId: string;
                id: string;
                from: string | null;
                to: string | null;
                recordedAt: string;
                timestamp: string | null;
                action: string | null;
                source: string | null;
                taskId: string | null;
                requestId: string | null;
                prior: boolean;
            }[] | undefined;
            episodes?: {
                state: string;
                durationMs: number | null;
                open: boolean;
                clipped: boolean;
            }[] | undefined;
        }[];
        view?: {
            kind: "count" | "duration";
            scope: "current" | "historical";
            nodes: ({
                state: string;
                value: number;
            } | {
                state: string;
                value: number | null;
                p95Ms: number | null;
                maxMs: number | null;
                cases: number;
                color?: string | undefined;
            })[];
            edges: {
                from: string | null;
                to: string | null;
                value: number;
            }[];
        } | undefined;
        metrics?: {
            node?: ReturnType<({ colors: _colors, ...metric }: {
                label: string;
                aggregation: {
                    op: "count";
                } | {
                    op: "avg" | "max" | "min" | "sum";
                    property: string;
                };
                decimals?: number | undefined;
                unit?: string | undefined;
                colors?: {
                    min: number;
                    color: "amber" | "green" | "red";
                }[] | undefined;
            }) => {
                label: string;
                aggregation: {
                    op: "count";
                } | {
                    op: "avg" | "max" | "min" | "sum";
                    property: string;
                };
                decimals?: number | undefined;
                unit?: string | undefined;
            }> & {
                values: unknown[];
            };
            edge?: ReturnType<({ colors: _colors, ...metric }: {
                label: string;
                aggregation: {
                    op: "count";
                } | {
                    op: "avg" | "max" | "min" | "sum";
                    property: string;
                };
                decimals?: number | undefined;
                unit?: string | undefined;
                colors?: {
                    min: number;
                    color: "amber" | "green" | "red";
                }[] | undefined;
            }) => {
                label: string;
                aggregation: {
                    op: "count";
                } | {
                    op: "avg" | "max" | "min" | "sum";
                    property: string;
                };
                decimals?: number | undefined;
                unit?: string | undefined;
            }> & {
                values: unknown[];
            };
        } | undefined;
    }>;
    scanOne(): Promise<boolean>;
}
