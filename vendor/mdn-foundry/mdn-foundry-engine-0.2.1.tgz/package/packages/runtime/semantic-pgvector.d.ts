import type { Database, Sql } from './database.js';
/** Discover the enabled column and the actual extension schema, including managed installations. */
export declare function pgvectorNamespace(db: Database, client: Sql): Promise<string | undefined>;
/** An administrative opt-in. PostgreSQL generates the new column for old and future JSONB rows. */
export declare function enablePgvector(db: Database): Promise<{
    backend: 'pgvector';
    extensionVersion: string;
}>;
