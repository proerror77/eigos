import { digest, NotFound } from '../core/identity.js';
import { Objects } from './objects.js';
import { appendTrace } from './execution-trace.js';
export class Sources {
    db;
    functions;
    projections;
    constructor(db, functions, projections) {
        this.db = db;
        this.functions = functions;
        this.projections = projections;
    }
    projection(model, name) {
        const mapping = model.sources.get(name), projection = mapping && this.projections.get(mapping.apiName);
        if (!mapping)
            throw new NotFound('Datasource is unavailable');
        if (!projection)
            throw new Error('Published datasource implementation is unavailable');
        return { mapping, projection };
    }
    bindings(model) {
        return Object.fromEntries(model.resolvedDocument.dataSources.map(source => { this.projection(model, source.apiName); return [source.apiName, digest(source)]; }));
    }
    checkReadAccess(model, name, access) {
        access.definition(model, 'datasource', name);
        const binding = this.projection(model, name);
        const functionName = binding.mapping.function;
        access.function(model, functionName);
        const provider = model.functions.get(functionName)?.source;
        if (provider)
            access.source(model, provider);
        return binding;
    }
    async read(model, name, input, access, task, tasks, signal) {
        const principal = access.principal;
        const { mapping, projection } = this.checkReadAccess(model, name, access);
        await projection.assertCurrent(principal.owner);
        const invoke = () => this.functions.invoke(model, mapping.function, input, { principal, objects: new Objects(this.db, model, access), signal, taskId: task?.id, ...(task && tasks ? { execution: { task, tasks } } : {}) });
        // A new execution step can request a fresh read when a saved observation no longer qualifies.
        const result = task && tasks ? await tasks.readSource(task, digest({ source: name, input, places: task.input.places, step: task.execution_step ?? 0 }), input, invoke) : await invoke();
        signal.throwIfAborted();
        return result;
    }
    async project(graph, name, input, result, signal) {
        const { projection } = this.projection(graph.model, name);
        graph.access.definition(graph.model, 'datasource', name);
        signal.throwIfAborted();
        await projection.assertCurrent(graph.owner);
        const output = await projection.apply(graph, name, input, result);
        signal.throwIfAborted();
        await projection.assertCurrent(graph.owner);
        const taskId = graph.change?.taskId;
        const requestId = graph.change?.action ? graph.change.requestId : undefined;
        if (taskId || requestId) {
            const linked = taskId && (await this.db.query(`SELECT name FROM ${this.db.schema}.source_calls
          WHERE task_id=$1 AND state='completed' AND result->'receipt'->>'id'=$2 ORDER BY name LIMIT 1`, [taskId, output.receipt.id], graph.client)).rows[0]?.name;
            const callId = linked && /^[a-f0-9]{64}$/.test(linked) ? linked : undefined;
            await appendTrace(this.db, { owner: graph.owner, release: graph.model.release, projection: graph.model.projection,
                taskId, requestId, scenarioId: graph.model.scenario }, { kind: 'source', source: name, receipt: output.receipt, callId }, graph.client, graph.access.dataRequirements());
        }
        return output;
    }
    async refresh(model, name, input, access, task, tasks, signal, view) {
        const result = await this.read(model, name, input, access, task, tasks, signal);
        return this.publishRead(model, name, input, result, access, task, tasks, signal, view);
    }
    /** Commit a reading already verified against the source and its account. */
    async publishRead(model, name, input, result, access, task, tasks, signal, view) {
        this.checkReadAccess(model, name, access);
        return this.db.transaction(async (client) => {
            if (task && tasks)
                await tasks.current(task, client, true);
            const executor = task
                ? { kind: 'agent', id: 'eigos-ontology-agent' }
                : { kind: 'client', id: access.principal.clientId ?? access.principal.owner };
            const graph = new Objects(this.db, model, access, client, { taskId: task?.id, executor });
            const output = await this.project(graph, name, input, result, signal);
            // The caller chooses the published Interface/Object Type and receipt Link.
            // Reading this view in the ingestion transaction avoids a model round trip for opaque IDs.
            const query = view ? await graph.query({ type: view.type, from: { object: output.receipt, link: view.link }, limit: 100 }) : undefined;
            signal.throwIfAborted();
            if (task && tasks)
                await tasks.current(task, client, true);
            await access.refresh(client);
            return { ...output, ...(query ? { view: query } : {}) };
        });
    }
}
