import { processLogTarget } from '../ontology/process-definition.js';
import type { Database, Sql } from './database.js';
import type { PublishedOntology } from './metadata.js';
type Tables = {
    prefix: string;
    objects: string;
    links: string;
};
type Target = NonNullable<ReturnType<typeof processLogTarget>>;
export type ProcessTransition = {
    sequence: string;
    objectId: string;
    recordedAt: Date;
};
/**
 * The latest transition of a type, or of one object. Writes to one object are serialized by its object lock,
 * so its history sequence is also its commit order.
 */
export declare function readProcessTransitions(db: Database, model: PublishedOntology, owner: string, target: Target, client: Sql, position: {
    latestFor?: string;
}): Promise<ProcessTransition[]>;
/**
 * A rule's place in the committed history of one owner: every transition in a commit before `commit`, and those of
 * `commit` up to history `sequence`, have been consumed. Commit 0 is the history written before the commit journal.
 */
export type ProcessPosition = {
    commit: string;
    sequence: string;
};
/** Where a new rule starts: after every committed transition, or after a history sequence when replaying. */
export declare function processStart(db: Database, owner: string, target: Target, client: Sql, replayFrom?: string): Promise<ProcessPosition>;
/**
 * Committed transitions after a position, in commit order, and the position after them. Earlier history comes first, in
 * sequence order. A read never passes a commit it cannot see yet, so it needs no write lock. Each call examines at
 * most `window` commits, and the position moves past commits without matching transitions.
 */
export declare function readCommittedTransitions(db: Database, model: PublishedOntology, owner: string, target: Target, client: Sql, position: ProcessPosition, limit: number, window?: number): Promise<{
    transitions: (ProcessTransition & {
        commit: string;
    })[];
    position: {
        commit: string;
        sequence: string;
    };
}>;
/** Extend the existing read view only when a query navigates process log types. */
export declare function processLogTables(db: Database, model: PublishedOntology, owner: string, values: unknown[], base: Tables, types: readonly string[], scope?: {
    before: string;
    ids: string;
}): Tables;
export {};
