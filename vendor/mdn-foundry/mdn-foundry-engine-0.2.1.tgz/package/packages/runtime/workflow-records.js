export async function readWorkflowRecord(db, identity, client, kind = null, lock = false) {
    const { rows } = await db.query(`SELECT body,revision FROM ${db.schema}.workflows
     WHERE id=$1 AND owner=$2 AND ontology=$3 AND body->>'kind' IS NOT DISTINCT FROM $4::text
     ${lock ? 'FOR SHARE' : ''}`, [identity.id, identity.owner, identity.ontology, kind], client);
    return rows[0];
}
export function insertWorkflowRecord(db, client, record) {
    return db.query(`INSERT INTO ${db.schema}.workflows(id,owner,ontology,name,body,revision) VALUES($1,$2,$3,$4,$5,1)
     RETURNING revision`, [record.id, record.owner, record.ontology, record.name, record.body], client);
}
