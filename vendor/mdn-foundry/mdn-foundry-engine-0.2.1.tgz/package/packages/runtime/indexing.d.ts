import { z } from 'zod';
import { Access } from './access.js';
import type { Database } from './database.js';
import { Metadata, type PublishedOntology } from './metadata.js';
export declare const indexingInputSchema: z.ZodObject<{
    source: z.ZodString;
    stream: z.ZodString;
    offset: z.ZodNumber;
    mode: z.ZodEnum<{
        batch: "batch";
        stream: "stream";
    }>;
    observedAt: z.ZodISODateTime;
    rows: z.ZodArray<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    deleted: z.ZodDefault<z.ZodArray<z.ZodString>>;
}, z.core.$strict>;
export type IndexingInput = z.input<typeof indexingInputSchema>;
export declare function initializeIndexing(db: Database): Promise<void>;
export declare class Indexing {
    private readonly db;
    private readonly metadata;
    constructor(db: Database, metadata?: Metadata);
    submit(access: Access, model: PublishedOntology, raw: unknown): Promise<{
        id: string;
        state: string;
        offset: number;
        provenance: string;
    }>;
    inspect(access: Access, model: PublishedOntology, id: string): Promise<{
        id: string;
        source: string;
        stream: string;
        offset: string;
        mode: string;
        state: string;
        attempts: number;
        error: string | null;
        submittedAt: Date;
        appliedAt: Date | null;
        release: string;
        digest: string;
        applied_offset: string;
        provenance: string;
    }>;
    retry(access: Access, model: PublishedOntology, id: string): Promise<{
        id: string;
        source: string;
        stream: string;
        offset: string;
        mode: string;
        state: string;
        attempts: number;
        error: string | null;
        submittedAt: Date;
        appliedAt: Date | null;
        release: string;
        digest: string;
        applied_offset: string;
        provenance: string;
    }>;
    cancel(access: Access, model: PublishedOntology, id: string): Promise<{
        id: string;
        source: string;
        stream: string;
        offset: string;
        mode: string;
        state: string;
        attempts: number;
        error: string | null;
        submittedAt: Date;
        appliedAt: Date | null;
        release: string;
        digest: string;
        applied_offset: string;
        provenance: string;
    }>;
    runOne(): Promise<boolean>;
    private applyOne;
    run(signal: AbortSignal): Promise<void>;
}
