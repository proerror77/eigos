import { combineClassification } from '../ontology/classification.js';
import { sseData } from '../sdk/event-stream.js';
import { readFileSync } from 'node:fs';
import { z } from 'zod';
import { Conflict, InvalidInput, PermissionDenied, ServiceUnavailable, digest } from '../core/identity.js';
import { ontologyName } from '../ontology/schema.js';
import { ModelEgress } from './model-egress.js';
import { ComponentSourceSecrets } from './component-source-secrets.js';
const destination = z.strictObject({
    provider: z.string().regex(/^[A-Za-z0-9_.:/-]{1,160}$/), model: z.string().regex(/^[A-Za-z0-9_.:/-]{1,160}$/),
    endpoint: z.url().refine(value => { const url = new URL(value); return url.protocol === 'https:' && !url.username && !url.password && !url.hash && !url.search; }),
    secret: z.string().min(1).max(128), maxTokens: z.number().int().min(1).max(32768),
});
const registry = z.record(ontologyName, destination);
const messages = z.array(z.strictObject({ role: z.enum(['system', 'user', 'assistant']), content: z.string().max(131072) })).min(1).max(100);
const usage = z.object({ prompt_tokens: z.number().int().nonnegative(), completion_tokens: z.number().int().nonnegative() });
const event = z.object({ choices: z.array(z.object({ delta: z.object({ content: z.string().nullish() }).optional() })), usage: usage.nullish() });
export class ComponentModels {
    db;
    secrets;
    transport;
    entries;
    constructor(db, raw, secrets, transport = fetch) {
        this.db = db;
        this.secrets = secrets;
        this.transport = transport;
        this.entries = registry.parse(raw);
    }
    binding(aliases) {
        return digest(aliases.map(alias => [alias, this.destination(alias)]));
    }
    destination(alias) {
        if (!Object.hasOwn(this.entries, alias))
            throw new Conflict('Unknown component model alias');
        return this.entries[alias];
    }
    async *generate(alias, input, context, signal, metrics) {
        const config = this.destination(alias), access = context.objects.access;
        const body = messages.parse(input);
        const authorize = async () => {
            await context.assertCurrent?.();
            await access.refresh();
            signal.throwIfAborted();
            if (!await access.canDisclose(access.requirements()))
                throw new PermissionDenied('Model input permissions changed');
            const decision = await new ModelEgress(this.db, context.principal.owner, config.model, config.provider).decide(combineClassification(access.exportedClassification(), context.execution?.task.input.classification), true);
            if (!decision.allowed)
                throw new PermissionDenied('Model egress is not authorized');
        };
        await authorize();
        const credential = await this.secrets.get(config.secret);
        await authorize();
        let measurement = metrics?.modelUsage?.find(row => row.alias === alias);
        if (metrics && !measurement) {
            measurement = { alias, provider: config.provider, model: config.model, calls: 0, reportedCalls: 0, inputTokens: 0, outputTokens: 0 };
            (metrics.modelUsage ??= []).push(measurement);
        }
        if (measurement)
            measurement.calls++;
        const response = await this.transport(config.endpoint, { method: 'POST', redirect: 'error', signal,
            headers: { authorization: 'Bearer ' + credential, 'content-type': 'application/json', accept: 'text/event-stream' },
            body: JSON.stringify({ model: config.model, messages: body, max_tokens: config.maxTokens, stream: true, stream_options: { include_usage: true } }) }).catch(() => {
            signal.throwIfAborted();
            throw new ServiceUnavailable('The configured model endpoint could not be reached');
        });
        let reported;
        for await (const data of sseData(response, 4 << 20)) {
            if (data === '[DONE]') {
                if (reported && measurement)
                    measurement.reportedCalls++;
                return;
            }
            let raw;
            try {
                raw = JSON.parse(data);
            }
            catch {
                throw new ServiceUnavailable('The model returned a malformed event');
            }
            const parsed = event.safeParse(raw);
            if (!parsed.success)
                throw new ServiceUnavailable('The model returned an invalid event');
            const frame = parsed.data;
            if (frame.usage) {
                if (reported && (frame.usage.prompt_tokens < reported.prompt_tokens || frame.usage.completion_tokens < reported.completion_tokens))
                    throw new ServiceUnavailable('The model returned inconsistent usage');
                if (measurement) {
                    measurement.inputTokens += frame.usage.prompt_tokens - (reported?.prompt_tokens ?? 0);
                    measurement.outputTokens += frame.usage.completion_tokens - (reported?.completion_tokens ?? 0);
                }
                reported = frame.usage;
            }
            const chunk = frame.choices[0]?.delta?.content;
            if (chunk) {
                await authorize();
                yield chunk;
            }
        }
        throw new ServiceUnavailable('Incomplete model response');
    }
}
export class ComponentModelSession {
    implementation;
    context;
    models;
    metrics;
    controller = new AbortController();
    signal;
    generation;
    calls = 0;
    emittedBytes = 0;
    constructor(implementation, context, models, outer, metrics) {
        this.implementation = implementation;
        this.context = context;
        this.models = models;
        this.metrics = metrics;
        this.signal = AbortSignal.any([outer, this.controller.signal, AbortSignal.timeout(implementation.limits.deadlineMs)]);
    }
    generate(alias, messages) {
        if (!this.implementation.models?.includes(alias) || !this.models || this.context.objects.model.scenario || this.context.scenarioEvaluation)
            throw new PermissionDenied('Model capability is unavailable');
        if (this.generation || ++this.calls > 8)
            throw new Conflict('Model call limit reached');
        this.generation = this.models.generate(alias, messages, this.context, this.signal, this.metrics);
    }
    async next() {
        if (!this.generation)
            throw new InvalidInput('No model generation in progress');
        const segment = await this.generation.next();
        if (!segment.done)
            return segment.value;
        this.generation = undefined;
        return null;
    }
    async emit(text) {
        if (!this.implementation.stream)
            throw new PermissionDenied('Streaming is not declared');
        if (!text)
            return;
        this.emittedBytes += Buffer.byteLength(text);
        const limit = this.implementation.limits.outputBytes ?? (1 << 20);
        if (this.emittedBytes > limit)
            throw new InvalidInput('Stream exceeded its output byte limit');
        this.signal.throwIfAborted();
        await this.context.assertCurrent?.();
        const access = this.context.objects.access;
        if (!await access.canDisclose(access.requirements()))
            throw new PermissionDenied('Result permissions changed');
        await this.context.onChunk?.(text);
    }
    async close() {
        this.controller.abort();
        await this.generation?.return(undefined).catch(() => { });
    }
}
export function configuredComponentModels(db, env = process.env) {
    const file = env.EIGOS_FUNCTION_MODELS_FILE;
    if (!file)
        return;
    const bundle = env.EIGOS_COMPONENT_SOURCE_SECRETS_FILE, key = env.EIGOS_COMPONENT_SOURCE_SECRETS_KEY_FILE;
    if (!bundle || !key)
        throw new Error('Component model aliases require encrypted credentials');
    return new ComponentModels(db, JSON.parse(readFileSync(file, 'utf8')), new ComponentSourceSecrets(bundle, key));
}
