import type { ObjectRef } from '../ontology/schema.js';
import { type Principal } from '../core/identity.js';
import { Database, type Sql } from './database.js';
import { Metadata, type PublishedOntology } from './metadata.js';
import { TaskResult } from './access.js';
import { Actions } from './actions.js';
import { Objects } from './objects.js';
import { Tasks, type Task } from './tasks.js';
export type ScheduledCall = {
    scheduleId: string;
    action: string;
    arguments: Record<string, unknown>;
    deadline: string;
    contract: string;
    observationInterestId?: string;
};
export type ScheduleTerminal = (db: Database, model: PublishedOntology, client: Sql, owner: string, scheduleId: string, call: {
    action: string;
    arguments: unknown;
}, state: 'expired' | 'failed', taskId?: string) => Promise<void>;
export declare class DeferredExecution extends Error {
    readonly until: string;
    constructor(until: string);
}
/** Future business work does not pin an old runtime for days. Admission checks
 * the exact action contract against the active release when the due task starts. */
export declare class ScheduledActions {
    private readonly db;
    private readonly metadata;
    private readonly terminalHandlers;
    constructor(db: Database, metadata?: Metadata, terminalHandlers?: ReadonlyMap<string, ScheduleTerminal>);
    enqueue(graph: Objects, job: {
        id: string;
        action: string;
        arguments: Record<string, unknown>;
        runAt: string;
        deadline: string;
        sourceTaskId?: string;
        observationInterestId?: string;
    }): Promise<void>;
    /** Retain the booked time and deadline. Only already authorized schedules bound to this subject can move off hold. */
    replanSubject(model: PublishedOntology, owner: string, object: ObjectRef, client: Sql): Promise<void>;
    /** A job may become due before the Indexer consumes its first dependency change. */
    private hasProcessWatch;
    private refreshTransition;
    promoteOne(): Promise<boolean>;
    current(task: Task, client?: Sql): Promise<void>;
    continueAt(graph: Objects, task: Task, until: string): Promise<void>;
    /** Move an authorized pending check forward while preserving its action, scopes and deadline. */
    advance(graph: Objects, id: string, at: string): Promise<boolean>;
    inspect(principal: Principal, id: string, client?: Sql): Promise<{
        id: any;
        state: any;
        runAt: any;
        deadline: any;
        taskId: any;
        sourceTaskId: any;
        error: any;
    }>;
    cancel(graph: Objects, id: string): Promise<{
        externalEffect: any;
    }>;
}
export declare class ScheduledActionRunner {
    private readonly db;
    private readonly metadata;
    private readonly tasks;
    private readonly actions;
    constructor(db: Database, metadata: Metadata, tasks: Tasks, actions: Actions);
    run(task: Task, signal: AbortSignal): Promise<TaskResult>;
}
