import { z } from 'zod';
import { type Principal } from '../core/identity.js';
import { type ActionInputPurpose } from './clarification.js';
import { Tasks, type Task } from './tasks.js';
import type { Sql } from './database.js';
export declare const paDispatchClaimSchema: z.ZodObject<{
    requestId: z.ZodUUID;
}, z.core.$strict>;
export declare const paResponseSchema: z.ZodObject<{
    requestId: z.ZodUUID;
    response: z.ZodRecord<z.ZodString, z.ZodUnknown>;
    dispatchToken: z.ZodOptional<z.ZodUUID>;
}, z.core.$strict>;
export type PADispatch = {
    expiresAt: string;
    operationKey: string;
    responseWithoutDispatch: Record<string, unknown>;
};
type ActionInput = {
    actionRequestId: string;
    purpose: ActionInputPurpose;
    dispatch?: PADispatch;
};
export declare const paInboxSchema: z.ZodObject<{
    cursor: z.ZodOptional<z.ZodUUID>;
    limit: z.ZodDefault<z.ZodNumber>;
}, z.core.$strict>;
/** The authenticated original PA supplies requested context; the model cannot impersonate it. */
export declare class PARequests {
    private readonly tasks;
    constructor(tasks: Tasks);
    pending(principal: Principal, raw?: unknown): Promise<{
        items: {
            taskId: any;
            sourceTaskId: any;
            scheduleId: any;
            request: any;
        }[];
        cursor: any;
    }>;
    requestActionInput(task: Task, actionRequestId: string, round: string, capability: string, purpose: ActionInputPurpose, input: Record<string, unknown>, responseSchema: Record<string, unknown>): Promise<unknown>;
    request(task: Task, operation: string, capability: string, input: Record<string, unknown>, responseSchema: Record<string, unknown>, dataScope?: Record<string, unknown>): Promise<unknown>;
    requestWithId(task: Task, operation: string, capability: string, input: Record<string, unknown>, responseSchema: Record<string, unknown>, dataScope?: Record<string, unknown>, beforeDispatch?: (client: Sql) => Promise<void>, actionInput?: ActionInput): Promise<{
        requestId: string;
        requestedAt: Date;
        response: unknown;
    }>;
    private lockTask;
    private lockRequest;
    private responseAccess;
    /** One successful transaction grants dispatch for one pending authorized request. A lost claim is never reissued. */
    claimDispatch(principal: Principal, taskId: string, raw: unknown, authorize?: (client: Sql) => Promise<void>): Promise<{
        dispatchToken: `${string}-${string}-${string}-${string}-${string}`;
    }>;
    respond(principal: Principal, taskId: string, raw: unknown, conversationId?: string, authorize?: (client: Sql) => Promise<void>): Promise<Task>;
}
export {};
