import { z } from 'zod';
import { type LinkData, type ObjectRef } from '../ontology/schema.js';
import { Access } from './access.js';
import { Database, type Sql } from './database.js';
import { Metadata, PublishedOntology } from './metadata.js';
import { Objects } from './objects.js';
type Properties = Record<string, unknown>;
type ValidateAction = (prefix: Objects, action: string, input: Properties) => Promise<void>;
export interface ScenarioDecisionContext {
    model: PublishedOntology;
    owner: string;
    reviewer: Access;
    client: Sql;
    review: {
        id: string;
        revision: number;
        snapshot: string;
        objects: {
            ref: ObjectRef;
            after: Properties | null;
        }[];
        links: {
            type: string;
            from: ObjectRef;
            to: ObjectRef;
            removed: boolean;
        }[];
    };
}
/** Installations can validate their own optional decision payload and expose their own decision memory. */
export interface ScenarioDecisionSupport<Decision extends Record<string, unknown> = Record<string, unknown>, Memory = unknown> {
    parseDecision?(input: Record<string, unknown>): Decision;
    inspect(context: ScenarioDecisionContext): Promise<Memory | undefined>;
    capture(context: ScenarioDecisionContext, decision: Decision, approvedAt?: Date): Promise<void>;
    validateApproval(context: ScenarioDecisionContext): Promise<boolean>;
}
export declare const createScenarioSchema: z.ZodObject<{
    requestId: z.ZodString;
    name: z.ZodString;
    kind: z.ZodDefault<z.ZodEnum<{
        persisted: "persisted";
        temporary: "temporary";
    }>>;
    sessionId: z.ZodOptional<z.ZodUUID>;
    description: z.ZodDefault<z.ZodString>;
    ttlSeconds: z.ZodOptional<z.ZodNumber>;
}, z.core.$strict>;
export declare const continueScenarioSchema: z.ZodObject<{
    id: z.ZodUUID;
    revision: z.ZodNumber;
    requestId: z.ZodString;
}, z.core.$strict>;
export declare function initializeScenarioLifecycle(db: Database): Promise<void>;
export declare class Scenarios<Memory = unknown> {
    private readonly db;
    private readonly decisions?;
    constructor(db: Database, decisions?: ScenarioDecisionSupport<Record<string, unknown>, Memory> | undefined);
    openSession(access: Access, ttlSeconds?: number, client?: Sql): Promise<{
        id: string;
        expiresAt: Date;
    }>;
    closeSession(access: Access, sessionId: string): Promise<{
        sessionId: string;
        closed: boolean;
    }>;
    cleanup(sessionId?: string, owner?: string): Promise<{
        deleted: number;
        more: boolean;
    }>;
    share(access: Access, model: PublishedOntology, id: string, revision: number, readers: string[]): Promise<{
        id: string;
        revision: number;
        readers: string[];
    }>;
    inviteReviewers(access: Access, model: PublishedOntology, id: string, revision: number, reviewers: string[], existing?: Sql): Promise<{
        id: string;
        revision: number;
        reviewers: string[];
    }>;
    pendingReviews(access: Access, model: PublishedOntology, page: number): Promise<{
        items: {
            id: string;
            name: string;
            revision: number;
            conflicts: boolean;
            evidenceChanged: boolean | undefined;
            approved: boolean;
        }[];
        nextPage?: number | undefined;
    }>;
    inspectReview(access: Access, model: PublishedOntology, id: string): Promise<{
        id: string;
        revision: number;
        objects: {
            ref: {
                type: string;
                id: string;
            };
            before: {
                [k: string]: unknown;
            } | null;
            after: {
                [k: string]: unknown;
            } | null;
            editedFields: string[];
            conflict: boolean;
        }[];
        links: {
            type: string;
            from: {
                type: string;
                id: string;
            };
            to: {
                type: string;
                id: string;
            };
            removed: boolean;
            conflict: boolean;
        }[];
        commit?: {
            action: string;
            input: Record<string, unknown>;
            effects: import("./effects.js").ActionEffect[];
        } | undefined;
        evidence?: {
            ref: ObjectRef;
            revision: number;
        }[] | undefined;
        evidenceVersion?: string | undefined;
        evidenceChanged?: boolean | undefined;
        name: string;
        conflicts: boolean;
        snapshot: string;
    }>;
    approveReview(access: Access, model: PublishedOntology, id: string, revision: number, snapshot: string, decision?: Record<string, unknown>, existing?: Sql): Promise<{
        id: string;
        revision: number;
        reviewer: string;
        approved: true;
    }>;
    rejectReview(access: Access, model: PublishedOntology, id: string, revision: number, snapshot: string, client: Sql): Promise<void>;
    private setReviewStatus;
    reviewActionOwner(access: Access, model: PublishedOntology, id: string, revision: number, kind: 'submit' | 'approve' | 'reject', client: Sql): Promise<string>;
    private reviewOffer;
    private lockReview;
    private reviewDiff;
    list(access: Access, model: PublishedOntology, cursor?: string): Promise<{
        items: {
            id: string;
            name: string;
            revision: number;
            state: string;
            expiresAt: Date;
            expires_at: Date;
        }[];
        cursor: string | undefined;
    }>;
    create(access: Access, model: PublishedOntology, raw: unknown, beforeCommit?: (client: Sql) => Promise<void>, context?: {
        client: Sql;
        runId: string;
        reviewers: string[];
    } | {
        client: Sql;
    }): Promise<{
        id: string;
        name: string;
        release: string;
        revision: number;
        state: string;
        expiresAt: Date;
        expires_at: Date;
        kind: string;
        description: string;
    }>;
    view(access: Access, model: PublishedOntology, id: string, client?: Sql): Promise<PublishedOntology>;
    private continuationRows;
    private continuationStatus;
    continuationSources(access: Access, model: PublishedOntology): Promise<{
        items: {
            id: string;
            name: string;
            kind: string;
            release: string;
            revision: number;
            expiresAt: Date;
            continuation: {
                status: 'ready';
                reason: null;
            } | {
                status: 'blocked';
                reason: 'incomplete-action-journal';
            };
        }[];
    }>;
    /** Recovery displays historical differences using today's schema and permissions; it performs no edits. */
    inspectContinuation(access: Access, model: PublishedOntology, id: string, revision: number): Promise<{
        id: string;
        revision: number;
        name: string;
        release: string;
        continuation: {
            status: 'ready';
            reason: null;
        } | {
            status: 'blocked';
            reason: 'incomplete-action-journal';
        };
        objects: {
            ref: {
                type: string;
                id: string;
            };
            before: {
                [k: string]: unknown;
            } | null;
            after: {
                [k: string]: unknown;
            } | null;
        }[];
        links: {
            type: string;
            from: {
                type: string;
                id: string;
            };
            to: {
                type: string;
                id: string;
            };
            removed: boolean;
        }[];
    }>;
    continueScenario(access: Access, model: PublishedOntology, raw: unknown): Promise<{
        id: string;
        revision: number;
        source: string;
        release: string;
    }>;
    private changedLinks;
    /** Compare staged rows with one snapshot of their live objects. Deleted objects carry bounded, ordered link snapshots. */
    private objectChangesWithLive;
    private changes;
    private steps;
    evaluationFootprint(owner: string, id: string, client: Sql): Promise<string>;
    private footprint;
    private applyProposedEdit;
    private validateSteps;
    private withReplay;
    private replayJournal;
    private lockDecisionSets;
    private decisionCheckpoint;
    inspect(access: Access, model: PublishedOntology, id: string, existing?: Sql): Promise<{
        id: string;
        name: string;
        revision: number;
        state: string;
        expiresAt: Date;
        objects: {
            ref: {
                type: string;
                id: string;
            };
            before: Record<string, unknown> | null;
            after: Record<string, unknown> | null;
            editedFields: string[];
            conflict: boolean;
        }[];
        links: {
            type: string;
            from: {
                type: string;
                id: string;
            };
            to: {
                type: string;
                id: string;
            };
            removed: boolean;
            conflict: boolean;
        }[];
        conflicts: boolean;
        review: {
            reviewers: string[];
            canInvite: boolean;
        };
    }>;
    /**
     * S1, automatic sync: brings one open persisted Scenario up to the live data, as Palantir rebases a scenario every 10
     * minutes, and reports whether it claimed one. Live commits since the Scenario's last sync that edit one of its staged
     * objects, or change a link of a staged link's type at one of its ends, rebase it as its creator. Other commits only
     * advance its position. A conflict, or a Scenario its publication no longer allows, stops automatic sync and is
     * recorded on the Scenario; an explicit rebase resolves it.
     */
    syncOne(metadata: Metadata): Promise<boolean>;
    /** Whether live commits after `after` through `through` touched the Scenario's staged objects or staged links' ends. */
    private stagedTouched;
    rebase(access: Access, model: PublishedOntology, id: string, revision: number): Promise<{
        id: string;
        revision: number;
    }>;
    /** Read occupied single-valued endpoints in sets and probe many-to-many edits by exact key. */
    private conflictingLinks;
    private linkConflict;
    private cardinalityConflict;
    discard(access: Access, model: PublishedOntology, id: string, revision: number, beforeCommit?: (client: Sql) => Promise<void>): Promise<{
        id: string;
        state: string;
        revision: number;
    }>;
    /** Called only from a published merge Action, inside its atomic edit transaction. */
    mergeInto(graph: Objects, id: string, revision: number, scope: {
        objects: string[];
        links: string[];
        validate?: (view: Objects, touched: {
            ref: ObjectRef;
            deleted: boolean;
        }[], links: LinkData[]) => Promise<void>;
        validateAction?: ValidateAction;
    }): Promise<void>;
}
export {};
