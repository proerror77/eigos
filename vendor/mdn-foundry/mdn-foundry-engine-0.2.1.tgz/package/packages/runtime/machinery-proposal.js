import { Conflict, digest, NotFound, PermissionDenied } from '../core/identity.js';
import { analyzeMachinery } from './machinery-analysis.js';
function summarize(report, proposed) {
    const reference = report.reference?.transitions ?? [];
    const proposedEdges = proposed.transitions;
    const keys = new Set([...reference, ...proposedEdges].map(edge => JSON.stringify([edge.from, edge.to])));
    const affected = [...keys].flatMap(key => {
        const [from, to] = JSON.parse(key);
        const matches = (edge) => edge.from === from && edge.to === to;
        if (digest(reference.filter(matches)) === digest(proposedEdges.filter(matches)))
            return [];
        return [{ from, to, observedCases: report.transitions.find(matches)?.cases ?? 0 }];
    });
    return { cases: report.casesTotal, deviationCases: report.conformance.deviation,
        candidateDeviationCases: report.comparison.candidate.deviation,
        bottlenecks: report.findings.bottlenecks.map(({ state, completedP95Ms }) => ({ state, completedP95Ms })),
        affectedEdges: affected };
}
export async function analyzeProposal(db, access, model, query, type, proposed) {
    if (query.type !== type || query.reference || query.candidate)
        throw new Conflict('Use the selected process and its published reference for proposal evidence');
    const report = await analyzeMachinery(db, access, model, { ...query, candidate: proposed });
    const requirements = await access.finalDataRequirements();
    if (!await access.canReturn(requirements))
        throw new PermissionDenied('Machinery evidence permissions changed');
    return { release: model.release, process: type, owner: access.principal.owner, contributors: [access.principal.owner], modelDigest: digest(proposed),
        query: { ...query, from: report.from, to: report.to }, visibility: access.visibilityDigest,
        requirements, summary: summarize(report, proposed) };
}
export async function visibleProposalEvidence(db, access, model, evidence, current) {
    const { query } = evidence;
    const header = { process: evidence.process, release: evidence.release, from: query.from, to: query.to };
    if (!current || digest(current) !== evidence.modelDigest)
        return { ...header, scope: 'earlier_revision' };
    if (access.principal.owner === evidence.owner) {
        if (await access.canReturn(evidence.requirements) && access.visibilityDigest === evidence.visibility)
            return { ...header, scope: 'recorded', summary: evidence.summary };
        return { ...header, scope: 'restricted' };
    }
    // A definition reviewer has their own data authority. Never expose private case selectors, saved sets or source rows.
    if (query.object || query.focus || query.setId || query.externalSource || query.filter)
        return { ...header, scope: 'restricted' };
    try {
        const replay = await analyzeProposal(db, access, model, query, evidence.process, current);
        return { ...header, scope: 'reviewer', summary: replay.summary };
    }
    catch (error) {
        if (error instanceof PermissionDenied || error instanceof NotFound)
            return { ...header, scope: 'restricted' };
        if (error instanceof Conflict)
            return { ...header, scope: 'unavailable' };
        throw error;
    }
}
