import type { Ontology } from '../ontology/model.js';
import type { ObjectRef } from '../ontology/schema.js';
import { Database } from './database.js';
import { Functions } from './functions.js';
import { Objects } from './objects.js';
import { Tasks, type Task } from './tasks.js';
import { Access } from './access.js';
import type { PublishedOntology } from './metadata.js';
/** A source projection consumes the server-held Function result, never model-supplied rows. */
export interface SourceProjection {
    assertCurrent(owner: string): Promise<void>;
    apply(objects: Objects, source: string, input: Record<string, unknown>, result: unknown): Promise<{
        receipt: ObjectRef;
        objects: ObjectRef[];
    }>;
}
export declare class Sources {
    private readonly db;
    private readonly functions;
    private readonly projections;
    constructor(db: Database, functions: Functions, projections: ReadonlyMap<string, SourceProjection>);
    private projection;
    bindings(model: Ontology): {
        [k: string]: string;
    };
    checkReadAccess(model: PublishedOntology, name: string, access: Access): {
        mapping: {
            apiName: string;
            objectType: string;
            function: string;
            classification?: {
                sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                compartments: string[];
            } | undefined;
            properties: Record<string, string>;
        };
        projection: SourceProjection;
    };
    read(model: PublishedOntology, name: string, input: Record<string, unknown>, access: Access, task: Task | undefined, tasks: Tasks | undefined, signal: AbortSignal): Promise<unknown>;
    project(graph: Objects, name: string, input: Record<string, unknown>, result: unknown, signal: AbortSignal): Promise<{
        receipt: ObjectRef;
        objects: ObjectRef[];
    }>;
    refresh(model: PublishedOntology, name: string, input: Record<string, unknown>, access: Access, task: Task | undefined, tasks: Tasks | undefined, signal: AbortSignal, view?: {
        type: string;
        link: string;
    }): Promise<{
        receipt: ObjectRef;
        objects: ObjectRef[];
        view?: {
            items: import("../ontology/schema.js").ObjectData[];
            cursor?: string;
        } | undefined;
    }>;
    /** Commit a reading already verified against the source and its account. */
    publishRead(model: PublishedOntology, name: string, input: Record<string, unknown>, result: unknown, access: Access, task: Task | undefined, tasks: Tasks | undefined, signal: AbortSignal, view?: {
        type: string;
        link: string;
    }): Promise<{
        receipt: ObjectRef;
        objects: ObjectRef[];
        view?: {
            items: import("../ontology/schema.js").ObjectData[];
            cursor?: string;
        } | undefined;
    }>;
}
