/** Deadline for a phase awaiting committed source evidence. Re-reading the same receipt never renews it. */
export declare function eventObservation(input: {
    startedAt: Date;
    lastObservedAt: Date | null;
    maxSilenceSeconds: number;
    now: Date;
}): {
    status: 'waiting' | 'stranded';
    reason: string;
    nextReviewAt: Date;
};
