import { type Principal } from '../core/identity.js';
import type { ObjectRef } from '../ontology/schema.js';
import { Access } from './access.js';
import type { ChangeFootprint } from './change-feed.js';
import type { Database, Sql } from './database.js';
import type { MachineryExecution } from './machinery-execution.js';
import type { Metadata, PublishedOntology } from './metadata.js';
type Watch = {
    object: ObjectRef;
    release: string;
    forward: string[];
    reverse: string[];
};
export type SubscriptionFootprint = ChangeFootprint & {
    machinery?: Watch;
};
export declare function processFootprint(model: PublishedOntology, object: ObjectRef): SubscriptionFootprint;
export declare class MachineryWatchPlanner {
    private readonly db;
    private readonly metadata;
    private readonly execution;
    constructor(db: Database, metadata: Metadata, execution: MachineryExecution);
    replanSchedules(ontology: string, owner: string, watch: Watch, client: Sql): Promise<void>;
    signature(model: PublishedOntology, access: Access, object: ObjectRef, client: Sql): Promise<string>;
    inspect(ontology: string, principal: Principal, watch: Watch, after: string, through: string, client: Sql): Promise<{
        readonly stopped: true;
        readonly end?: undefined;
        readonly signature?: undefined;
    } | {
        readonly stopped?: undefined;
        readonly end: string;
        readonly signature?: undefined;
    } | {
        readonly stopped?: undefined;
        readonly end: string;
        readonly signature: string;
    } | undefined>;
}
export {};
