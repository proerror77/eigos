import { z } from 'zod';
import type { PublishedOntology } from './metadata.js';
import type { Objects } from './objects.js';
import type { Database, Sql } from './database.js';
declare const allocationSchema: z.ZodObject<{
    allocation: z.ZodString;
    resource: z.ZodString;
    start: z.ZodISODateTime;
    end: z.ZodISODateTime;
}, z.core.$strict>;
export type ResourceAllocation = z.infer<typeof allocationSchema>;
/** An uncertain delivery may survive a release, provided its published confirmation contract still exists. */
export declare function checkPendingReservationContracts(db: Database, model: PublishedOntology, client: Sql): Promise<void>;
export declare function initializeResourceReservations(db: Database): Promise<void>;
/** One authority for occupied resource intervals. Call from the Action's existing transaction. */
export declare class ResourceReservations {
    private readonly db;
    constructor(db: Database);
    /** All mutations use the same holder lock, including changes to a supplier operation's outstanding claim. */
    private lock;
    private allocations;
    private snapshot;
    /** Replacing or undoing an allocation can remove a shared provider's occupied range. */
    private authorizeOccupancy;
    private journal;
    replace(owner: string, holder: string, raw: readonly ResourceAllocation[], state: 'held' | 'committed', client: Sql, graph?: Objects): Promise<void>;
    /** Replace at Action commit; before irreversible dispatch retain both the old and proposed occupied intervals. */
    forAction(graph: Objects, name: string, input: Record<string, unknown>, requestId: string, phase: 'dispatch' | 'commit' | 'merge'): Promise<void>;
    /** A declared outbox fulfillment becomes authoritative in the transaction that acknowledges that exact effect. */
    finishEffect(owner: string, ontology: string, action: string, request: string, effect: string, completed: boolean, client: Sql): Promise<void>;
    undo(graph: Objects, request: string): Promise<void>;
    private write;
}
export {};
