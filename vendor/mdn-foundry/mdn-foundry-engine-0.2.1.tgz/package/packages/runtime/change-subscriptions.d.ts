import { MachineryWatchPlanner } from './machinery-watch.js';
import { z } from 'zod';
import type { Access } from './access.js';
import { type ChangeFootprint } from './change-feed.js';
import type { Database } from './database.js';
import type { PublishedOntology } from './metadata.js';
import type { Tasks } from './tasks.js';
/**
 * Funnel 05.4: change subscriptions. A subscription is a footprint (the object types and link types whose committed
 * changes matter to its subscriber) and a position (the owner's last commit it has been woken for). After commits that
 * touch the footprint, the subscriber is woken once with the commits it has not seen: a task in its conversation that
 * carries the commit window and the types and links it touched. The window and the new position are committed in one
 * transaction, so no commit is missed and none is delivered twice. Wake tasks run as the subscription's principal, which
 * reads the changes again under its current permissions; a subscription keeps no data.
 */
export declare function initializeChangeSubscriptions(db: Database): Promise<void>;
export declare const watchMachinerySchema: z.ZodObject<{
    requestId: z.ZodString;
    conversationId: z.ZodString;
    object: z.ZodObject<{
        type: z.ZodString;
        id: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const subscribeSchema: z.ZodObject<{
    requestId: z.ZodString;
    conversationId: z.ZodString;
    types: z.ZodDefault<z.ZodArray<z.ZodString>>;
    links: z.ZodDefault<z.ZodArray<z.ZodString>>;
    query: z.ZodOptional<z.ZodObject<{
        type: z.ZodString;
        where: z.ZodOptional<z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodNumber, z.ZodBoolean, z.ZodNull]>>>>;
        filter: z.ZodOptional<z.ZodPipe<z.ZodUnknown, z.ZodType<import("./query-filter.js").Predicate, unknown, z.core.$ZodTypeInternals<import("./query-filter.js").Predicate, unknown>>>>;
        orderBy: z.ZodOptional<z.ZodArray<z.ZodObject<{
            property: z.ZodString;
            direction: z.ZodDefault<z.ZodEnum<{
                asc: "asc";
                desc: "desc";
            }>>;
        }, z.core.$strict>>>;
        select: z.ZodOptional<z.ZodArray<z.ZodString>>;
        from: z.ZodOptional<z.ZodObject<{
            object: z.ZodObject<{
                type: z.ZodString;
                id: z.ZodString;
            }, z.core.$strict>;
            link: z.ZodString;
            as: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
/** The wake a subscriber receives: the commits after `after` through `through`, and what in its footprint they touched. */
export type ChangeWake = {
    event: 'ontology_changes';
    subscription: string;
    commits: {
        after: string;
        through: string;
    };
    types: string[];
    links: string[];
};
export declare class ChangeSubscriptions {
    private readonly db;
    private readonly tasks;
    private readonly planner?;
    constructor(db: Database, tasks: Tasks, planner?: MachineryWatchPlanner | undefined);
    /**
     * Subscribes the principal to commits that touch the footprint, from the owner's latest commit on. The principal must
     * be able to read every watched type and see every watched link, and to submit tasks, as each wake is one.
     */
    subscribe(access: Access, model: PublishedOntology, raw: unknown): Promise<{
        id: string;
        position: string;
        footprint: ChangeFootprint;
    }>;
    watchMachinery(access: Access, model: PublishedOntology, raw: unknown): Promise<{
        id: string;
        position: string;
        footprint: ChangeFootprint;
    }>;
    private save;
    cancel(access: Access, id: string, machineryOnly?: boolean): Promise<void>;
    list(access: Access): Promise<import("pg").QueryResultRow[]>;
    private scanMachinery;
    /**
     * Checks one due subscription, at most once a second each, and reports whether it claimed one. Commits that touch the
     * footprint wake the subscriber with their window; other commits only advance its position. The position moves only
     * from the value read, in the transaction that submits the wake, so concurrent dispatchers deliver each window once.
     */
    scanOne(): Promise<boolean>;
}
