/** Identity of the shipped implementation inputs, identical in source and built execution. */
export declare function implementationDigest(): string;
