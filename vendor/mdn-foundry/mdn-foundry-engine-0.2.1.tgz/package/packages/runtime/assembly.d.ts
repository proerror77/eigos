import type { Ontology } from '../ontology/model.js';
import type { OntologyDocument } from '../ontology/schema.js';
import { Actions, type CommittedEffects } from './actions.js';
import type { Database } from './database.js';
import { Effects } from './effects.js';
import type { RuntimeExtensions } from './extensions.js';
import { Functions, type FunctionHandler } from './functions.js';
import { Sources, type SourceProjection } from './sources.js';
export declare function assembleRuntime(db: Database, definitions: OntologyDocument['functionTypes'], handlers: ReadonlyMap<string, FunctionHandler>, projections?: ReadonlyMap<string, SourceProjection>, extensions?: RuntimeExtensions, committedEffects?: CommittedEffects): {
    functions: Functions;
    sources: Sources;
    effects: Effects;
    actions: Actions;
    scenarioDecisions: import("./scenarios.js").ScenarioDecisionSupport<Record<string, unknown>, unknown> | undefined;
    describe(model: Ontology): {
        functions: Record<string, string>;
        sources: {
            [k: string]: string;
        };
        webhooks?: {
            [k: string]: string;
        } | undefined;
    };
    checkRelease: (model: Ontology) => Promise<void>;
};
