import type { Database } from './database.js';
export declare function installOwnerIsolation(db: Database): Promise<{
    tables: ("action_changes" | "action_undo_requests" | "actions" | "change_commits" | "edit_history" | "entity_binding_history" | "entity_bindings" | "execution_trace" | "geometry_blobs" | "link_history" | "links" | "machinery_history" | "materializations" | "materialized_links" | "materialized_objects" | "object_edits" | "objects" | "scenario_actions" | "scenario_approvals" | "scenario_evaluation_runs" | "scenario_evaluation_suites" | "scenario_links" | "scenario_objects" | "semantic_vectors" | "source_values")[];
}>;
export declare function assertOwnerIsolation(db: Database): Promise<void>;
