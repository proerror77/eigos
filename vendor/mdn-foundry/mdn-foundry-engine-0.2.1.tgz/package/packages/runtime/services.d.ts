import { type TaskResultProjection } from './tasks.js';
import type { Actions } from './actions.js';
import { z } from 'zod';
import type { Principal } from '../core/identity.js';
import { Access } from './access.js';
import { Database } from './database.js';
import { Metadata } from './metadata.js';
import { type ScenarioDecisionSupport } from './scenarios.js';
import { Effects } from './effects.js';
import type { Functions } from './functions.js';
import type { Bindings } from './metadata.js';
export type ServiceRegistration = <S extends z.ZodType>(name: string, description: string, schema: S, write: boolean, run: (access: Access, input: z.output<S>) => Promise<unknown>) => void;
export type RegisterServices = (register: ServiceRegistration, db: Database, metadata: Metadata, actions: Actions) => void;
export declare function ontologyServices(db: Database, metadata: Metadata, bindings: Bindings & {
    registerServices?: RegisterServices;
    projectTaskResult: TaskResultProjection;
    scenarioDecisions?: ScenarioDecisionSupport<Record<string, unknown>, unknown>;
}, functions: Functions, effects: Effects, actions: Actions, ontologyId?: string): Map<string, {
    schema: z.ZodType;
    description: string;
    invoke: (principal: Principal, input: unknown) => Promise<unknown>;
    invokeForMcpOperator?: (principal: Principal, input: unknown) => Promise<unknown>;
}>;
