import type { Predicate } from './query-filter.js';
export type Metric = {
    op: 'count';
    property?: string;
} | {
    op: 'sum' | 'min' | 'max' | 'avg';
    property: string;
};
export declare function supportsStoredPredicate(predicate?: Predicate): boolean;
export declare function isNumeric(schema: Record<string, unknown>): boolean;
export declare function supportsStoredOrder(schema: Record<string, unknown>): boolean;
export declare function storedPredicate(predicate: Predicate, property: (path: string) => string, bind: (value: unknown) => string): string;
