import type { Database, Sql } from './database.js';
import type { Bindings, PublishedOntology } from './metadata.js';
export type ReleaseCheck = {
    name: string;
    passed: boolean;
};
export declare function initializeReleaseEvaluation(db: Database): Promise<void>;
export declare function requireReleaseEvaluation(db: Database, client: Sql, model: PublishedOntology, bindings: Bindings, base: string | null, projectionFingerprint: string): Promise<void>;
