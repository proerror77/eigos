import { Conflict, NotFound } from '../core/identity.js';
const active = new WeakMap();
/**
 * Transaction-local state of one exclusively locked plain object. The usual rule evaluator, row/cell checks and
 * journal still run for each logical revision. Physical object state and durable records flush before COMMIT.
 */
export class HotEditBuffer {
    db;
    client;
    model;
    owner;
    ref;
    original;
    edits = [];
    steps = [];
    related;
    snapshotBytes = 0;
    current;
    constructor(db, client, model, owner, ref, original) {
        this.db = db;
        this.client = client;
        this.model = model;
        this.owner = owner;
        this.ref = ref;
        this.original = original;
        this.current = original;
    }
    static for(client, model, owner, ref) {
        const buffer = active.get(client);
        return buffer && !model.scenario && !model.evaluation && buffer.model.release === model.release && buffer.owner === owner &&
            (!ref || (buffer.ref.type === ref.type && buffer.ref.id === ref.id)) ? buffer : undefined;
    }
    static async run(db, client, model, owner, ref, work) {
        const row = await db.withObjectAccess(() => db.query(`SELECT revision,properties FROM ${db.schema}.objects
      WHERE projection=$1 AND owner=$2 AND type=$3 AND id=$4 FOR UPDATE`, [model.projection, owner, ref.type, ref.id], client));
        if (!row.rows[0])
            throw new NotFound('Object is unavailable');
        const buffer = new HotEditBuffer(db, client, model, owner, ref, { revision: Number(row.rows[0].revision), properties: row.rows[0].properties });
        active.set(client, buffer);
        try {
            const result = await work();
            await buffer.flushChanges();
            return result;
        }
        finally {
            active.delete(client);
        }
    }
    snapshot() { return this.current; }
    links(load) { return this.related ??= load(); }
    edit(revision, properties, fields) {
        if (this.current.revision !== revision)
            throw new Conflict('Object revision changed');
        this.snapshotBytes += Buffer.byteLength(JSON.stringify(properties));
        if (this.snapshotBytes > 2 * 1024 * 1024)
            throw new Conflict('Use individual transactions for large object snapshots');
        this.edits.push({ before: this.current.properties, after: properties, fields });
        this.current = { revision: revision + 1, properties };
    }
    receipt(request, action, fingerprint, result, actor, task, objects, links) {
        if (this.edits.length !== this.steps.length + 1)
            throw new Conflict('Retry with the ordinary Action transaction');
        this.steps.push({ ...this.edits[this.steps.length], request, action, fingerprint, result, actor, task, objects, links });
    }
    async flushChanges() {
        await this.db.withObjectAccess(() => this.flush());
    }
    async flush() {
        if (!this.steps.length)
            return;
        if (this.edits.length !== this.steps.length)
            throw new Conflict('Missing edit receipt');
        const s = this.db.schema, base = [this.model.projection, this.owner, this.ref.type, this.ref.id];
        const result = await this.db.query(`UPDATE ${s}.objects SET properties=$5,revision=$6
      WHERE projection=$1 AND owner=$2 AND type=$3 AND id=$4 AND revision=$7`, [...base, this.current.properties, this.current.revision, this.original.revision], this.client);
        if (result.rowCount !== 1)
            throw new Conflict('Object revision changed');
        const fields = Object.assign({}, ...this.steps.map(step => step.fields));
        const overrides = Object.fromEntries(Object.entries(fields).map(([name, value]) => [name, { value }]));
        await this.db.query(`WITH legacy AS (
        INSERT INTO ${s}.source_values(projection,owner,type,id,source,properties,observed_at)
        SELECT $1,$2,$3,$4,'__legacy__',$5,'-infinity'::timestamptz WHERE NOT EXISTS (
          SELECT 1 FROM ${s}.source_values WHERE projection=$1 AND owner=$2 AND type=$3 AND id=$4)
        ON CONFLICT DO NOTHING)
      INSERT INTO ${s}.object_edits AS prior(projection,owner,type,id,overrides,deleted,created)
      SELECT $1,$2,$3,$4,coalesce(jsonb_object_agg(key,value||jsonb_build_object('at',to_char(clock_timestamp() AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'))),'{}'),false,false FROM jsonb_each($6::jsonb)
      ON CONFLICT(projection,owner,type,id) DO UPDATE SET overrides=prior.overrides||excluded.overrides,deleted=false`, [...base, this.original.properties, JSON.stringify(overrides)], this.client);
        const packed = JSON.stringify(this.steps);
        await this.db.query(`WITH rows AS MATERIALIZED (SELECT item,ord FROM jsonb_array_elements($6::jsonb) WITH ORDINALITY AS changes(item,ord)),
      receipts AS (INSERT INTO ${s}.actions(owner,request_id,digest,action,release,result,executor_kind,executor_id,task_id)
        SELECT $2,item->>'request',item->>'fingerprint',item->>'action',$5,item->'result',item#>>'{actor,kind}',item#>>'{actor,id}',(item->>'task')::uuid FROM rows),
      journals AS (INSERT INTO ${s}.action_changes(owner,request_id,release,action,result,objects,links)
        SELECT $2,item->>'request',$5,item->>'action',item->'result',item->'objects',item->'links' FROM rows)
      INSERT INTO ${s}.edit_history(projection,owner,type,id,release,operation,before_values,after_values,actor,action,request_id,task_id,executor_kind,executor_id)
        SELECT $1,$2,$3,$4,$5,'edit',item->'before',item->'after',$2,item->>'action',item->>'request',item->>'task',item#>>'{actor,kind}',item#>>'{actor,id}'
        FROM rows ORDER BY ord`, [...base, this.model.release, packed], this.client);
        this.original = this.current;
        this.edits.length = 0;
        this.steps.length = 0;
        this.snapshotBytes = 0;
    }
}
