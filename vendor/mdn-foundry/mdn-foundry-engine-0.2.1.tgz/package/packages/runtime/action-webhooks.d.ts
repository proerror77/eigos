import type { Ontology } from '../ontology/model.js';
import { type ActionEffectDefinition } from '../ontology/schema.js';
import type { Access } from './access.js';
import type { ConfiguredComponentSources } from './component-source-egress.js';
import type { Functions } from './functions.js';
import type { PublishedOntology } from './metadata.js';
export declare const effectHandlerName: (effect: ActionEffectDefinition) => string;
export declare const isWebhookHandler: (name: string) => name is "ComponentSourceWebhook";
export declare const webhookApprovalCapability = "action.webhook.authorize";
export declare const webhookApprovalDigest: (model: PublishedOntology, action: string, requestId: string, input: Record<string, unknown>) => string;
export declare class ActionSourceWebhooks {
    private readonly sources;
    private readonly functions;
    constructor(sources: ConfiguredComponentSources, functions: Functions);
    bindings(model: Ontology): {
        [k: string]: string;
    };
    private declared;
    prepare(model: PublishedOntology, action: string, name: string, input: Record<string, unknown>, access: Access): {
        input: Record<string, unknown>;
        classification: {
            sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
            compartments: string[];
        };
        body?: string | undefined;
    };
    deliver(model: PublishedOntology, action: string, name: string, payload: unknown, access: Access, id: string, signal: AbortSignal, authorize: () => Promise<void>, persistBody: (body: string) => Promise<void>): Promise<void>;
}
