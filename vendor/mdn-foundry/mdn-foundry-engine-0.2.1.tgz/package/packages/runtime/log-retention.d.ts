import type { Database, Sql } from './database.js';
/**
 * Commit log retention (platform plan, "提交日志保留"; the user chose 90 days on 2026-11-27). Rows of `edit_history`,
 * `link_history` and `change_commits` older than the retention are archived to Parquet, one file per owner, table and
 * month, and deleted once the archive reads back identical. The archive stays queryable through `eigos-archive read`.
 *
 * Kept in the tables whatever their age:
 * - history rows of object types a ProcessLog tracks in any active or retired release: those rows are the ProcessLog
 *   objects, which Machinery analyzes up to 366 days back;
 * - commits after the cutoff, or not yet consumed by a change subscription, an open Scenario's sync, or an object rule;
 * - a commit that still has a kept history row.
 *
 * It runs as a maintenance command with a role that owns the tables; the runtime roles cannot delete history.
 */
export declare const archiveTables: readonly ['edit_history', 'link_history', 'change_commits'];
export type ArchiveTable = typeof archiveTables[number];
export type ArchivedRow = Record<string, string | null>;
export type ArchiveFilter = Partial<Record<'owner' | 'type' | 'id' | 'fromType' | 'fromId' | 'toType' | 'toId' | 'requestId' | 'taskId' | 'after' | 'from' | 'to' | 'limit', string>>;
/** A digest of rows in archive order that depends on neither how they were stored nor the order of their keys. */
export declare const contentDigest: (rows: ArchivedRow[]) => string;
/** Spawns the `eigos-archive` codec of the kernel crate. */
export declare class ArchiveCodec {
    readonly binary: string;
    constructor(binary: string);
    /** Writes rows in archive order to a new Parquet file and returns how many it wrote. */
    write(table: ArchiveTable, file: string, rows: ArchivedRow[]): Promise<number>;
    /** The rows of the files that match the filter, in history or commit order. */
    read(table: ArchiveTable, filter: ArchiveFilter, files: string[]): Promise<ArchivedRow[]>;
    private run;
}
/** The archive this process reads, from EIGOS_LOG_ARCHIVE_DIR and EIGOS_ARCHIVE_BIN, if both are set. */
export declare function configuredArchive(): {
    dir: string;
    codec: ArchiveCodec;
} | undefined;
export declare function initializeLogArchives(db: Database): Promise<void>;
export type RetentionOptions = {
    days: number;
    archive: string;
    codec: ArchiveCodec;
    now?: Date;
};
export type ArchivedMonth = {
    owner: string;
    month: string;
    boundary: string;
    rows: Record<ArchiveTable, number>;
};
export declare class LogRetention {
    private readonly db;
    private readonly options;
    constructor(db: Database, options: RetentionOptions);
    private retained?;
    private get cutoff();
    /** The start of the cutoff's month: only months before it are complete before the cutoff. */
    private get cutoffMonth();
    /** Object types a ProcessLog tracks in any active or retired release: their history is ProcessLog data. */
    retainedTypes(client?: Sql): Promise<string[]>;
    /**
     * The first commit of the owner that must stay: the first after the cutoff, or the earliest position a change
     * subscription, an open Scenario's sync or an enabled object rule still reads after. Commits before it may go.
     */
    boundary(owner: string, client?: Sql): Promise<string>;
    /**
     * Months of each owner that can be archived, oldest first: they end before the cutoff, all their commits lie before
     * the owner's boundary, and they are not archived yet. History from before the commit journal counts by its time.
     */
    plan(owner?: string): Promise<{
        owner: string;
        month: string;
        boundary: string;
    }[]>;
    /** Archives one owner's month, deletes what it archived, and returns how many rows of each table moved. */
    archiveMonth(owner: string, month: string): Promise<ArchivedMonth | undefined>;
    /** Archives every month that can be archived, at most `limit`. */
    run(options?: {
        owner?: string;
        limit?: number;
    }): Promise<ArchivedMonth[]>;
}
/**
 * History of one owner across the tables and the archive, in order: what an audit reads. The archive holds rows the
 * tables no longer do, so the two never overlap.
 */
export declare function auditHistory(db: Database, archive: string | undefined, codec: ArchiveCodec | undefined, table: 'edit_history' | 'link_history', filter: ArchiveFilter & {
    owner: string;
}): Promise<ArchivedRow[]>;
