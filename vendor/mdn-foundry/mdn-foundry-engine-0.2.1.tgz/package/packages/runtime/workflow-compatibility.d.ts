import type { FunctionDependencies } from '../ontology/schema.js';
import type { PublishedOntology } from './metadata.js';
/** Check the published dependencies of a saved workflow before invoking its first tool. */
export declare function checkWorkflowDependencies(previous: PublishedOntology, current: PublishedOntology, roots: FunctionDependencies, unscopedInterfaces: ReadonlySet<string>): void;
