import { z } from 'zod';
import type { Access } from './access.js';
import type { Database } from './database.js';
import type { PublishedOntology } from './metadata.js';
export declare const machineryHistorySchema: z.ZodObject<{
    type: z.ZodString;
    source: z.ZodString;
    events: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        object: z.ZodObject<{
            type: z.ZodString;
            id: z.ZodString;
        }, z.core.$strict>;
        from: z.ZodNullable<z.ZodString>;
        to: z.ZodNullable<z.ZodString>;
        observedAt: z.ZodISODateTime;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare function initializeMachineryHistory(db: Database): Promise<void>;
export declare function ingestMachineryHistory(db: Database, access: Access, model: PublishedOntology, raw: unknown): Promise<{
    inserted: number;
    replayed: number;
    source: string;
}>;
