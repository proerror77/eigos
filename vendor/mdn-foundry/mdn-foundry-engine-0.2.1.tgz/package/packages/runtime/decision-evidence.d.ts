import { z } from 'zod';
import { type Classification } from '../ontology/classification.js';
import { type ObjectRef } from '../ontology/schema.js';
import type { Access } from './access.js';
import type { Database, Sql } from './database.js';
import type { PublishedOntology } from './metadata.js';
import type { Objects } from './objects.js';
declare const readSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"object">;
    ref: z.ZodObject<{
        type: z.ZodString;
        id: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"stored">;
    ref: z.ZodObject<{
        type: z.ZodString;
        id: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"follow">;
    ref: z.ZodObject<{
        type: z.ZodString;
        id: z.ZodString;
    }, z.core.$strict>;
    link: z.ZodString;
    as: z.ZodString;
    maximum: z.ZodOptional<z.ZodNumber>;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"query">;
    input: z.ZodRecord<z.ZodString, z.ZodUnknown>;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"source">;
    ref: z.ZodObject<{
        type: z.ZodString;
        id: z.ZodString;
    }, z.core.$strict>;
    source: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"set">;
    input: z.ZodRecord<z.ZodString, z.ZodUnknown>;
    maximum: z.ZodNumber;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"aggregate">;
    input: z.ZodRecord<z.ZodString, z.ZodUnknown>;
    maximum: z.ZodNumber;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"pa">;
    requestId: z.ZodUUID;
}, z.core.$strict>], "kind">;
export type DecisionRead = z.infer<typeof readSchema>;
declare const observationSchema: z.ZodObject<{
    read: z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"object">;
        ref: z.ZodObject<{
            type: z.ZodString;
            id: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"stored">;
        ref: z.ZodObject<{
            type: z.ZodString;
            id: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"follow">;
        ref: z.ZodObject<{
            type: z.ZodString;
            id: z.ZodString;
        }, z.core.$strict>;
        link: z.ZodString;
        as: z.ZodString;
        maximum: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"query">;
        input: z.ZodRecord<z.ZodString, z.ZodUnknown>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"source">;
        ref: z.ZodObject<{
            type: z.ZodString;
            id: z.ZodString;
        }, z.core.$strict>;
        source: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"set">;
        input: z.ZodRecord<z.ZodString, z.ZodUnknown>;
        maximum: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"aggregate">;
        input: z.ZodRecord<z.ZodString, z.ZodUnknown>;
        maximum: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"pa">;
        requestId: z.ZodUUID;
    }, z.core.$strict>], "kind">;
    view: z.ZodEnum<{
        live: "live";
        scenario: "scenario";
    }>;
    step: z.ZodNumber;
    offset: z.ZodNumber;
    clearance: z.ZodOptional<z.ZodObject<{
        sensitivity: z.ZodEnum<{
            CONFIDENTIAL: "CONFIDENTIAL";
            INTERNAL: "INTERNAL";
            PUBLIC: "PUBLIC";
            RESTRICTED: "RESTRICTED";
        }>;
        compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>>;
    fingerprint: z.ZodString;
    refs: z.ZodArray<z.ZodObject<{
        ref: z.ZodObject<{
            type: z.ZodString;
            id: z.ZodString;
        }, z.core.$strict>;
        revision: z.ZodNumber;
    }, z.core.$strict>>;
    savedSets: z.ZodOptional<z.ZodArray<z.ZodUUID>>;
}, z.core.$strict>;
export declare const decisionEvidenceSchema: z.ZodArray<z.ZodObject<{
    read: z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"object">;
        ref: z.ZodObject<{
            type: z.ZodString;
            id: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"stored">;
        ref: z.ZodObject<{
            type: z.ZodString;
            id: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"follow">;
        ref: z.ZodObject<{
            type: z.ZodString;
            id: z.ZodString;
        }, z.core.$strict>;
        link: z.ZodString;
        as: z.ZodString;
        maximum: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"query">;
        input: z.ZodRecord<z.ZodString, z.ZodUnknown>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"source">;
        ref: z.ZodObject<{
            type: z.ZodString;
            id: z.ZodString;
        }, z.core.$strict>;
        source: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"set">;
        input: z.ZodRecord<z.ZodString, z.ZodUnknown>;
        maximum: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"aggregate">;
        input: z.ZodRecord<z.ZodString, z.ZodUnknown>;
        maximum: z.ZodNumber;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"pa">;
        requestId: z.ZodUUID;
    }, z.core.$strict>], "kind">;
    view: z.ZodEnum<{
        live: "live";
        scenario: "scenario";
    }>;
    step: z.ZodNumber;
    offset: z.ZodNumber;
    clearance: z.ZodOptional<z.ZodObject<{
        sensitivity: z.ZodEnum<{
            CONFIDENTIAL: "CONFIDENTIAL";
            INTERNAL: "INTERNAL";
            PUBLIC: "PUBLIC";
            RESTRICTED: "RESTRICTED";
        }>;
        compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>>;
    fingerprint: z.ZodString;
    refs: z.ZodArray<z.ZodObject<{
        ref: z.ZodObject<{
            type: z.ZodString;
            id: z.ZodString;
        }, z.core.$strict>;
        revision: z.ZodNumber;
    }, z.core.$strict>>;
    savedSets: z.ZodOptional<z.ZodArray<z.ZodUUID>>;
}, z.core.$strict>>;
export type DecisionObservation = z.infer<typeof observationSchema>;
export type DecisionRef = {
    ref: ObjectRef;
    revision: number;
};
interface EvidenceScope {
    db: Database;
    owner: string;
    release: string;
    scenarioId: string;
    clearance?: Classification;
    step: number;
    taskId?: string;
    token?: string;
    reads: DecisionObservation[];
    saved: number;
}
/** Whether reads are being recorded as decision evidence, which a retried transaction would record twice. */
export declare function capturingDecisionReads(): boolean;
/** A semantic operation can depend on a versioned input beyond its returned page. */
export declare function observeReadInput(identity: unknown, savedSet?: string): void;
type EvidenceView = {
    db: Database;
    model: PublishedOntology;
    access: Access;
    change?: Objects['change'];
};
export declare function observeDecisionRead<T>(graph: EvidenceView, read: DecisionRead, execute: () => Promise<T>, describe?: (result: T) => {
    value: unknown;
    refs?: DecisionRef[];
}): Promise<T>;
export declare const observedObjects: <T extends DecisionRef[]>(items: T) => {
    value: T;
    refs: {
        ref: {
            type: string;
            id: string;
        };
        revision: number;
    }[];
};
export declare const observedPage: <T extends {
    items: DecisionRef[];
}>(page: T) => {
    value: T;
    refs: {
        ref: {
            type: string;
            id: string;
        };
        revision: number;
    }[];
};
export declare const observedObject: <T extends DecisionRef>(value: T) => {
    value: T;
    refs: {
        ref: {
            type: string;
            id: string;
        };
        revision: number;
    }[];
};
export declare function proposalStep(db: Database, owner: string, scenarioId: string, client?: Sql): Promise<number>;
export declare function captureProposalReads<T>(db: Database, task: {
    id: string;
    owner: string;
    release: string;
    token: string | null;
}, scenarioId: string, clearance: Classification | undefined, execute: () => Promise<T>): Promise<T>;
/** Called after recording the Action journal, inside the very same edit transaction. */
export declare function persistActionEvidence(graph: Objects): Promise<void>;
/** Later model observations must see the committed prefix, including after a receipt retry. */
export declare function advanceDecisionReadStep(): Promise<void>;
export declare function observePAResponse(db: Database, task: {
    id: string;
    owner: string;
}, requestId: string, responseDigest: string): void;
/** Re-use the permission-aware read implementation without re-running the computing Function. */
export declare function replayRead(graph: Objects, scope: Pick<EvidenceScope, 'scenarioId'>, observation: DecisionObservation, execute: () => Promise<unknown>): Promise<void>;
export {};
