import type { Database } from './database.js';
import type { FunctionContext } from './functions.js';
import type { FunctionInvocationMetrics } from './function-invocations.js';
import { type Objects } from './objects.js';
/**
 * The Ontology a component Function reads while it runs (F2). For each call the runtime opens a session named by a
 * random token and gives the function host its loopback callback. The host forwards each Ontology import of the
 * Function to it, and the session runs the operation with the call's own `Objects` and `Access`. Permissions, masking,
 * recorded dependencies and egress labels are therefore those of a direct read; the host decides nothing.
 */
export type OntologyLimits = {
    calls: number;
    objects: number;
    bytes: number;
    edits: number;
};
/** Per call: host function calls, objects returned in total, the size of one answer, and edits. */
export declare const defaultOntologyLimits: OntologyLimits;
/** `writer` is set for an edit Function inside its Action's commit: edits go through it, and reads see them. */
type ModelOperations = {
    generate(alias: string, messages: unknown): void;
    next(): Promise<string | null>;
    emit(chunk: string): Promise<void>;
};
type Session = {
    models?: ModelOperations;
    db: Database;
    context: FunctionContext;
    writer?: Objects;
    outgoing?: (input: unknown) => Promise<unknown>;
    limits: OntologyLimits;
    calls: number;
    objects: number;
    edits: number;
};
export declare class FunctionCallbacks {
    private readonly server;
    /** Opens the session of one call; `close` ends it, after which its token is refused. */
    open(db: Database, context: FunctionContext, writer?: Objects, options?: {
        limits?: OntologyLimits;
        outgoing?: Session['outgoing'];
        models?: ModelOperations;
        timings?: FunctionInvocationMetrics['callbacks'];
    }): Promise<{
        callback: {
            url: string;
            token: string;
        };
        close: () => void;
    }>;
}
/** The callbacks of this process. */
export declare const functionCallbacks: FunctionCallbacks;
export {};
