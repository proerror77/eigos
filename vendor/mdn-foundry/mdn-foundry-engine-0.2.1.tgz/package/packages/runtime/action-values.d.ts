import type { LinkData, ObjectRef, Value } from '../ontology/schema.js';
import type { ActionEffect } from './effects.js';
import type { PublishedOntology } from './metadata.js';
export declare function evaluate(expression: Value, input: Record<string, unknown>): unknown;
export declare function actionEffects(model: PublishedOntology, action: string, input: Record<string, unknown>): ActionEffect[];
type Properties = Record<string, unknown>;
export declare function changeDigest(objects: readonly {
    ref: ObjectRef;
    before: Properties | null;
    after: Properties | null;
}[], links: readonly {
    edge: LinkData;
    removed: boolean;
}[]): string;
export {};
