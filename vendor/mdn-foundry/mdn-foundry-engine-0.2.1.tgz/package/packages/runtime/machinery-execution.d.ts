import { z } from 'zod';
import type { Access } from './access.js';
import type { Actions } from './actions.js';
import type { Database, Sql } from './database.js';
import type { PublishedOntology } from './metadata.js';
import { Objects } from './objects.js';
export declare const machineryNextActionsInput: z.ZodObject<{
    object: z.ZodObject<{
        type: z.ZodString;
        id: z.ZodString;
    }, z.core.$strict>;
    process: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export declare const machineryReplanInput: z.ZodObject<{
    changedObjects: z.ZodArray<z.ZodObject<{
        type: z.ZodString;
        id: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
type Availability = 'ready' | 'needs_check' | 'blocked';
/** Called from the authoritative Action submission path, including validated direct calls. */
export declare function requireMachineryTransition(objects: Objects, action: string, input: Record<string, unknown>): Promise<void>;
export declare class MachineryExecution {
    private readonly db;
    private readonly actions;
    constructor(db: Database, actions: Actions);
    /** Re-read the changed subjects and the parents reached through published transition guards. */
    replan(model: PublishedOntology, access: Access, raw: unknown): Promise<{
        release: string;
        items: {
            object: {
                type: string;
                id: string;
            };
            release: string;
            items: {
                process: string;
                action: string;
                to: string;
                input: Record<string, unknown>;
                status: Availability | 'needs_input';
                missing: string[];
            }[];
        }[];
    }>;
    nextActions(model: PublishedOntology, access: Access, raw: unknown): Promise<{
        object: {
            type: string;
            id: string;
        };
        release: string;
        items: {
            process: string;
            action: string;
            to: string;
            input: Record<string, unknown>;
            status: Availability | 'needs_input';
            missing: string[];
        }[];
    }>;
    evaluate(model: PublishedOntology, access: Access, input: z.infer<typeof machineryNextActionsInput>, client: Sql): Promise<{
        object: {
            type: string;
            id: string;
        };
        release: string;
        items: {
            process: string;
            action: string;
            to: string;
            input: Record<string, unknown>;
            status: Availability | 'needs_input';
            missing: string[];
        }[];
    }>;
}
export {};
