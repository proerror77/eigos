import { z } from 'zod';
import { type ObjectRef } from '../ontology/schema.js';
import { Access } from './access.js';
import type { Database } from './database.js';
import { Objects } from './objects.js';
import type { PublishedOntology } from './metadata.js';
export declare const entityLookupSchema: z.ZodObject<{
    source: z.ZodString;
    externalId: z.ZodString;
}, z.core.$strict>;
export declare const bindEntitySchema: z.ZodObject<{
    source: z.ZodString;
    externalId: z.ZodString;
    target: z.ZodObject<{
        type: z.ZodString;
        id: z.ZodString;
    }, z.core.$strict>;
    expectedRevision: z.ZodNumber;
    reason: z.ZodString;
}, z.core.$strict>;
export declare const entityHistorySchema: z.ZodObject<{
    source: z.ZodString;
    externalId: z.ZodString;
    after: z.ZodOptional<z.ZodString>;
    limit: z.ZodDefault<z.ZodNumber>;
}, z.core.$strict>;
export declare function initializeEntityResolution(db: Database): Promise<void>;
export declare class EntityResolution {
    private readonly db;
    constructor(db: Database);
    private binding;
    private selected;
    lookup(access: Access, model: PublishedOntology, raw: unknown): Promise<{
        ref: {
            type: string;
            id: string;
        };
        revision: number;
        bound: boolean;
    }>;
    /** Source adapters call inside their write transaction, before mapping a source row's primary key. */
    resolve(graph: Objects, source: string, externalId: string, fallbackId?: string): Promise<ObjectRef>;
    bind(access: Access, model: PublishedOntology, raw: unknown): Promise<{
        ref: {
            type: string;
            id: string;
        };
        revision: number;
        bound: boolean;
    }>;
    history(access: Access, model: PublishedOntology, raw: unknown): Promise<{
        items: import("pg").QueryResultRow[];
        cursor: string | undefined;
    }>;
}
