import { digest } from '../core/identity.js';
import { effectHandlerName } from './action-webhooks.js';
export function evaluate(expression, input) {
    if ('literal' in expression)
        return expression.literal;
    let value = input[expression.parameter];
    for (const field of expression.path ?? [])
        value = value && typeof value === 'object' ? Reflect.get(value, field) : undefined;
    return value;
}
export function actionEffects(model, action, input) {
    return (model.action(action).effects ?? []).map(effect => ({
        name: effect.name,
        handler: effectHandlerName(effect),
        payload: Object.fromEntries(Object.entries(effect.payload).map(([name, expression]) => [name, evaluate(expression, input)])),
    }));
}
export function changeDigest(objects, links) {
    const net = objects.flatMap(({ ref, before, after }) => {
        if (!before || !after)
            return [{ ref, before, after }];
        const fields = [...new Set([...Object.keys(before), ...Object.keys(after)])].filter(field => digest({ value: before[field] }) !== digest({ value: after[field] }));
        if (fields.length === 0)
            return [];
        const select = (value) => Object.fromEntries(fields.filter(field => Object.hasOwn(value, field)).map(field => [field, value[field]]));
        return [{ ref, before: select(before), after: select(after) }];
    });
    return digest({ objects: net.map(digest).sort(), links: links.map(digest).sort() });
}
