import type { QueryResultRow } from 'pg';
import { z } from 'zod';
import { Access } from './access.js';
import { Database, type Sql } from './database.js';
import { Metadata, type PublishedOntology } from './metadata.js';
import type { Actions } from './actions.js';
import { Objects } from './objects.js';
export declare const workflowSchema: z.ZodObject<{
    id: z.ZodOptional<z.ZodUUID>;
    revision: z.ZodDefault<z.ZodNumber>;
    name: z.ZodString;
    description: z.ZodDefault<z.ZodString>;
    steps: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        action: z.ZodString;
        input: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
            literal: z.ZodUnknown;
        }, z.core.$strict>, z.ZodObject<{
            property: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            object: z.ZodLiteral<true>;
        }, z.core.$strict>, z.ZodObject<{
            step: z.ZodString;
        }, z.core.$strict>]>>;
    }, z.core.$strict>>;
    proposal: z.ZodOptional<z.ZodObject<{
        name: z.ZodString;
        mergeAction: z.ZodString;
        mergeObjectParameter: z.ZodString;
        goal: z.ZodString;
        actions: z.ZodArray<z.ZodString>;
        functions: z.ZodDefault<z.ZodArray<z.ZodString>>;
        validation: z.ZodObject<{
            function: z.ZodString;
            objectParameter: z.ZodString;
        }, z.core.$strict>;
        reviewers: z.ZodArray<z.ZodString>;
        timeoutSeconds: z.ZodDefault<z.ZodNumber>;
        maxToolCalls: z.ZodDefault<z.ZodNumber>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const saveRuleSchema: z.ZodObject<{
    id: z.ZodOptional<z.ZodUUID>;
    revision: z.ZodDefault<z.ZodNumber>;
    name: z.ZodString;
    enabled: z.ZodDefault<z.ZodBoolean>;
    workflow: z.ZodOptional<z.ZodUUID>;
    effect: z.ZodOptional<z.ZodObject<{
        action: z.ZodString;
        input: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
            literal: z.ZodUnknown;
        }, z.core.$strict>, z.ZodObject<{
            property: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            object: z.ZodLiteral<true>;
        }, z.core.$strict>, z.ZodObject<{
            step: z.ZodString;
        }, z.core.$strict>]>>;
        related: z.ZodOptional<z.ZodObject<{
            path: z.ZodArray<z.ZodString>;
            sourceParameter: z.ZodString;
            transitionParameter: z.ZodString;
            targetParameter: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    notify: z.ZodOptional<z.ZodObject<{
        message: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    query: z.ZodOptional<z.ZodObject<{
        type: z.ZodString;
        where: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodNumber, z.ZodBoolean, z.ZodNull]>>>;
        filter: z.ZodOptional<z.ZodPipe<z.ZodUnknown, z.ZodType<import("./query-filter.js").Predicate, unknown, z.core.$ZodTypeInternals<import("./query-filter.js").Predicate, unknown>>>>;
        orderBy: z.ZodOptional<z.ZodArray<z.ZodObject<{
            property: z.ZodString;
            direction: z.ZodDefault<z.ZodEnum<{
                asc: "asc";
                desc: "desc";
            }>>;
        }, z.core.$strict>>>;
        intervalOverlap: z.ZodOptional<z.ZodObject<{
            start: z.ZodString;
            end: z.ZodString;
            from: z.ZodISODateTime;
            until: z.ZodISODateTime;
            includeUnknown: z.ZodOptional<z.ZodBoolean>;
        }, z.core.$strict>>;
        from: z.ZodOptional<z.ZodObject<{
            object: z.ZodObject<{
                type: z.ZodString;
                id: z.ZodString;
            }, z.core.$strict>;
            link: z.ZodString;
            as: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    onModified: z.ZodOptional<z.ZodObject<{
        watch: z.ZodArray<z.ZodObject<{
            path: z.ZodDefault<z.ZodArray<z.ZodString>>;
            properties: z.ZodArray<z.ZodString>;
        }, z.core.$strict>>;
        includeAdded: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strict>>;
    replayFrom: z.ZodOptional<z.ZodString>;
    process: z.ZodOptional<z.ZodObject<{
        type: z.ZodString;
        from: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        to: z.ZodOptional<z.ZodString>;
        dwellSeconds: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const processBindingsSchema: z.ZodObject<{
    type: z.ZodString;
    cursor: z.ZodOptional<z.ZodUUID>;
}, z.core.$strict>;
export declare const runWorkflowSchema: z.ZodObject<{
    workflow: z.ZodUUID;
    object: z.ZodObject<{
        type: z.ZodString;
        id: z.ZodString;
    }, z.core.$strict>;
    requestId: z.ZodString;
}, z.core.$strict>;
export declare const publishWorkflowSchema: z.ZodObject<{
    id: z.ZodUUID;
    revision: z.ZodNumber;
    targetType: z.ZodString;
}, z.core.$strict>;
export declare const withdrawWorkflowSchema: z.ZodObject<{
    id: z.ZodUUID;
    revision: z.ZodNumber;
}, z.core.$strict>;
export declare const runPublishedWorkflowSchema: z.ZodObject<{
    workflow: z.ZodUUID;
    object: z.ZodObject<{
        type: z.ZodString;
        id: z.ZodString;
    }, z.core.$strict>;
    requestId: z.ZodString;
    revision: z.ZodNumber;
}, z.core.$strict>;
export declare const automationPreviewSchema: z.ZodObject<{
    rule: z.ZodUUID;
    revision: z.ZodNumber;
    scenarios: z.ZodArray<z.ZodObject<{
        id: z.ZodUUID;
        revision: z.ZodNumber;
    }, z.core.$strict>>;
    elapsedSeconds: z.ZodDefault<z.ZodNumber>;
}, z.core.$strict>;
export declare function initializeAutomation(db: Database): Promise<void>;
export declare class Automation {
    private readonly db;
    private readonly metadata;
    private readonly actions;
    constructor(db: Database, metadata: Metadata, actions: Actions);
    private authorize;
    private active;
    workflow(access: Access, model: PublishedOntology, raw: unknown, transaction?: Sql): Promise<{
        name: string;
        description: string;
        steps: {
            name: string;
            action: string;
            input: Record<string, {
                literal: unknown;
            } | {
                property: string;
            } | {
                object: true;
            } | {
                step: string;
            }>;
        }[];
        proposal?: {
            name: string;
            mergeAction: string;
            mergeObjectParameter: string;
            goal: string;
            actions: string[];
            functions: string[];
            validation: {
                function: string;
                objectParameter: string;
            };
            reviewers: string[];
            timeoutSeconds: number;
            maxToolCalls: number;
        } | undefined;
        id: string;
        revision: number;
    }>;
    private ruleDefinition;
    private relatedContract;
    private checkDirectEffect;
    rule(access: Access, model: PublishedOntology, raw: unknown, transaction?: Sql): Promise<{
        name: string;
        workflow: string;
        enabled: boolean;
        query: {
            type: string;
            where: Record<string, string | number | boolean | null>;
            filter?: import("./query-filter.js").Predicate | undefined;
            orderBy?: {
                property: string;
                direction: "asc" | "desc";
            }[] | undefined;
            intervalOverlap?: {
                start: string;
                end: string;
                from: string;
                until: string;
                includeUnknown?: boolean | undefined;
            } | undefined;
            from?: {
                object: {
                    type: string;
                    id: string;
                };
                link: string;
                as?: string | undefined;
            } | undefined;
        };
        onModified?: {
            watch: {
                path: string[];
                properties: string[];
            }[];
            includeAdded: boolean;
        } | undefined;
        id: string;
        revision: number;
    } | {
        name: string;
        workflow: string;
        enabled: boolean;
        process: {
            type: string;
            from?: string | null | undefined;
            to?: string | undefined;
            dwellSeconds?: number | undefined;
        };
        id: string;
        revision: number;
    } | {
        name: string;
        enabled: boolean;
        process: {
            type: string;
            from?: string | null | undefined;
            to?: string | undefined;
            dwellSeconds?: number | undefined;
        };
        effect: {
            action: string;
            input: Record<string, {
                literal: unknown;
            } | {
                property: string;
            } | {
                object: true;
            } | {
                step: string;
            }>;
            related?: {
                path: string[];
                sourceParameter: string;
                transitionParameter: string;
                targetParameter: string;
            } | undefined;
        };
        replayFrom?: string | undefined;
        id: string;
        revision: number;
    } | {
        name: string;
        enabled: boolean;
        process: {
            type: string;
            from?: string | null | undefined;
            to?: string | undefined;
            dwellSeconds?: number | undefined;
        };
        notify: {
            message?: string | undefined;
        };
        id: string;
        revision: number;
    }>;
    disableObjectRule(graph: Objects, id: string): Promise<void>;
    processBindings(access: Access, model: PublishedOntology, raw: unknown): Promise<{
        owner: string;
        release: string;
        items: {
            id: string;
            revision: number;
            name: string;
            process: {
                type: string;
                from?: string | null | undefined;
                to?: string | undefined;
                dwellSeconds?: number | undefined;
            };
            enabled: boolean;
            error: any;
            lastScan: any;
            effect: {
                action: string;
                notify?: undefined;
                workflow?: undefined;
            } | {
                action?: undefined;
                notify: boolean;
                workflow?: undefined;
            } | {
                action?: undefined;
                notify?: undefined;
                workflow: string;
            };
            latestRun: {
                id: string;
                state: string;
                updatedAt: any;
            } | null;
        }[];
        cursor: string | null;
    }>;
    processStatus(access: Access, model: PublishedOntology, raw: unknown): Promise<{
        object: {
            type: string;
            id: string;
        };
        property: string;
        schedules: QueryResultRow[];
        state: {} | null;
        transition: {
            type: string;
            id: string;
        } | null;
        observedAt: unknown;
        recordedAt: string | null;
        asOf: string;
        recordedDurationSeconds: number | null;
    }>;
    list(access: Access, model: PublishedOntology, kind: 'workflows' | 'object_rules' | 'workflow_runs'): Promise<{
        items: any[];
        hasMore: boolean;
    }>;
    preview(access: Access, model: PublishedOntology, raw: unknown): Promise<{
        rule: string;
        revision: number;
        enabled: any;
        workflowRevision: number | null;
        release: string;
        mode: string;
        scenarios: {
            id: string;
            revision: number;
            name: string;
            waiting: {
                type: string;
                id: string;
            }[];
            results: {
                object: {
                    type: string;
                    id: string;
                };
                status: "completed" | "proposal_required" | "rejected";
                reason: string | undefined;
                steps: {
                    name: string;
                    action: string;
                    status: 'completed' | 'rejected';
                }[];
            }[];
        }[];
    }>;
    publishWorkflow(access: Access, model: PublishedOntology, raw: unknown): Promise<{
        id: string;
        revision: number;
        release: string;
        targetType: string;
    }>;
    withdrawWorkflow(access: Access, model: PublishedOntology, raw: unknown): Promise<{
        id: string;
        withdrawn: boolean;
    }>;
    private checkPublishedWorkflow;
    listPublishedWorkflows(access: Access, model: PublishedOntology): Promise<{
        items: {
            id: string;
            name: string;
            description: string;
            revision: number;
            targetType: string;
        }[];
        hasMore: boolean;
    }>;
    runPublishedWorkflow(access: Access, model: PublishedOntology, raw: unknown): Promise<{
        id: string;
        state: string;
    }>;
    run(access: Access, model: PublishedOntology, raw: unknown, publishedRevision?: number): Promise<{
        id: string;
        state: string;
    }>;
    scanOne(): Promise<boolean>;
    /** Scans one due object-set rule, reporting whether one was due. */
    scanObjectRules(): Promise<boolean>;
    /** Scans one due process rule, reporting whether one was due. */
    scanProcessRules(): Promise<boolean>;
    private scanRule;
    /**
     * An object-set rule consumes its owner's committed changes from its own position. It re-reads its whole set on its
     * first scan, after the publication or the rule principal's visibility changed, when more objects changed than one
     * scan re-evaluates, when a change touched the footprint of a rule that depends on relationships or derived
     * properties, and once per reconcile interval. Otherwise it re-evaluates only the objects that changed, and a scan
     * without a relevant change reads only the journal.
     */
    private scanMatches;
    /** Updates a rule's matches from its whole set, or from `candidates` alone, and submits runs for the objects that triggered. */
    private evaluateMatches;
    private visibleProcessRun;
    private scanProcess;
    private verifyProcessTrigger;
    runOne(signal?: AbortSignal): Promise<boolean>;
    private executeRun;
    private runProposal;
    private finishProposal;
    private cancelProposalTask;
    retry(access: Access, model: PublishedOntology, id: string): Promise<{
        id: string;
        state: string;
    }>;
    cancel(access: Access, model: PublishedOntology, id: string): Promise<{
        id: string;
        state: string;
        step: number;
    }>;
}
