import type { Ontology } from '../ontology/model.js';
import type { Database, Sql } from './database.js';
import type { BindingManifest } from './metadata.js';
export type SemanticIndexInput = {
    name: string;
    type: string;
    property: string;
    embeddingFunction: string;
    dimensions: number;
};
/** Configuration and publication use the same stored-text and versioned-model contract. */
export declare function semanticIndexBinding(model: Ontology, bindings: BindingManifest, input: SemanticIndexInput): {
    binding: string;
    modelVersion: string;
};
/** Copy publication-owned storage; query-time permissions and freshness still govern every vector. */
export declare function copySemanticIndexes(db: Database, from: string, model: Ontology, target: {
    release: string;
    bindings: BindingManifest;
}, client: Sql): Promise<void>;
export declare function semanticFingerprint(db: Database, projection: string, client: Sql): Promise<import("pg").QueryResultRow | undefined>;
