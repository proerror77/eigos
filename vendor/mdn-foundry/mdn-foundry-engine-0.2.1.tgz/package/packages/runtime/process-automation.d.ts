import { z } from 'zod';
import { type ObjectRef } from '../ontology/schema.js';
import type { Objects } from './objects.js';
export declare const processRuleSchema: z.ZodObject<{
    type: z.ZodString;
    from: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    to: z.ZodOptional<z.ZodString>;
    dwellSeconds: z.ZodOptional<z.ZodNumber>;
}, z.core.$strict>;
export declare const processStatusSchema: z.ZodObject<{
    type: z.ZodString;
    object: z.ZodObject<{
        type: z.ZodString;
        id: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const processRelatedPath: z.ZodArray<z.ZodString>;
export declare const processTriggerSchema: z.ZodObject<{
    ruleId: z.ZodUUID;
    revision: z.ZodNumber;
    sequence: z.ZodString;
    process: z.ZodObject<{
        type: z.ZodString;
        from: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        to: z.ZodOptional<z.ZodString>;
        dwellSeconds: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>;
    relatedPath: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strict>;
export declare function processTarget(graph: Objects, rule: z.output<typeof processRuleSchema>): {
    type: string;
    objectType: string;
    property: string;
    link: string;
};
export declare function visibleTransition(graph: Objects, type: string, sequence: string): Promise<import("../ontology/schema.js").ObjectData | undefined>;
export declare function matchingTransition(graph: Objects, rule: z.output<typeof processRuleSchema>, sequence: string): Promise<import("../ontology/schema.js").ObjectData | undefined>;
export declare function relatedProcessObjects(graph: Objects, source: ObjectRef, path: string[]): Promise<{
    type: string;
    id: string;
}[]>;
export declare function readProcessStatus(graph: Objects, input: z.output<typeof processStatusSchema>): Promise<{
    object: {
        type: string;
        id: string;
    };
    property: string;
    schedules: import("pg").QueryResultRow[];
    state: {} | null;
    transition: {
        type: string;
        id: string;
    } | null;
    observedAt: unknown;
    recordedAt: string | null;
    asOf: string;
    recordedDurationSeconds: number | null;
}>;
