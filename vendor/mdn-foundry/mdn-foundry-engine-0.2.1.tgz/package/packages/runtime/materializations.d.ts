import { z } from 'zod';
import type { ObjectData } from '../ontology/schema.js';
import type { Database } from './database.js';
import type { Access } from './access.js';
import type { PublishedOntology } from './metadata.js';
export declare const materializationInputSchema: z.ZodObject<{
    requestId: z.ZodString;
    name: z.ZodString;
    types: z.ZodArray<z.ZodString>;
}, z.core.$strict>;
export declare function initializeMaterializations(db: Database): Promise<void>;
export declare class Materializations {
    private readonly db;
    constructor(db: Database);
    capture(access: Access, model: PublishedOntology, raw: unknown): Promise<{
        id: string;
    }>;
    read(access: Access, model: PublishedOntology, id: string, cursor?: string): Promise<{
        id: string;
        name: any;
        release: any;
        capturedAt: any;
        items: ObjectData[];
        cursor: string | undefined;
    }>;
    links(access: Access, model: PublishedOntology, id: string, after?: number): Promise<{
        items: {
            type: string;
            from: {
                type: string;
                id: string;
            };
            to: {
                type: string;
                id: string;
            };
        }[];
        cursor: number | undefined;
    }>;
}
