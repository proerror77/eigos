import { type Principal } from '../core/identity.js';
import type { Ontology } from '../ontology/model.js';
import type { componentImplementationSchema } from '../ontology/schema.js';
import type { z } from 'zod';
import type { Database } from './database.js';
import type { ConfiguredComponentSources } from './component-source-egress.js';
import { type FunctionHostClient } from './function-host.js';
import type { FunctionContext } from './functions.js';
import type { FunctionInvocationMetrics } from './function-invocations.js';
import type { Objects } from './objects.js';
export type ComponentImplementation = z.infer<typeof componentImplementationSchema>;
export declare const componentWorld = "eigos:function/handler@0.2.0";
/** Components that definition editors uploaded, by SHA-256. A release refers to them from its component Functions. */
export declare function initializeFunctionArtifacts(db: Database): Promise<void>;
/**
 * Functions implemented by WebAssembly components, which the function host runs. The host keeps precompiled
 * components; when it does not have one, it gets it from `function_artifacts`.
 */
export declare class ComponentFunctions {
    private readonly db;
    private readonly host;
    private readonly sources?;
    private readonly models;
    constructor(db: Database, host?: () => Promise<FunctionHostClient> | undefined, sources?: ConfiguredComponentSources | undefined, models?: import("./component-models.js").ComponentModels | undefined);
    modelBinding(aliases?: readonly string[]): string | undefined;
    sourceBinding(source: string): string;
    /**
     * Stores a component once the function host has checked it: its imports, and an `invoke` export of the EIGOS world.
     * The caller checks `edit_definition`.
     */
    upload(component: Buffer, principal: Principal): Promise<{
        sha256: string;
        size: number;
        world: string;
        imports?: string[] | undefined;
    }>;
    /** Checks a release's component Functions: the host runs within their limits and has, or now gets, their components. */
    check(model: Ontology): Promise<void>;
    /**
     * Calls a component Function on parameters that match its contract, and returns its JSON output. With `context`, the
     * Function reads the Ontology as that call's caller, through a callback session that ends with the call.
     */
    invoke(name: string, implementation: ComponentImplementation, parameters: Record<string, unknown>, signal: AbortSignal, context?: FunctionContext, options?: {
        writer?: Objects;
        source?: {
            name: string;
            binding: string;
        };
        metrics?: FunctionInvocationMetrics;
    }): Promise<unknown>;
    private connect;
    /** Gives the host a stored component it does not have. */
    private provide;
    /** A host's refusal of a component is the component's fault; anything else means the host is unavailable. */
    private refusal;
}
