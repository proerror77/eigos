import { compileMachineryExecution } from '../ontology/process-definition.js';
import { requireMachineryTransition } from './machinery-execution.js';
import { withoutExternalDispatch } from './external-operations.js';
import { ObservationInterests } from './observation-interests.js';
import { randomUUID } from 'node:crypto';
import { Conflict, digest, NotFound, PermissionDenied } from '../core/identity.js';
import { objectRefSchema } from '../ontology/schema.js';
import { validator } from '../ontology/model.js';
import { Metadata } from './metadata.js';
import { Access, TaskResult } from './access.js';
import { Objects } from './objects.js';
import { taskPrincipal } from './tasks.js';
import { Clarification } from './clarification.js';
export class DeferredExecution extends Error {
    until;
    constructor(until) {
        super('Scheduled check will resume');
        this.until = until;
    }
}
const actionContract = (model, name) => {
    const action = model.action(name);
    return digest({
        action,
        functions: [action.function, ...action.submissionCriteria.map((c) => c.function)]
            .filter((n) => !!n)
            .map((n) => ({ definition: model.functions.get(n), binding: model.bindings.functions[n] })),
    });
};
/** Future business work does not pin an old runtime for days. Admission checks
 * the exact action contract against the active release when the due task starts. */
export class ScheduledActions {
    db;
    metadata;
    terminalHandlers;
    constructor(db, metadata = new Metadata(db), terminalHandlers = new Map()) {
        this.db = db;
        this.metadata = metadata;
        this.terminalHandlers = terminalHandlers;
    }
    async enqueue(graph, job) {
        if (graph.model.scenario)
            throw new Conflict('Scenarios cannot schedule external execution');
        const start = Date.parse(job.runAt), end = Date.parse(job.deadline);
        if (!Number.isFinite(start) ||
            !Number.isFinite(end) ||
            end <= Date.now() ||
            end <= start ||
            end > Date.now() + 31 * 86400000)
            throw new Conflict('Use a bounded future execution window');
        graph.access.action(graph.model, job.action);
        validator(graph.model.action(job.action).parameters).parse(job.arguments);
        if (job.sourceTaskId) {
            const original = await this.db.query(`SELECT 1 FROM ${this.db.schema}.tasks WHERE id=$1 AND owner=$2 AND ontology=$3`, [job.sourceTaskId, graph.owner, graph.model.document.id], graph.client);
            if (!original.rowCount)
                throw new Conflict('Original task owner mismatch');
        }
        const body = {
            action: job.action,
            arguments: job.arguments,
            contract: actionContract(graph.model, job.action),
            sourceTaskId: job.sourceTaskId ?? null,
            plannedRelease: graph.model.release,
            ...(graph.access.principal.clientId ? { paClient: graph.access.principal.clientId } : {}),
            ...(graph.access.principal.memberAccess ? { memberAccess: true } : {}),
            ...(job.observationInterestId ? { observationInterestId: job.observationInterestId } : {}),
        };
        const prior = (await this.db.query(`SELECT body,run_at,deadline FROM ${this.db.schema}.scheduled_actions WHERE owner=$1 AND id=$2`, [graph.owner, job.id], graph.client)).rows[0];
        if (prior) {
            if (digest(prior.body) !== digest(body) ||
                new Date(prior.run_at).getTime() !== start ||
                new Date(prior.deadline).getTime() !== end)
                throw new Conflict('Scheduled operation already has different input');
            return;
        }
        await this.db.query(`INSERT INTO ${this.db.schema}.scheduled_actions(id,owner,body,scopes,run_at,deadline) VALUES($1,$2,$3,$4,$5,$6)`, [job.id, graph.owner, body, JSON.stringify(graph.access.principal.scopes), job.runAt, job.deadline], graph.client);
        await this.db.query("SELECT pg_notify('eigos_tasks','scheduled')", [], graph.client);
    }
    /** Retain the booked time and deadline. Only already authorized schedules bound to this subject can move off hold. */
    async replanSubject(model, owner, object, client) {
        const edges = compileMachineryExecution(model).byType.get(object.type) ?? [];
        const patterns = edges.map(edge => JSON.stringify({ action: edge.action, arguments: { [edge.execution.subject]: object },
            plannedRelease: model.release }));
        const jobs = await this.db.query(`SELECT id,body,scopes FROM ${this.db.schema}.scheduled_actions
      WHERE owner=$1 AND state='scheduled' AND deadline>now() AND body @> ANY($2::jsonb[]) ORDER BY id FOR UPDATE`, [owner, patterns], client);
        for (const job of jobs.rows) {
            const principal = { owner, scopes: job.scopes, memberAccess: job.body.memberAccess === true };
            await this.refreshTransition(model, principal, job.id, job.body, client);
        }
    }
    /** A job may become due before the Indexer consumes its first dependency change. */
    async hasProcessWatch(model, owner, call, client) {
        const subjects = [];
        for (const edge of compileMachineryExecution(model).byAction.get(call.action) ?? []) {
            const ref = objectRefSchema.safeParse(call.arguments[edge.execution.subject]);
            if (ref.success && ref.data.type === edge.process.objectType)
                subjects.push(JSON.stringify(ref.data));
        }
        if (!subjects.length)
            return false;
        return this.db.withTransactionOwner(client, owner, async () => {
            const result = await this.db.query(`SELECT 1 FROM ${this.db.schema}.change_subscriptions
        WHERE owner=$1 AND cancelled_at IS NULL AND footprint->'machinery'->>'release'=$2
          AND footprint->'machinery'->'object'=ANY($3::jsonb[]) LIMIT 1`, [owner, model.release, subjects], client);
            return Boolean(result.rowCount);
        });
    }
    async refreshTransition(model, principal, id, call, client) {
        let ready = true;
        try {
            const access = await Access.load(this.db, principal, client);
            access.action(model, call.action);
            await requireMachineryTransition(new Objects(this.db, model, access, client), call.action, call.arguments);
        }
        catch (error) {
            if (!(error instanceof Conflict || error instanceof PermissionDenied || error instanceof NotFound))
                throw error;
            ready = false;
        }
        await this.db.query(`UPDATE ${this.db.schema}.scheduled_actions SET machinery_retry_at=
      CASE WHEN $3 THEN now() ELSE least(deadline,now()+interval '30 seconds') END
      WHERE owner=$1 AND id=$2 AND state='scheduled'`, [principal.owner, id, ready], client);
        return ready;
    }
    async promoteOne() {
        return this.db.transaction(async (client) => {
            const activeFor = async (release) => {
                const planned = await this.metadata.get(release, client);
                return this.metadata.active(planned.document.id, client, true);
            };
            const notify = async (job, state) => this.terminalHandlers.get(job.body.action)?.(this.db, await activeFor(job.body.plannedRelease), client, job.owner, job.id, job.body, state, job.task_id ?? undefined);
            const terminalActions = [...this.terminalHandlers.keys()];
            const failed = await this.db.query(`UPDATE ${this.db.schema}.scheduled_actions s SET state='blocked',error='Scheduled Action failed'
          WHERE s.state='started' AND s.deadline>now() AND s.body->>'action'=ANY($1::text[])
            AND EXISTS (SELECT 1 FROM ${this.db.schema}.tasks t WHERE t.id=s.task_id AND t.owner=s.owner AND t.state='failed')
          RETURNING owner,id,body,task_id`, [terminalActions], client);
            const expired = await this.db.query(`WITH due AS(SELECT t.id FROM ${this.db.schema}.tasks t JOIN ${this.db.schema}.scheduled_actions s ON s.task_id=t.id AND s.owner=t.owner
        WHERE s.state='started' AND s.deadline<=now() AND t.state IN('submitted','working','input-required') FOR UPDATE OF t SKIP LOCKED LIMIT 100)
        UPDATE ${this.db.schema}.tasks t SET state='canceled',error='Scheduled execution window expired',token=NULL,lease_until=NULL,updated_at=now() FROM due WHERE t.id=due.id RETURNING t.id`, [], client);
            const startedExpired = expired.rows.length ? await this.db.query(`UPDATE ${this.db.schema}.scheduled_actions SET state='expired',error='Execution window expired; inspect the original external operation'
          WHERE task_id=ANY($1::uuid[]) RETURNING owner,id,body,task_id`, [expired.rows.map(row => row.id)], client) : undefined;
            const unstartedExpired = await this.db.query(`UPDATE ${this.db.schema}.scheduled_actions SET state='expired',error='Execution window expired'
        WHERE deadline<=now() AND (state='scheduled' OR
          state='started' AND body->>'action'=ANY($1::text[]) AND EXISTS (
            SELECT 1 FROM ${this.db.schema}.tasks t WHERE t.id=task_id AND t.state IN ('completed','failed','canceled')))
        RETURNING owner,id,body,task_id`, [terminalActions], client);
            const terminalJobs = [
                ...[...(startedExpired?.rows ?? []), ...unstartedExpired.rows].map(job => ({ job, state: 'expired' })),
                ...failed.rows.map(job => ({ job, state: 'failed' })),
            ];
            for (const { job, state } of terminalJobs.sort((a, b) => a.job.owner.localeCompare(b.job.owner)))
                await notify(job, state);
            const row = (await this.db.query(`SELECT * FROM ${this.db.schema}.scheduled_actions WHERE state='scheduled' AND run_at<=now()
            AND (machinery_retry_at IS NULL OR machinery_retry_at<=now()) ORDER BY run_at FOR UPDATE SKIP LOCKED LIMIT 1`, [], client)).rows[0];
            if (!row)
                return false;
            const fail = async (reason) => {
                await this.db.query(`UPDATE ${this.db.schema}.scheduled_actions SET state='blocked',error=$2 WHERE id=$1 AND owner=$3`, [row.id, reason, row.owner], client);
                await notify(row, 'failed');
                return true;
            };
            if (new Date(row.deadline).getTime() <= Date.now())
                return fail('Execution window expired');
            const model = await activeFor(row.body.plannedRelease);
            const principal = { owner: row.owner, scopes: row.scopes, memberAccess: row.body.memberAccess === true };
            try {
                const access = await Access.load(this.db, principal, client);
                access.action(model, row.body.action);
                if (actionContract(model, row.body.action) !== row.body.contract)
                    return fail('Published action contract changed; review and authorize a new plan');
            }
            catch {
                return fail('Current action or permissions are unavailable');
            }
            if (row.machinery_retry_at && row.body.plannedRelease !== model.release) {
                const original = await this.metadata.get(row.body.plannedRelease, client);
                const transitions = (publication) => compileMachineryExecution(publication).byAction.get(row.body.action) ?? [];
                if (digest(transitions(original)) !== digest(transitions(model)))
                    return fail('Published Machinery transitions changed; review and authorize a new plan');
            }
            if (row.machinery_retry_at || await this.hasProcessWatch(model, row.owner, row.body, client)) {
                const ready = await this.db.withTransactionOwner(client, row.owner, () => this.refreshTransition(model, principal, row.id, row.body, client));
                if (!ready)
                    return true;
            }
            const taskId = randomUUID(), requestId = `schedule:${row.id}`;
            const input = {
                requestId,
                message: `Execute scheduled Action ${row.body.action}`,
                ...(principal.memberAccess ? { memberAccess: true } : {}),
                ...(row.body.paClient ? { paClient: row.body.paClient } : {}),
                scheduledAction: {
                    scheduleId: row.id,
                    action: row.body.action,
                    arguments: row.body.arguments,
                    deadline: new Date(row.deadline).toISOString(),
                    contract: row.body.contract,
                    ...(row.body.observationInterestId ? { observationInterestId: row.body.observationInterestId } : {}),
                },
            };
            await this.db.query(`INSERT INTO ${this.db.schema}.tasks(id,owner,request_id,input_digest,input,release,scopes) VALUES($1,$2,$3,$4,$5,$6,$7)`, [taskId, row.owner, requestId, digest(input), input, model.release, JSON.stringify(row.scopes)], client);
            await this.db.query(`UPDATE ${this.db.schema}.scheduled_actions SET state='started',task_id=$2 WHERE id=$1 AND owner=$3`, [row.id, taskId, row.owner], client);
            await this.db.query("SELECT pg_notify('eigos_tasks','ready')", [], client);
            return true;
        });
    }
    async current(task, client = this.db.pool) {
        const call = task.input.scheduledAction;
        if (!call)
            throw new Conflict('Not a scheduled Action task');
        const row = (await this.db.query(`SELECT 1 FROM ${this.db.schema}.scheduled_actions WHERE id=$1 AND owner=$2 AND task_id=$3 AND state='started' AND deadline>now()`, [call.scheduleId, task.owner, task.id], client)).rows[0];
        if (!row)
            throw new Conflict('Scheduled Action was canceled or expired');
    }
    async continueAt(graph, task, until) {
        await this.current(task, graph.client);
        const end = Date.parse(task.input.scheduledAction.deadline), when = Date.parse(until);
        if (!Number.isFinite(when) || when <= Date.now() || when >= end)
            throw new Conflict('Continuation is outside the authorized execution window');
        await this.db.query(`UPDATE ${this.db.schema}.scheduled_actions SET continue_at=$3 WHERE owner=$1 AND id=$2 AND task_id=$4`, [graph.owner, task.input.scheduledAction.scheduleId, until, task.id], graph.client);
    }
    /** Move an authorized pending check forward while preserving its action, scopes and deadline. */
    async advance(graph, id, at) {
        if (graph.model.scenario || !(Date.parse(at) > Date.now()))
            return false;
        const [schedule] = (await this.db.query(`SELECT state,task_id FROM ${this.db.schema}.scheduled_actions
      WHERE id=$1 AND owner=$2 AND deadline>$3 AND state IN ('scheduled','started') FOR UPDATE`, [id, graph.owner, at], graph.client)).rows;
        if (!schedule)
            return false;
        const updated = schedule.state === 'scheduled'
            ? await this.db.query(`UPDATE ${this.db.schema}.scheduled_actions SET run_at=$3
          WHERE id=$1 AND owner=$2 AND run_at>$3`, [id, graph.owner, at], graph.client)
            : await this.db.query(`UPDATE ${this.db.schema}.tasks SET available_at=$3
          WHERE id=$1 AND owner=$2 AND state='submitted' AND available_at>$3`, [schedule.task_id, graph.owner, at], graph.client);
        if (!updated.rowCount)
            return false;
        await this.db.query("SELECT pg_notify('eigos_tasks','scheduled')", [], graph.client);
        return true;
    }
    async inspect(principal, id, client = this.db.pool) {
        const row = (await this.db.query(`SELECT s.id,s.state,s.run_at,s.deadline,s.task_id,coalesce(s.error,t.error) AS error,s.body,t.state AS task_state FROM ${this.db.schema}.scheduled_actions s LEFT JOIN ${this.db.schema}.tasks t ON t.id=s.task_id AND t.owner=s.owner WHERE s.owner=$1 AND s.id=$2`, [principal.owner, id], client)).rows[0];
        if (!row)
            throw new Conflict('Scheduled operation unavailable');
        return {
            id: row.id,
            state: row.state === 'started' ? row.task_state : row.state,
            runAt: row.run_at,
            deadline: row.deadline,
            taskId: row.task_id,
            sourceTaskId: row.body.sourceTaskId,
            error: row.error,
        };
    }
    async cancel(graph, id) {
        if (graph.model.scenario)
            throw new Conflict('Cancel execution on the live plan');
        const row = (await this.db.query(`SELECT task_id FROM ${this.db.schema}.scheduled_actions WHERE id=$1 AND owner=$2 AND state IN('scheduled','started','blocked')`, [id, graph.owner], graph.client)).rows[0];
        if (!row)
            throw new Conflict('Scheduled operation unavailable');
        if (row.task_id)
            await this.db.query(`UPDATE ${this.db.schema}.tasks SET state='canceled',token=NULL,lease_until=NULL,updated_at=now() WHERE id=$1 AND owner=$2 AND state IN('submitted','working','input-required')`, [row.task_id, graph.owner], graph.client);
        await this.db.query(`UPDATE ${this.db.schema}.scheduled_actions SET state='canceled',continue_at=NULL WHERE id=$1 AND owner=$2`, [id, graph.owner], graph.client);
        const effect = (await this.db.query(`SELECT state FROM ${this.db.schema}.external_operations WHERE owner=$1 AND operation_key=$2`, [graph.owner, id], graph.client)).rows[0];
        return { externalEffect: effect?.state ?? 'not_dispatched' };
    }
}
export class ScheduledActionRunner {
    db;
    metadata;
    tasks;
    actions;
    constructor(db, metadata, tasks, actions) {
        this.db = db;
        this.metadata = metadata;
        this.tasks = tasks;
        this.actions = actions;
    }
    async run(task, signal) {
        const call = task.input.scheduledAction;
        if (!call)
            throw new Conflict('Scheduled Action is required');
        const schedules = new ScheduledActions(this.db, this.metadata), model = await this.metadata.get(task.release), access = await Access.load(this.db, taskPrincipal(task));
        if (actionContract(model, call.action) !== call.contract)
            throw new Conflict('Scheduled Action contract changed');
        const guard = async (client) => {
            await this.tasks.current(task, client);
            await schedules.current(task, client);
            if (call.observationInterestId) {
                const graph = new Objects(this.db, model, access, client);
                const interest = await new ObservationInterests(this.db, this.metadata).assertScheduled(graph, task);
                if (interest.id !== call.observationInterestId)
                    throw new Conflict('Observation interest changed');
            }
        };
        await guard(this.db.pool);
        let ref;
        try {
            const apply = () => this.actions.apply(access, model, call.action, call.arguments, `${call.scheduleId}:step:${task.execution_step ?? 0}`, guard, { task, tasks: this.tasks }, signal, { kind: 'scheduled', id: call.scheduleId });
            ref = objectRefSchema.parse(await (call.observationInterestId ? withoutExternalDispatch(apply) : apply()));
        }
        catch (error) {
            if (error instanceof Clarification)
                throw new Clarification(error.message, error.choices, access.dataRequirements());
            throw error;
        }
        const continuation = (await this.db.query(`SELECT continue_at FROM ${this.db.schema}.scheduled_actions WHERE owner=$1 AND id=$2`, [
            task.owner,
            call.scheduleId,
        ])).rows[0]?.continue_at;
        if (continuation)
            throw new DeferredExecution(new Date(Math.max(Date.now() + 1000, new Date(continuation).getTime())).toISOString());
        return new TaskResult({ operation: ref, scheduleId: call.scheduleId }, access.dataRequirements());
    }
}
