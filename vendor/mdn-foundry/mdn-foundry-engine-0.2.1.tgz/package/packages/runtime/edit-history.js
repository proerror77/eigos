import pg from 'pg';
import { join } from 'node:path';
import { configuredArchive } from './log-retention.js';
import { z } from 'zod';
import { Conflict, digest } from '../core/identity.js';
export const conflictPolicySchema = z.enum(['user_wins', 'latest_value']);
export async function initializeEditHistory(db) {
    await db.query(`CREATE TABLE IF NOT EXISTS ${db.schema}.source_values (
    projection text NOT NULL, owner text NOT NULL, type text NOT NULL, id text NOT NULL,
    source text NOT NULL, properties jsonb, observed_at timestamptz NOT NULL,
    PRIMARY KEY(projection,owner,type,id,source));
    CREATE TABLE IF NOT EXISTS ${db.schema}.object_edits (
      projection text NOT NULL, owner text NOT NULL, type text NOT NULL, id text NOT NULL,
      overrides jsonb NOT NULL DEFAULT '{}', deleted boolean NOT NULL DEFAULT false,
      created boolean NOT NULL DEFAULT false, PRIMARY KEY(projection,owner,type,id));
    CREATE TABLE IF NOT EXISTS ${db.schema}.edit_policies (
      ontology text NOT NULL, type text NOT NULL, policy text NOT NULL CHECK(policy IN('user_wins','latest_value')),
      PRIMARY KEY(ontology,type));
    CREATE TABLE IF NOT EXISTS ${db.schema}.edit_history (
      sequence bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, projection text NOT NULL, release text NOT NULL,
      owner text NOT NULL, type text NOT NULL, id text NOT NULL, operation text NOT NULL,
      source text, before_values jsonb, after_values jsonb, actor text NOT NULL,
      happened_at timestamptz NOT NULL DEFAULT clock_timestamp());
    ALTER TABLE ${db.schema}.edit_history ADD COLUMN IF NOT EXISTS action text;
    ALTER TABLE ${db.schema}.edit_history ADD COLUMN IF NOT EXISTS request_id text;
    ALTER TABLE ${db.schema}.edit_history ADD COLUMN IF NOT EXISTS task_id text;
    ALTER TABLE ${db.schema}.edit_history ADD COLUMN IF NOT EXISTS observed_at timestamptz;
    ALTER TABLE ${db.schema}.edit_history ADD COLUMN IF NOT EXISTS executor_kind text;
    ALTER TABLE ${db.schema}.edit_history ADD COLUMN IF NOT EXISTS executor_id text;
    CREATE INDEX IF NOT EXISTS edit_history_object ON ${db.schema}.edit_history(owner,type,id,sequence);
    CREATE INDEX IF NOT EXISTS edit_history_process_cursor ON ${db.schema}.edit_history(owner,type,sequence);`);
    await initializeChangeJournal(db);
}
/**
 * Numbers committed changes per owner in commit order. History rows record their transaction. At COMMIT a deferred
 * trigger takes a per-owner lock and numbers the transaction in change_commits; the lock is released only after the
 * commit is visible. A reader that sees commit N of an owner therefore also sees every earlier commit of that owner and
 * can follow commit numbers without blocking writers. History written before the journal existed has no transaction;
 * change_journal records where it ends, and readers consume it in sequence order first.
 */
async function initializeChangeJournal(db) {
    const s = db.schema, relation = (name) => pg.escapeLiteral(`${s}.${name}`);
    // The key matches db.lockKey('change-commit', owner).
    const lockPrefix = pg.escapeLiteral(db.lockKey('change-commit').slice(0, -1) + ',');
    await db.query(`CREATE TABLE IF NOT EXISTS ${s}.change_journal(
      singleton boolean PRIMARY KEY DEFAULT true CHECK (singleton), legacy_end bigint NOT NULL);
    DO $install$ BEGIN
      IF NOT EXISTS (SELECT 1 FROM pg_attribute WHERE attrelid=${relation('edit_history')}::regclass AND attname='xact' AND NOT attisdropped) THEN
        -- Existing rows keep a NULL transaction. The table lock keeps writers out until the boundary is recorded.
        ALTER TABLE ${s}.edit_history ADD COLUMN xact xid8;
        ALTER TABLE ${s}.edit_history ALTER COLUMN xact SET DEFAULT pg_current_xact_id();
        INSERT INTO ${s}.change_journal(legacy_end) SELECT coalesce(max(sequence),0) FROM ${s}.edit_history;
      END IF;
    END $install$;
    CREATE INDEX IF NOT EXISTS edit_history_commit ON ${s}.edit_history(xact,type,sequence) WHERE xact IS NOT NULL;
    CREATE TABLE IF NOT EXISTS ${s}.link_history (
      sequence bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY, projection text NOT NULL, release text NOT NULL, owner text NOT NULL,
      type text NOT NULL, from_type text NOT NULL, from_id text NOT NULL, to_type text NOT NULL, to_id text NOT NULL,
      operation text NOT NULL CHECK (operation IN ('link','unlink')), source text, actor text NOT NULL, action text,
      request_id text, task_id text, executor_kind text, executor_id text,
      happened_at timestamptz NOT NULL DEFAULT clock_timestamp(), xact xid8 NOT NULL DEFAULT pg_current_xact_id());
    CREATE INDEX IF NOT EXISTS link_history_from ON ${s}.link_history(owner,from_type,from_id,sequence);
    CREATE INDEX IF NOT EXISTS link_history_to ON ${s}.link_history(owner,to_type,to_id,sequence);
    CREATE INDEX IF NOT EXISTS link_history_commit ON ${s}.link_history(xact,type);
    CREATE TABLE IF NOT EXISTS ${s}.change_commits (owner text NOT NULL, xact xid8 NOT NULL,
      commit_seq bigint GENERATED ALWAYS AS IDENTITY, committed_at timestamptz NOT NULL DEFAULT clock_timestamp(),
      PRIMARY KEY(owner,xact));
    CREATE UNIQUE INDEX IF NOT EXISTS change_commits_order ON ${s}.change_commits(owner,commit_seq);
    -- The query kernel's Funnel finds new commits across owners by number.
    CREATE INDEX IF NOT EXISTS change_commits_sequence ON ${s}.change_commits(commit_seq);
    CREATE OR REPLACE FUNCTION ${s}.record_change_commit() RETURNS trigger LANGUAGE plpgsql AS $journal$
    DECLARE prior text := current_setting('eigos.owner', true);
    BEGIN
      IF NEW.xact IS NULL THEN RETURN NULL; END IF;
      -- The row passed owner isolation when it was written. The commit may run after the owner context was restored.
      PERFORM set_config('eigos.owner', NEW.owner, true);
      IF NOT EXISTS (SELECT 1 FROM ${s}.change_commits WHERE owner=NEW.owner AND xact=NEW.xact) THEN
        -- Held until the transaction ends, so this owner's next commit is numbered after this one is visible.
        PERFORM pg_advisory_xact_lock(hashtextextended(${lockPrefix} || to_json(NEW.owner)::text || ']', 0));
        INSERT INTO ${s}.change_commits(owner,xact) VALUES (NEW.owner,NEW.xact);
      END IF;
      PERFORM set_config('eigos.owner', coalesce(prior, ''), true);
      RETURN NULL;
    END $journal$;
    DO $install$ BEGIN
      IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgrelid=${relation('edit_history')}::regclass AND tgname='record_edit_commit') THEN
        CREATE CONSTRAINT TRIGGER record_edit_commit AFTER INSERT ON ${s}.edit_history DEFERRABLE INITIALLY DEFERRED
          FOR EACH ROW EXECUTE FUNCTION ${s}.record_change_commit();
      END IF;
      IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgrelid=${relation('link_history')}::regclass AND tgname='record_link_commit') THEN
        CREATE CONSTRAINT TRIGGER record_link_commit AFTER INSERT ON ${s}.link_history DEFERRABLE INITIALLY DEFERRED
          FOR EACH ROW EXECUTE FUNCTION ${s}.record_change_commit();
      END IF;
    END $install$;`);
}
/**
 * Journals the relationships a statement's CTE returned (type, from_type, from_id, to_type, to_id), with the
 * graph's change identity. Appends its parameters to `values`; `projection` and `owner` are placeholders already bound.
 */
export function journalLinks(graph, operation, rows, projection, owner, values, source = null) {
    const bind = (value) => { values.push(value); return '$' + values.length; };
    const { change } = graph;
    return `INSERT INTO ${graph.db.schema}.link_history(projection,release,owner,type,from_type,from_id,to_type,to_id,
      operation,source,actor,action,request_id,task_id,executor_kind,executor_id)
    SELECT ${projection},${bind(graph.model.release)},${owner},type,from_type,from_id,to_type,to_id,${bind(operation)},${bind(source)},
      ${bind(graph.access.principal.owner)},${bind(change?.action ?? null)},${bind(change?.requestId ?? null)},${bind(change?.taskId ?? null)},
      ${bind(change?.executor?.kind ?? null)},${bind(change?.executor?.id ?? null)} FROM ${rows}`;
}
export async function setConflictPolicy(db, access, model, type, policy) {
    model.object(type);
    await access.refresh();
    access.require(model.document.id, 'manage_definition', model.document.id);
    await db.transaction(async (client) => {
        await access.refresh(client);
        await db.query(`INSERT INTO ${db.schema}.edit_policies(ontology,type,policy) VALUES($1,$2,$3)
      ON CONFLICT(ontology,type) DO UPDATE SET policy=excluded.policy`, [model.document.id, type, conflictPolicySchema.parse(policy)], client);
    });
    return { type, policy };
}
function requireTransaction(graph) {
    if (graph.client === graph.db.pool)
        throw new Conflict('Edit history must share the object transaction');
}
function applyObjectEdit(value, { after, kind, changedFields }, at) {
    if (kind === 'create') {
        value.overrides = {};
        value.created = true;
    }
    value.deleted = after === null;
    if (after)
        for (const [field, fieldValue] of Object.entries(changedFields ?? after))
            value.overrides[field] = { value: fieldValue, at };
}
/** Called after the live mutation, in the same transaction. Scenario deltas are journaled when merged. */
export async function recordObjectEdit(graph, ref, before, after, changedFields, kind = 'edit') {
    if (graph.model.scenario)
        return;
    await recordObjectEdits(graph, [{ ref, before, after, changedFields, kind }]);
}
/** Unique live edits in an Action, with the same source baselines and overrides as individual writes. */
export async function recordObjectEdits(graph, edits) {
    if (!edits.length)
        return;
    if (graph.model.scenario)
        throw new Conflict('Bulk edit history requires the live projection');
    requireTransaction(graph);
    const { db, client, model, change, owner } = graph;
    const scope = [model.projection, owner];
    const existing = new Map((await db.query(`
    SELECT e.type,e.id,e.overrides,e.deleted,e.created FROM ${db.schema}.object_edits e
    JOIN jsonb_to_recordset($3::jsonb) AS k(type text,id text) ON e.type=k.type AND e.id=k.id
    WHERE e.projection=$1 AND e.owner=$2`, [...scope, keyRows(edits.map(edit => edit.ref))], client))
        .rows.map(row => [objectKey(row), row]));
    const at = (await db.query('SELECT clock_timestamp() AS at', [], client)).rows[0].at.toISOString();
    const rows = edits.map((edit, ordinal) => {
        const value = existing.get(objectKey(edit.ref)) ?? { overrides: {}, deleted: false, created: false };
        applyObjectEdit(value, edit, at);
        return { ...edit.ref, overrides: value.overrides, deleted: value.deleted, created: value.created,
            before_values: edit.before, after_values: edit.after, operation: edit.kind, ordinal };
    });
    const values = [...scope, JSON.stringify(rows)];
    if (edits.some(edit => edit.before))
        await db.query(`INSERT INTO ${db.schema}.source_values(projection,owner,type,id,source,properties,observed_at)
    SELECT $1,$2,r.type,r.id,'__legacy__',r.before_values,'-infinity'::timestamptz
    FROM jsonb_to_recordset($3::jsonb) AS r(type text,id text,before_values jsonb)
    WHERE r.before_values IS NOT NULL AND NOT EXISTS (SELECT 1 FROM ${db.schema}.source_values s
      WHERE s.projection=$1 AND s.owner=$2 AND s.type=r.type AND s.id=r.id)
    ON CONFLICT DO NOTHING`, values, client);
    await db.query(`INSERT INTO ${db.schema}.object_edits(projection,owner,type,id,overrides,deleted,created)
    SELECT $1,$2,type,id,overrides,deleted,created FROM jsonb_to_recordset($3::jsonb)
      AS r(type text,id text,overrides jsonb,deleted boolean,created boolean)
    ON CONFLICT(projection,owner,type,id) DO UPDATE
    SET overrides=excluded.overrides,deleted=excluded.deleted,created=excluded.created`, values, client);
    await db.query(`INSERT INTO ${db.schema}.edit_history(projection,owner,type,id,release,operation,before_values,after_values,
      actor,action,request_id,task_id,executor_kind,executor_id)
    SELECT $1,$2,type,id,$4,operation,before_values,after_values,$2,$5,$6,$7,$8,$9 FROM jsonb_to_recordset($3::jsonb)
      AS r(type text,id text,operation text,before_values jsonb,after_values jsonb,ordinal integer)
    ORDER BY ordinal`, [...values, model.release, change?.action ?? null, change?.requestId ?? null,
        change?.taskId ?? null, change?.executor?.kind ?? null, change?.executor?.id ?? null], client);
}
const objectKey = (ref) => JSON.stringify([ref.type, ref.id]);
const keyRows = (refs) => JSON.stringify(refs.map(({ type, id }) => ({ type, id })));
/**
 * Persists the source baselines of a batch and resolves each object with its user edits, in input order.
 * Each object needs the same decisions as a single observation; the statements are shared by the batch.
 * The caller writes the returned object values in the same transaction.
 */
export async function resolveSourceEdits(graph, observations, source = 'default', observedAt) {
    requireTransaction(graph);
    if (graph.model.scenario)
        throw new Conflict('Source ingestion requires the live projection');
    if (!observations.length)
        return [];
    const { db, model, client, change } = graph, scope = [model.projection, graph.owner];
    const matching = (alias) => `JOIN jsonb_to_recordset($3::jsonb) AS k(type text,id text) ON ${alias}.type=k.type AND ${alias}.id=k.id
    WHERE ${alias}.projection=$1 AND ${alias}.owner=$2`;
    const group = (rows) => {
        const grouped = new Map();
        for (const row of rows)
            grouped.set(objectKey(row), [...grouped.get(objectKey(row)) ?? [], row]);
        return grouped;
    };
    const keys = keyRows(observations.map(item => item.ref));
    const baselines = group((await db.query(`SELECT s.type,s.id,s.source,s.properties,s.observed_at FROM ${db.schema}.source_values s ${matching('s')}`, [...scope, keys], client)).rows);
    const edits = new Map((await db.query(`SELECT e.type,e.id,e.overrides,e.deleted,e.created FROM ${db.schema}.object_edits e ${matching('e')}`, [...scope, keys], client)).rows.map(row => [objectKey(row),
        { overrides: row.overrides, deleted: row.deleted, created: row.created }]));
    const now = new Date().toISOString();
    const plans = observations.map(item => {
        const key = objectKey(item.ref), rows = baselines.get(key) ?? [];
        const state = edits.get(key) ?? { overrides: {}, deleted: false, created: false };
        const candidateTime = observedAt ?? (typeof item.incoming?.observedAt === 'string' ? item.incoming.observedAt : now);
        const observed = z.iso.datetime({ offset: true }).parse(candidateTime);
        let prior = rows.find(row => row.source === source), legacy;
        // An upgraded row has no source history yet. Retain its observed time before handling the first refresh or deletion.
        if (!prior && item.before && !state.created && rows.every(row => row.source === '__legacy__')) {
            const baseline = rows.find(row => row.source === '__legacy__')?.properties ?? item.before;
            const timestamp = z.iso.datetime({ offset: true }).safeParse(baseline.observedAt);
            if (timestamp.success)
                prior = legacy = { source, properties: baseline, observed_at: timestamp.data };
        }
        const priorTime = prior && new Date(prior.observed_at).getTime();
        const stale = priorTime !== undefined && priorTime > Date.parse(observed);
        if (!stale && prior && priorTime === Date.parse(observed) && digest(prior.properties) !== digest(item.incoming))
            throw new Conflict('One source timestamp contains conflicting object data');
        return { item, key, observed, state, stale, legacy };
    });
    const current = plans.filter(plan => !plan.stale);
    const baselineRows = [
        ...current.map(plan => ({ ...plan.item.ref, properties: plan.item.incoming, observed_at: plan.observed })),
        // A stale observation keeps the stored value, but an upgraded row records the baseline it was compared with.
        ...plans.filter(plan => plan.stale && plan.legacy).map(plan => ({ ...plan.item.ref, ...plan.legacy })),
    ].map(({ type, id, properties, observed_at }) => ({ type, id, properties, observed_at }));
    if (current.length)
        await db.query(`DELETE FROM ${db.schema}.source_values s USING jsonb_to_recordset($3::jsonb) AS k(type text,id text)
    WHERE s.projection=$1 AND s.owner=$2 AND s.type=k.type AND s.id=k.id AND s.source='__legacy__'`, [...scope, keyRows(current.map(plan => plan.item.ref))], client);
    if (baselineRows.length)
        await db.query(`INSERT INTO ${db.schema}.source_values(projection,owner,type,id,source,properties,observed_at)
    SELECT $1,$2,r.type,r.id,$3,r.properties,r.observed_at FROM jsonb_to_recordset($4::jsonb) AS r(type text,id text,properties jsonb,observed_at timestamptz)
    ON CONFLICT(projection,owner,type,id,source) DO UPDATE SET properties=excluded.properties,observed_at=excluded.observed_at`, [...scope, source, JSON.stringify(baselineRows)], client);
    const resolving = current.filter(plan => !plan.state.deleted);
    const merged = resolving.length ? group((await db.query(`SELECT s.type,s.id,s.properties,s.observed_at,s.source FROM ${db.schema}.source_values s ${matching('s')}
    ORDER BY s.type,s.id,s.observed_at,s.source`, [...scope, keyRows(resolving.map(plan => plan.item.ref))], client)).rows) : new Map();
    const types = [...new Set(resolving.map(plan => plan.item.ref.type))];
    const policies = new Map(types.length ? (await db.query(`SELECT type,policy FROM ${db.schema}.edit_policies WHERE ontology=$1 AND type=ANY($2::text[])`, [model.document.id, types], client)).rows.map(row => [String(row.type), String(row.policy)]) : []);
    const history = [];
    const results = plans.map(({ item, key, observed, state, stale }) => {
        if (stale)
            return { value: item.before, current: false };
        const { ref } = item, fields = model.object(ref.type).properties;
        let resolved = null;
        if (!state.deleted) {
            const times = new Map();
            for (const row of merged.get(key) ?? []) {
                if (row.properties === null)
                    continue;
                resolved ??= {};
                for (const [field, value] of Object.entries(row.properties)) {
                    if (!fields[field])
                        continue;
                    resolved[field] = value;
                    const timestamp = new Date(row.observed_at).getTime();
                    times.set(field, Number.isFinite(timestamp) ? timestamp : -Infinity);
                }
            }
            if (state.created)
                resolved ??= {};
            const policy = policies.get(ref.type) ?? 'user_wins';
            if (resolved)
                for (const [field, edit] of Object.entries(state.overrides)) {
                    if (!fields[field])
                        continue;
                    if (policy === 'user_wins' || !times.has(field) || Date.parse(edit.at) > times.get(field))
                        resolved[field] = edit.value;
                }
        }
        if (resolved)
            resolved = model.parseObject(ref, resolved);
        if (digest(item.before) !== digest(resolved))
            history.push({ position: history.length, type: ref.type, id: ref.id, before_values: item.before, after_values: resolved, observed_at: observed });
        return { value: resolved, current: true };
    });
    if (history.length)
        await db.query(`INSERT INTO ${db.schema}.edit_history(projection,owner,type,id,release,operation,source,before_values,after_values,actor,action,request_id,task_id,observed_at,executor_kind,executor_id)
    SELECT $1,$2,h.type,h.id,$3,'source',$4,h.before_values,h.after_values,$5,$6,$7,$8,h.observed_at,$9,$10
    FROM jsonb_to_recordset($11::jsonb) AS h(position integer,type text,id text,before_values jsonb,after_values jsonb,observed_at timestamptz) ORDER BY h.position`, [...scope, model.release, source, graph.access.principal.owner, change?.action ?? null, change?.requestId ?? null, change?.taskId ?? null,
            change?.executor?.kind ?? null, change?.executor?.id ?? null, JSON.stringify(history)], client);
    return results;
}
export class EditHistory {
    db;
    archive;
    /** `archive` reads history that commit log retention archived; without it, only the tables' history is read. */
    constructor(db, archive = configuredArchive()) {
        this.db = db;
        this.archive = archive;
    }
    async read(graph, ref, after = '0', limit = 100) {
        z.string().regex(/^\d+$/).parse(after);
        z.number().int().min(1).max(100).parse(limit);
        // Current object visibility governs historical data too. Deleted instances cannot be loaded through this endpoint.
        await graph.read(ref);
        const live = (await this.db.query(`SELECT h.sequence::text,h.operation,h.source,h.before_values,h.after_values,h.actor,h.happened_at,h.release,h.action,h.request_id,h.task_id,h.observed_at,h.executor_kind,h.executor_id
      FROM ${this.db.schema}.edit_history h JOIN ${this.db.schema}.releases r ON r.digest=h.release
      WHERE r.body->>'id'=$1 AND h.owner=$2 AND h.type=$3 AND h.id=$4 AND h.sequence>$5::bigint ORDER BY h.sequence LIMIT $6`, [graph.model.document.id, graph.owner, ref.type, ref.id, after, limit + 1], graph.client)).rows;
        const { rows: archived, unavailable } = await this.archived(graph, ref, after, limit + 1);
        // Archived and kept rows can interleave at a month's edge, so the page takes the lowest sequences of both.
        const rows = [...archived, ...live].sort((a, b) => Number(BigInt(a.sequence) - BigInt(b.sequence))).slice(0, limit + 1);
        const mask = (properties) => properties && graph.maskSnapshot(ref, properties);
        const items = rows.slice(0, limit).map(row => ({ sequence: row.sequence, operation: row.operation, source: row.source, before: mask(row.before_values), after: mask(row.after_values), actor: row.actor, at: row.happened_at, release: row.release,
            action: row.action, requestId: row.request_id, taskId: row.task_id, observedAt: row.observed_at,
            executor: row.executor_kind && row.executor_id ? { kind: row.executor_kind, id: row.executor_id } : null }));
        await graph.access.refresh(graph.client);
        return { items, cursor: rows.length > limit ? items.at(-1).sequence : undefined, ...(unavailable ? { archive: 'unavailable' } : {}) };
    }
    /** The object's archived history after `after`, in this ontology's releases, as the tables would return it. */
    async archived(graph, ref, after, take) {
        const s = this.db.schema;
        const files = (await this.db.query(`SELECT path FROM ${s}.log_archives
      WHERE owner=$1 AND table_name='edit_history' AND last_key>$2::bigint ORDER BY month`, [graph.owner, after], graph.client)).rows;
        if (!files.length)
            return { rows: [] };
        if (!this.archive)
            return { rows: [], unavailable: true };
        const found = await this.archive.codec.read('edit_history', { owner: graph.owner, type: ref.type, id: ref.id, after, limit: String(take) }, files.map(file => join(this.archive.dir, file.path)));
        const releases = new Set((await this.db.query(`SELECT digest FROM ${s}.releases WHERE body->>'id'=$1 AND digest=ANY($2::text[])`, [graph.model.document.id, [...new Set(found.map(row => row.release))]], graph.client)).rows.map(row => row.digest));
        const json = (text) => text == null ? null : JSON.parse(text);
        return { rows: found.filter(row => releases.has(row.release)).map(row => ({
                sequence: row.sequence, operation: row.operation, source: row.source ?? null, before_values: json(row.before_values), after_values: json(row.after_values),
                actor: row.actor, happened_at: new Date(row.happened_at), release: row.release, action: row.action ?? null, request_id: row.request_id ?? null,
                task_id: row.task_id ?? null, observed_at: row.observed_at == null ? null : new Date(row.observed_at), executor_kind: row.executor_kind ?? null,
                executor_id: row.executor_id ?? null
            })) };
    }
}
/** A replacement publication carries conflict baselines and overlays forward with the resolved objects. */
export async function copyEditState(db, from, to, client, types) {
    if (from === to)
        throw new Conflict('A replacement projection must differ from its source');
    for (const table of ['source_values', 'object_edits']) {
        const columns = table === 'source_values' ? 'owner,type,id,source,properties,observed_at' : 'owner,type,id,overrides,deleted,created';
        await db.query(`DELETE FROM ${db.schema}.${table} WHERE projection=$1`, [to], client);
        await db.query(`INSERT INTO ${db.schema}.${table}(projection,${columns}) SELECT $2,${columns} FROM ${db.schema}.${table} WHERE projection=$1 AND ($3::text[] IS NULL OR type=ANY($3::text[]))`, [from, to, types ?? null], client);
    }
}
