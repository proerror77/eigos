import { ComponentModelSession, configuredComponentModels } from './component-models.js';
import { createHash } from 'node:crypto';
import { Conflict, FunctionFailed, InvalidInput, PermissionDenied, ResourceExhausted, ServiceUnavailable } from '../core/identity.js';
import { functionCallbacks } from './function-callbacks.js';
import { defaultFunctionHost, FunctionHostError, lostFunctionHost } from './function-host.js';
export const componentWorld = 'eigos:function/handler@0.2.0';
const maxComponentBytes = 16 << 20, maxInputBytes = 1 << 20;
/** Components that definition editors uploaded, by SHA-256. A release refers to them from its component Functions. */
export async function initializeFunctionArtifacts(db) {
    await db.query(`CREATE TABLE IF NOT EXISTS ${db.schema}.function_artifacts(
    sha256 text PRIMARY KEY CHECK (sha256 ~ '^[0-9a-f]{64}$'),
    bytes bytea NOT NULL,
    size integer NOT NULL CHECK (size > 0),
    world text NOT NULL,
    uploaded_by text NOT NULL,
    uploaded_at timestamptz NOT NULL DEFAULT now())`);
}
/**
 * Functions implemented by WebAssembly components, which the function host runs. The host keeps precompiled
 * components; when it does not have one, it gets it from `function_artifacts`.
 */
export class ComponentFunctions {
    db;
    host;
    sources;
    models;
    constructor(db, host = defaultFunctionHost, sources, models = configuredComponentModels(db)) {
        this.db = db;
        this.host = host;
        this.sources = sources;
        this.models = models;
    }
    modelBinding(aliases) {
        if (!aliases)
            return;
        if (!this.models)
            throw new ServiceUnavailable('Component model aliases are unavailable');
        return this.models.binding(aliases);
    }
    sourceBinding(source) {
        if (!this.sources)
            throw new ServiceUnavailable('Component HTTP Sources are unavailable');
        return this.sources.egress.binding(source);
    }
    /**
     * Stores a component once the function host has checked it: its imports, and an `invoke` export of the EIGOS world.
     * The caller checks `edit_definition`.
     */
    async upload(component, principal) {
        if (!component.length || component.length > maxComponentBytes)
            throw new InvalidInput(`A component is 1 to ${maxComponentBytes} bytes`);
        const host = await this.connect();
        let checked;
        try {
            checked = await host.upload(new Uint8Array(component));
        }
        catch (error) {
            throw this.refusal(host, error);
        }
        const sha256 = createHash('sha256').update(component).digest('hex');
        await this.db.query(`INSERT INTO ${this.db.schema}.function_artifacts(sha256,bytes,size,world,uploaded_by) VALUES($1,$2,$3,$4,$5)
      ON CONFLICT (sha256) DO NOTHING`, [sha256, component, component.length, componentWorld, principal.owner]);
        return { sha256, size: component.length, world: componentWorld, ...(checked.imports ? { imports: checked.imports } : {}) };
    }
    /** Checks a release's component Functions: the host runs within their limits and has, or now gets, their components. */
    async check(model) {
        const functions = model.resolvedDocument.functionTypes.filter(fn => fn.implementation);
        if (!functions.length)
            return;
        const host = await this.connect();
        let maxima;
        try {
            maxima = (await host.health()).maxima;
        }
        catch (error) {
            throw this.refusal(host, error);
        }
        if (functions.some(fn => fn.source) && !await host.supports(3))
            throw new ServiceUnavailable('Component HTTP Sources require a protocol 3 function host');
        if (functions.some(fn => fn.implementation?.models || fn.implementation?.stream) && !await host.supports(4))
            throw new ServiceUnavailable('Model and streaming Functions require a protocol 4 host');
        for (const fn of functions) {
            this.modelBinding(fn.implementation?.models);
            if (fn.source)
                this.sourceBinding(fn.source);
            const { sha256, limits } = fn.implementation;
            const over = ['fuel', 'memoryMb', 'deadlineMs', 'inputBytes', 'outputBytes']
                .filter(limit => (limits[limit] ?? 0) > maxima[limit]);
            if (over.length)
                throw new Conflict(`The function host allows less ${over.join(', ')} than ${fn.apiName} asks for`);
            await this.provide(host, sha256, fn.apiName);
        }
    }
    /**
     * Calls a component Function on parameters that match its contract, and returns its JSON output. With `context`, the
     * Function reads the Ontology as that call's caller, through a callback session that ends with the call.
     */
    async invoke(name, implementation, parameters, signal, context, options = {}) {
        const input = JSON.stringify(parameters), limits = implementation.limits;
        const inputBytes = limits.inputBytes ?? maxInputBytes;
        if (Buffer.byteLength(input) > inputBytes)
            throw new InvalidInput(`The input of ${name} exceeds ${inputBytes} bytes`);
        const host = await this.connect();
        // A host before protocol 2 would refuse the callback; its Functions then find no Ontology to read.
        const source = options.source, sources = this.sources;
        const outgoing = source && sources && context ? (raw) => sources.egress.send(source.name, source.binding, raw, {
            mode: 'read',
            signal,
            authorize: async (name) => {
                const access = context.objects.access;
                await access.refresh();
                access.source(context.objects.model, name);
                signal.throwIfAborted();
            },
            secret: async (name) => {
                if (!sources.secrets)
                    throw new PermissionDenied('Source credential is unavailable');
                return sources.secrets.get(name);
            },
        }) : undefined;
        if (source && (!outgoing || !await host.supports(3)))
            throw new ServiceUnavailable('Component HTTP Sources require a configured protocol 3 function host');
        const streams = implementation.stream || implementation.models;
        if (streams && !await host.supports(4))
            throw new ServiceUnavailable('Component needs a protocol 4 function host');
        const modelSession = context && streams ? new ComponentModelSession(implementation, context, this.models, signal, options.metrics) : undefined;
        const session = context && await host.supports(2) ? await functionCallbacks.open(this.db, context, options.writer, {
            outgoing, models: modelSession, timings: options.metrics?.callbacks,
        }) : undefined;
        let outcome;
        try {
            try {
                outcome = await host.invoke(implementation.sha256, input, limits, signal, session?.callback);
            }
            catch (error) {
                if (!(error instanceof FunctionHostError && error.status === 404))
                    throw error;
                // A restarted host, or one that evicted the component without keeping it on disk.
                await this.provide(host, implementation.sha256, name);
                outcome = await host.invoke(implementation.sha256, input, limits, signal, session?.callback);
            }
        }
        catch (error) {
            if (signal.aborted)
                throw signal.reason;
            throw this.refusal(host, error);
        }
        finally {
            session?.close();
            await modelSession?.close();
        }
        if (options.metrics) {
            options.metrics.fuelUsed = outcome.fuelUsed;
            options.metrics.hostMs = Math.round(outcome.ms);
        }
        const detail = { fuelUsed: outcome.fuelUsed, ms: outcome.ms, ...(outcome.stderr ? { stderr: outcome.stderr } : {}) };
        if (outcome.error) {
            const { error } = outcome;
            if (error.kind === 'failure')
                throw Object.assign(new FunctionFailed(error.message, error.code), { detail });
            if (error.kind === 'trap')
                throw Object.assign(new FunctionFailed(`${name} failed: ${error.message}`, 'trap'), { detail });
            const limit = { fuel: 'fuel', memory: 'memory', deadline: 'deadline', output: 'output size' }[error.kind];
            throw Object.assign(new ResourceExhausted(`${name} exceeded its ${limit} limit`, error.kind), { detail });
        }
        try {
            return JSON.parse(outcome.output);
        }
        catch (cause) {
            throw Object.assign(new FunctionFailed(`${name} returned an output that is not JSON`, 'contract', { cause }), { detail });
        }
    }
    async connect() {
        const host = this.host();
        if (!host)
            throw new ServiceUnavailable('Component Functions need a function host: set EIGOS_FUNCTION_HOST_URL');
        try {
            return await host;
        }
        catch (cause) {
            throw new ServiceUnavailable('The function host is unavailable', { cause });
        }
    }
    /** Gives the host a stored component it does not have. */
    async provide(host, sha256, name) {
        const row = (await this.db.query(`SELECT bytes FROM ${this.db.schema}.function_artifacts WHERE sha256=$1`, [sha256])).rows[0];
        if (!row)
            throw new Conflict(`The component of ${name} has not been uploaded: ${sha256}`);
        try {
            await host.upload(new Uint8Array(row.bytes));
        }
        catch (error) {
            throw this.refusal(host, error);
        }
    }
    /** A host's refusal of a component is the component's fault; anything else means the host is unavailable. */
    refusal(host, error) {
        if (error instanceof FunctionHostError && (error.status === 400 || error.status === 413 || error.status === 422))
            return new InvalidInput(`The function host refused the component: ${error.message}`);
        if (error instanceof Conflict || error instanceof InvalidInput)
            return error;
        if (!(error instanceof FunctionHostError))
            lostFunctionHost(host);
        return new ServiceUnavailable('The function host is unavailable', { cause: error });
    }
}
