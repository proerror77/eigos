import { z } from 'zod';
import { Database } from './database.js';
import { Metadata, type Bindings } from './metadata.js';
import { TaskResult } from './access.js';
import { Actions } from './actions.js';
import { Functions } from './functions.js';
import { Sources } from './sources.js';
import { Tasks, type Task } from './tasks.js';
import type { AgentTaskPrompt, AgentTaskWorkflow } from './agent-task.js';
export { Clarification } from './clarification.js';
export interface AgentTool {
    description: string;
    schema: z.ZodType;
    invoke(input: unknown): Promise<unknown>;
}
export interface AgentDriver {
    readonly model: string;
    readonly provider?: string;
    run(prompt: string, tools: ReadonlyMap<string, AgentTool>, signal: AbortSignal): Promise<void>;
}
export interface Capabilities extends Bindings {
    functions: Functions;
    actions: Actions;
    sources: Sources;
    agentInstructions?: readonly string[];
    legacyProfiles?: NonNullable<import('../ontology/schema.js').OntologyDocument['agentProfiles']>;
    taskWorkflow?: AgentTaskWorkflow;
    taskPrompt?: AgentTaskPrompt;
}
export declare class OntologyAgent {
    private readonly db;
    private readonly metadata;
    private readonly tasks;
    private readonly capabilities;
    private readonly driver;
    private readonly options;
    constructor(db: Database, metadata: Metadata, tasks: Tasks, capabilities: Capabilities, driver: AgentDriver, options?: {
        sandbox?: boolean;
        onFunctionChunk?: (task: Task, functionName: string, chunk: string) => Promise<void>;
    });
    run(task: Task, outerSignal: AbortSignal): Promise<TaskResult>;
    private execute;
}
