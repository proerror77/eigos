import type { Access } from './access.js';
import type { ActionContinuation } from './clarification.js';
import type { Database, Sql } from './database.js';
import type { PublishedOntology } from './metadata.js';
import type { Task } from './tasks.js';
export declare const actionConfirmationRef: (requestId: string) => {
    type: string;
    id: string;
};
type State = 'awaiting-input' | 'confirmed' | 'completed' | 'failed' | 'canceled';
/** The runtime owns this lifecycle row. Reading its published projection still requires an object grant. */
export declare function recordActionConfirmation(db: Database, model: PublishedOntology, access: Access, task: Task, client: Sql, continuation: ActionContinuation, state: State): Promise<void>;
export declare function assertActionConfirmed(db: Database, model: PublishedOntology, task: Task, continuation: ActionContinuation, client?: Sql): Promise<void>;
export {};
