import { type ExecutionActor } from '../core/identity.js';
import type { ObjectRef } from '../ontology/schema.js';
import type { Database, Sql } from './database.js';
import type { PublishedOntology } from './metadata.js';
import type { ObjectChange, LinkChange } from './action-journal.js';
type Properties = Record<string, unknown>;
type Version = {
    revision: number;
    properties: Properties;
};
/**
 * Transaction-local state of one exclusively locked plain object. The usual rule evaluator, row/cell checks and
 * journal still run for each logical revision. Physical object state and durable records flush before COMMIT.
 */
export declare class HotEditBuffer {
    private readonly db;
    private readonly client;
    private readonly model;
    private readonly owner;
    private readonly ref;
    private original;
    private readonly edits;
    private readonly steps;
    private related?;
    private snapshotBytes;
    private current;
    private constructor();
    static for(client: Sql, model: PublishedOntology, owner: string, ref?: ObjectRef): HotEditBuffer | undefined;
    static run<T>(db: Database, client: Sql, model: PublishedOntology, owner: string, ref: ObjectRef, work: () => Promise<T>): Promise<T>;
    snapshot(): Version;
    links(load: () => Promise<unknown[]>): Promise<unknown[]>;
    edit(revision: number, properties: Properties, fields: Properties): void;
    receipt(request: string, action: string, fingerprint: string, result: ObjectRef, actor: ExecutionActor, task: string | undefined, objects: ObjectChange[], links: LinkChange[]): void;
    flushChanges(): Promise<void>;
    private flush;
}
export {};
