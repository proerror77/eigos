import { z } from 'zod';
import { type MachineryModel } from '../ontology/process-definition.js';
import { type ObjectRef } from '../ontology/schema.js';
import type { Access } from './access.js';
import type { Database } from './database.js';
import type { PublishedOntology } from './metadata.js';
export declare const machineryAnalysisSchema: z.ZodObject<{
    type: z.ZodString;
    from: z.ZodISODateTime;
    to: z.ZodISODateTime;
    object: z.ZodOptional<z.ZodObject<{
        type: z.ZodString;
        id: z.ZodString;
    }, z.core.$strict>>;
    setId: z.ZodOptional<z.ZodUUID>;
    externalSource: z.ZodOptional<z.ZodString>;
    eventLimit: z.ZodDefault<z.ZodNumber>;
    focus: z.ZodOptional<z.ZodObject<{
        parent: z.ZodObject<{
            type: z.ZodString;
            id: z.ZodString;
        }, z.core.$strict>;
        type: z.ZodString;
        link: z.ZodString;
    }, z.core.$strict>>;
    reference: z.ZodOptional<z.ZodObject<{
        states: z.ZodArray<z.ZodObject<{
            name: z.ZodString;
            terminal: z.ZodOptional<z.ZodBoolean>;
            dwellSeconds: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        transitions: z.ZodArray<z.ZodObject<{
            from: z.ZodNullable<z.ZodString>;
            to: z.ZodNullable<z.ZodString>;
            action: z.ZodOptional<z.ZodString>;
            execution: z.ZodOptional<z.ZodObject<{
                subject: z.ZodString;
                parameters: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
                requires: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    process: z.ZodString;
                    link: z.ZodOptional<z.ZodString>;
                    states: z.ZodArray<z.ZodString>;
                    match: z.ZodDefault<z.ZodEnum<{
                        all: "all";
                        any: "any";
                    }>>;
                }, z.core.$strict>>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        subprocesses: z.ZodOptional<z.ZodArray<z.ZodObject<{
            link: z.ZodString;
            process: z.ZodString;
        }, z.core.$strict>>>;
        parallel: z.ZodOptional<z.ZodArray<z.ZodString>>;
        metrics: z.ZodOptional<z.ZodObject<{
            node: z.ZodOptional<z.ZodObject<{
                label: z.ZodString;
                aggregation: z.ZodDiscriminatedUnion<[z.ZodObject<{
                    op: z.ZodLiteral<"count">;
                }, z.core.$strict>, z.ZodObject<{
                    op: z.ZodEnum<{
                        avg: "avg";
                        max: "max";
                        min: "min";
                        sum: "sum";
                    }>;
                    property: z.ZodString;
                }, z.core.$strict>], "op">;
                decimals: z.ZodOptional<z.ZodNumber>;
                unit: z.ZodOptional<z.ZodString>;
                colors: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    min: z.ZodNumber;
                    color: z.ZodEnum<{
                        amber: "amber";
                        green: "green";
                        red: "red";
                    }>;
                }, z.core.$strict>>>;
            }, z.core.$strict>>;
            edge: z.ZodOptional<z.ZodObject<{
                label: z.ZodString;
                aggregation: z.ZodDiscriminatedUnion<[z.ZodObject<{
                    op: z.ZodLiteral<"count">;
                }, z.core.$strict>, z.ZodObject<{
                    op: z.ZodEnum<{
                        avg: "avg";
                        max: "max";
                        min: "min";
                        sum: "sum";
                    }>;
                    property: z.ZodString;
                }, z.core.$strict>], "op">;
                decimals: z.ZodOptional<z.ZodNumber>;
                unit: z.ZodOptional<z.ZodString>;
                colors: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    min: z.ZodNumber;
                    color: z.ZodEnum<{
                        amber: "amber";
                        green: "green";
                        red: "red";
                    }>;
                }, z.core.$strict>>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    candidate: z.ZodOptional<z.ZodObject<{
        states: z.ZodArray<z.ZodObject<{
            name: z.ZodString;
            terminal: z.ZodOptional<z.ZodBoolean>;
            dwellSeconds: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        transitions: z.ZodArray<z.ZodObject<{
            from: z.ZodNullable<z.ZodString>;
            to: z.ZodNullable<z.ZodString>;
            action: z.ZodOptional<z.ZodString>;
            execution: z.ZodOptional<z.ZodObject<{
                subject: z.ZodString;
                parameters: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
                requires: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    process: z.ZodString;
                    link: z.ZodOptional<z.ZodString>;
                    states: z.ZodArray<z.ZodString>;
                    match: z.ZodDefault<z.ZodEnum<{
                        all: "all";
                        any: "any";
                    }>>;
                }, z.core.$strict>>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        subprocesses: z.ZodOptional<z.ZodArray<z.ZodObject<{
            link: z.ZodString;
            process: z.ZodString;
        }, z.core.$strict>>>;
        parallel: z.ZodOptional<z.ZodArray<z.ZodString>>;
        metrics: z.ZodOptional<z.ZodObject<{
            node: z.ZodOptional<z.ZodObject<{
                label: z.ZodString;
                aggregation: z.ZodDiscriminatedUnion<[z.ZodObject<{
                    op: z.ZodLiteral<"count">;
                }, z.core.$strict>, z.ZodObject<{
                    op: z.ZodEnum<{
                        avg: "avg";
                        max: "max";
                        min: "min";
                        sum: "sum";
                    }>;
                    property: z.ZodString;
                }, z.core.$strict>], "op">;
                decimals: z.ZodOptional<z.ZodNumber>;
                unit: z.ZodOptional<z.ZodString>;
                colors: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    min: z.ZodNumber;
                    color: z.ZodEnum<{
                        amber: "amber";
                        green: "green";
                        red: "red";
                    }>;
                }, z.core.$strict>>>;
            }, z.core.$strict>>;
            edge: z.ZodOptional<z.ZodObject<{
                label: z.ZodString;
                aggregation: z.ZodDiscriminatedUnion<[z.ZodObject<{
                    op: z.ZodLiteral<"count">;
                }, z.core.$strict>, z.ZodObject<{
                    op: z.ZodEnum<{
                        avg: "avg";
                        max: "max";
                        min: "min";
                        sum: "sum";
                    }>;
                    property: z.ZodString;
                }, z.core.$strict>], "op">;
                decimals: z.ZodOptional<z.ZodNumber>;
                unit: z.ZodOptional<z.ZodString>;
                colors: z.ZodOptional<z.ZodArray<z.ZodObject<{
                    min: z.ZodNumber;
                    color: z.ZodEnum<{
                        amber: "amber";
                        green: "green";
                        red: "red";
                    }>;
                }, z.core.$strict>>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    includeIdle: z.ZodDefault<z.ZodBoolean>;
    durationClock: z.ZodDefault<z.ZodEnum<{
        observedAt: "observedAt";
        recordedAt: "recordedAt";
    }>>;
    mining: z.ZodOptional<z.ZodObject<{
        minCases: z.ZodDefault<z.ZodNumber>;
        coveragePercent: z.ZodDefault<z.ZodNumber>;
        exclude: z.ZodDefault<z.ZodArray<z.ZodObject<{
            from: z.ZodNullable<z.ZodString>;
            to: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>>>;
    }, z.core.$strict>>;
    view: z.ZodOptional<z.ZodObject<{
        kind: z.ZodEnum<{
            count: "count";
            duration: "duration";
        }>;
        scope: z.ZodEnum<{
            current: "current";
            historical: "historical";
        }>;
    }, z.core.$strict>>;
    filter: z.ZodOptional<z.ZodObject<{
        state: z.ZodOptional<z.ZodString>;
        current: z.ZodDefault<z.ZodBoolean>;
        edge: z.ZodOptional<z.ZodObject<{
            from: z.ZodNullable<z.ZodString>;
            to: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>>;
        states: z.ZodOptional<z.ZodArray<z.ZodString>>;
        edges: z.ZodOptional<z.ZodArray<z.ZodObject<{
            from: z.ZodNullable<z.ZodString>;
            to: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>>>;
        edgeMode: z.ZodDefault<z.ZodEnum<{
            last: "last";
            through: "through";
        }>>;
        path: z.ZodOptional<z.ZodString>;
        conformance: z.ZodOptional<z.ZodEnum<{
            conforming: "conforming";
            deviation: "deviation";
            unknown: "unknown";
        }>>;
        duration: z.ZodOptional<z.ZodObject<{
            state: z.ZodString;
            minMs: z.ZodDefault<z.ZodNumber>;
            maxExclusiveMs: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    offset: z.ZodDefault<z.ZodNumber>;
    limit: z.ZodDefault<z.ZodNumber>;
}, z.core.$strict>;
type Input = z.output<typeof machineryAnalysisSchema>;
type Event = {
    caseId: string;
    id: string;
    from: string | null;
    to: string | null;
    recordedAt: string;
    timestamp: string | null;
    action: string | null;
    source: string | null;
    taskId: string | null;
    requestId: string | null;
    prior: boolean;
};
type Episode = {
    state: string;
    durationMs: number | null;
    open: boolean;
    clipped: boolean;
};
type Conformance = 'deviation' | 'conforming' | 'unknown';
export declare function listMachineryProcesses(access: Access, model: PublishedOntology): {
    release: string;
    items: {
        type: string;
        objectType: string;
        property: string;
        name: string;
        states: unknown;
        reference: {
            states: {
                name: string;
                terminal?: boolean | undefined;
                dwellSeconds?: number | undefined;
            }[];
            transitions: {
                from: string | null;
                to: string | null;
                execution?: {
                    subject: string;
                    parameters?: Record<string, string> | undefined;
                    requires?: {
                        process: string;
                        link?: string | undefined;
                        states: string[];
                        match: "all" | "any";
                    }[] | undefined;
                } | undefined;
                action?: string | undefined;
            }[];
            subprocesses: {
                link: string;
                process: string;
            }[];
        } | null;
    }[];
};
type Metric = NonNullable<NonNullable<MachineryModel['metrics']>['node']>;
type Crosstab = {
    state: string;
    with: {
        state: string | null;
        count: number;
    }[];
}[];
export declare function analyzeMachinery(db: Database, access: Access, model: PublishedOntology, input: Input, collectMembers?: boolean): Promise<{
    states: {
        name: string;
        ever: number;
        current: number;
        historical: {
            count: number;
            totalMs: number;
            p50Ms: number | null;
            p95Ms: number | null;
            maxMs: number | null;
            distribution: {
                fromMs: number;
                toMs: number | null;
                count: number;
            }[];
        };
        currentDuration: {
            count: number;
            totalMs: number;
            p50Ms: number | null;
            p95Ms: number | null;
            maxMs: number | null;
            distribution: {
                fromMs: number;
                toMs: number | null;
                count: number;
            }[];
        };
        unknownDuration: number;
        priorToWindow: number;
        dwellSeconds: number | null;
        breaches: number;
        terminal: boolean;
    }[];
    transitions: {
        from: string | null;
        to: string | null;
        count: number;
        cases: number;
        last: number;
        expected: boolean | null;
        action?: string;
        observedActions: Record<string, number>;
        observedSources: Record<string, number>;
    }[];
    paths: {
        id: string;
        states: string[];
        partial: boolean;
        count: number;
    }[];
    pathsTotal: number;
    conformance: {
        conforming: number;
        deviation: number;
        unknown: number;
    };
    findings: {
        bottlenecks: {
            state: string;
            totalMs: number;
            completedP95Ms: number | null;
            currentMaxMs: number | null;
            breaches: number;
        }[];
        observedOnly: {
            from: string | null;
            to: string | null;
            count: number;
            cases: number;
            last: number;
            expected: boolean | null;
            action?: string;
            observedActions: Record<string, number>;
            observedSources: Record<string, number>;
        }[];
        expectedOnly: {
            from: string | null;
            to: string | null;
            count: number;
            cases: number;
            last: number;
            expected: boolean | null;
            action?: string;
            observedActions: Record<string, number>;
            observedSources: Record<string, number>;
        }[];
    };
    release: string;
    type: string;
    objectType: string;
    from: string;
    to: string;
    windowClock: string;
    durationClock: "observedAt" | "recordedAt";
    members?: {
        type: string;
        id: string;
    }[] | undefined;
    reference: {
        states: {
            name: string;
            terminal?: boolean | undefined;
            dwellSeconds?: number | undefined;
        }[];
        transitions: {
            from: string | null;
            to: string | null;
            execution?: {
                subject: string;
                parameters?: Record<string, string> | undefined;
                requires?: {
                    process: string;
                    link?: string | undefined;
                    states: string[];
                    match: "all" | "any";
                }[] | undefined;
            } | undefined;
            action?: string | undefined;
        }[];
        subprocesses: {
            link: string;
            process: string;
        }[];
    } | null;
    mined: {
        states: {
            name: string;
            cases: number;
        }[];
        transitions: {
            from: string | null;
            to: string | null;
            count: number;
            cases: number;
            last: number;
            expected: boolean | null;
            action?: string;
            observedActions: Record<string, number>;
            observedSources: Record<string, number>;
        }[];
    };
    comparison: {
        baseline: {
            conforming: number;
            deviation: number;
            unknown: number;
        };
        candidate: {
            conforming: number;
            deviation: number;
            unknown: number;
        };
        evidence: string;
    } | undefined;
    parallel?: {
        process: string;
        property: string;
        states: Crosstab;
    }[] | undefined;
    alignment?: {
        link: string;
        process: string;
        property: string;
        states: Crosstab;
    }[] | undefined;
    casesTotal: number;
    nextOffset: number | null;
    cases: {
        object: ObjectRef;
        states: string[];
        path: string;
        partial: boolean;
        current: string | null;
        conformance: Conformance;
        transitions: number;
        timeline?: Event[] | undefined;
        episodes?: Episode[] | undefined;
    }[];
    view?: {
        kind: "count" | "duration";
        scope: "current" | "historical";
        nodes: ({
            state: string;
            value: number;
        } | {
            state: string;
            value: number | null;
            p95Ms: number | null;
            maxMs: number | null;
            cases: number;
            color?: string | undefined;
        })[];
        edges: {
            from: string | null;
            to: string | null;
            value: number;
        }[];
    } | undefined;
    metrics?: {
        node?: ReturnType<({ colors: _colors, ...metric }: Metric) => {
            label: string;
            aggregation: {
                op: "count";
            } | {
                op: "avg" | "max" | "min" | "sum";
                property: string;
            };
            decimals?: number | undefined;
            unit?: string | undefined;
        }> & {
            values: unknown[];
        };
        edge?: ReturnType<({ colors: _colors, ...metric }: Metric) => {
            label: string;
            aggregation: {
                op: "count";
            } | {
                op: "avg" | "max" | "min" | "sum";
                property: string;
            };
            decimals?: number | undefined;
            unit?: string | undefined;
        }> & {
            values: unknown[];
        };
    } | undefined;
}>;
export {};
