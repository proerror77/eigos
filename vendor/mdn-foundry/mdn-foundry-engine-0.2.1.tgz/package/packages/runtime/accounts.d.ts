import { type Principal } from '../core/identity.js';
import type { Database, Sql } from './database.js';
export declare const accountGroup = "eigos-accounts";
export declare const accountActionsGroup = "eigos-account-actions";
export declare const accountTaskScopes: readonly ['tasks:read', 'tasks:write'];
export declare const agentTokenPattern: RegExp;
export type SignupMode = 'open' | 'invite' | 'closed';
export interface Account {
    owner: string;
    status: 'active' | 'suspended';
    activated_at: Date;
    approved_at: Date | null;
    revoked_at: Date | null;
    suspended_at: Date | null;
    suspended_reason: string | null;
    email_hash: string | null;
    has_agent_token: boolean;
}
type VerifiedSession = {
    owner: string;
    email_hash: string;
};
export interface AccountApplication {
    owner: string;
    email: string;
    purpose: string;
    applied_at: Date;
    invited_until: Date | null;
}
export type ProvisionRefusal = 'signup_closed' | 'invite_required' | 'operator_account';
export type Denial = ProvisionRefusal | 'account_suspended' | 'client_not_allowed' | 'client_not_authorized' | 'insufficient_scope';
export type Authorization = {
    kind: 'account';
} | {
    kind: 'existing';
} | {
    kind: 'denied';
    reason: Denial;
};
export declare const newAccountSecret: () => string;
export declare const emailDigest: (email: string) => string;
export declare function initializeAccounts(db: Database): Promise<void>;
/** Default supplier reads are available to verified, currently authorized invite recipients. */
export declare function hasBetaReadAccess(db: Database, owner: string): Promise<boolean>;
export declare class Accounts {
    private readonly db;
    private readonly signup;
    constructor(db: Database, signup: SignupMode);
    apply(session: VerifiedSession, email: string, purpose: string): Promise<boolean>;
    applicationStatus(session: VerifiedSession): Promise<'pending' | 'invited' | undefined>;
    applications(offset?: number): Promise<AccountApplication[]>;
    private invitationOwner;
    invite(target: string, hours: number): Promise<string>;
    /** Open the exact verified account an operator reviewed. The receipt enables the existing Beta grants. */
    approveApplication(owner: string, email: string): Promise<boolean>;
    private lockApplication;
    startSession(owner: string, email: string, previousToken: string): Promise<string>;
    session(token: string): Promise<VerifiedSession | undefined>;
    endSession(token: string): Promise<void>;
    account(owner: string, client?: Sql): Promise<Account | undefined>;
    /** Looks an account up by owner digest, or by e-mail address (newest account first when several share it). */
    find(ownerOrEmail: string): Promise<Account | undefined>;
    /** Subjects with Eigos definition grants are operators. They keep their own grants and never become accounts. */
    isOperator(owner: string, client?: Sql): Promise<boolean>;
    /** Returns the existing account in any status, or opens one when the sign-up mode allows it. */
    provision(owner: string, emailHash?: string, client?: Sql): Promise<Account | ProvisionRefusal>;
    activate(session: VerifiedSession, code: string): Promise<'activated' | 'invalid' | 'operator_account'>;
    /** Grants agent access. Approving again after a revocation starts a new grant, and `authorize` only accepts tokens issued in or after the second it started. */
    approve(owner: string): Promise<boolean>;
    /** Creates or replaces the private Agent credential after the account holder consents in the portal. */
    issueAgentToken(owner: string): Promise<string | undefined>;
    agentTokenOwner(tokenHash: string): Promise<string | undefined>;
    active(owner: string, client: Sql, tokenHash?: string): Promise<boolean>;
    revoke(owner: string): Promise<void>;
    suspend(owner: string, reason: string): Promise<boolean>;
    restore(owner: string): Promise<boolean>;
    authorize(principal: Principal, clientId: string, legacyClientIds: readonly string[]): Promise<Authorization>;
}
export {};
