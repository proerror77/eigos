import type { Database } from './database.js';
import type { ComponentImplementation } from './component-functions.js';
import type { FunctionContext } from './functions.js';
import type { FunctionInvocationMetrics } from './function-invocations.js';
import { ComponentSourceSecrets } from './component-source-secrets.js';
export declare class ComponentModels {
    private readonly db;
    private readonly secrets;
    private readonly transport;
    private readonly entries;
    constructor(db: Database, raw: unknown, secrets: Pick<ComponentSourceSecrets, 'get'>, transport?: typeof fetch);
    binding(aliases: readonly string[]): string;
    private destination;
    generate(alias: string, input: unknown, context: FunctionContext, signal: AbortSignal, metrics?: FunctionInvocationMetrics): AsyncGenerator<string, void, unknown>;
}
export declare class ComponentModelSession {
    private readonly implementation;
    private readonly context;
    private readonly models;
    private readonly metrics?;
    private readonly controller;
    private readonly signal;
    private generation?;
    private calls;
    private emittedBytes;
    constructor(implementation: ComponentImplementation, context: FunctionContext, models: ComponentModels | undefined, outer: AbortSignal, metrics?: FunctionInvocationMetrics | undefined);
    generate(alias: string, messages: unknown): void;
    next(): Promise<string | null>;
    emit(text: string): Promise<void>;
    close(): Promise<void>;
}
export declare function configuredComponentModels(db: Database, env?: NodeJS.ProcessEnv): ComponentModels | undefined;
