import { z } from 'zod';
import { type ActionContinuation } from './clarification.js';
import type { Task } from './tasks.js';
export declare function legacyActionInput(wait: ActionContinuation): {
    capability: string;
    purpose: "input" | "observation";
    responseSchema: z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
        kind: z.ZodLiteral<"city">;
        city: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        kind: z.ZodLiteral<"origin">;
        place: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        kind: z.ZodLiteral<"destination">;
        place: z.ZodString;
    }, z.core.$strict> | z.ZodObject<{
        kind: z.ZodLiteral<"retry-source">;
    }, z.core.$strict> | z.ZodUnion<readonly [z.ZodObject<{
        kind: z.ZodLiteral<"select">;
        places: z.ZodObject<{
            origin: z.ZodObject<{
                type: z.ZodString;
                id: z.ZodString;
            }, z.core.$strict>;
            destination: z.ZodObject<{
                type: z.ZodString;
                id: z.ZodString;
            }, z.core.$strict>;
        }, z.core.$strict>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"amend">;
        amendment: z.ZodObject<{
            address: z.ZodOptional<z.ZodString>;
            landmark: z.ZodOptional<z.ZodString>;
            name: z.ZodOptional<z.ZodString>;
            side: z.ZodEnum<{
                destination: "destination";
                origin: "origin";
            }>;
            keep: z.ZodOptional<z.ZodObject<{
                type: z.ZodString;
                id: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
    }, z.core.$strict>]>>;
} | undefined;
export declare function applyLegacyActionInput(task: Task, input: unknown): Task['input'];
