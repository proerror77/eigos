import { z } from 'zod';
import { Access } from './access.js';
import type { Database } from './database.js';
import { Metadata } from './metadata.js';
export declare const migrateOntologyDataSchema: z.ZodObject<{
    sourceOntology: z.ZodString;
    targetOntology: z.ZodString;
    requestId: z.ZodString;
    types: z.ZodRecord<z.ZodString, z.ZodString>;
    links: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodString>>;
    objects: z.ZodOptional<z.ZodArray<z.ZodObject<{
        type: z.ZodString;
        id: z.ZodString;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export declare const readDataMigrationSchema: z.ZodObject<{
    id: z.ZodUUID;
    kind: z.ZodDefault<z.ZodEnum<{
        links: "links";
        objects: "objects";
    }>>;
    after: z.ZodDefault<z.ZodNumber>;
    limit: z.ZodDefault<z.ZodNumber>;
}, z.core.$strict>;
export declare function initializeOntologyDataMigrations(db: Database): Promise<void>;
export declare class OntologyDataMigrations {
    private readonly db;
    private readonly metadata;
    constructor(db: Database, metadata: Metadata);
    private copyGeometry;
    copy(access: Access, raw: unknown): Promise<{
        id: string;
        requestId: string;
        sourceOntology: string;
        targetOntology: string;
        sourceRelease: string;
        targetRelease: string;
        objects: number;
        links: number;
        createdAt: any;
        provenance: 'copied_ontology_objects';
    }>;
    private authorizeReceipt;
    read(access: Access, raw: unknown): Promise<{
        id: string;
        requestId: string;
        sourceOntology: string;
        targetOntology: string;
        sourceRelease: string;
        targetRelease: string;
        objects: number;
        links: number;
        createdAt: any;
        provenance: 'copied_ontology_objects';
        items: import("pg").QueryResultRow[];
        cursor: number | undefined;
    }>;
}
