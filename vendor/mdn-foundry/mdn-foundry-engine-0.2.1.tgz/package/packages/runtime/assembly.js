import { Actions } from './actions.js';
import { ComponentFunctions } from './component-functions.js';
import { ActionSourceWebhooks, effectHandlerName } from './action-webhooks.js';
import { configuredComponentSources } from './component-source-egress.js';
import { Effects } from './effects.js';
import { FunctionInvocations } from './function-invocations.js';
import { Functions } from './functions.js';
import { ProviderBudgets } from './provider-budgets.js';
import { Sources } from './sources.js';
export function assembleRuntime(db, definitions, handlers, projections = new Map(), extensions = {}, committedEffects) {
    const registered = new Map(projections);
    for (const [name, projection] of extensions.sources ?? []) {
        if (registered.has(name))
            throw new Error('Source projection is already registered: ' + name);
        registered.set(name, projection);
    }
    const componentSources = extensions.componentSources ?? configuredComponentSources(db);
    const components = new ComponentFunctions(db, undefined, componentSources, extensions.componentModels?.(db));
    const functions = new Functions(handlers, definitions, extensions.functions, components, new ProviderBudgets(db), new FunctionInvocations(db));
    const sources = new Sources(db, functions, registered);
    const webhooks = componentSources && new ActionSourceWebhooks(componentSources, functions);
    const effects = new Effects(db, extensions.effects ?? new Map(), webhooks);
    const actions = new Actions(db, functions, effects, committedEffects, extensions.scenarioDecisions);
    return {
        functions, sources, effects, actions, scenarioDecisions: extensions.scenarioDecisions,
        describe(model) {
            effects.check(model.resolvedDocument.actionTypes.flatMap(action => action.effects?.map(effectHandlerName) ?? []));
            const publishedWebhooks = webhooks?.bindings(model);
            return { functions: functions.bindings(model), sources: sources.bindings(model),
                ...(publishedWebhooks && Object.keys(publishedWebhooks).length ? { webhooks: publishedWebhooks } : {}) };
        },
        checkRelease: (model) => functions.checkRelease(model),
    };
}
