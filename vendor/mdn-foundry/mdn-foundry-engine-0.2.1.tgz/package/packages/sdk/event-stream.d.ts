/** Read SSE data events across arbitrary UTF-8 byte, CR/LF and network chunk boundaries. */
export declare function sseData(response: Response, maxBytes: number): AsyncGenerator<string, void, unknown>;
