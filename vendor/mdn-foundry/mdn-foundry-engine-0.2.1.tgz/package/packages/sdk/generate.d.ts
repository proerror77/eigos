import type { OntologyDocument } from '../ontology/schema.js';
/** Emit TypeScript from describe()'s permission-filtered published definition. */
export interface SDKSelection {
    objects: readonly string[];
    actions: readonly string[];
    functions: readonly string[];
}
/** Select resources from an already authorized definition. Keep the server's access check on every call. */
export declare function generateOntologyTypes(document: OntologyDocument, selection?: SDKSelection): string;
