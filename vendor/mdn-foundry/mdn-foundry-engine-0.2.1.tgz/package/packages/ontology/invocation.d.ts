import { z } from 'zod';
/** A capability constraint resolves to a concrete published Action. */
export declare const interfaceActionTargetSchema: z.ZodObject<{
    object: z.ZodOptional<z.ZodObject<{
        type: z.ZodString;
        id: z.ZodString;
    }, z.core.$strict>>;
    implementation: z.ZodOptional<z.ZodString>;
    type: z.ZodString;
    action: z.ZodString;
}, z.core.$strict>;
export declare const interfaceActionCallSchema: z.ZodObject<{
    scenarioId: z.ZodOptional<z.ZodUUID>;
    input: z.ZodRecord<z.ZodString, z.ZodUnknown>;
    interface: z.ZodObject<{
        object: z.ZodOptional<z.ZodObject<{
            type: z.ZodString;
            id: z.ZodString;
        }, z.core.$strict>>;
        implementation: z.ZodOptional<z.ZodString>;
        type: z.ZodString;
        action: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const actionCallSchema: z.ZodObject<{
    scenarioId: z.ZodOptional<z.ZodUUID>;
    input: z.ZodRecord<z.ZodString, z.ZodUnknown>;
    action: z.ZodOptional<z.ZodString>;
    interface: z.ZodOptional<z.ZodObject<{
        object: z.ZodOptional<z.ZodObject<{
            type: z.ZodString;
            id: z.ZodString;
        }, z.core.$strict>>;
        implementation: z.ZodOptional<z.ZodString>;
        type: z.ZodString;
        action: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const actionResultReadSchema: z.ZodObject<{
    function: z.ZodString;
    resultParameter: z.ZodString;
    input: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
}, z.core.$strict>;
export declare const completeWithActionSchema: z.ZodObject<{
    action: z.ZodObject<{
        scenarioId: z.ZodOptional<z.ZodUUID>;
        input: z.ZodRecord<z.ZodString, z.ZodUnknown>;
        interface: z.ZodObject<{
            object: z.ZodOptional<z.ZodObject<{
                type: z.ZodString;
                id: z.ZodString;
            }, z.core.$strict>>;
            implementation: z.ZodOptional<z.ZodString>;
            type: z.ZodString;
            action: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>;
    read: z.ZodObject<{
        function: z.ZodString;
        resultParameter: z.ZodString;
        input: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    }, z.core.$strict>;
}, z.core.$strict>;
export type ActionResultRead = z.infer<typeof actionResultReadSchema>;
export declare const completeWithActionRequestSchema: z.ZodObject<{
    action: z.ZodObject<{
        scenarioId: z.ZodOptional<z.ZodUUID>;
        input: z.ZodRecord<z.ZodString, z.ZodUnknown>;
        interface: z.ZodObject<{
            object: z.ZodOptional<z.ZodObject<{
                type: z.ZodString;
                id: z.ZodString;
            }, z.core.$strict>>;
            implementation: z.ZodOptional<z.ZodString>;
            type: z.ZodString;
            action: z.ZodString;
        }, z.core.$strict>;
    }, z.core.$strict>;
    read: z.ZodObject<{
        function: z.ZodString;
        resultParameter: z.ZodString;
        input: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    }, z.core.$strict>;
    ontology: z.ZodOptional<z.ZodString>;
    requestId: z.ZodString;
}, z.core.$strict>;
export declare const functionCallSchema: z.ZodObject<{
    scenarioId: z.ZodOptional<z.ZodUUID>;
    input: z.ZodRecord<z.ZodString, z.ZodUnknown>;
    function: z.ZodString;
}, z.core.$strict>;
/** Protocol metadata does not change the operation or its Scenario view. */
export declare const actionRequestSchema: z.ZodObject<{
    scenarioId: z.ZodOptional<z.ZodUUID>;
    input: z.ZodRecord<z.ZodString, z.ZodUnknown>;
    action: z.ZodOptional<z.ZodString>;
    interface: z.ZodOptional<z.ZodObject<{
        object: z.ZodOptional<z.ZodObject<{
            type: z.ZodString;
            id: z.ZodString;
        }, z.core.$strict>>;
        implementation: z.ZodOptional<z.ZodString>;
        type: z.ZodString;
        action: z.ZodString;
    }, z.core.$strict>>;
    ontology: z.ZodOptional<z.ZodString>;
    requestId: z.ZodString;
}, z.core.$strict>;
export declare const actionBatchSchema: z.ZodObject<{
    actions: z.ZodArray<z.ZodObject<{
        input: z.ZodRecord<z.ZodString, z.ZodUnknown>;
        action: z.ZodOptional<z.ZodString>;
        interface: z.ZodOptional<z.ZodObject<{
            object: z.ZodOptional<z.ZodObject<{
                type: z.ZodString;
                id: z.ZodString;
            }, z.core.$strict>>;
            implementation: z.ZodOptional<z.ZodString>;
            type: z.ZodString;
            action: z.ZodString;
        }, z.core.$strict>>;
        requestId: z.ZodString;
        scenarioId: z.ZodOptional<z.ZodNever>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const functionRequestSchema: z.ZodObject<{
    scenarioId: z.ZodOptional<z.ZodUUID>;
    input: z.ZodRecord<z.ZodString, z.ZodUnknown>;
    function: z.ZodString;
    ontology: z.ZodOptional<z.ZodString>;
    taskId: z.ZodOptional<z.ZodUUID>;
}, z.core.$strict>;
export type ActionCall = z.infer<typeof actionCallSchema>;
export type ActionInput = Omit<z.infer<typeof actionRequestSchema>, 'ontology' | 'scenarioId'>;
export type ActionBatchInput = z.input<typeof actionBatchSchema>;
