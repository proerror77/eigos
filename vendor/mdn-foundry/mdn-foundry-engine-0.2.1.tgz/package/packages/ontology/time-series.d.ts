import { z } from 'zod';
export declare const timeSeriesFormat = "eigos-timeseries";
export declare const maxTimeSeriesPoints = 10000;
export declare const timeSeriesJsonSchema: {
    type: string;
    format: string;
    maxItems: number;
    items: {
        type: string;
        properties: {
            t: {
                type: string;
                format: string;
            };
            v: {
                type: string;
            };
        };
        required: string[];
        additionalProperties: boolean;
    };
};
export declare const timeSeriesSchema: z.ZodArray<z.ZodObject<{
    t: z.ZodISODateTime;
    v: z.ZodNumber;
}, z.core.$strict>>;
export type TimeSeries = z.infer<typeof timeSeriesSchema>;
export type TimeSeriesAggregate = 'sum' | 'avg' | 'min' | 'max';
type Field = {
    path: (string | '*')[];
};
/** Resolve the time series markers used for stored properties and structured model arguments or results. */
export declare function timeSeriesFields(schema: unknown, path?: Field['path']): Field[];
export declare function validateTimeSeriesFields(fields: Field[], data: unknown, context: z.RefinementCtx): void;
/** Compute successive windows in a linear scan. Each output is timestamped at the last point of the window. */
export declare function timeSeriesWindows(points: TimeSeries, options: {
    size: number;
    step: number;
}, aggregate: TimeSeriesAggregate): TimeSeries;
export {};
