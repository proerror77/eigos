export declare const betaQueries: {
    readonly sources: readonly ['Amap', 'Fliggy'];
    readonly objects: readonly ['FliggyFlightOffer', 'FliggyFlightSearch', 'FliggyHotelOffer', 'FliggyHotelSearch', 'RestaurantSearchResult', 'RestaurantSourceVenue'];
    readonly functions: readonly ['readFliggyFlights', 'readFliggyHotels', 'readServiceSearch', 'readServiceSearchPages', 'readWeather', 'searchMapPlaces', 'readMapPlace', 'readRestaurantSearch'];
    readonly actions: readonly [readonly ['SearchFliggyFlights', 'searchFliggyFlights'], readonly ['SearchFliggyHotels', 'searchFliggyHotels'], readonly ['FindRestaurants', 'findRestaurants']];
};
