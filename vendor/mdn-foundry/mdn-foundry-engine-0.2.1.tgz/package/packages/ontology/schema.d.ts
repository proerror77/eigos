import { z } from 'zod';
export declare const ontologyName: z.ZodString;
export declare const objectRefSchema: z.ZodObject<{
    type: z.ZodString;
    id: z.ZodString;
}, z.core.$strict>;
export type ObjectRef = z.infer<typeof objectRefSchema>;
export type DerivedExpression = {
    op: 'linked';
    path: {
        link: string;
        as?: string;
    }[];
    aggregate: 'count' | 'sum' | 'min' | 'max' | 'avg' | 'select';
    property?: string;
} | {
    op: 'property';
    property: string;
} | {
    op: 'literal';
    value: number;
} | {
    op: 'timeseries';
    property: string;
    aggregate: 'sum' | 'avg' | 'min' | 'max';
    window: {
        size: number;
        step: number;
    };
} | {
    op: 'add' | 'subtract' | 'multiply' | 'divide';
    left: DerivedExpression;
    right: DerivedExpression;
};
export declare const derivedExpressionSchema: z.ZodType<DerivedExpression>;
export declare const valueTypeRefSchema: z.ZodObject<{
    name: z.ZodString;
    version: z.ZodString;
}, z.core.$strict>;
export declare const propertySchema: z.ZodObject<{
    typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
        kind: z.ZodString;
        name: z.ZodString;
    }, z.core.$strict>>>;
    renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
    status: z.ZodOptional<z.ZodEnum<{
        active: "active";
        deprecated: "deprecated";
        experimental: "experimental";
    }>>;
    classification: z.ZodOptional<z.ZodObject<{
        sensitivity: z.ZodEnum<{
            CONFIDENTIAL: "CONFIDENTIAL";
            INTERNAL: "INTERNAL";
            PUBLIC: "PUBLIC";
            RESTRICTED: "RESTRICTED";
        }>;
        compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>>;
    description: z.ZodDefault<z.ZodString>;
    schema: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    required: z.ZodDefault<z.ZodBoolean>;
    sharedProperty: z.ZodOptional<z.ZodString>;
    valueType: z.ZodOptional<z.ZodObject<{
        name: z.ZodString;
        version: z.ZodString;
    }, z.core.$strict>>;
    struct: z.ZodOptional<z.ZodObject<{
        type: z.ZodString;
        mainField: z.ZodOptional<z.ZodString>;
        reducer: z.ZodOptional<z.ZodObject<{
            op: z.ZodEnum<{
                first: "first";
                last: "last";
                max: "max";
                min: "min";
            }>;
            field: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        array: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>>;
    format: z.ZodOptional<z.ZodObject<{
        kind: z.ZodEnum<{
            currency: "currency";
            date: "date";
            number: "number";
            percent: "percent";
            text: "text";
        }>;
        locale: z.ZodOptional<z.ZodString>;
        currency: z.ZodOptional<z.ZodString>;
        minimumFractionDigits: z.ZodOptional<z.ZodNumber>;
        maximumFractionDigits: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
    derived: z.ZodOptional<z.ZodType<DerivedExpression, unknown, z.core.$ZodTypeInternals<DerivedExpression, unknown>>>;
}, z.core.$strict>;
declare const value: z.ZodUnion<readonly [z.ZodObject<{
    parameter: z.ZodString;
    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strict>, z.ZodObject<{
    literal: z.ZodUnknown;
}, z.core.$strict>]>;
export declare const functionDependenciesSchema: z.ZodObject<{
    objectTypes: z.ZodOptional<z.ZodArray<z.ZodString>>;
    interfaceTypes: z.ZodOptional<z.ZodArray<z.ZodString>>;
    linkTypes: z.ZodOptional<z.ZodArray<z.ZodString>>;
    functions: z.ZodOptional<z.ZodArray<z.ZodString>>;
    dataSources: z.ZodOptional<z.ZodArray<z.ZodString>>;
    actions: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strict>;
export type FunctionDependencies = z.infer<typeof functionDependenciesSchema>;
/**
 * A Function implemented by a WebAssembly component of the world `eigos:function/handler@0.1.0`, which the function host
 * runs within these limits. The maxima are the host's (`function-host/`).
 */
export declare const componentImplementationSchema: z.ZodObject<{
    kind: z.ZodLiteral<"component">;
    models: z.ZodOptional<z.ZodArray<z.ZodString>>;
    stream: z.ZodOptional<z.ZodLiteral<"text">>;
    sha256: z.ZodString;
    limits: z.ZodObject<{
        fuel: z.ZodNumber;
        memoryMb: z.ZodNumber;
        deadlineMs: z.ZodNumber;
        inputBytes: z.ZodOptional<z.ZodNumber>;
        outputBytes: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>;
}, z.core.$strict>;
export declare const semanticVersion: RegExp;
/** A version range a consumer accepts: `1.2.3` exactly, `~1.2.3` its later patches, `^1.2.3` later versions until the next major. */
export declare const versionRange: RegExp;
export declare const machineryEdgeSchema: z.ZodObject<{
    from: z.ZodNullable<z.ZodString>;
    to: z.ZodNullable<z.ZodString>;
}, z.core.$strict>;
/**
 * A number Machinery shows on each node or edge, after Palantir's node and edge metrics: an aggregation over the tracked
 * objects of conforming processes, with optional formatting and conditional colors (the highest `min` reached wins).
 */
export declare const machineryMetricSchema: z.ZodObject<{
    label: z.ZodString;
    aggregation: z.ZodDiscriminatedUnion<[z.ZodObject<{
        op: z.ZodLiteral<"count">;
    }, z.core.$strict>, z.ZodObject<{
        op: z.ZodEnum<{
            avg: "avg";
            max: "max";
            min: "min";
            sum: "sum";
        }>;
        property: z.ZodString;
    }, z.core.$strict>], "op">;
    decimals: z.ZodOptional<z.ZodNumber>;
    unit: z.ZodOptional<z.ZodString>;
    colors: z.ZodOptional<z.ZodArray<z.ZodObject<{
        min: z.ZodNumber;
        color: z.ZodEnum<{
            amber: "amber";
            green: "green";
            red: "red";
        }>;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export declare const machineryModelSchema: z.ZodObject<{
    states: z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        terminal: z.ZodOptional<z.ZodBoolean>;
        dwellSeconds: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
    transitions: z.ZodArray<z.ZodObject<{
        from: z.ZodNullable<z.ZodString>;
        to: z.ZodNullable<z.ZodString>;
        action: z.ZodOptional<z.ZodString>;
        execution: z.ZodOptional<z.ZodObject<{
            subject: z.ZodString;
            parameters: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
            requires: z.ZodOptional<z.ZodArray<z.ZodObject<{
                process: z.ZodString;
                link: z.ZodOptional<z.ZodString>;
                states: z.ZodArray<z.ZodString>;
                match: z.ZodDefault<z.ZodEnum<{
                    all: "all";
                    any: "any";
                }>>;
            }, z.core.$strict>>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    subprocesses: z.ZodOptional<z.ZodArray<z.ZodObject<{
        link: z.ZodString;
        process: z.ZodString;
    }, z.core.$strict>>>;
    parallel: z.ZodOptional<z.ZodArray<z.ZodString>>;
    metrics: z.ZodOptional<z.ZodObject<{
        node: z.ZodOptional<z.ZodObject<{
            label: z.ZodString;
            aggregation: z.ZodDiscriminatedUnion<[z.ZodObject<{
                op: z.ZodLiteral<"count">;
            }, z.core.$strict>, z.ZodObject<{
                op: z.ZodEnum<{
                    avg: "avg";
                    max: "max";
                    min: "min";
                    sum: "sum";
                }>;
                property: z.ZodString;
            }, z.core.$strict>], "op">;
            decimals: z.ZodOptional<z.ZodNumber>;
            unit: z.ZodOptional<z.ZodString>;
            colors: z.ZodOptional<z.ZodArray<z.ZodObject<{
                min: z.ZodNumber;
                color: z.ZodEnum<{
                    amber: "amber";
                    green: "green";
                    red: "red";
                }>;
            }, z.core.$strict>>>;
        }, z.core.$strict>>;
        edge: z.ZodOptional<z.ZodObject<{
            label: z.ZodString;
            aggregation: z.ZodDiscriminatedUnion<[z.ZodObject<{
                op: z.ZodLiteral<"count">;
            }, z.core.$strict>, z.ZodObject<{
                op: z.ZodEnum<{
                    avg: "avg";
                    max: "max";
                    min: "min";
                    sum: "sum";
                }>;
                property: z.ZodString;
            }, z.core.$strict>], "op">;
            decimals: z.ZodOptional<z.ZodNumber>;
            unit: z.ZodOptional<z.ZodString>;
            colors: z.ZodOptional<z.ZodArray<z.ZodObject<{
                min: z.ZodNumber;
                color: z.ZodEnum<{
                    amber: "amber";
                    green: "green";
                    red: "red";
                }>;
            }, z.core.$strict>>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const agentProfileSchema: z.ZodObject<{
    apiName: z.ZodString;
    terms: z.ZodArray<z.ZodString>;
    objects: z.ZodOptional<z.ZodArray<z.ZodString>>;
    interfaces: z.ZodOptional<z.ZodArray<z.ZodString>>;
    actions: z.ZodOptional<z.ZodArray<z.ZodString>>;
    functions: z.ZodOptional<z.ZodArray<z.ZodString>>;
    sources: z.ZodOptional<z.ZodArray<z.ZodString>>;
    links: z.ZodOptional<z.ZodArray<z.ZodString>>;
    instructions: z.ZodOptional<z.ZodArray<z.ZodObject<{
        action: z.ZodOptional<z.ZodString>;
        function: z.ZodOptional<z.ZodString>;
        text: z.ZodString;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export declare const scenarioReviewRule: z.ZodObject<{
    op: z.ZodLiteral<"reviewScenario">;
    scenario: z.ZodUnion<readonly [z.ZodObject<{
        parameter: z.ZodString;
        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>, z.ZodObject<{
        literal: z.ZodUnknown;
    }, z.core.$strict>]>;
    expectedRevision: z.ZodUnion<readonly [z.ZodObject<{
        parameter: z.ZodString;
        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>, z.ZodObject<{
        literal: z.ZodUnknown;
    }, z.core.$strict>]>;
    review: z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"submit">;
        reviewers: z.ZodUnion<readonly [z.ZodObject<{
            parameter: z.ZodString;
            path: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>, z.ZodObject<{
            literal: z.ZodUnknown;
        }, z.core.$strict>]>;
        authorizeMerge: z.ZodOptional<z.ZodUnion<readonly [z.ZodObject<{
            parameter: z.ZodString;
            path: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>, z.ZodObject<{
            literal: z.ZodUnknown;
        }, z.core.$strict>]>>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"approve">;
        snapshot: z.ZodUnion<readonly [z.ZodObject<{
            parameter: z.ZodString;
            path: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>, z.ZodObject<{
            literal: z.ZodUnknown;
        }, z.core.$strict>]>;
        decision: z.ZodOptional<z.ZodUnion<readonly [z.ZodObject<{
            parameter: z.ZodString;
            path: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>, z.ZodObject<{
            literal: z.ZodUnknown;
        }, z.core.$strict>]>>;
        applyAuthorizedMerge: z.ZodOptional<z.ZodLiteral<true>>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"reject">;
        snapshot: z.ZodUnion<readonly [z.ZodObject<{
            parameter: z.ZodString;
            path: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>, z.ZodObject<{
            literal: z.ZodUnknown;
        }, z.core.$strict>]>;
    }, z.core.$strict>], "kind">;
}, z.core.$strict>;
export type ScenarioReviewRule = z.infer<typeof scenarioReviewRule>;
export declare const webhookMethod: z.ZodEnum<{
    DELETE: "DELETE";
    PATCH: "PATCH";
    POST: "POST";
    PUT: "PUT";
}>;
export declare const webhookPath: z.ZodString;
export declare const actionWebhookSchema: z.ZodObject<{
    source: z.ZodString;
    method: z.ZodEnum<{
        DELETE: "DELETE";
        PATCH: "PATCH";
        POST: "POST";
        PUT: "PUT";
    }>;
    path: z.ZodString;
    function: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export declare const sourceWebhookEffectHandler = "ComponentSourceWebhook";
export declare const actionEffectSchema: z.ZodUnion<readonly [z.ZodObject<{
    name: z.ZodString;
    handler: z.ZodString;
    payload: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
        parameter: z.ZodString;
        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>, z.ZodObject<{
        literal: z.ZodUnknown;
    }, z.core.$strict>]>>;
}, z.core.$strict>, z.ZodObject<{
    name: z.ZodString;
    webhook: z.ZodObject<{
        source: z.ZodString;
        method: z.ZodEnum<{
            DELETE: "DELETE";
            PATCH: "PATCH";
            POST: "POST";
            PUT: "PUT";
        }>;
        path: z.ZodString;
        function: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    payload: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
        parameter: z.ZodString;
        path: z.ZodOptional<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>, z.ZodObject<{
        literal: z.ZodUnknown;
    }, z.core.$strict>]>>;
}, z.core.$strict>]>;
export type ActionWebhook = z.infer<typeof actionWebhookSchema>;
export type ActionEffectDefinition = z.infer<typeof actionEffectSchema>;
export declare const ontologySchema: z.ZodObject<{
    id: z.ZodString;
    version: z.ZodString;
    classification: z.ZodOptional<z.ZodObject<{
        sensitivity: z.ZodEnum<{
            CONFIDENTIAL: "CONFIDENTIAL";
            INTERNAL: "INTERNAL";
            PUBLIC: "PUBLIC";
            RESTRICTED: "RESTRICTED";
        }>;
        compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
    }, z.core.$strict>>;
    sharedProperties: z.ZodOptional<z.ZodArray<z.ZodObject<{
        typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
            kind: z.ZodString;
            name: z.ZodString;
        }, z.core.$strict>>>;
        renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
        status: z.ZodOptional<z.ZodEnum<{
            active: "active";
            deprecated: "deprecated";
            experimental: "experimental";
        }>>;
        classification: z.ZodOptional<z.ZodObject<{
            sensitivity: z.ZodEnum<{
                CONFIDENTIAL: "CONFIDENTIAL";
                INTERNAL: "INTERNAL";
                PUBLIC: "PUBLIC";
                RESTRICTED: "RESTRICTED";
            }>;
            compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        description: z.ZodDefault<z.ZodString>;
        schema: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
        required: z.ZodDefault<z.ZodBoolean>;
        sharedProperty: z.ZodOptional<z.ZodString>;
        valueType: z.ZodOptional<z.ZodObject<{
            name: z.ZodString;
            version: z.ZodString;
        }, z.core.$strict>>;
        struct: z.ZodOptional<z.ZodObject<{
            type: z.ZodString;
            mainField: z.ZodOptional<z.ZodString>;
            reducer: z.ZodOptional<z.ZodObject<{
                op: z.ZodEnum<{
                    first: "first";
                    last: "last";
                    max: "max";
                    min: "min";
                }>;
                field: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>>;
            array: z.ZodOptional<z.ZodBoolean>;
        }, z.core.$strict>>;
        format: z.ZodOptional<z.ZodObject<{
            kind: z.ZodEnum<{
                currency: "currency";
                date: "date";
                number: "number";
                percent: "percent";
                text: "text";
            }>;
            locale: z.ZodOptional<z.ZodString>;
            currency: z.ZodOptional<z.ZodString>;
            minimumFractionDigits: z.ZodOptional<z.ZodNumber>;
            maximumFractionDigits: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        derived: z.ZodOptional<z.ZodType<DerivedExpression, unknown, z.core.$ZodTypeInternals<DerivedExpression, unknown>>>;
        apiName: z.ZodString;
    }, z.core.$strict>>>;
    valueTypes: z.ZodOptional<z.ZodArray<z.ZodObject<{
        typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
            kind: z.ZodString;
            name: z.ZodString;
        }, z.core.$strict>>>;
        renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
        status: z.ZodOptional<z.ZodEnum<{
            active: "active";
            deprecated: "deprecated";
            experimental: "experimental";
        }>>;
        classification: z.ZodOptional<z.ZodObject<{
            sensitivity: z.ZodEnum<{
                CONFIDENTIAL: "CONFIDENTIAL";
                INTERNAL: "INTERNAL";
                PUBLIC: "PUBLIC";
                RESTRICTED: "RESTRICTED";
            }>;
            compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        apiName: z.ZodString;
        version: z.ZodString;
        description: z.ZodString;
        schema: z.ZodRecord<z.ZodString, z.ZodUnknown>;
    }, z.core.$strict>>>;
    structTypes: z.ZodOptional<z.ZodArray<z.ZodObject<{
        typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
            kind: z.ZodString;
            name: z.ZodString;
        }, z.core.$strict>>>;
        renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
        status: z.ZodOptional<z.ZodEnum<{
            active: "active";
            deprecated: "deprecated";
            experimental: "experimental";
        }>>;
        classification: z.ZodOptional<z.ZodObject<{
            sensitivity: z.ZodEnum<{
                CONFIDENTIAL: "CONFIDENTIAL";
                INTERNAL: "INTERNAL";
                PUBLIC: "PUBLIC";
                RESTRICTED: "RESTRICTED";
            }>;
            compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        apiName: z.ZodString;
        description: z.ZodString;
        fields: z.ZodRecord<z.ZodString, z.ZodRecord<z.ZodString, z.ZodUnknown>>;
        required: z.ZodOptional<z.ZodArray<z.ZodString>>;
        mainField: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>>;
    typeGroups: z.ZodOptional<z.ZodArray<z.ZodObject<{
        apiName: z.ZodString;
        displayName: z.ZodString;
        description: z.ZodString;
        objectTypes: z.ZodArray<z.ZodString>;
    }, z.core.$strict>>>;
    agentProfiles: z.ZodOptional<z.ZodArray<z.ZodObject<{
        apiName: z.ZodString;
        terms: z.ZodArray<z.ZodString>;
        objects: z.ZodOptional<z.ZodArray<z.ZodString>>;
        interfaces: z.ZodOptional<z.ZodArray<z.ZodString>>;
        actions: z.ZodOptional<z.ZodArray<z.ZodString>>;
        functions: z.ZodOptional<z.ZodArray<z.ZodString>>;
        sources: z.ZodOptional<z.ZodArray<z.ZodString>>;
        links: z.ZodOptional<z.ZodArray<z.ZodString>>;
        instructions: z.ZodOptional<z.ZodArray<z.ZodObject<{
            action: z.ZodOptional<z.ZodString>;
            function: z.ZodOptional<z.ZodString>;
            text: z.ZodString;
        }, z.core.$strict>>>;
    }, z.core.$strict>>>;
    imports: z.ZodOptional<z.ZodArray<z.ZodObject<{
        ontology: z.ZodString;
        version: z.ZodString;
        digest: z.ZodString;
        namespace: z.ZodString;
        document: z.ZodUnknown;
    }, z.core.$strict>>>;
    objectTypes: z.ZodArray<z.ZodObject<{
        typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
            kind: z.ZodString;
            name: z.ZodString;
        }, z.core.$strict>>>;
        renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
        status: z.ZodOptional<z.ZodEnum<{
            active: "active";
            deprecated: "deprecated";
            experimental: "experimental";
        }>>;
        classification: z.ZodOptional<z.ZodObject<{
            sensitivity: z.ZodEnum<{
                CONFIDENTIAL: "CONFIDENTIAL";
                INTERNAL: "INTERNAL";
                PUBLIC: "PUBLIC";
                RESTRICTED: "RESTRICTED";
            }>;
            compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        apiName: z.ZodString;
        displayName: z.ZodString;
        description: z.ZodString;
        primaryKey: z.ZodString;
        titleProperty: z.ZodString;
        properties: z.ZodRecord<z.ZodString, z.ZodObject<{
            typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>>;
            renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
            status: z.ZodOptional<z.ZodEnum<{
                active: "active";
                deprecated: "deprecated";
                experimental: "experimental";
            }>>;
            classification: z.ZodOptional<z.ZodObject<{
                sensitivity: z.ZodEnum<{
                    CONFIDENTIAL: "CONFIDENTIAL";
                    INTERNAL: "INTERNAL";
                    PUBLIC: "PUBLIC";
                    RESTRICTED: "RESTRICTED";
                }>;
                compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            description: z.ZodDefault<z.ZodString>;
            schema: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
            required: z.ZodDefault<z.ZodBoolean>;
            sharedProperty: z.ZodOptional<z.ZodString>;
            valueType: z.ZodOptional<z.ZodObject<{
                name: z.ZodString;
                version: z.ZodString;
            }, z.core.$strict>>;
            struct: z.ZodOptional<z.ZodObject<{
                type: z.ZodString;
                mainField: z.ZodOptional<z.ZodString>;
                reducer: z.ZodOptional<z.ZodObject<{
                    op: z.ZodEnum<{
                        first: "first";
                        last: "last";
                        max: "max";
                        min: "min";
                    }>;
                    field: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
                array: z.ZodOptional<z.ZodBoolean>;
            }, z.core.$strict>>;
            format: z.ZodOptional<z.ZodObject<{
                kind: z.ZodEnum<{
                    currency: "currency";
                    date: "date";
                    number: "number";
                    percent: "percent";
                    text: "text";
                }>;
                locale: z.ZodOptional<z.ZodString>;
                currency: z.ZodOptional<z.ZodString>;
                minimumFractionDigits: z.ZodOptional<z.ZodNumber>;
                maximumFractionDigits: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>>;
            derived: z.ZodOptional<z.ZodType<DerivedExpression, unknown, z.core.$ZodTypeInternals<DerivedExpression, unknown>>>;
        }, z.core.$strict>>;
        machinery: z.ZodOptional<z.ZodObject<{
            states: z.ZodArray<z.ZodObject<{
                name: z.ZodString;
                terminal: z.ZodOptional<z.ZodBoolean>;
                dwellSeconds: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>>;
            transitions: z.ZodArray<z.ZodObject<{
                from: z.ZodNullable<z.ZodString>;
                to: z.ZodNullable<z.ZodString>;
                action: z.ZodOptional<z.ZodString>;
                execution: z.ZodOptional<z.ZodObject<{
                    subject: z.ZodString;
                    parameters: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
                    requires: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        process: z.ZodString;
                        link: z.ZodOptional<z.ZodString>;
                        states: z.ZodArray<z.ZodString>;
                        match: z.ZodDefault<z.ZodEnum<{
                            all: "all";
                            any: "any";
                        }>>;
                    }, z.core.$strict>>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
            subprocesses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                link: z.ZodString;
                process: z.ZodString;
            }, z.core.$strict>>>;
            parallel: z.ZodOptional<z.ZodArray<z.ZodString>>;
            metrics: z.ZodOptional<z.ZodObject<{
                node: z.ZodOptional<z.ZodObject<{
                    label: z.ZodString;
                    aggregation: z.ZodDiscriminatedUnion<[z.ZodObject<{
                        op: z.ZodLiteral<"count">;
                    }, z.core.$strict>, z.ZodObject<{
                        op: z.ZodEnum<{
                            avg: "avg";
                            max: "max";
                            min: "min";
                            sum: "sum";
                        }>;
                        property: z.ZodString;
                    }, z.core.$strict>], "op">;
                    decimals: z.ZodOptional<z.ZodNumber>;
                    unit: z.ZodOptional<z.ZodString>;
                    colors: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        min: z.ZodNumber;
                        color: z.ZodEnum<{
                            amber: "amber";
                            green: "green";
                            red: "red";
                        }>;
                    }, z.core.$strict>>>;
                }, z.core.$strict>>;
                edge: z.ZodOptional<z.ZodObject<{
                    label: z.ZodString;
                    aggregation: z.ZodDiscriminatedUnion<[z.ZodObject<{
                        op: z.ZodLiteral<"count">;
                    }, z.core.$strict>, z.ZodObject<{
                        op: z.ZodEnum<{
                            avg: "avg";
                            max: "max";
                            min: "min";
                            sum: "sum";
                        }>;
                        property: z.ZodString;
                    }, z.core.$strict>], "op">;
                    decimals: z.ZodOptional<z.ZodNumber>;
                    unit: z.ZodOptional<z.ZodString>;
                    colors: z.ZodOptional<z.ZodArray<z.ZodObject<{
                        min: z.ZodNumber;
                        color: z.ZodEnum<{
                            amber: "amber";
                            green: "green";
                            red: "red";
                        }>;
                    }, z.core.$strict>>>;
                }, z.core.$strict>>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        classificationProperty: z.ZodOptional<z.ZodString>;
        groups: z.ZodOptional<z.ZodArray<z.ZodString>>;
        interfaces: z.ZodRecord<z.ZodString, z.ZodObject<{
            properties: z.ZodRecord<z.ZodString, z.ZodString>;
            links: z.ZodRecord<z.ZodString, z.ZodString>;
            actions: z.ZodRecord<z.ZodString, z.ZodObject<{
                action: z.ZodString;
                parameters: z.ZodRecord<z.ZodString, z.ZodString>;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    interfaceTypes: z.ZodArray<z.ZodObject<{
        typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
            kind: z.ZodString;
            name: z.ZodString;
        }, z.core.$strict>>>;
        renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
        status: z.ZodOptional<z.ZodEnum<{
            active: "active";
            deprecated: "deprecated";
            experimental: "experimental";
        }>>;
        classification: z.ZodOptional<z.ZodObject<{
            sensitivity: z.ZodEnum<{
                CONFIDENTIAL: "CONFIDENTIAL";
                INTERNAL: "INTERNAL";
                PUBLIC: "PUBLIC";
                RESTRICTED: "RESTRICTED";
            }>;
            compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        apiName: z.ZodString;
        description: z.ZodString;
        properties: z.ZodRecord<z.ZodString, z.ZodObject<{
            typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
                kind: z.ZodString;
                name: z.ZodString;
            }, z.core.$strict>>>;
            renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
            status: z.ZodOptional<z.ZodEnum<{
                active: "active";
                deprecated: "deprecated";
                experimental: "experimental";
            }>>;
            classification: z.ZodOptional<z.ZodObject<{
                sensitivity: z.ZodEnum<{
                    CONFIDENTIAL: "CONFIDENTIAL";
                    INTERNAL: "INTERNAL";
                    PUBLIC: "PUBLIC";
                    RESTRICTED: "RESTRICTED";
                }>;
                compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>>;
            description: z.ZodDefault<z.ZodString>;
            schema: z.ZodDefault<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
            required: z.ZodDefault<z.ZodBoolean>;
            sharedProperty: z.ZodOptional<z.ZodString>;
            valueType: z.ZodOptional<z.ZodObject<{
                name: z.ZodString;
                version: z.ZodString;
            }, z.core.$strict>>;
            struct: z.ZodOptional<z.ZodObject<{
                type: z.ZodString;
                mainField: z.ZodOptional<z.ZodString>;
                reducer: z.ZodOptional<z.ZodObject<{
                    op: z.ZodEnum<{
                        first: "first";
                        last: "last";
                        max: "max";
                        min: "min";
                    }>;
                    field: z.ZodOptional<z.ZodString>;
                }, z.core.$strict>>;
                array: z.ZodOptional<z.ZodBoolean>;
            }, z.core.$strict>>;
            format: z.ZodOptional<z.ZodObject<{
                kind: z.ZodEnum<{
                    currency: "currency";
                    date: "date";
                    number: "number";
                    percent: "percent";
                    text: "text";
                }>;
                locale: z.ZodOptional<z.ZodString>;
                currency: z.ZodOptional<z.ZodString>;
                minimumFractionDigits: z.ZodOptional<z.ZodNumber>;
                maximumFractionDigits: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>>;
            derived: z.ZodOptional<z.ZodType<DerivedExpression, unknown, z.core.$ZodTypeInternals<DerivedExpression, unknown>>>;
        }, z.core.$strict>>;
        extends: z.ZodOptional<z.ZodArray<z.ZodString>>;
        optionalProperties: z.ZodArray<z.ZodString>;
        links: z.ZodRecord<z.ZodString, z.ZodObject<{
            target: z.ZodString;
            cardinality: z.ZodEnum<{
                many: "many";
                one: "one";
            }>;
            required: z.ZodBoolean;
        }, z.core.$strict>>;
        actions: z.ZodRecord<z.ZodString, z.ZodObject<{
            parameters: z.ZodRecord<z.ZodString, z.ZodUnknown>;
            objectParameters: z.ZodRecord<z.ZodString, z.ZodString>;
            required: z.ZodBoolean;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    linkTypes: z.ZodArray<z.ZodObject<{
        typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
            kind: z.ZodString;
            name: z.ZodString;
        }, z.core.$strict>>>;
        renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
        status: z.ZodOptional<z.ZodEnum<{
            active: "active";
            deprecated: "deprecated";
            experimental: "experimental";
        }>>;
        classification: z.ZodOptional<z.ZodObject<{
            sensitivity: z.ZodEnum<{
                CONFIDENTIAL: "CONFIDENTIAL";
                INTERNAL: "INTERNAL";
                PUBLIC: "PUBLIC";
                RESTRICTED: "RESTRICTED";
            }>;
            compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        apiName: z.ZodString;
        description: z.ZodString;
        from: z.ZodObject<{
            type: z.ZodString;
            name: z.ZodString;
            cardinality: z.ZodEnum<{
                many: "many";
                one: "one";
            }>;
        }, z.core.$strict>;
        to: z.ZodObject<{
            type: z.ZodString;
            name: z.ZodString;
            cardinality: z.ZodEnum<{
                many: "many";
                one: "one";
            }>;
        }, z.core.$strict>;
    }, z.core.$strict>>;
    functionTypes: z.ZodArray<z.ZodObject<{
        typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
            kind: z.ZodString;
            name: z.ZodString;
        }, z.core.$strict>>>;
        renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
        status: z.ZodOptional<z.ZodEnum<{
            active: "active";
            deprecated: "deprecated";
            experimental: "experimental";
        }>>;
        classification: z.ZodOptional<z.ZodObject<{
            sensitivity: z.ZodEnum<{
                CONFIDENTIAL: "CONFIDENTIAL";
                INTERNAL: "INTERNAL";
                PUBLIC: "PUBLIC";
                RESTRICTED: "RESTRICTED";
            }>;
            compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        apiName: z.ZodString;
        description: z.ZodString;
        parameters: z.ZodRecord<z.ZodString, z.ZodUnknown>;
        returns: z.ZodRecord<z.ZodString, z.ZodUnknown>;
        source: z.ZodOptional<z.ZodString>;
        edits: z.ZodOptional<z.ZodBoolean>;
        version: z.ZodOptional<z.ZodString>;
        kind: z.ZodOptional<z.ZodLiteral<"model">>;
        dependencies: z.ZodOptional<z.ZodObject<{
            objectTypes: z.ZodOptional<z.ZodArray<z.ZodString>>;
            interfaceTypes: z.ZodOptional<z.ZodArray<z.ZodString>>;
            linkTypes: z.ZodOptional<z.ZodArray<z.ZodString>>;
            functions: z.ZodOptional<z.ZodArray<z.ZodString>>;
            dataSources: z.ZodOptional<z.ZodArray<z.ZodString>>;
            actions: z.ZodOptional<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        implementation: z.ZodOptional<z.ZodObject<{
            kind: z.ZodLiteral<"component">;
            models: z.ZodOptional<z.ZodArray<z.ZodString>>;
            stream: z.ZodOptional<z.ZodLiteral<"text">>;
            sha256: z.ZodString;
            limits: z.ZodObject<{
                fuel: z.ZodNumber;
                memoryMb: z.ZodNumber;
                deadlineMs: z.ZodNumber;
                inputBytes: z.ZodOptional<z.ZodNumber>;
                outputBytes: z.ZodOptional<z.ZodNumber>;
            }, z.core.$strict>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    actionTypes: z.ZodArray<z.ZodObject<{
        typeClasses: z.ZodOptional<z.ZodArray<z.ZodObject<{
            kind: z.ZodString;
            name: z.ZodString;
        }, z.core.$strict>>>;
        renderHints: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodString, z.ZodBoolean, z.ZodNumber]>>>;
        status: z.ZodOptional<z.ZodEnum<{
            active: "active";
            deprecated: "deprecated";
            experimental: "experimental";
        }>>;
        classification: z.ZodOptional<z.ZodObject<{
            sensitivity: z.ZodEnum<{
                CONFIDENTIAL: "CONFIDENTIAL";
                INTERNAL: "INTERNAL";
                PUBLIC: "PUBLIC";
                RESTRICTED: "RESTRICTED";
            }>;
            compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        apiName: z.ZodString;
        description: z.ZodString;
        parameters: z.ZodRecord<z.ZodString, z.ZodUnknown>;
        objectParameters: z.ZodRecord<z.ZodString, z.ZodString>;
        submissionCriteria: z.ZodArray<z.ZodObject<{
            function: z.ZodString;
            arguments: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                parameter: z.ZodString;
                path: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>, z.ZodObject<{
                literal: z.ZodUnknown;
            }, z.core.$strict>]>>;
            message: z.ZodOptional<z.ZodString>;
            functionVersion: z.ZodOptional<z.ZodString>;
            executionContext: z.ZodOptional<z.ZodEnum<{
                live: "live";
                scenario: "scenario";
            }>>;
        }, z.core.$strict>>;
        rules: z.ZodOptional<z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            op: z.ZodLiteral<"createObject">;
            object: z.ZodObject<{
                type: z.ZodString;
                id: z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>;
            }, z.core.$strict>;
            properties: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                parameter: z.ZodString;
                path: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>, z.ZodObject<{
                literal: z.ZodUnknown;
            }, z.core.$strict>]>>;
        }, z.core.$strict>, z.ZodObject<{
            op: z.ZodLiteral<"editObject">;
            object: z.ZodObject<{
                parameter: z.ZodString;
                path: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>;
            expectedRevision: z.ZodUnion<readonly [z.ZodObject<{
                parameter: z.ZodString;
                path: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>, z.ZodObject<{
                literal: z.ZodUnknown;
            }, z.core.$strict>]>;
            properties: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                parameter: z.ZodString;
                path: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>, z.ZodObject<{
                literal: z.ZodUnknown;
            }, z.core.$strict>]>>;
            expectedProperties: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                parameter: z.ZodString;
                path: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>, z.ZodObject<{
                literal: z.ZodUnknown;
            }, z.core.$strict>]>>>;
        }, z.core.$strict>, z.ZodObject<{
            op: z.ZodLiteral<"addLink">;
            link: z.ZodString;
            from: z.ZodObject<{
                type: z.ZodString;
                id: z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>;
            }, z.core.$strict>;
            to: z.ZodObject<{
                type: z.ZodString;
                id: z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>;
            }, z.core.$strict>;
        }, z.core.$strict>, z.ZodObject<{
            op: z.ZodLiteral<"removeLink">;
            link: z.ZodString;
            from: z.ZodObject<{
                type: z.ZodString;
                id: z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>;
            }, z.core.$strict>;
            to: z.ZodObject<{
                type: z.ZodString;
                id: z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>;
            }, z.core.$strict>;
        }, z.core.$strict>, z.ZodObject<{
            op: z.ZodLiteral<"deleteObject">;
            object: z.ZodObject<{
                parameter: z.ZodString;
                path: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>;
            expectedRevision: z.ZodUnion<readonly [z.ZodObject<{
                parameter: z.ZodString;
                path: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>, z.ZodObject<{
                literal: z.ZodUnknown;
            }, z.core.$strict>]>;
        }, z.core.$strict>, z.ZodObject<{
            op: z.ZodLiteral<"editStruct">;
            object: z.ZodObject<{
                parameter: z.ZodString;
                path: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>;
            expectedRevision: z.ZodUnion<readonly [z.ZodObject<{
                parameter: z.ZodString;
                path: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>, z.ZodObject<{
                literal: z.ZodUnknown;
            }, z.core.$strict>]>;
            property: z.ZodString;
            fields: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                parameter: z.ZodString;
                path: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>, z.ZodObject<{
                literal: z.ZodUnknown;
            }, z.core.$strict>]>>;
        }, z.core.$strict>, z.ZodObject<{
            op: z.ZodLiteral<"applyScenario">;
            scenario: z.ZodUnion<readonly [z.ZodObject<{
                parameter: z.ZodString;
                path: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>, z.ZodObject<{
                literal: z.ZodUnknown;
            }, z.core.$strict>]>;
            expectedRevision: z.ZodUnion<readonly [z.ZodObject<{
                parameter: z.ZodString;
                path: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>, z.ZodObject<{
                literal: z.ZodUnknown;
            }, z.core.$strict>]>;
            objectTypes: z.ZodArray<z.ZodString>;
            linkTypes: z.ZodArray<z.ZodString>;
        }, z.core.$strict>, z.ZodObject<{
            op: z.ZodLiteral<"reviewScenario">;
            scenario: z.ZodUnion<readonly [z.ZodObject<{
                parameter: z.ZodString;
                path: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>, z.ZodObject<{
                literal: z.ZodUnknown;
            }, z.core.$strict>]>;
            expectedRevision: z.ZodUnion<readonly [z.ZodObject<{
                parameter: z.ZodString;
                path: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>, z.ZodObject<{
                literal: z.ZodUnknown;
            }, z.core.$strict>]>;
            review: z.ZodDiscriminatedUnion<[z.ZodObject<{
                kind: z.ZodLiteral<"submit">;
                reviewers: z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>;
                authorizeMerge: z.ZodOptional<z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>>;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"approve">;
                snapshot: z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>;
                decision: z.ZodOptional<z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>>;
                applyAuthorizedMerge: z.ZodOptional<z.ZodLiteral<true>>;
            }, z.core.$strict>, z.ZodObject<{
                kind: z.ZodLiteral<"reject">;
                snapshot: z.ZodUnion<readonly [z.ZodObject<{
                    parameter: z.ZodString;
                    path: z.ZodOptional<z.ZodArray<z.ZodString>>;
                }, z.core.$strict>, z.ZodObject<{
                    literal: z.ZodUnknown;
                }, z.core.$strict>]>;
            }, z.core.$strict>], "kind">;
        }, z.core.$strict>], "op">>>;
        result: z.ZodOptional<z.ZodObject<{
            type: z.ZodString;
            id: z.ZodUnion<readonly [z.ZodObject<{
                parameter: z.ZodString;
                path: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>, z.ZodObject<{
                literal: z.ZodUnknown;
            }, z.core.$strict>]>;
        }, z.core.$strict>>;
        function: z.ZodOptional<z.ZodString>;
        functionVersion: z.ZodOptional<z.ZodString>;
        effects: z.ZodOptional<z.ZodArray<z.ZodUnion<readonly [z.ZodObject<{
            name: z.ZodString;
            handler: z.ZodString;
            payload: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                parameter: z.ZodString;
                path: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>, z.ZodObject<{
                literal: z.ZodUnknown;
            }, z.core.$strict>]>>;
        }, z.core.$strict>, z.ZodObject<{
            name: z.ZodString;
            webhook: z.ZodObject<{
                source: z.ZodString;
                method: z.ZodEnum<{
                    DELETE: "DELETE";
                    PATCH: "PATCH";
                    POST: "POST";
                    PUT: "PUT";
                }>;
                path: z.ZodString;
                function: z.ZodOptional<z.ZodString>;
            }, z.core.$strict>;
            payload: z.ZodRecord<z.ZodString, z.ZodUnion<readonly [z.ZodObject<{
                parameter: z.ZodString;
                path: z.ZodOptional<z.ZodArray<z.ZodString>>;
            }, z.core.$strict>, z.ZodObject<{
                literal: z.ZodUnknown;
            }, z.core.$strict>]>>;
        }, z.core.$strict>]>>>;
        reservation: z.ZodOptional<z.ZodObject<{
            holderParameter: z.ZodString;
            allocationsParameter: z.ZodString;
            state: z.ZodEnum<{
                committed: "committed";
                held: "held";
                released: "released";
            }>;
            sharedSource: z.ZodOptional<z.ZodString>;
            confirmationEffect: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    dataSources: z.ZodArray<z.ZodObject<{
        apiName: z.ZodString;
        objectType: z.ZodString;
        function: z.ZodString;
        classification: z.ZodOptional<z.ZodObject<{
            sensitivity: z.ZodEnum<{
                CONFIDENTIAL: "CONFIDENTIAL";
                INTERNAL: "INTERNAL";
                PUBLIC: "PUBLIC";
                RESTRICTED: "RESTRICTED";
            }>;
            compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
        }, z.core.$strict>>;
        properties: z.ZodRecord<z.ZodString, z.ZodString>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type OntologyDocument = z.infer<typeof ontologySchema>;
export type Value = z.infer<typeof value>;
export interface ObjectData {
    ref: ObjectRef;
    revision: number;
    properties: Record<string, unknown>;
}
export interface LinkData {
    type: string;
    from: ObjectRef;
    to: ObjectRef;
}
export {};
