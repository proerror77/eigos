import { z } from 'zod';
export declare const sensitivitySchema: z.ZodEnum<{
    CONFIDENTIAL: "CONFIDENTIAL";
    INTERNAL: "INTERNAL";
    PUBLIC: "PUBLIC";
    RESTRICTED: "RESTRICTED";
}>;
export declare const sensitivityRank: {
    readonly PUBLIC: 10;
    readonly INTERNAL: 20;
    readonly CONFIDENTIAL: 30;
    readonly RESTRICTED: 40;
};
export declare const classificationSchema: z.ZodObject<{
    sensitivity: z.ZodEnum<{
        CONFIDENTIAL: "CONFIDENTIAL";
        INTERNAL: "INTERNAL";
        PUBLIC: "PUBLIC";
        RESTRICTED: "RESTRICTED";
    }>;
    compartments: z.ZodDefault<z.ZodArray<z.ZodString>>;
}, z.core.$strict>;
export type Classification = z.output<typeof classificationSchema>;
export declare const internalClassification: Classification;
export declare function combineClassification(...labels: (Classification | undefined)[]): Classification;
export declare function marksClassification(markings: string[]): Classification;
export declare function isProtected(label: Classification): boolean;
export declare function allowsClassification(clearance: Classification, required: Classification): boolean;
