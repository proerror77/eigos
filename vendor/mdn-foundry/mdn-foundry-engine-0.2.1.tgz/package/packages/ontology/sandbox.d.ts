import type { Ontology } from './model.js';
export declare const sandboxAgentCapability: {
    readonly kind: 'agent-capability';
    readonly name: 'sandbox';
};
export declare const historicalAgentSandboxResources: {
    actions: string[];
    objects: string[];
};
/** Published tags carry forward through resource renames. API names protect older definitions. */
export declare function isSandboxResource(model: Ontology, kind: string, name: string): boolean;
