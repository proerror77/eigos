import { z } from 'zod';
import { type OntologyDocument, type ObjectRef } from './schema.js';
export declare function validator(schema: Record<string, unknown>): z.ZodType;
export declare class Ontology {
    readonly document: OntologyDocument;
    readonly resourceDocument: OntologyDocument;
    readonly resolvedDocument: OntologyDocument;
    readonly digest: string;
    readonly objects: ReadonlyMap<string, OntologyDocument['objectTypes'][number]>;
    readonly interfaces: ReadonlyMap<string, OntologyDocument['interfaceTypes'][number]>;
    readonly links: ReadonlyMap<string, OntologyDocument['linkTypes'][number]>;
    readonly functions: ReadonlyMap<string, OntologyDocument['functionTypes'][number]>;
    readonly actions: ReadonlyMap<string, OntologyDocument['actionTypes'][number]>;
    readonly sources: ReadonlyMap<string, OntologyDocument['dataSources'][number]>;
    private readonly objectValidators;
    constructor(input: unknown, options?: {
        published?: boolean;
    });
    object(name: string): {
        typeClasses?: {
            kind: string;
            name: string;
        }[] | undefined;
        renderHints?: Record<string, string | number | boolean> | undefined;
        status?: "active" | "deprecated" | "experimental" | undefined;
        classification?: {
            sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
            compartments: string[];
        } | undefined;
        apiName: string;
        displayName: string;
        description: string;
        primaryKey: string;
        titleProperty: string;
        properties: Record<string, {
            typeClasses?: {
                kind: string;
                name: string;
            }[] | undefined;
            renderHints?: Record<string, string | number | boolean> | undefined;
            status?: "active" | "deprecated" | "experimental" | undefined;
            classification?: {
                sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                compartments: string[];
            } | undefined;
            description: string;
            schema: Record<string, unknown>;
            required: boolean;
            sharedProperty?: string | undefined;
            valueType?: {
                name: string;
                version: string;
            } | undefined;
            struct?: {
                type: string;
                mainField?: string | undefined;
                reducer?: {
                    op: "first" | "last" | "max" | "min";
                    field?: string | undefined;
                } | undefined;
                array?: boolean | undefined;
            } | undefined;
            format?: {
                kind: "currency" | "date" | "number" | "percent" | "text";
                locale?: string | undefined;
                currency?: string | undefined;
                minimumFractionDigits?: number | undefined;
                maximumFractionDigits?: number | undefined;
            } | undefined;
            derived?: import("./schema.js").DerivedExpression | undefined;
        }>;
        machinery?: {
            states: {
                name: string;
                terminal?: boolean | undefined;
                dwellSeconds?: number | undefined;
            }[];
            transitions: {
                from: string | null;
                to: string | null;
                action?: string | undefined;
                execution?: {
                    subject: string;
                    parameters?: Record<string, string> | undefined;
                    requires?: {
                        process: string;
                        link?: string | undefined;
                        states: string[];
                        match: "all" | "any";
                    }[] | undefined;
                } | undefined;
            }[];
            subprocesses?: {
                link: string;
                process: string;
            }[] | undefined;
            parallel?: string[] | undefined;
            metrics?: {
                node?: {
                    label: string;
                    aggregation: {
                        op: "count";
                    } | {
                        op: "avg" | "max" | "min" | "sum";
                        property: string;
                    };
                    decimals?: number | undefined;
                    unit?: string | undefined;
                    colors?: {
                        min: number;
                        color: "amber" | "green" | "red";
                    }[] | undefined;
                } | undefined;
                edge?: {
                    label: string;
                    aggregation: {
                        op: "count";
                    } | {
                        op: "avg" | "max" | "min" | "sum";
                        property: string;
                    };
                    decimals?: number | undefined;
                    unit?: string | undefined;
                    colors?: {
                        min: number;
                        color: "amber" | "green" | "red";
                    }[] | undefined;
                } | undefined;
            } | undefined;
        } | undefined;
        classificationProperty?: string | undefined;
        groups?: string[] | undefined;
        interfaces: Record<string, {
            properties: Record<string, string>;
            links: Record<string, string>;
            actions: Record<string, {
                action: string;
                parameters: Record<string, string>;
            }>;
        }>;
    };
    action(name: string): {
        typeClasses?: {
            kind: string;
            name: string;
        }[] | undefined;
        renderHints?: Record<string, string | number | boolean> | undefined;
        status?: "active" | "deprecated" | "experimental" | undefined;
        classification?: {
            sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
            compartments: string[];
        } | undefined;
        apiName: string;
        description: string;
        parameters: Record<string, unknown>;
        objectParameters: Record<string, string>;
        submissionCriteria: {
            function: string;
            arguments: Record<string, {
                parameter: string;
                path?: string[] | undefined;
            } | {
                literal: unknown;
            }>;
            message?: string | undefined;
            functionVersion?: string | undefined;
            executionContext?: "live" | "scenario" | undefined;
        }[];
        rules?: ({
            op: "createObject";
            object: {
                type: string;
                id: {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                };
            };
            properties: Record<string, {
                parameter: string;
                path?: string[] | undefined;
            } | {
                literal: unknown;
            }>;
        } | {
            op: "editObject";
            object: {
                parameter: string;
                path?: string[] | undefined;
            };
            expectedRevision: {
                parameter: string;
                path?: string[] | undefined;
            } | {
                literal: unknown;
            };
            properties: Record<string, {
                parameter: string;
                path?: string[] | undefined;
            } | {
                literal: unknown;
            }>;
            expectedProperties?: Record<string, {
                parameter: string;
                path?: string[] | undefined;
            } | {
                literal: unknown;
            }> | undefined;
        } | {
            op: "addLink";
            link: string;
            from: {
                type: string;
                id: {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                };
            };
            to: {
                type: string;
                id: {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                };
            };
        } | {
            op: "removeLink";
            link: string;
            from: {
                type: string;
                id: {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                };
            };
            to: {
                type: string;
                id: {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                };
            };
        } | {
            op: "deleteObject";
            object: {
                parameter: string;
                path?: string[] | undefined;
            };
            expectedRevision: {
                parameter: string;
                path?: string[] | undefined;
            } | {
                literal: unknown;
            };
        } | {
            op: "editStruct";
            object: {
                parameter: string;
                path?: string[] | undefined;
            };
            expectedRevision: {
                parameter: string;
                path?: string[] | undefined;
            } | {
                literal: unknown;
            };
            property: string;
            fields: Record<string, {
                parameter: string;
                path?: string[] | undefined;
            } | {
                literal: unknown;
            }>;
        } | {
            op: "applyScenario";
            scenario: {
                parameter: string;
                path?: string[] | undefined;
            } | {
                literal: unknown;
            };
            expectedRevision: {
                parameter: string;
                path?: string[] | undefined;
            } | {
                literal: unknown;
            };
            objectTypes: string[];
            linkTypes: string[];
        } | {
            op: "reviewScenario";
            scenario: {
                parameter: string;
                path?: string[] | undefined;
            } | {
                literal: unknown;
            };
            expectedRevision: {
                parameter: string;
                path?: string[] | undefined;
            } | {
                literal: unknown;
            };
            review: {
                kind: "submit";
                reviewers: {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                };
                authorizeMerge?: {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                } | undefined;
            } | {
                kind: "approve";
                snapshot: {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                };
                decision?: {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                } | undefined;
                applyAuthorizedMerge?: true | undefined;
            } | {
                kind: "reject";
                snapshot: {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                };
            };
        })[] | undefined;
        result?: {
            type: string;
            id: {
                parameter: string;
                path?: string[] | undefined;
            } | {
                literal: unknown;
            };
        } | undefined;
        function?: string | undefined;
        functionVersion?: string | undefined;
        effects?: ({
            name: string;
            handler: string;
            payload: Record<string, {
                parameter: string;
                path?: string[] | undefined;
            } | {
                literal: unknown;
            }>;
        } | {
            name: string;
            webhook: {
                source: string;
                method: "DELETE" | "PATCH" | "POST" | "PUT";
                path: string;
                function?: string | undefined;
            };
            payload: Record<string, {
                parameter: string;
                path?: string[] | undefined;
            } | {
                literal: unknown;
            }>;
        })[] | undefined;
        reservation?: {
            holderParameter: string;
            allocationsParameter: string;
            state: "committed" | "held" | "released";
            sharedSource?: string | undefined;
            confirmationEffect?: string | undefined;
        } | undefined;
    };
    implements(type: string, target: string): boolean;
    concreteTypes(target: string): string[];
    propertyName(type: string, view: string, property: string): string | undefined;
    propertyPath(view: string, path: string): Record<string, unknown>;
    parseObject(ref: ObjectRef, properties: Record<string, unknown>): Record<string, unknown>;
    navigation(type: string, name: string, view?: string): {
        link: string;
        forward: boolean;
        target: string;
        cardinality: "many" | "one";
    };
    resolveAction(ref: ObjectRef, interfaceName: string, name: string, input: Record<string, unknown>): {
        action: string;
        input: {
            [k: string]: {} | null;
        };
    };
    resolveTypeAction(type: string, interfaceName: string, name: string, input: Record<string, unknown>): {
        action: string;
        input: {
            [k: string]: {} | null;
        };
    };
}
