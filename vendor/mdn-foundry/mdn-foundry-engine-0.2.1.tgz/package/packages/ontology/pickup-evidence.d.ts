import { z } from 'zod';
export declare const placeDetailInput: z.ZodObject<{
    id: z.ZodString;
}, z.core.$strict>;
export declare const pickupCoordinateEvidence: z.ZodObject<{
    provider: z.ZodLiteral<"Amap">;
    fetchedAt: z.ZodISODateTime;
    inputCoordinateSystem: z.ZodEnum<{
        gcj02: "gcj02";
        wgs84: "wgs84";
    }>;
    coordinateSystem: z.ZodLiteral<"gcj02">;
    conversion: z.ZodEnum<{
        already_gcj02: "already_gcj02";
        converted_by_amap: "converted_by_amap";
    }>;
}, z.core.$strict>;
