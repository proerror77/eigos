import { z } from 'zod';
import type { OntologyDocument, propertySchema } from './schema.js';
type Property = z.infer<typeof propertySchema>;
export declare function compileTypes(input: OntologyDocument): OntologyDocument;
export declare function propertyDisplay(property: Property, value: unknown): unknown;
export {};
