import type { validator, Ontology } from './model.js';
/** Check concrete references and expression types before a definition can be published. */
export declare function validateDerivedProperties(model: Ontology, validate: typeof validator): void;
