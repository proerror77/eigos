import { versionRange, type OntologyDocument } from './schema.js';
export { versionRange };
/**
 * Versions of published Functions, after Palantir's function versioning: a publisher chooses each version, a released
 * version is immutable, and a backward incompatible change needs a new major version. Consumers accept a pinned
 * version or a range of backward compatible versions.
 */
type FunctionType = OntologyDocument['functionTypes'][number];
type Version = readonly [number, number, number];
export declare function parseVersion(version: string | undefined): Version | undefined;
export declare function compareVersions(a: Version, b: Version): number;
/**
 * Whether `version` lies in `range`. Below 1.0.0 the minor version is the major one, as in npm: `^0.2.3` accepts 0.2.x
 * from 0.2.3, and `^0.0.3` only 0.0.3.
 */
export declare function satisfies(version: string | undefined, range: string): boolean;
/**
 * Why `next` is not backward compatible with `previous`. Callers send inputs and read outputs, so a change is breaking
 * when an input is removed, changes, or becomes required, when inputs stop accepting other properties, or when an output
 * is removed, changes, or may be missing. Annotations are ignored. As Palantir notes, such checks cannot be exhaustive:
 * they find breaking changes, and a change they accept can still break a caller.
 */
export declare function breakingChanges(previous: FunctionType, next: FunctionType): string[];
/**
 * Why `next` cannot be released as a new version after `previous`, the version the active release has, or undefined
 * when it can. Only semantic versions are compared. A changed Function needs a higher version, and a breaking change a
 * new major version; below 1.0.0, a new minor version.
 */
export declare function versionProblem(previous: FunctionType, next: FunctionType): string | undefined;
