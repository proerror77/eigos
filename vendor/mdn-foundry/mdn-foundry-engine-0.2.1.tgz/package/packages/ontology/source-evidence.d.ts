/** Retain the historical DiDi read bindings after adding PA evidence. */
export declare function legacySourceEvidence(schema: Record<string, unknown>): Record<string, unknown>;
