import type { OntologyDocument } from './schema.js';
export declare const documentType = "OperationalDocumentVersion";
export declare const documentChunkType = "OperationalDocumentChunk";
export declare const documentChunkLink = "DocumentVersionChunk";
export declare const documentLink = "SchedulePlanDocument";
export declare const registerDocument = "RegisterSchedulePlanDocument";
export declare const registerDocumentFunction = "registerSchedulePlanDocument";
export declare const documentDefinition: Pick<OntologyDocument, 'objectTypes' | 'linkTypes' | 'functionTypes' | 'actionTypes'>;
