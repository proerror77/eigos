type Schema = Record<string, unknown>;
/** Compare the full parameter object after projecting it through the Interface mapping. */
export declare function actionParametersCompatible(supplied: Schema, accepted: Schema, mapping: Record<string, string>): boolean;
export {};
