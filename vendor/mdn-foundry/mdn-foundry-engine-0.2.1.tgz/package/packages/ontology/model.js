import { z } from 'zod';
import { satisfies } from './function-versions.js';
import { timeSeriesFields, validateTimeSeriesFields } from './time-series.js';
import { compileTypes } from './type-system.js';
import { expandImports } from './resource-mapping.js';
import { actionParametersCompatible } from './action-compatibility.js';
import { schemaSubset } from './schema-compatibility.js';
import { validateDerivedProperties } from './derived-validation.js';
import { fieldSchema, propertyPathSchema } from './property-path.js';
import { compileMachineryExecution, processLogTarget, validateMachineryModel } from './process-definition.js';
import { digest, InvalidInput, NotFound } from '../core/identity.js';
import { ontologySchema } from './schema.js';
const validators = new WeakMap();
export function validator(schema) {
    let cached = validators.get(schema);
    if (!cached) {
        const structure = z.fromJSONSchema(schema), series = timeSeriesFields(schema);
        cached = series.length ? structure.superRefine((value, context) => validateTimeSeriesFields(series, value, context)) : structure;
        validators.set(schema, cached);
    }
    return cached;
}
const unique = (items) => {
    const map = new Map(items.map(item => [item.apiName, item]));
    if (map.size !== items.length)
        throw new Error('Duplicate API name');
    return map;
};
const required = (map, name) => {
    const item = map.get(name);
    if (!item)
        throw new Error(`Unknown ontology resource ${name}`);
    return item;
};
/** A Function an Action refers to, which must have a version in the range the Action accepts. */
const acceptedVersion = (action, fn, range) => {
    if (range && !satisfies(fn.version, range))
        throw new Error(`${action} accepts ${fn.apiName} ${range}, but the ontology has ${fn.version ?? 'no version'}`);
    return fn;
};
export class Ontology {
    document;
    resourceDocument;
    resolvedDocument;
    digest;
    objects;
    interfaces;
    links;
    functions;
    actions;
    sources;
    objectValidators = new Map();
    constructor(input, options = {}) {
        this.document = ontologySchema.parse(input);
        this.digest = digest(this.document);
        this.resourceDocument = expandImports(this.document);
        this.resolvedDocument = compileTypes(this.resourceDocument);
        this.objects = unique(this.resolvedDocument.objectTypes);
        this.interfaces = unique(this.resolvedDocument.interfaceTypes);
        this.links = unique(this.resolvedDocument.linkTypes);
        this.functions = unique(this.resolvedDocument.functionTypes);
        this.actions = unique(this.resolvedDocument.actionTypes);
        this.sources = unique(this.resolvedDocument.dataSources);
        for (const profile of unique(this.resolvedDocument.agentProfiles ?? []).values()) {
            for (const name of profile.objects ?? [])
                required(this.objects, name);
            for (const name of profile.interfaces ?? [])
                required(this.interfaces, name);
            for (const name of profile.actions ?? [])
                required(this.actions, name);
            for (const name of profile.functions ?? [])
                required(this.functions, name);
            for (const name of profile.sources ?? [])
                required(this.sources, name);
            for (const name of profile.links ?? [])
                required(this.links, name);
            for (const hint of profile.instructions ?? []) {
                if (hint.action && !profile.actions?.includes(hint.action)
                    || hint.function && !profile.functions?.includes(hint.function))
                    throw new Error('Agent instructions require resources within their profile');
            }
        }
        // Publication performs the current inclusion proof. Stored snapshots retain the
        // basic-type contract accepted by earlier runtimes without rewriting their identity.
        const compatible = (supplied, accepted) => schemaSubset(supplied, accepted) || options.published === true && digest(supplied.type ?? null) === digest(accepted.type ?? null);
        for (const type of this.objects.values()) {
            if (this.interfaces.has(type.apiName))
                throw new Error('Object and interface names must be distinct');
            for (const key of [type.primaryKey, type.titleProperty]) {
                if (type.properties[key]?.derived || type.properties[key]?.schema.type !== 'string' || !type.properties[key]?.required)
                    throw new Error(`Missing required string key on ${type.apiName}`);
            }
            if (type.classificationProperty && (!type.properties[type.classificationProperty]
                || type.properties[type.classificationProperty]?.derived))
                throw new Error(`Missing stored classification property on ${type.apiName}`);
            this.objectValidators.set(type.apiName, z.strictObject(Object.fromEntries(Object.entries(type.properties).filter(([, property]) => !property.derived)
                .map(([name, property]) => [name, property.required ? validator(property.schema) : validator(property.schema).optional()]))));
        }
        for (const link of this.links.values()) {
            this.object(link.from.type);
            this.object(link.to.type);
            for (const side of [link.from, link.to]) {
                const same = [...this.links.values()].flatMap(item => [item.from, item.to]).filter(item => item.type === side.type && item.name === side.name);
                if (same.length !== 1)
                    throw new Error(`Ambiguous relationship ${side.type}.${side.name}`);
            }
        }
        for (const type of this.objects.values())
            for (const [name, mapping] of Object.entries(type.interfaces)) {
                const contract = required(this.interfaces, name);
                for (const [alias, property] of Object.entries(contract.properties)) {
                    const local = mapping.properties[alias];
                    if (!local && contract.optionalProperties.includes(alias))
                        continue;
                    if (!local || !type.properties[local] || !compatible(type.properties[local].schema, property.schema))
                        throw new Error(`Invalid property mapping ${type.apiName}.${alias}`);
                    if (property.derived && !type.properties[local].derived)
                        throw new Error('Derived Interface properties require a derived implementation');
                }
                if (Object.keys(mapping.properties).some(name => !contract.properties[name]))
                    throw new Error('Unknown interface property');
                for (const [alias, constraint] of Object.entries(contract.links)) {
                    const local = mapping.links[alias];
                    if (!local && !constraint.required)
                        continue;
                    const navigation = this.navigation(type.apiName, local ?? '');
                    if (!this.implements(navigation.target, constraint.target) || navigation.cardinality !== constraint.cardinality)
                        throw new Error(`Invalid link mapping ${type.apiName}.${alias}`);
                }
                for (const [alias, constraint] of Object.entries(contract.actions)) {
                    const local = mapping.actions[alias];
                    if (!local && !constraint.required)
                        continue;
                    if (!local)
                        throw new Error(`Missing action mapping ${type.apiName}.${alias}`);
                    const action = this.action(local.action);
                    const expected = constraint.parameters.properties ?? {};
                    const actual = action.parameters.properties ?? {};
                    const expectedRequired = new Set(constraint.parameters.required ?? []);
                    const actualRequired = new Set(action.parameters.required ?? []);
                    const targets = Object.values(local.parameters);
                    // Each implementing type maps the constraint to an Action of its own, as with Palantir
                    // action type constraints. Only a sole parameter able to hold the selected object may narrow
                    // to this type; Actions.checkInput still checks every object reference at execution.
                    const own = Object.keys(constraint.objectParameters).filter(name => this.implements(type.apiName, constraint.objectParameters[name]));
                    if (new Set(targets).size !== targets.length)
                        throw new Error('An action parameter can satisfy one interface parameter');
                    for (const parameter of expectedRequired)
                        if (!local.parameters[parameter])
                            throw new Error('Incompatible action parameters');
                    for (const [parameter, target] of Object.entries(local.parameters)) {
                        if (!expected[parameter] || !actual[target] || !compatible(expected[parameter], actual[target]))
                            throw new Error('Incompatible action parameter constraints');
                        if (actualRequired.has(target) && !expectedRequired.has(parameter) && !Object.hasOwn(actual[target], 'default') && !Object.hasOwn(expected[parameter], 'default'))
                            throw new Error('Optional Interface input cannot satisfy a required Action input');
                        const objectType = constraint.objectParameters[parameter], targetType = action.objectParameters[target];
                        const candidates = own.length === 1 && own[0] === parameter ? [type.apiName] : objectType ? this.concreteTypes(objectType) : [];
                        if (objectType && (!targetType || !candidates.every(candidate => this.implements(candidate, targetType))))
                            throw new Error(`Incompatible Action object parameter type for ${type.apiName}.${alias}`);
                        if (!options.published && targetType && !objectType)
                            throw new Error(`Incompatible Action object parameter type for ${type.apiName}.${alias}`);
                    }
                    for (const parameter of actualRequired)
                        if (!targets.includes(parameter) && !Object.hasOwn(actual[parameter] ?? {}, 'default'))
                            throw new Error('Action requires an unmapped parameter');
                    if (!options.published) {
                        if (Object.keys(action.objectParameters).some(parameter => !targets.includes(parameter)))
                            throw new Error('Action requires an unmapped object parameter');
                        if (!actionParametersCompatible(constraint.parameters, action.parameters, local.parameters))
                            throw new Error('Incompatible action parameter constraints for ' + type.apiName + '.' + alias);
                    }
                }
            }
        if (!options.published)
            validateDerivedProperties(this, validator);
        for (const action of this.actions.values()) {
            if (new Set(action.effects?.map(effect => effect.name)).size !== (action.effects?.length ?? 0))
                throw new Error('Duplicate Action effect name');
            for (const effect of action.effects ?? []) {
                if (!('webhook' in effect) || !effect.webhook.function)
                    continue;
                const fn = required(this.functions, effect.webhook.function);
                if (!fn.implementation || fn.source || fn.edits)
                    throw new Error('A webhook formatter requires a component Function without Source access or edits');
            }
            if (action.reservation) {
                const { holderParameter, allocationsParameter, sharedSource, confirmationEffect } = action.reservation;
                if (!action.objectParameters[holderParameter] || !Object.hasOwn(action.parameters.properties ?? {}, allocationsParameter))
                    throw new Error('A reservation requires a typed holder and an allocations parameter');
                if (sharedSource)
                    required(this.sources, sharedSource);
                if (confirmationEffect && !action.effects?.some(effect => effect.name === confirmationEffect))
                    throw new Error('A reservation confirmation effect must belong to the published Action');
            }
            validator(action.parameters);
            for (const rule of action.rules ?? []) {
                if (rule.op === 'editObject' && rule.expectedProperties &&
                    JSON.stringify(Object.keys(rule.expectedProperties).sort()) !== JSON.stringify(Object.keys(rule.properties).sort()))
                    throw new InvalidInput('An edit must compare every property it changes');
            }
            for (const type of Object.values(action.objectParameters))
                this.concreteTypes(type);
            for (const criterion of action.submissionCriteria)
                acceptedVersion(action.apiName, required(this.functions, criterion.function), criterion.functionVersion);
            if (action.function && !acceptedVersion(action.apiName, required(this.functions, action.function), action.functionVersion).edits)
                throw new Error('Function-backed Actions require an ontology edit Function');
            for (const rule of action.rules ?? []) {
                if (rule.op === 'createObject') {
                    const object = this.object(rule.object.type);
                    if (Object.keys(rule.properties).some(name => !object.properties[name]))
                        throw new Error('Action writes an undeclared property');
                }
                if (rule.op === 'applyScenario') {
                    for (const name of rule.objectTypes)
                        this.object(name);
                    for (const name of rule.linkTypes)
                        required(this.links, name);
                }
                if (rule.op === 'reviewScenario')
                    this.object('OntologyScenario');
                if (rule.op === 'addLink' || rule.op === 'removeLink') {
                    const link = required(this.links, rule.link);
                    if (rule.from.type !== link.from.type || rule.to.type !== link.to.type)
                        throw new Error('Action link endpoints differ from the Link Type');
                }
            }
        }
        for (const source of this.sources.values()) {
            const type = this.object(source.objectType);
            required(this.functions, source.function);
            if (Object.keys(source.properties).some(name => !type.properties[name] || type.properties[name]?.derived))
                throw new Error('Datasource maps an unknown property');
            if (Object.entries(type.properties).some(([name, property]) => property.required && !property.derived && !source.properties[name]))
                throw new Error('Datasource lacks a required property mapping');
        }
        for (const fn of this.functions.values()) {
            validator(fn.parameters);
            validator(fn.returns);
            const resources = { objectTypes: this.objects, interfaceTypes: this.interfaces, linkTypes: this.links, functions: this.functions, dataSources: this.sources, actions: this.actions };
            for (const [kind, names] of Object.entries(fn.dependencies ?? {}))
                for (const name of names) {
                    if (!resources[kind].has(name))
                        throw new Error(`Unknown Function dependency ${fn.apiName}: ${kind}/${name}`);
                }
        }
        for (const [type, definition] of this.objects) {
            processLogTarget(this, type);
            if (definition.machinery)
                validateMachineryModel(this, type, definition.machinery);
        }
        compileMachineryExecution(this);
        // Process containers nest through subprocesses; a container cannot contain itself. Releases published before this
        // check load as they are, like derived properties.
        if (!options.published) {
            const children = (type) => this.objects.get(type)?.machinery?.subprocesses?.map(child => child.process) ?? [];
            const settled = new Set();
            const visit = (type, path) => {
                if (path.has(type))
                    throw new Error('Machinery subprocesses must not form a cycle: ' + [...path, type].join(' → '));
                if (settled.has(type))
                    return;
                for (const child of children(type))
                    visit(child, new Set([...path, type]));
                settled.add(type);
            };
            for (const type of this.objects.keys())
                visit(type, new Set());
        }
    }
    object(name) {
        const object = this.objects.get(name);
        if (!object)
            throw new NotFound(`Unknown ontology resource ${name}`);
        return object;
    }
    action(name) {
        const action = this.actions.get(name);
        if (!action)
            throw new NotFound(`Unknown ontology resource ${name}`);
        return action;
    }
    implements(type, target) { return type === target || Object.hasOwn(this.object(type).interfaces, target); }
    concreteTypes(target) {
        if (!this.objects.has(target) && !this.interfaces.has(target))
            throw new NotFound(`Unknown type ${target}`);
        return [...this.objects.keys()].filter(type => this.implements(type, target));
    }
    propertyName(type, view, property) {
        if (type === view) {
            if (!Object.hasOwn(this.object(type).properties, property))
                throw new InvalidInput('Unknown property ' + type + '.' + property);
            return property;
        }
        const mapping = this.object(type).interfaces[view];
        if (!mapping || !Object.hasOwn(required(this.interfaces, view).properties, property))
            throw new InvalidInput('Unknown interface property ' + view + '.' + property);
        return Object.hasOwn(mapping.properties, property) ? mapping.properties[property] : undefined;
    }
    propertyPath(view, path) {
        const [name, ...fields] = propertyPathSchema.parse(path).split('.');
        const definitions = this.interfaces.get(view)?.properties ?? this.object(view).properties;
        let schema = Object.hasOwn(definitions, name) ? definitions[name].schema : undefined;
        for (const field of fields)
            schema = schema && fieldSchema(schema, field);
        if (!schema)
            throw new InvalidInput('Unknown property ' + view + '.' + path);
        return schema;
    }
    parseObject(ref, properties) {
        if (properties[this.object(ref.type).primaryKey] !== ref.id)
            throw new Error('Primary key differs from object reference');
        const value = this.objectValidators.get(ref.type).parse(properties);
        for (const [name, mapping] of Object.entries(this.object(ref.type).interfaces)) {
            for (const [alias, local] of Object.entries(mapping.properties)) {
                const property = required(this.interfaces, name).properties[alias];
                if (value[local] !== undefined || property.required && !this.object(ref.type).properties[local]?.derived)
                    validator(property.schema).parse(value[local]);
            }
        }
        return value;
    }
    navigation(type, name, view = type) {
        const actual = view === type ? name : this.object(type).interfaces[view]?.links[name];
        for (const link of this.links.values()) {
            if (link.from.type === type && link.from.name === actual)
                return { link: link.apiName, forward: true, target: link.to.type, cardinality: link.from.cardinality };
            if (link.to.type === type && link.to.name === actual)
                return { link: link.apiName, forward: false, target: link.from.type, cardinality: link.to.cardinality };
        }
        throw new InvalidInput(`Unknown relationship ${view}.${name}`);
    }
    resolveAction(ref, interfaceName, name, input) {
        const contract = this.interfaces.get(interfaceName)?.actions[name];
        const mapping = this.object(ref.type).interfaces[interfaceName]?.actions[name];
        if (!contract || !mapping)
            throw new NotFound('Interface action is unavailable');
        const supplied = validator(contract.parameters).parse(input);
        const subjects = Object.keys(contract.objectParameters).filter(parameter => this.implements(ref.type, contract.objectParameters[parameter]));
        if (!subjects.some(parameter => digest(supplied[parameter]) === digest(ref)))
            throw new InvalidInput('Interface action must bind the selected object');
        return { action: mapping.action, input: Object.fromEntries(Object.entries(mapping.parameters)
                .flatMap(([alias, local]) => supplied[alias] === undefined ? [] : [[local, supplied[alias]]])) };
    }
    resolveTypeAction(type, interfaceName, name, input) {
        const contract = this.interfaces.get(interfaceName)?.actions[name];
        const mapping = this.object(type).interfaces[interfaceName]?.actions[name];
        if (!contract || !mapping)
            throw new NotFound('Interface action is unavailable');
        const supplied = validator(contract.parameters).parse(input);
        return { action: mapping.action, input: Object.fromEntries(Object.entries(mapping.parameters)
                .flatMap(([alias, local]) => supplied[alias] === undefined ? [] : [[local, supplied[alias]]])) };
    }
}
