import { z } from 'zod';
type Schema = Record<string, unknown>;
export declare const propertyPathSchema: z.ZodString;
/** Resolve a declared field from the compiled property contract, including reusable and nullable types. */
export declare function fieldSchema(schema: Schema, field: string): Schema | undefined;
/** The possible JSON value kinds, ignoring refinements that do not change the kind. */
export declare function valueKinds(schema: Schema): string[];
export {};
