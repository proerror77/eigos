import { type OntologyDocument } from './schema.js';
export declare const resourceGroups: {
    readonly object: 'objectTypes';
    readonly interface: 'interfaceTypes';
    readonly link: 'linkTypes';
    readonly function: 'functionTypes';
    readonly action: 'actionTypes';
    readonly datasource: 'dataSources';
    readonly sharedProperty: 'sharedProperties';
    readonly valueType: 'valueTypes';
    readonly struct: 'structTypes';
    readonly group: 'typeGroups';
    readonly agentProfile: 'agentProfiles';
};
export type ResourceKind = keyof typeof resourceGroups;
export type ResourceNameMap = Partial<Record<ResourceKind, Record<string, string>>>;
export declare function remapResources(definition: OntologyDocument, ontology: string, names: ResourceNameMap): OntologyDocument;
/** Imports are immutable definition snapshots. Expansion performs no network or credential access. */
export declare function expandImports(input: OntologyDocument, depth?: number): OntologyDocument;
