import type { Ontology } from './model.js';
import { type OntologyDocument, type ObjectRef } from './schema.js';
/** Log objects are read-only projections of the existing, committed edit history. */
export declare function addProcessLogs(document: OntologyDocument, tracked: {
    type: string;
    property: string;
}[]): void;
export declare function processLogTarget(model: Ontology, type: string): {
    type: string;
    objectType: string;
    property: string;
    link: string;
} | undefined;
export type MachineryModel = NonNullable<OntologyDocument['objectTypes'][number]['machinery']>;
export type ProcessLogTarget = NonNullable<ReturnType<typeof processLogTarget>>;
export declare function validateMachineryModel(model: Ontology, type: ObjectRef['type'], specification: MachineryModel): void;
type Execution = NonNullable<MachineryModel['transitions'][number]['execution']>;
export type ExecutableTransition = {
    process: ProcessLogTarget;
    action: string;
    from: string;
    to: string;
    execution: Execution;
};
/** Compile the optional execution contracts once for each published Ontology definition. */
export declare function compileMachineryExecution(model: Ontology): {
    byType: Map<string, ExecutableTransition[]>;
    byAction: Map<string, ExecutableTransition[]>;
};
export {};
