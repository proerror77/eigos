import type { OntologyDocument } from './schema.js';
export declare const scenarioInterfaceName = "Scenario";
export declare const scenarioInterface: OntologyDocument['interfaceTypes'][number];
export declare const scenarioObjectType: OntologyDocument['objectTypes'][number];
export declare const scenarioReviewActions: {
    readonly submit: 'SubmitScenarioReview';
    readonly approve: 'ApproveScenarioReview';
    readonly reject: 'RejectScenarioReview';
    readonly submitForMerge: 'SubmitScenarioReviewForMerge';
    readonly approveAndMerge: 'ApproveAndMergeScenarioReview';
};
type ActionDefinition = OntologyDocument['actionTypes'][number];
export declare const scenarioReviewDefinitions: {
    typeClasses?: {
        kind: string;
        name: string;
    }[] | undefined;
    renderHints?: Record<string, string | number | boolean> | undefined;
    status?: "active" | "deprecated" | "experimental" | undefined;
    classification?: {
        sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
        compartments: string[];
    } | undefined;
    apiName: string;
    description: string;
    parameters: Record<string, unknown>;
    objectParameters: Record<string, string>;
    submissionCriteria: {
        function: string;
        arguments: Record<string, {
            parameter: string;
            path?: string[] | undefined;
        } | {
            literal: unknown;
        }>;
        message?: string | undefined;
        functionVersion?: string | undefined;
        executionContext?: "live" | "scenario" | undefined;
    }[];
    rules?: ({
        op: "createObject";
        object: {
            type: string;
            id: {
                parameter: string;
                path?: string[] | undefined;
            } | {
                literal: unknown;
            };
        };
        properties: Record<string, {
            parameter: string;
            path?: string[] | undefined;
        } | {
            literal: unknown;
        }>;
    } | {
        op: "editObject";
        object: {
            parameter: string;
            path?: string[] | undefined;
        };
        expectedRevision: {
            parameter: string;
            path?: string[] | undefined;
        } | {
            literal: unknown;
        };
        properties: Record<string, {
            parameter: string;
            path?: string[] | undefined;
        } | {
            literal: unknown;
        }>;
        expectedProperties?: Record<string, {
            parameter: string;
            path?: string[] | undefined;
        } | {
            literal: unknown;
        }> | undefined;
    } | {
        op: "addLink";
        link: string;
        from: {
            type: string;
            id: {
                parameter: string;
                path?: string[] | undefined;
            } | {
                literal: unknown;
            };
        };
        to: {
            type: string;
            id: {
                parameter: string;
                path?: string[] | undefined;
            } | {
                literal: unknown;
            };
        };
    } | {
        op: "removeLink";
        link: string;
        from: {
            type: string;
            id: {
                parameter: string;
                path?: string[] | undefined;
            } | {
                literal: unknown;
            };
        };
        to: {
            type: string;
            id: {
                parameter: string;
                path?: string[] | undefined;
            } | {
                literal: unknown;
            };
        };
    } | {
        op: "deleteObject";
        object: {
            parameter: string;
            path?: string[] | undefined;
        };
        expectedRevision: {
            parameter: string;
            path?: string[] | undefined;
        } | {
            literal: unknown;
        };
    } | {
        op: "editStruct";
        object: {
            parameter: string;
            path?: string[] | undefined;
        };
        expectedRevision: {
            parameter: string;
            path?: string[] | undefined;
        } | {
            literal: unknown;
        };
        property: string;
        fields: Record<string, {
            parameter: string;
            path?: string[] | undefined;
        } | {
            literal: unknown;
        }>;
    } | {
        op: "applyScenario";
        scenario: {
            parameter: string;
            path?: string[] | undefined;
        } | {
            literal: unknown;
        };
        expectedRevision: {
            parameter: string;
            path?: string[] | undefined;
        } | {
            literal: unknown;
        };
        objectTypes: string[];
        linkTypes: string[];
    } | {
        op: "reviewScenario";
        scenario: {
            parameter: string;
            path?: string[] | undefined;
        } | {
            literal: unknown;
        };
        expectedRevision: {
            parameter: string;
            path?: string[] | undefined;
        } | {
            literal: unknown;
        };
        review: {
            kind: "submit";
            reviewers: {
                parameter: string;
                path?: string[] | undefined;
            } | {
                literal: unknown;
            };
            authorizeMerge?: {
                parameter: string;
                path?: string[] | undefined;
            } | {
                literal: unknown;
            } | undefined;
        } | {
            kind: "approve";
            snapshot: {
                parameter: string;
                path?: string[] | undefined;
            } | {
                literal: unknown;
            };
            decision?: {
                parameter: string;
                path?: string[] | undefined;
            } | {
                literal: unknown;
            } | undefined;
            applyAuthorizedMerge?: true | undefined;
        } | {
            kind: "reject";
            snapshot: {
                parameter: string;
                path?: string[] | undefined;
            } | {
                literal: unknown;
            };
        };
    })[] | undefined;
    result?: {
        type: string;
        id: {
            parameter: string;
            path?: string[] | undefined;
        } | {
            literal: unknown;
        };
    } | undefined;
    function?: string | undefined;
    functionVersion?: string | undefined;
    effects?: ({
        name: string;
        handler: string;
        payload: Record<string, {
            parameter: string;
            path?: string[] | undefined;
        } | {
            literal: unknown;
        }>;
    } | {
        name: string;
        webhook: {
            source: string;
            method: "DELETE" | "PATCH" | "POST" | "PUT";
            path: string;
            function?: string | undefined;
        };
        payload: Record<string, {
            parameter: string;
            path?: string[] | undefined;
        } | {
            literal: unknown;
        }>;
    })[] | undefined;
    reservation?: {
        holderParameter: string;
        allocationsParameter: string;
        state: "committed" | "held" | "released";
        sharedSource?: string | undefined;
        confirmationEffect?: string | undefined;
    } | undefined;
}[];
/** Legacy review authority applies only to these immutable platform actions and their dynamic Scenario checks. */
export declare function isScenarioReviewAction(definition: ActionDefinition | undefined): boolean;
export {};
