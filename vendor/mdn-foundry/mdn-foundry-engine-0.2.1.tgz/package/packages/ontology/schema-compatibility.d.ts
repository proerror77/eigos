type Schema = Record<string, unknown>;
/** Conservative JSON Schema inclusion. Unproved constraints fail publication rather than narrowing an Interface silently. */
export declare function schemaSubset(supplied: Schema, accepted: Schema): boolean;
export {};
