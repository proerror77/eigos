import type { OntologyDocument } from './schema.js';
export declare const geometryUploadCriterion = "verifyGeometryUpload";
export declare const applicationDefinition: Pick<OntologyDocument, 'objectTypes' | 'interfaceTypes' | 'linkTypes' | 'functionTypes' | 'actionTypes' | 'dataSources'>;
