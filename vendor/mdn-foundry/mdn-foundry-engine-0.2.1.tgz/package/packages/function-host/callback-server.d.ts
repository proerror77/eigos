type Arguments = Record<string, unknown>;
export type CallbackFailure = {
    code: string;
    message: string;
};
export type CallbackResult = {
    result: unknown;
} | {
    error: CallbackFailure;
};
type Dispatch = (operation: string, args: Arguments) => Promise<CallbackResult>;
/** Loopback transport shared by the runtime's authorized Ontology callbacks and offline test stubs. */
export declare class FunctionCallbackServer {
    private server?;
    private readonly sessions;
    open(dispatch: Dispatch, maxResponseBytes: number): Promise<{
        callback: {
            url: string;
            token: string;
        };
        close: () => void;
    }>;
    close(): Promise<void>;
    private listen;
    private handle;
}
export {};
