import { createHash } from 'node:crypto';
export function canonical(value) {
    const normalize = (item) => {
        if (Array.isArray(item))
            return item.map(normalize);
        if (item && typeof item === 'object')
            return Object.fromEntries(Object.entries(item)
                .filter(([, value]) => value !== undefined).sort(([left], [right]) => left.localeCompare(right, 'en'))
                .map(([key, value]) => [key, normalize(value)]));
        return item;
    };
    return JSON.stringify(normalize(value));
}
export const digest = (value) => createHash('sha256').update(canonical(value)).digest('hex');
export function requireScope(principal, scope) {
    if (!principal.owner || !principal.scopes.includes(scope))
        throw new PermissionDenied(`Permission required: ${scope}`);
}
export class InvalidInput extends Error {
}
export class PermissionDenied extends Error {
}
export class Conflict extends Error {
}
export class NotFound extends Error {
}
/** A local runtime dependency is temporarily saturated. The same request can be retried later. */
export class ServiceUnavailable extends Error {
}
/** A component Function stopped at one of its published limits. */
export class ResourceExhausted extends Error {
    limit;
    constructor(message, limit, options) {
        super(message, options);
        this.limit = limit;
    }
}
/**
 * A component Function failed: with its own failure and the code it chose, with a trap (code `trap`), or with an output
 * outside its contract (code `contract`).
 */
export class FunctionFailed extends Error {
    code;
    constructor(message, code, options) {
        super(message, options);
        this.code = code;
    }
}
export class SourceReadFailure extends Error {
    unavailable;
    constructor(message, options) {
        super(message, options);
        this.unavailable = options?.unavailable ?? false;
    }
}
