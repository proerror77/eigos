import { AsyncLocalStorage } from 'node:async_hooks';
const active = new AsyncLocalStorage();
/** Runs an operation with its own profile. Work in nested profiles also counts toward enclosing ones. */
export function profileDatabase(run) {
    const profile = { statements: 0, durationMs: 0, editLockWaitMs: 0, editLockHoldMs: 0, lockTimeouts: 0, commitFallbacks: 0 };
    return active.run([...(active.getStore() ?? []), profile], () => run(profile));
}
/** Runs work that is not part of the operation being measured, such as a shadow comparison, outside every profile. */
export function unprofiled(run) {
    return active.run([], run);
}
/** The profiles charged for work started now, kept for work that finishes later, such as a held lock. */
export function activeProfiles() {
    return active.getStore() ?? [];
}
export function chargeProfiles(profiles, counter, amount) {
    for (const profile of profiles)
        profile[counter] += amount;
}
/** Log form: counts as recorded and times rounded to 0.1 ms. */
export function profileSummary(profile) {
    const round = (value) => Math.round(value * 10) / 10;
    return {
        statements: profile.statements, durationMs: round(profile.durationMs), editLockWaitMs: round(profile.editLockWaitMs),
        editLockHoldMs: round(profile.editLockHoldMs), lockTimeouts: profile.lockTimeouts, commitFallbacks: profile.commitFallbacks,
    };
}
