/** Database work observed while an operation ran, in milliseconds where timed. */
export interface DatabaseProfile {
    /** Statements sent through the runtime database client. */
    statements: number;
    /** Sum of their round trips, including any lock waits inside them. */
    durationMs: number;
    /** Time spent acquiring Ontology edit locks, including waits that timed out. */
    editLockWaitMs: number;
    /** Time from acquiring an Ontology edit lock until its transaction ended. */
    editLockHoldMs: number;
    /** Statements that failed because a lock wait exceeded lock_timeout. */
    lockTimeouts: number;
    /** Optimistic commits rerun with the exclusive edit lock after a serialization failure or deadlock. */
    commitFallbacks: number;
}
type Counter = keyof DatabaseProfile;
/** Runs an operation with its own profile. Work in nested profiles also counts toward enclosing ones. */
export declare function profileDatabase<T>(run: (profile: DatabaseProfile) => Promise<T>): Promise<T>;
/** Runs work that is not part of the operation being measured, such as a shadow comparison, outside every profile. */
export declare function unprofiled<T>(run: () => Promise<T>): Promise<T>;
/** The profiles charged for work started now, kept for work that finishes later, such as a held lock. */
export declare function activeProfiles(): readonly DatabaseProfile[];
export declare function chargeProfiles(profiles: readonly DatabaseProfile[], counter: Counter, amount: number): void;
/** Log form: counts as recorded and times rounded to 0.1 ms. */
export declare function profileSummary(profile: DatabaseProfile): DatabaseProfile;
export {};
