import { AsyncLocalStorage } from 'node:async_hooks';
import { profileDatabase, profileSummary } from './database-profile.js';
const timing = new AsyncLocalStorage();
export function withOperationTiming(correlation, run) {
    return timing.run(correlation, run);
}
/** Keep the owning run when a harness invokes its tools from another connection. */
export function bindOperationTiming(run) {
    const correlation = timing.getStore();
    return correlation ? (input) => timing.run(correlation, () => run(input)) : run;
}
/** Logs one runtime event with the current run's correlation, if any. Callers pass metadata only. */
export function recordOperationEvent(event, fields) {
    console.info(JSON.stringify({ event, ...timing.getStore(), ...fields, at: new Date().toISOString() }));
}
export async function timeOperation(stage, run, operation) {
    const correlation = timing.getStore();
    if (!correlation)
        return run();
    const startedAt = new Date().toISOString(), started = performance.now();
    return profileDatabase(async (profile) => {
        let outcome = 'threw';
        try {
            const result = await run();
            outcome = 'returned';
            return result;
        }
        finally {
            console.info(JSON.stringify({
                event: 'stage_timing', ...correlation, stage, operation, outcome,
                startedAt, finishedAt: new Date().toISOString(), durationMs: Math.round(performance.now() - started),
                db: profileSummary(profile),
            }));
        }
    });
}
