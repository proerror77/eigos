export declare function canonical(value: unknown): string;
export declare const digest: (value: unknown) => string;
export interface Principal {
    owner: string;
    scopes: readonly string[];
    clientId?: string;
    issuedAt?: number;
    memberAudience?: true;
    memberAccess?: true;
}
export type ExecutionActor = {
    kind: 'client' | 'agent' | 'workflow' | 'scheduled' | 'indexer' | 'system';
    id: string;
};
export declare function requireScope(principal: Principal, scope: string): void;
export declare class InvalidInput extends Error {
}
export declare class PermissionDenied extends Error {
}
export declare class Conflict extends Error {
}
export declare class NotFound extends Error {
}
/** A local runtime dependency is temporarily saturated. The same request can be retried later. */
export declare class ServiceUnavailable extends Error {
}
/** A component Function stopped at one of its published limits. */
export declare class ResourceExhausted extends Error {
    readonly limit: 'fuel' | 'memory' | 'deadline' | 'output';
    constructor(message: string, limit: 'fuel' | 'memory' | 'deadline' | 'output', options?: ErrorOptions);
}
/**
 * A component Function failed: with its own failure and the code it chose, with a trap (code `trap`), or with an output
 * outside its contract (code `contract`).
 */
export declare class FunctionFailed extends Error {
    readonly code: string;
    constructor(message: string, code: string, options?: ErrorOptions);
}
export declare class SourceReadFailure extends Error {
    readonly unavailable: boolean;
    constructor(message: string, options?: ErrorOptions & {
        unavailable?: boolean;
    });
}
