interface SandboxConfiguration {
    EIGOS_AUTH_MODE?: string;
    EIGOS_AGENT_SANDBOX_ENABLED?: string;
    HOST?: string;
    NODE_ENV?: string;
}
/** Sandbox capabilities are available only in an explicitly enabled loopback development runtime. */
export declare function developmentSandboxEnabled(config?: SandboxConfiguration): boolean;
export {};
