{{- define "eigos.image" -}}
{{- if not (regexMatch "^[^ @]+@sha256:[a-f0-9]{64}$" .Values.image) -}}{{ fail "Pin the runtime image by digest" }}{{- end -}}
{{- .Values.image | quote -}}
{{- end -}}
{{- define "eigos.pod" -}}
automountServiceAccountToken: false
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  runAsGroup: 1000
  fsGroup: 1000
volumes:
  - name: state
    persistentVolumeClaim:
      claimName: {{ .Values.stateClaim | quote }}
{{- end -}}
{{- define "eigos.container" -}}
image: {{ include "eigos.image" . }}
workingDir: /opt/eigos/app
securityContext:
  allowPrivilegeEscalation: false
  capabilities:
    drop: ["ALL"]
volumeMounts:
  - name: state
    mountPath: /var/lib/eigos
env:
  - name: EIGOS_STATE_DIR
    value: /var/lib/eigos
  {{- if .Values.migration }}
  - name: JOB_NAME
    valueFrom:
      fieldRef:
        fieldPath: metadata.labels['batch.kubernetes.io/job-name']
  {{- end }}
  - name: ARCHIVE_DIGEST
    {{- if not (regexMatch "^[a-f0-9]{64}$" .Values.archiveDigest) }}{{ fail "Supply the verified VM archive digest" }}{{ end }}
    value: {{ .Values.archiveDigest | quote }}
  - name: HOST
    value: "0.0.0.0"
  - name: PORT
    value: "3000"
{{- end -}}
