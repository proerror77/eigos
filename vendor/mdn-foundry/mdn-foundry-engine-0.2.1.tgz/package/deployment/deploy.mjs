// Run on the trusted release controller. Adapter paths and target names are operator-owned.
import { DatabaseSync } from 'node:sqlite';
import { createHash, randomUUID } from 'node:crypto';
import { createReadStream } from 'node:fs';
import { readFile, realpath } from 'node:fs/promises';
import { execFileSync } from 'node:child_process';
import { isAbsolute } from 'node:path';

const [command, configFile, ...args] = process.argv.slice(2);
if (!configFile) throw Error('Usage: deploy.mjs plan|apply|verify|recover|status|history|events CONFIG [arguments]');
process.umask(0o077);
const configBytes = await readFile(configFile);
const config = JSON.parse(configBytes);
const hash = bytes => createHash('sha256').update(bytes).digest('hex');
const configHash = hash(configBytes);
const stages = ['dev', 'staging', 'production'];
const name = /^[a-z][a-z0-9-]{0,62}$/;
if (typeof config.solution !== 'string' || !name.test(config.solution) || !isAbsolute(config.database) || !isAbsolute(config.adapter))
  throw Error('Invalid controller configuration');
const targets = stages.map(stage => config.targets[stage]);
if (targets.some(target => typeof target !== 'string' || !name.test(target)) || new Set(targets).size !== stages.length)
  throw Error('Configure a distinct target for each stage');
const db = new DatabaseSync(config.database);
db.exec(`PRAGMA busy_timeout=5000;
 CREATE TABLE IF NOT EXISTS deployment (
 id TEXT PRIMARY KEY, solution TEXT NOT NULL, stage TEXT NOT NULL, target TEXT NOT NULL,
 archive TEXT NOT NULL, digest TEXT NOT NULL, config TEXT NOT NULL, previous TEXT,
 state TEXT NOT NULL, receipt TEXT, created TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
 CREATE UNIQUE INDEX IF NOT EXISTS target_busy ON deployment(target)
 WHERE state IN ('applying','uncertain','verifying');
 CREATE TABLE IF NOT EXISTS deployment_event (
 seq INTEGER PRIMARY KEY,id TEXT NOT NULL,state TEXT NOT NULL,at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
 CREATE TRIGGER IF NOT EXISTS deployment_created AFTER INSERT ON deployment BEGIN
 INSERT INTO deployment_event(id,state) VALUES(new.id,new.state); END;
 CREATE TRIGGER IF NOT EXISTS deployment_changed AFTER UPDATE OF state ON deployment BEGIN
 INSERT INTO deployment_event(id,state) VALUES(new.id,new.state); END;`);
const one = (sql, ...params) => db.prepare(sql).get(...params);
const latest = (solution, stage, target) => one(
  "SELECT * FROM deployment WHERE solution=? AND stage=? AND target=? AND state='verified' ORDER BY rowid DESC LIMIT 1",
  solution, stage, target);
function transaction(fn) {
  db.exec('BEGIN IMMEDIATE');
  try { const value = fn(); db.exec('COMMIT'); return value; }
  catch (error) { db.exec('ROLLBACK'); throw error; }
}
async function checksum(path) {
  const digest = createHash('sha256');
  for await (const bytes of createReadStream(path)) digest.update(bytes);
  return digest.digest('hex');
}
function qualify(stage, digest) {
  const index = stages.indexOf(stage);
  if (index < 0) throw Error('Unknown stage');
  if (index && one("SELECT id FROM deployment WHERE target=? AND state IN ('applying','uncertain','verifying')", targets[index-1]))
    throw Error('Previous stage has an unresolved rollout');
  if (index && latest(config.solution, stages[index-1], targets[index-1])?.digest !== digest)
    throw Error('Previous stage must verify this exact archive first');
}
function plan(stage, archive, digest) {
  qualify(stage, digest);
  const target = config.targets[stage];
  const previous = latest(config.solution, stage, target)?.id ?? null;
  const id = randomUUID();
  db.prepare(`INSERT INTO deployment(id,solution,stage,target,archive,digest,config,previous,state)
    VALUES(?,?,?,?,?,?,?,?,'planned')`).run(id, config.solution, stage, target, archive, digest, configHash, previous);
  return {id, stage, target, archive, digest, previous};
}
function transition(row, from, to, receipt = null) {
  const result = db.prepare('UPDATE deployment SET state=?,receipt=? WHERE id=? AND state=?')
    .run(to, receipt, row.id, from);
  if (result.changes !== 1) throw Error('Deployment state changed concurrently');
}
async function execute(id) {
  const row = one('SELECT * FROM deployment WHERE id=? AND solution=?', id, config.solution);
  if (!row || row.config !== configHash) throw Error('Plan or controller configuration mismatch');
  if (row.state === 'verified' && command !== 'recover') return JSON.parse(row.receipt);
  // A separate connection holds this target's process lock even while the journal commits.
  // SQLite releases it on controller exit. The destination also locks remote operations.
  const lock = new DatabaseSync(config.database + '.' + row.target + '.lock');
  try {
    lock.exec('BEGIN IMMEDIATE');
    return await run(row);
  } finally { lock.close(); }
}
function inspect(row, operation) {
  const output = execFileSync(config.adapter, [operation,row.target,row.digest,row.archive],
    {encoding:'utf8', stdio:['ignore','pipe','inherit']});
  const receipt = JSON.parse(output);
  if (receipt.target !== row.target || receipt.digest !== row.digest || !receipt.installation?.release)
    throw Error('Target receipt does not identify the planned deployment');
  return receipt;
}
async function run(row) {
  const id = row.id;
  const apply = command === 'apply';
  if (apply && await checksum(row.archive) !== row.digest) throw Error('Archive checksum mismatch');
  const recovering = command === 'recover';
  const expected = recovering && row.previous
    ? one("SELECT * FROM deployment WHERE id=? AND state='verified'", row.previous) : row;
  if (recovering && expected === row) throw Error('No prior verified deployment to reconcile');
  const busy = apply ? 'applying' : 'verifying';
  transaction(() => {
    if (apply) {
      qualify(row.stage, row.digest);
      if ((latest(row.solution,row.stage,row.target)?.id ?? null) !== row.previous) throw Error('Stale plan');
      transition(row,'planned',busy);
    } else {
      if (!['applying','uncertain','verifying'].includes(row.state)) throw Error('No interrupted rollout');
      transition(row,row.state,busy);
    }
  });
  try {
    // Site adapter serializes apply and inspection at the destination and rechecks transferred bytes.
    const previous = row.previous && one('SELECT * FROM deployment WHERE id=?',row.previous);
    const receipt = inspect(expected, apply && previous?.digest !== row.digest ? 'apply' : 'verify');
    if (recovering) {
      const prior = JSON.parse(expected.receipt).installation;
      for (const key of ['instance','storage','release','projection','bindings','runtime'])
        if (!prior[key] || receipt.installation[key] !== prior[key]) throw Error('Restored installation differs: ' + key);
    }
    transition(row,busy,recovering ? 'recovered' : 'verified',JSON.stringify(receipt));
    return receipt;
  } catch (error) {
    db.prepare("UPDATE deployment SET state='uncertain' WHERE id=? AND state=?").run(id,busy);
    throw error;
  }
}
try {
  let result;
  if (command === 'plan' && args.length === 3) {
    const [stage, path, digest] = args;
    const archive = await realpath(path);
    if (await checksum(archive) !== digest) throw Error('Archive checksum mismatch');
    result = transaction(() => plan(stage, archive, digest));
  } else if (['apply','verify','recover'].includes(command) && args.length === 1) {
    result = await execute(args[0]);
  } else if (command === 'status' && args.length === 1 && stages.includes(args[0])) {
    const stage = args[0];
    const row = latest(config.solution,stage,config.targets[stage]);
    if (!row || row.config !== configHash) throw Error('No matching verified deployment');
    if (one("SELECT id FROM deployment WHERE target=? AND state IN ('applying','uncertain','verifying')", row.target))
      throw Error('Target has an unresolved rollout');
    result = inspect(row,'verify');
  } else if (command === 'events' && args.length === 1) {
    result = db.prepare('SELECT e.seq,e.at,e.state FROM deployment_event e JOIN deployment d ON d.id=e.id WHERE d.solution=? AND e.id=? ORDER BY e.seq')
      .all(config.solution,args[0]);
  } else if (command === 'history' && !args.length) {
    result = db.prepare('SELECT id,stage,target,digest,previous,state,created,receipt FROM deployment WHERE solution=? ORDER BY rowid')
      .all(config.solution);
  } else throw Error('Expected plan CONFIG STAGE ARCHIVE SHA256, apply|verify CONFIG PLAN_ID, or history CONFIG');
  console.log(JSON.stringify(result,null,2));
} finally { db.close(); }
