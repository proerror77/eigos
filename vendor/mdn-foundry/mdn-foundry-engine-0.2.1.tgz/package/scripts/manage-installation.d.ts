import type { Installation } from '../packages/runtime/installation.js';
export declare function manageInstallation(installation: Installation, [command, argument]: string[]): Promise<void>;
