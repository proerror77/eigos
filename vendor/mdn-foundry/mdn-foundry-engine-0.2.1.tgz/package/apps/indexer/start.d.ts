import type { Installation } from '../../packages/runtime/installation.js';
export declare function startIndexer(installation: Installation): Promise<void>;
