/** The Indexer's automation work: Scenario cleanup, rule scans and durable workflow runs. */
export interface AutomationDispatch {
    /** Removes expired Scenario state and reports whether more remains. */
    cleanup(): Promise<{
        more: boolean;
    }>;
    /** Independent change consumers; each scan reports whether it found work. */
    scans: readonly (() => Promise<boolean>)[];
    /** Claims and executes one durable workflow run, reporting whether one was claimed. */
    run(signal: AbortSignal): Promise<boolean>;
}
/**
 * Runs Scenario cleanup, each scan and workflow execution in separate loops, so a slow run does not delay rule
 * discovery and a slow consumer does not delay the others. Runs stay durable rows claimed with leases; a productive
 * scan wakes an idle runner. If any loop fails, the others stop after their current step and the first error is reported.
 */
export declare function dispatchAutomation(parts: AutomationDispatch, signal: AbortSignal, idleMs?: number): Promise<void>;
