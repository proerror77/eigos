import express, { type Request } from 'express';
import type { CallToolResult } from '@modelcontextprotocol/server';
import { McpServer } from '@modelcontextprotocol/server';
import { AgentCard } from '@a2a-js/sdk';
import type { InstalledRuntime } from '../../packages/runtime/installation.js';
import { z } from 'zod';
import { type Principal } from '../../packages/core/identity.js';
import type { Config } from '../../packages/core/config.js';
import { completeWithActionRequestSchema } from '../../packages/ontology/invocation.js';
import { Database, type Sql } from '../../packages/runtime/database.js';
import { Metadata, type PublishedOntology } from '../../packages/runtime/metadata.js';
import { Tasks, type Task } from '../../packages/runtime/tasks.js';
import { type VerifyToken } from './auth.js';
import { Accounts } from '../../packages/runtime/accounts.js';
export interface BusinessAdapter {
    card: AgentCard;
    profile(app: express.Express): void;
    mountPortal(app: express.Express, members: Accounts): void;
    mountWorkbench(app: express.Express): void;
    instructions(member: boolean, quoteOnly: boolean): string;
    submitDescription: string;
    taskRead(name: string): boolean;
    validateQuote(model: PublishedOntology, action: string): void;
    mountTasks(app: express.Express, tasks: Tasks, metadata: Metadata, principal: (request: Request) => Principal, publicTask: (task: Task) => unknown): void;
    registerTools(context: {
        server: McpServer;
        tasks: Tasks;
        metadata: Metadata;
        p: Principal;
        member: boolean;
        quoteOnly: boolean;
        response: (operation: () => Promise<unknown>) => Promise<CallToolResult>;
        authorize: (client: Sql) => Promise<void>;
        publicTask: (task: Task) => unknown;
        completeQuote: (input: z.infer<typeof completeWithActionRequestSchema>) => Promise<unknown>;
    }): void;
}
export declare function createHostApp(config: Config, db: Database, capabilities: InstalledRuntime, ontologyId: string, verify?: VerifyToken, business?: BusinessAdapter): {
    app: import("express-serve-static-core").Express;
    tasks: Tasks;
    metadata: Metadata;
    capabilities: InstalledRuntime;
};
