import { timingSafeEqual } from 'node:crypto';
import { createRemoteJWKSet, jwtVerify } from 'jose';
import { z } from 'zod';
import { digest } from '../../packages/core/identity.js';
export const developmentPrincipal = { owner: 'local-developer', scopes: ['tasks:read', 'tasks:write', 'ontology:read', 'ontology:write', 'sources:Didi:read'] };
export function jwtVerifier(issuer, audience, keys, tenantClaim = 'tenant_id', memberAudience) {
    return async (token) => {
        const { payload } = await jwtVerify(token, keys, { issuer, audience: memberAudience ? [audience, memberAudience] : audience, algorithms: ['RS256', 'ES256', 'EdDSA'], requiredClaims: ['exp', 'iat', 'sub', tenantClaim, 'scope'] });
        const claims = z.object({ sub: z.string().min(1), scope: z.string(), iat: z.number().int() }).parse(payload);
        const tenant = z.string().min(1).parse(payload[tenantClaim]);
        const clientId = z.string().min(1).max(200).safeParse(payload.client_id ?? payload.azp);
        const forMember = memberAudience && (typeof payload.aud === 'string' ? payload.aud === memberAudience : payload.aud?.includes(memberAudience));
        return { owner: digest([issuer, tenant, claims.sub]), issuedAt: claims.iat, ...(forMember ? { memberAudience: true } : {}), scopes: claims.scope.split(/\s+/).filter(Boolean), ...(clientId.success ? { clientId: clientId.data } : {}) };
    };
}
export function verifier(config) {
    if (config.EIGOS_AUTH_MODE === 'jwt')
        return jwtVerifier(config.OAUTH_ISSUER, config.OAUTH_AUDIENCE, createRemoteJWKSet(new URL(config.OAUTH_JWKS_URL)), config.OAUTH_TENANT_CLAIM, config.OAUTH_MEMBER_MCP_CLIENT_ID ? config.PUBLIC_URL + '/mcp' : undefined);
    return async (token) => {
        const expected = Buffer.from(config.EIGOS_DEV_TOKEN), actual = Buffer.from(token);
        if (actual.length !== expected.length || !timingSafeEqual(expected, actual))
            throw new Error('Invalid access token');
        return developmentPrincipal;
    };
}
