import { type JWTVerifyGetKey } from 'jose';
import { type Principal } from '../../packages/core/identity.js';
import type { Config } from '../../packages/core/config.js';
export type VerifyToken = (token: string) => Promise<Principal>;
export declare const developmentPrincipal: Principal;
export declare function jwtVerifier(issuer: string, audience: string, keys: JWTVerifyGetKey, tenantClaim?: string, memberAudience?: string): VerifyToken;
export declare function verifier(config: Config): VerifyToken;
