import express from 'express';
import type { Config } from '../../packages/core/config.js';
import type { VerifyToken } from './auth.js';
type WorkbenchOptions = {
    brand?: string;
    pages?: ReadonlyArray<{
        id: string;
        label: string;
    }>;
    imports?: Record<string, string>;
    geolocation?: boolean;
    stylesheet?: string;
    mountAssets?(app: express.Express): void;
};
export declare function mountOntologyWorkbench(app: express.Express, config: Config, verify: VerifyToken, ontology: string, options?: WorkbenchOptions): void;
export {};
