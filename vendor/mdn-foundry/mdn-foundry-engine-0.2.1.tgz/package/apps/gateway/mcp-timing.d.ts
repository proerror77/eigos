import type { Response } from 'express';
/** Record transport timings without retaining the request or response payload. */
export declare function startMcpTiming(res: Response): (body: unknown, clientId?: string) => {
    start(): void;
    run<T>(operation: () => Promise<T>): Promise<T>;
    succeed(result: unknown): void;
    fail(status: number): void;
} | undefined;
