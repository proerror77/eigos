import { z } from 'zod';
import { type Query } from '../../packages/runtime/objects.js';
export declare const codeModeInput: z.ZodObject<{
    code: z.ZodString;
}, z.core.$strict>;
export declare const codeModeActionCall: z.ZodObject<{
    input: z.ZodRecord<z.ZodString, z.ZodUnknown>;
    action: z.ZodOptional<z.ZodString>;
    interface: z.ZodOptional<z.ZodObject<{
        object: z.ZodOptional<z.ZodObject<{
            type: z.ZodString;
            id: z.ZodString;
        }, z.core.$strict>>;
        implementation: z.ZodOptional<z.ZodString>;
        type: z.ZodString;
        action: z.ZodString;
    }, z.core.$strict>>;
    scenarioId: z.ZodOptional<z.ZodNever>;
}, z.core.$strict>;
export declare class CodeMode {
    private running;
    execute(code: string, query: (input: Query) => Promise<unknown>, signal: AbortSignal, stageAction?: (action: z.infer<typeof codeModeActionCall>) => void): Promise<unknown>;
}
