import type { Database } from '../../packages/runtime/database.js';
import type { InstalledRuntime } from '../../packages/runtime/installation.js';
import { readConfig } from '../../packages/core/config.js';
import type { Installation } from '../../packages/runtime/installation.js';
import { createHostApp } from './host.js';
export declare function startGateway(installation: Installation, adapter?: (config: ReturnType<typeof readConfig>, db: Database, capabilities: InstalledRuntime) => ReturnType<typeof createHostApp>): Promise<void>;
