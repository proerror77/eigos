export declare function publicError(error: unknown): {
    status: number;
    message: string;
    requestId?: undefined;
} | {
    status: number;
    message: string;
    requestId: `${string}-${string}-${string}-${string}-${string}`;
};
