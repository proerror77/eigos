import { AgentCard, Task as A2ATask, type SendMessageRequest, type GetTaskRequest, type CancelTaskRequest, type ListTasksRequest, type StreamResponse } from '@a2a-js/sdk';
import type { A2ARequestHandler, ServerCallContext, User } from '@a2a-js/sdk/server';
import type { Principal } from '../../packages/core/identity.js';
import type { Sql } from '../../packages/runtime/database.js';
import { Tasks, type TaskResultProjection } from '../../packages/runtime/tasks.js';
export declare class AgentUser implements User {
    readonly principal: Principal;
    readonly authorizeSubmission?: ((client: Sql) => Promise<void>) | undefined;
    readonly isAuthenticated = true;
    constructor(principal: Principal, authorizeSubmission?: ((client: Sql) => Promise<void>) | undefined);
    get userName(): string;
}
export declare function agentCard(url: string, profile?: {
    name: string;
    description: string;
    skills: Pick<AgentCard['skills'][number], 'id' | 'name' | 'description' | 'tags'>[];
}): AgentCard;
export declare class A2A implements A2ARequestHandler {
    private readonly tasks;
    private readonly card;
    private readonly projectResult;
    constructor(tasks: Tasks, card: AgentCard, projectResult: TaskResultProjection);
    private user;
    getAgentCard(): Promise<AgentCard>;
    private task;
    sendMessage(params: SendMessageRequest, context: ServerCallContext): Promise<A2ATask>;
    getTask(params: GetTaskRequest, context: ServerCallContext): Promise<A2ATask>;
    cancelTask(params: CancelTaskRequest, context: ServerCallContext): Promise<A2ATask>;
    listTasks(_params: ListTasksRequest): Promise<never>;
    getAuthenticatedExtendedAgentCard(): Promise<never>;
    sendMessageStream(): AsyncGenerator<StreamResponse, void, undefined>;
    resubscribe(): AsyncGenerator<StreamResponse, void, undefined>;
    createTaskPushNotificationConfig(): Promise<never>;
    getTaskPushNotificationConfig(): Promise<never>;
    listTaskPushNotificationConfigs(): Promise<never>;
    deleteTaskPushNotificationConfig(): Promise<never>;
}
