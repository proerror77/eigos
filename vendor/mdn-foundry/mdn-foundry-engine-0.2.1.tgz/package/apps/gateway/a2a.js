import { AgentCard, Task as A2ATask } from '@a2a-js/sdk';
import { UnsupportedOperationError, PushNotificationNotSupportedError, ExtendedAgentCardNotConfiguredError, RequestMalformedError, TaskNotFoundError, TaskNotCancelableError, A2AError } from '@a2a-js/sdk/errors';
import { z } from 'zod';
import { actionCallSchema, actionResultReadSchema } from '../../packages/ontology/invocation.js';
import { PARequests } from '../../packages/runtime/pa.js';
import { publicError } from './public-error.js';
export class AgentUser {
    principal;
    authorizeSubmission;
    isAuthenticated = true;
    constructor(principal, authorizeSubmission) {
        this.principal = principal;
        this.authorizeSubmission = authorizeSubmission;
    }
    get userName() { return this.principal.owner; }
}
const states = { submitted: 'TASK_STATE_SUBMITTED', working: 'TASK_STATE_WORKING', completed: 'TASK_STATE_COMPLETED', failed: 'TASK_STATE_FAILED', canceled: 'TASK_STATE_CANCELED', 'input-required': 'TASK_STATE_INPUT_REQUIRED' };
const memberAction = z.strictObject({
    action: actionCallSchema.safeExtend({ scenarioId: z.never().optional() }),
    read: actionResultReadSchema.optional(),
});
const taskView = (task, projectResult) => {
    const result = projectResult(task.result);
    return A2ATask.fromJSON({ id: task.id, contextId: task.conversation_id ?? task.id, status: { state: states[task.state], timestamp: task.updated_at.toISOString() },
        artifacts: result ? [{ artifactId: task.id, name: 'Task result', parts: [{ data: result, mediaType: 'application/json' }] }] : [], metadata: { error: task.error } });
};
export function agentCard(url, profile) {
    return AgentCard.fromJSON({ name: 'EIGOS', description: 'Source-backed inquiries and calendar-backed scenario scheduling through Ontology queries, functions and actions.', version: '0.2.0',
        supportedInterfaces: [{ url: url + '/a2a', protocolBinding: 'JSONRPC', protocolVersion: '1.0' }], capabilities: { streaming: false, pushNotifications: false },
        defaultInputModes: ['text/plain', 'application/json'], defaultOutputModes: ['application/json'],
        skills: [{ id: 'rideEstimate', name: 'Ride estimate', description: 'Find route endpoints and return provider price estimates.', tags: ['ride', 'estimate'] }, { id: 'calendarPlanning', name: 'Calendar planning', description: 'Request calendar availability from the original PA and compare scheduling scenarios without external calendar writes.', tags: ['calendar', 'scheduling', 'scenario'] }],
        ...profile,
        securitySchemes: { bearer: { httpAuthSecurityScheme: { scheme: 'Bearer' } } }, securityRequirements: [{ schemes: { bearer: { list: [] } } }] });
}
export class A2A {
    tasks;
    card;
    projectResult;
    constructor(tasks, card, projectResult) {
        this.tasks = tasks;
        this.card = card;
        this.projectResult = projectResult;
    }
    user(context) {
        if (!(context.user instanceof AgentUser))
            throw new RequestMalformedError('Authenticated user required');
        return context.user;
    }
    async getAgentCard() { return this.card; }
    async task(operation, cancel = false) {
        try {
            return taskView(await operation(), this.projectResult);
        }
        catch (error) {
            if (error instanceof A2AError)
                throw error;
            const { status, message, requestId } = publicError(error);
            if (status === 404)
                throw new TaskNotFoundError(message);
            if (status === 409 && cancel)
                throw new TaskNotCancelableError(message);
            if (status < 500)
                throw new RequestMalformedError(message);
            throw new Error(requestId ? `${message} (request ID: ${requestId})` : message);
        }
    }
    async sendMessage(params, context) {
        return this.task(async () => {
            const message = params.message;
            if (!message?.messageId)
                throw new RequestMalformedError('Message ID is required');
            const text = message.parts.flatMap(part => part.content?.$case === 'text' ? [part.content.value] : []).join('\n');
            const { principal, authorizeSubmission } = this.user(context);
            const dataPart = message.parts.find(part => part.content?.$case === 'data')?.content;
            const data = dataPart?.$case === 'data' ? dataPart.value : undefined;
            if (message.taskId) {
                if (!data?.paResponse)
                    throw new RequestMalformedError('Continuation requires the PA response for the original task');
                return new PARequests(this.tasks).respond(principal, message.taskId, data.paResponse, message.contextId || undefined, authorizeSubmission);
            }
            if (principal.memberAccess || (data?.action && principal.scopes.includes('ontology:write'))) {
                if (message.parts.length === 1 && data) {
                    const invocation = memberAction.safeParse(data);
                    if (!invocation.success)
                        throw new RequestMalformedError('Provide a published Action and optional result Function');
                    return this.tasks.submit(principal, { requestId: message.messageId, message: 'Execute the selected published Action',
                        conversationId: message.contextId || undefined }, {
                        actionInvocation: invocation.data, authorize: authorizeSubmission,
                    });
                }
                if (!text.trim() || message.parts.some(part => part.content?.$case !== 'text'))
                    throw new RequestMalformedError('Send a text request, a published Action, or a response to the original task');
                return this.tasks.submit(principal, { requestId: message.messageId, message: text,
                    conversationId: message.contextId || undefined }, { assignConversation: true, authorize: authorizeSubmission });
            }
            if (data?.paResponse)
                throw new RequestMalformedError('PA response requires the original taskId');
            return this.tasks.submit(principal, { requestId: message.messageId, message: text || data?.message,
                route: data?.route, classification: data?.classification, conversationId: message.contextId || undefined }, { assignConversation: true });
        });
    }
    async getTask(params, context) {
        return this.task(() => this.tasks.get(this.user(context).principal, params.id));
    }
    async cancelTask(params, context) {
        return this.task(() => this.tasks.cancel(this.user(context).principal, params.id), true);
    }
    async listTasks(_params) { throw new UnsupportedOperationError('Use GetTask with the submitted task ID'); }
    async getAuthenticatedExtendedAgentCard() { throw new ExtendedAgentCardNotConfiguredError(); }
    async *sendMessageStream() { throw new UnsupportedOperationError('Streaming is unavailable'); }
    async *resubscribe() { throw new UnsupportedOperationError('Subscriptions are unavailable'); }
    async createTaskPushNotificationConfig() { throw new PushNotificationNotSupportedError(); }
    async getTaskPushNotificationConfig() { throw new PushNotificationNotSupportedError(); }
    async listTaskPushNotificationConfigs() { throw new PushNotificationNotSupportedError(); }
    async deleteTaskPushNotificationConfig() { throw new PushNotificationNotSupportedError(); }
}
