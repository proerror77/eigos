import type { Installation } from '../../packages/runtime/installation.js';
export declare function startWorker(installation: Installation): Promise<void>;
