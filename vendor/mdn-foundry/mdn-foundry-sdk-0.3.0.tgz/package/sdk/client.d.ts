import type { ObjectData, ObjectRef } from '../ontology/schema.js';
import type { ActionBatchInput, ActionCall, ActionInput } from '../ontology/invocation.js';
import type { ActionLogInput, ActionLogEntry } from './contracts.js';
import type { Query } from './contracts.js';
import type { ScenarioComparisonInput, ScenarioComparison, ScenarioTrialInput, ScenarioTrial } from './contracts.js';
export type { ScenarioComparisonInput, ScenarioComparison, ScenarioTrialInput, ScenarioTrial };
export type { ActionInput } from '../ontology/invocation.js';
export type { ActionBatchInput, ActionCall, ActionLogInput, ActionLogEntry };
export declare class OntologyHttpError extends Error {
    readonly status: number;
    readonly detail: unknown;
    constructor(status: number, detail: unknown);
}
export interface ClientOptions {
    baseUrl: string;
    token: string | (() => string | Promise<string>);
    ontology?: string;
    fetch?: typeof fetch;
}
export interface QueryResult<T = ObjectData> {
    items: T[];
    cursor?: string;
}
export interface ScenarioInfo {
    id: string;
    name: string;
    revision: number;
    state: string;
    expiresAt: string;
}
export interface ScenarioInspection extends ScenarioInfo {
    review?: {
        reviewers: string[];
        canInvite: boolean;
    };
    objects: {
        ref: ObjectRef;
        before: Record<string, unknown> | null;
        after: Record<string, unknown> | null;
        editedFields?: string[];
        conflict: boolean;
    }[];
    links: {
        type: string;
        from: ObjectRef;
        to: ObjectRef;
        removed: boolean;
        conflict: boolean;
    }[];
}
export interface ScenarioReview<Memory = unknown> extends Pick<ScenarioInspection, 'id' | 'name' | 'revision' | 'objects' | 'links'> {
    conflicts: boolean;
    snapshot: string;
    commit?: {
        action: string;
        input: Record<string, unknown>;
        effects: {
            name: string;
            handler: string;
            payload: Record<string, unknown>;
        }[];
    };
    evidence?: {
        ref: ObjectRef;
        revision: number;
    }[];
    evidenceVersion?: string;
    evidenceChanged?: boolean;
    decisionMemory?: Memory;
}
export interface ScenarioReviewItem {
    id: string;
    name: string;
    revision: number;
    conflicts: boolean;
    evidenceChanged?: boolean;
    approved: boolean;
}
export interface ScenarioInput {
    requestId: string;
    name: string;
    description?: string;
    ttlSeconds?: number;
    kind?: 'persisted' | 'temporary';
    sessionId?: string;
}
/** Authenticated HTTP client. Credentials are supplied by the host and remain in its control. */
export declare class OntologyClient {
    private readonly options;
    private readonly base;
    private readonly fetcher;
    constructor(options: ClientOptions);
    get ontology(): string | undefined;
    request<T>(path: string, body?: unknown, signal?: AbortSignal, headers?: Record<string, string>): Promise<T>;
    query<T = ObjectData>(query: Query, options?: {
        scenarioId?: string;
        taskId?: string;
        signal?: AbortSignal;
    }): Promise<QueryResult<T>>;
    evaluateStream<T>(name: string, input: Record<string, unknown>, options?: {
        scenarioId?: string;
        taskId?: string;
        signal?: AbortSignal;
    }): AsyncGenerator<{
        type: 'chunk';
        text: string;
    } | {
        type: 'result';
        value: T;
    }>;
    evaluate<T>(name: string, input: Record<string, unknown>, options?: {
        scenarioId?: string;
        taskId?: string;
        signal?: AbortSignal;
    }): Promise<T>;
    apply(input: ActionInput, options?: {
        scenarioId?: string;
        signal?: AbortSignal;
    }): Promise<ObjectRef>;
    validateAction(input: ActionCall, signal?: AbortSignal): Promise<{
        valid: true;
        phase: 'submission';
        action: string;
        release: string;
    }>;
    applyActionBatch(input: ActionBatchInput, signal?: AbortSignal): Promise<{
        release: string;
        items: {
            requestId: string;
            result: ObjectRef;
        }[];
    }>;
    listActionLog(input?: ActionLogInput, signal?: AbortSignal): Promise<QueryResult<ActionLogEntry> & {
        release: string;
    }>;
    service<T>(operation: string, input: Record<string, unknown>, signal?: AbortSignal): Promise<T>;
    createScenario(input: ScenarioInput, signal?: AbortSignal): Promise<ScenarioClient>;
    compareScenarios(input: ScenarioComparisonInput, signal?: AbortSignal): Promise<ScenarioComparison>;
    trialScenarios(input: ScenarioTrialInput, signal?: AbortSignal): Promise<ScenarioTrial>;
    pendingScenarioReviews(page?: number, signal?: AbortSignal): Promise<{
        items: ScenarioReviewItem[];
        nextPage?: number;
    }>;
    scenario(id: string, sessionId?: string): ScenarioClient;
    describe(signal?: AbortSignal): Promise<{
        id: string;
        version: string;
        classification?: {
            sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
            compartments: string[];
        } | undefined;
        sharedProperties?: {
            typeClasses?: {
                kind: string;
                name: string;
            }[] | undefined;
            renderHints?: Record<string, string | number | boolean> | undefined;
            status?: "active" | "deprecated" | "experimental" | undefined;
            classification?: {
                sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                compartments: string[];
            } | undefined;
            description: string;
            schema: Record<string, unknown>;
            required: boolean;
            sharedProperty?: string | undefined;
            valueType?: {
                name: string;
                version: string;
            } | undefined;
            struct?: {
                type: string;
                mainField?: string | undefined;
                reducer?: {
                    op: "first" | "last" | "max" | "min";
                    field?: string | undefined;
                } | undefined;
                array?: boolean | undefined;
            } | undefined;
            format?: {
                kind: "currency" | "date" | "number" | "percent" | "text";
                locale?: string | undefined;
                currency?: string | undefined;
                minimumFractionDigits?: number | undefined;
                maximumFractionDigits?: number | undefined;
            } | undefined;
            derived?: import("../ontology/schema.js").DerivedExpression | undefined;
            apiName: string;
        }[] | undefined;
        valueTypes?: {
            typeClasses?: {
                kind: string;
                name: string;
            }[] | undefined;
            renderHints?: Record<string, string | number | boolean> | undefined;
            status?: "active" | "deprecated" | "experimental" | undefined;
            classification?: {
                sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                compartments: string[];
            } | undefined;
            apiName: string;
            version: string;
            description: string;
            schema: Record<string, unknown>;
        }[] | undefined;
        structTypes?: {
            typeClasses?: {
                kind: string;
                name: string;
            }[] | undefined;
            renderHints?: Record<string, string | number | boolean> | undefined;
            status?: "active" | "deprecated" | "experimental" | undefined;
            classification?: {
                sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                compartments: string[];
            } | undefined;
            apiName: string;
            description: string;
            fields: Record<string, Record<string, unknown>>;
            required?: string[] | undefined;
            mainField?: string | undefined;
        }[] | undefined;
        typeGroups?: {
            apiName: string;
            displayName: string;
            description: string;
            objectTypes: string[];
        }[] | undefined;
        agentProfiles?: {
            apiName: string;
            terms: string[];
            objects?: string[] | undefined;
            interfaces?: string[] | undefined;
            actions?: string[] | undefined;
            functions?: string[] | undefined;
            sources?: string[] | undefined;
            links?: string[] | undefined;
            instructions?: {
                action?: string | undefined;
                function?: string | undefined;
                text: string;
            }[] | undefined;
        }[] | undefined;
        imports?: {
            ontology: string;
            version: string;
            digest: string;
            namespace: string;
            document: unknown;
        }[] | undefined;
        objectTypes: {
            typeClasses?: {
                kind: string;
                name: string;
            }[] | undefined;
            renderHints?: Record<string, string | number | boolean> | undefined;
            status?: "active" | "deprecated" | "experimental" | undefined;
            classification?: {
                sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                compartments: string[];
            } | undefined;
            apiName: string;
            displayName: string;
            description: string;
            primaryKey: string;
            titleProperty: string;
            properties: Record<string, {
                typeClasses?: {
                    kind: string;
                    name: string;
                }[] | undefined;
                renderHints?: Record<string, string | number | boolean> | undefined;
                status?: "active" | "deprecated" | "experimental" | undefined;
                classification?: {
                    sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                    compartments: string[];
                } | undefined;
                description: string;
                schema: Record<string, unknown>;
                required: boolean;
                sharedProperty?: string | undefined;
                valueType?: {
                    name: string;
                    version: string;
                } | undefined;
                struct?: {
                    type: string;
                    mainField?: string | undefined;
                    reducer?: {
                        op: "first" | "last" | "max" | "min";
                        field?: string | undefined;
                    } | undefined;
                    array?: boolean | undefined;
                } | undefined;
                format?: {
                    kind: "currency" | "date" | "number" | "percent" | "text";
                    locale?: string | undefined;
                    currency?: string | undefined;
                    minimumFractionDigits?: number | undefined;
                    maximumFractionDigits?: number | undefined;
                } | undefined;
                derived?: import("../ontology/schema.js").DerivedExpression | undefined;
            }>;
            machinery?: {
                states: {
                    name: string;
                    terminal?: boolean | undefined;
                    dwellSeconds?: number | undefined;
                }[];
                transitions: {
                    from: string | null;
                    to: string | null;
                    action?: string | undefined;
                    execution?: {
                        subject: string;
                        parameters?: Record<string, string> | undefined;
                        requires?: {
                            process: string;
                            link?: string | undefined;
                            states: string[];
                            match: "all" | "any";
                        }[] | undefined;
                    } | undefined;
                }[];
                subprocesses?: {
                    link: string;
                    process: string;
                }[] | undefined;
                parallel?: string[] | undefined;
                metrics?: {
                    node?: {
                        label: string;
                        aggregation: {
                            op: "count";
                        } | {
                            op: "avg" | "max" | "min" | "sum";
                            property: string;
                        };
                        decimals?: number | undefined;
                        unit?: string | undefined;
                        colors?: {
                            min: number;
                            color: "amber" | "green" | "red";
                        }[] | undefined;
                    } | undefined;
                    edge?: {
                        label: string;
                        aggregation: {
                            op: "count";
                        } | {
                            op: "avg" | "max" | "min" | "sum";
                            property: string;
                        };
                        decimals?: number | undefined;
                        unit?: string | undefined;
                        colors?: {
                            min: number;
                            color: "amber" | "green" | "red";
                        }[] | undefined;
                    } | undefined;
                } | undefined;
            } | undefined;
            classificationProperty?: string | undefined;
            groups?: string[] | undefined;
            interfaces: Record<string, {
                properties: Record<string, string>;
                links: Record<string, string>;
                actions: Record<string, {
                    action: string;
                    parameters: Record<string, string>;
                }>;
            }>;
        }[];
        interfaceTypes: {
            typeClasses?: {
                kind: string;
                name: string;
            }[] | undefined;
            renderHints?: Record<string, string | number | boolean> | undefined;
            status?: "active" | "deprecated" | "experimental" | undefined;
            classification?: {
                sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                compartments: string[];
            } | undefined;
            apiName: string;
            description: string;
            properties: Record<string, {
                typeClasses?: {
                    kind: string;
                    name: string;
                }[] | undefined;
                renderHints?: Record<string, string | number | boolean> | undefined;
                status?: "active" | "deprecated" | "experimental" | undefined;
                classification?: {
                    sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                    compartments: string[];
                } | undefined;
                description: string;
                schema: Record<string, unknown>;
                required: boolean;
                sharedProperty?: string | undefined;
                valueType?: {
                    name: string;
                    version: string;
                } | undefined;
                struct?: {
                    type: string;
                    mainField?: string | undefined;
                    reducer?: {
                        op: "first" | "last" | "max" | "min";
                        field?: string | undefined;
                    } | undefined;
                    array?: boolean | undefined;
                } | undefined;
                format?: {
                    kind: "currency" | "date" | "number" | "percent" | "text";
                    locale?: string | undefined;
                    currency?: string | undefined;
                    minimumFractionDigits?: number | undefined;
                    maximumFractionDigits?: number | undefined;
                } | undefined;
                derived?: import("../ontology/schema.js").DerivedExpression | undefined;
            }>;
            extends?: string[] | undefined;
            optionalProperties: string[];
            links: Record<string, {
                target: string;
                cardinality: "many" | "one";
                required: boolean;
            }>;
            actions: Record<string, {
                parameters: Record<string, unknown>;
                objectParameters: Record<string, string>;
                required: boolean;
            }>;
        }[];
        linkTypes: {
            typeClasses?: {
                kind: string;
                name: string;
            }[] | undefined;
            renderHints?: Record<string, string | number | boolean> | undefined;
            status?: "active" | "deprecated" | "experimental" | undefined;
            classification?: {
                sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                compartments: string[];
            } | undefined;
            apiName: string;
            description: string;
            from: {
                type: string;
                name: string;
                cardinality: "many" | "one";
            };
            to: {
                type: string;
                name: string;
                cardinality: "many" | "one";
            };
            properties?: Record<string, {
                typeClasses?: {
                    kind: string;
                    name: string;
                }[] | undefined;
                renderHints?: Record<string, string | number | boolean> | undefined;
                status?: "active" | "deprecated" | "experimental" | undefined;
                classification?: {
                    sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                    compartments: string[];
                } | undefined;
                description: string;
                schema: Record<string, unknown>;
                required: boolean;
                sharedProperty?: string | undefined;
                valueType?: {
                    name: string;
                    version: string;
                } | undefined;
                struct?: {
                    type: string;
                    mainField?: string | undefined;
                    reducer?: {
                        op: "first" | "last" | "max" | "min";
                        field?: string | undefined;
                    } | undefined;
                    array?: boolean | undefined;
                } | undefined;
                format?: {
                    kind: "currency" | "date" | "number" | "percent" | "text";
                    locale?: string | undefined;
                    currency?: string | undefined;
                    minimumFractionDigits?: number | undefined;
                    maximumFractionDigits?: number | undefined;
                } | undefined;
                derived?: import("../ontology/schema.js").DerivedExpression | undefined;
            }> | undefined;
        }[];
        functionTypes: {
            typeClasses?: {
                kind: string;
                name: string;
            }[] | undefined;
            renderHints?: Record<string, string | number | boolean> | undefined;
            status?: "active" | "deprecated" | "experimental" | undefined;
            classification?: {
                sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                compartments: string[];
            } | undefined;
            apiName: string;
            description: string;
            parameters: Record<string, unknown>;
            returns: Record<string, unknown>;
            source?: string | undefined;
            edits?: boolean | undefined;
            version?: string | undefined;
            kind?: "model" | undefined;
            dependencies?: {
                objectTypes?: string[] | undefined;
                interfaceTypes?: string[] | undefined;
                linkTypes?: string[] | undefined;
                functions?: string[] | undefined;
                dataSources?: string[] | undefined;
                actions?: string[] | undefined;
            } | undefined;
            implementation?: {
                kind: "component";
                models?: string[] | undefined;
                stream?: "text" | undefined;
                sha256: string;
                limits: {
                    fuel: number;
                    memoryMb: number;
                    deadlineMs: number;
                    inputBytes?: number | undefined;
                    outputBytes?: number | undefined;
                };
            } | undefined;
        }[];
        actionTypes: {
            typeClasses?: {
                kind: string;
                name: string;
            }[] | undefined;
            renderHints?: Record<string, string | number | boolean> | undefined;
            status?: "active" | "deprecated" | "experimental" | undefined;
            classification?: {
                sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                compartments: string[];
            } | undefined;
            apiName: string;
            description: string;
            parameters: Record<string, unknown>;
            objectParameters: Record<string, string>;
            submissionCriteria: {
                function: string;
                arguments: Record<string, {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                }>;
                message?: string | undefined;
                functionVersion?: string | undefined;
                executionContext?: "live" | "scenario" | undefined;
            }[];
            rules?: ({
                op: "createObject";
                object: {
                    type: string;
                    id: {
                        parameter: string;
                        path?: string[] | undefined;
                    } | {
                        literal: unknown;
                    };
                };
                properties: Record<string, {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                }>;
            } | {
                op: "editObject";
                object: {
                    parameter: string;
                    path?: string[] | undefined;
                };
                expectedRevision: {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                };
                properties: Record<string, {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                }>;
                expectedProperties?: Record<string, {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                }> | undefined;
            } | {
                op: "addLink";
                link: string;
                from: {
                    type: string;
                    id: {
                        parameter: string;
                        path?: string[] | undefined;
                    } | {
                        literal: unknown;
                    };
                };
                to: {
                    type: string;
                    id: {
                        parameter: string;
                        path?: string[] | undefined;
                    } | {
                        literal: unknown;
                    };
                };
            } | {
                op: "removeLink";
                link: string;
                from: {
                    type: string;
                    id: {
                        parameter: string;
                        path?: string[] | undefined;
                    } | {
                        literal: unknown;
                    };
                };
                to: {
                    type: string;
                    id: {
                        parameter: string;
                        path?: string[] | undefined;
                    } | {
                        literal: unknown;
                    };
                };
            } | {
                op: "deleteObject";
                object: {
                    parameter: string;
                    path?: string[] | undefined;
                };
                expectedRevision: {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                };
            } | {
                op: "editStruct";
                object: {
                    parameter: string;
                    path?: string[] | undefined;
                };
                expectedRevision: {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                };
                property: string;
                fields: Record<string, {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                }>;
            } | {
                op: "applyScenario";
                scenario: {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                };
                expectedRevision: {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                };
                objectTypes: string[];
                linkTypes: string[];
            } | {
                op: "reviewScenario";
                scenario: {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                };
                expectedRevision: {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                };
                review: {
                    kind: "submit";
                    reviewers: {
                        parameter: string;
                        path?: string[] | undefined;
                    } | {
                        literal: unknown;
                    };
                    authorizeMerge?: {
                        parameter: string;
                        path?: string[] | undefined;
                    } | {
                        literal: unknown;
                    } | undefined;
                } | {
                    kind: "approve";
                    snapshot: {
                        parameter: string;
                        path?: string[] | undefined;
                    } | {
                        literal: unknown;
                    };
                    decision?: {
                        parameter: string;
                        path?: string[] | undefined;
                    } | {
                        literal: unknown;
                    } | undefined;
                    applyAuthorizedMerge?: true | undefined;
                } | {
                    kind: "reject";
                    snapshot: {
                        parameter: string;
                        path?: string[] | undefined;
                    } | {
                        literal: unknown;
                    };
                };
            })[] | undefined;
            result?: {
                type: string;
                id: {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                };
            } | undefined;
            function?: string | undefined;
            functionVersion?: string | undefined;
            effects?: ({
                name: string;
                handler: string;
                payload: Record<string, {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                }>;
            } | {
                name: string;
                webhook: {
                    source: string;
                    method: "DELETE" | "PATCH" | "POST" | "PUT";
                    path: string;
                    function?: string | undefined;
                };
                payload: Record<string, {
                    parameter: string;
                    path?: string[] | undefined;
                } | {
                    literal: unknown;
                }>;
            })[] | undefined;
            reservation?: {
                holderParameter: string;
                allocationsParameter: string;
                state: "committed" | "held" | "released";
                sharedSource?: string | undefined;
                confirmationEffect?: string | undefined;
            } | undefined;
        }[];
        dataSources: {
            apiName: string;
            objectType: string;
            function: string;
            classification?: {
                sensitivity: "CONFIDENTIAL" | "INTERNAL" | "PUBLIC" | "RESTRICTED";
                compartments: string[];
            } | undefined;
            properties: Record<string, string>;
        }[];
    }>;
    listScenarios(cursor?: string, signal?: AbortSignal): Promise<QueryResult<ScenarioInfo>>;
    openSession(ttlSeconds?: number, signal?: AbortSignal): Promise<{
        id: string;
        expiresAt: string;
    }>;
    closeSession(sessionId: string, signal?: AbortSignal): Promise<{
        sessionId: string;
        closed: boolean;
    }>;
    undo(originalRequestId: string, requestId: string, signal?: AbortSignal): Promise<{
        requestId: string;
        originalRequestId: string;
        result: ObjectRef;
        externalEffectsReversed: false;
    }>;
}
export declare class ScenarioClient {
    private readonly client;
    readonly id: string;
    readonly sessionId?: string | undefined;
    constructor(client: OntologyClient, id: string, sessionId?: string | undefined);
    query<T = ObjectData>(query: Query, signal?: AbortSignal): Promise<QueryResult<T>>;
    evaluate<T>(name: string, input: Record<string, unknown>, signal?: AbortSignal): Promise<T>;
    apply(input: ActionInput, signal?: AbortSignal): Promise<{
        type: string;
        id: string;
    }>;
    inspect(signal?: AbortSignal): Promise<ScenarioInspection>;
    discard(revision: number, signal?: AbortSignal): Promise<ScenarioInfo>;
    share(revision: number, readers: string[], signal?: AbortSignal): Promise<{
        id: string;
        revision: number;
        readers: string[];
    }>;
    rebase(revision: number, signal?: AbortSignal): Promise<{
        id: string;
        revision: number;
    }>;
    inviteReviewers(revision: number, reviewers: string[], signal?: AbortSignal): Promise<{
        id: string;
        revision: number;
        reviewers: string[];
    }>;
    inspectReview<Memory = unknown>(signal?: AbortSignal): Promise<ScenarioReview<Memory>>;
    approveReview(revision: number, snapshot: string, options?: AbortSignal | {
        signal?: AbortSignal;
        decision: Record<string, unknown>;
    }): Promise<{
        id: string;
        revision: number;
        reviewer: string;
        approved: true;
    }>;
    rejectReview(revision: number, snapshot: string, signal?: AbortSignal): Promise<{
        id: string;
        revision: number;
        reviewer: string;
        rejected: true;
    }>;
    /** Authorize one exact published merge. Its input must target the revision created by this submission. */
    submitForMerge(revision: number, reviewers: string[], merge: {
        action: string;
        input: Record<string, unknown>;
    }, requestId: string, signal?: AbortSignal): Promise<{
        type: string;
        id: string;
    }>;
    approveAndMerge(revision: number, snapshot: string, requestId: string, options?: {
        signal?: AbortSignal;
        decision?: Record<string, unknown>;
    }): Promise<{
        type: string;
        id: string;
    }>;
    /** Merge Actions conventionally bind scenarioId and the explicitly reviewed revision. */
    merge(action: string, requestId: string, revision: number, input?: Record<string, unknown>, signal?: AbortSignal): Promise<{
        type: string;
        id: string;
    }>;
    closeSession(signal?: AbortSignal): Promise<{
        sessionId: string;
        closed: boolean;
    }>;
}
