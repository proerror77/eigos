/** Fluent, immutable typed ObjectSet query builder over OntologyClient.query(). */
export class TypedObjectSet {
    client;
    spec;
    constructor(client, spec) {
        this.client = client;
        this.spec = spec;
    }
    where(where) {
        const merged = { ...(this.spec.where ?? {}) };
        for (const [key, value] of Object.entries(where)) {
            if (value !== undefined)
                merged[key] = value;
        }
        return new TypedObjectSet(this.client, { ...this.spec, where: merged });
    }
    filter(filter) {
        return new TypedObjectSet(this.client, { ...this.spec, filter });
    }
    orderBy(orderBy) {
        return new TypedObjectSet(this.client, { ...this.spec, orderBy });
    }
    select(select) {
        return new TypedObjectSet(this.client, { ...this.spec, select });
    }
    limit(limit) {
        return new TypedObjectSet(this.client, { ...this.spec, limit });
    }
    cursor(cursor) {
        return new TypedObjectSet(this.client, { ...this.spec, cursor });
    }
    from(object, link, as) {
        return new TypedObjectSet(this.client, {
            ...this.spec,
            from: { object, link, ...(as ? { as } : {}) },
        });
    }
    fetch(options) {
        return this.client.query(this.spec, options);
    }
    async all(options) {
        const items = [];
        let cursor = this.spec.cursor;
        for (;;) {
            const page = await this.client.query(cursor === undefined ? this.spec : { ...this.spec, cursor }, options);
            items.push(...page.items);
            if (!page.cursor)
                return items;
            cursor = page.cursor;
        }
    }
}
/** A TypeScript view of the existing client, parameterized by a published definition's generated types. */
export class TypedOntologyClient {
    client;
    linkTargets;
    constructor(client, linkTargets) {
        this.client = client;
        this.linkTargets = linkTargets;
    }
    query(query, options) {
        return this.client.query(query, options);
    }
    objectSet(type) {
        return new TypedObjectSet(this.client, { type });
    }
    follow(from, link, query = {}, options) {
        const targetType = query.type ?? this.linkTargets?.[from.type]?.[link];
        if (!targetType)
            throw new Error(`Target type is required to follow ${from.type}.${link}`);
        const { type: _type, as, ...rest } = query;
        return this.client.query({ ...rest, type: targetType, from: { object: from, link, ...(as ? { as } : {}) } }, options);
    }
    queryInterface(query, options) {
        return this.client.query(query, options);
    }
    applyInterfaceAction(target, input, requestId, options) {
        return this.client.apply({ interface: target, input, requestId }, options);
    }
    evaluate(name, input, options) {
        return this.client.evaluate(name, input, options);
    }
    apply(action, input, requestId, options) {
        return this.client.apply({ action, input, requestId }, options);
    }
    validateAction(action, input, options = {}) {
        return this.client.validateAction({ action, input, scenarioId: options.scenarioId }, options.signal);
    }
    applyActionBatch(actions, signal) {
        return this.client.applyActionBatch({ actions }, signal);
    }
}
