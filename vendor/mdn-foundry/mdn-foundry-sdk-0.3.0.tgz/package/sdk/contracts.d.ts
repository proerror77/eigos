import type { ObjectRef } from '../ontology/schema.js';
type Scalar = string | number | boolean | null;
export interface Query {
    type: string;
    where?: Record<string, Scalar>;
    filter?: unknown;
    orderBy?: {
        property: string;
        direction?: 'asc' | 'desc';
    }[];
    intervalOverlap?: {
        start: string;
        end: string;
        from: string;
        until: string;
        includeUnknown?: boolean;
    };
    select?: string[];
    limit?: number;
    cursor?: string;
    from?: {
        object: ObjectRef;
        link: string;
        as?: string;
    };
}
export type ActionLogInput = {
    action?: string;
    release?: string;
    cursor?: string;
    limit?: number;
};
export interface ActionLogEntry {
    requestId: string;
    action: string;
    appliedAt: string;
    executorKind: string | null;
}
type FunctionMetric = {
    name: string;
    function: string;
    path: (string | number)[];
};
type BoundInput = Record<string, {
    value: unknown;
} | {
    input: string;
} | {
    result: string;
}>;
type Evidence = {
    object: ObjectRef;
    revision: number;
};
type Changes = {
    objectsCreated: number;
    objectsEdited: number;
    objectsDeleted: number;
    linksAdded: number;
    linksRemoved: number;
    conflicts: boolean;
};
export type ScenarioComparisonInput = {
    scenarios: {
        id: string;
        revision: number;
    }[];
    aggregates?: {
        set: unknown;
        view?: string;
        groupBy?: string[];
        metrics: Record<string, {
            op: 'count';
            property?: string;
        } | {
            op: 'sum' | 'min' | 'max' | 'avg';
            property: string;
        }>;
    }[];
    metrics?: (FunctionMetric & {
        input: Record<string, unknown>;
    })[];
};
type Measurements = {
    metrics: Record<string, Scalar>;
    aggregates: {
        count: number;
        items: {
            group: Record<string, unknown>;
            metrics: Record<string, number | null>;
        }[];
    }[];
};
export interface ScenarioComparison {
    release: string;
    evaluatedAt: string;
    baseline: Measurements;
    scenarios: (Measurements & {
        id: string;
        name: string;
        revision: number;
        changes: Changes;
        preview: {
            objects: {
                ref: ObjectRef;
                before: Record<string, unknown> | null;
                after: Record<string, unknown> | null;
                editedFields: string[];
                conflict: boolean;
            }[];
            links: {
                type: string;
                from: ObjectRef;
                to: ObjectRef;
                removed: boolean;
                conflict: boolean;
            }[];
        };
    })[];
}
export type ScenarioTrialInput = {
    cases: {
        name: string;
        inputs: Record<string, unknown>;
        evaluatedAt?: string;
        evidence: Evidence[];
    }[];
    variants: {
        name: string;
        steps: ({
            kind: 'action';
            name: string;
            action: string;
            input: BoundInput;
        } | (FunctionMetric & {
            kind: 'check';
            input: BoundInput;
            equals: Scalar;
        }))[];
    }[];
    metrics: (FunctionMetric & {
        input: BoundInput;
    })[];
};
type EvaluationStep = {
    name: string;
    operation: string;
    status: 'completed' | 'rejected';
    value?: Scalar | ObjectRef;
};
export interface ScenarioTrial {
    mode: 'offline';
    release: string;
    evaluatedAt: string;
    experimentDigest: string;
    cases: {
        name: string;
        evidence: Evidence[];
        evaluatedAt: string;
        inputDigest: string;
        variants: ({
            name: string;
            status: 'completed';
            steps: EvaluationStep[];
            metrics: Record<string, Scalar>;
            changes: Changes;
        } | {
            name: string;
            status: 'rejected';
            reason: string;
            steps: EvaluationStep[];
        })[];
    }[];
    summary: {
        name: string;
        completed: number;
        rejected: number;
        attemptedSteps: number;
    }[];
}
export {};
