import { sseData } from './event-stream.js';
export class OntologyHttpError extends Error {
    status;
    detail;
    constructor(status, detail) {
        super(typeof detail === 'object' && detail !== null && 'error' in detail
            ? String(detail.error)
            : `Ontology request failed (${status})`);
        this.status = status;
        this.detail = detail;
        this.name = 'OntologyHttpError';
    }
}
/** Authenticated HTTP client. Credentials are supplied by the host and remain in its control. */
export class OntologyClient {
    options;
    base;
    fetcher;
    constructor(options) {
        this.options = options;
        this.base = new URL(options.baseUrl.endsWith('/') ? options.baseUrl : options.baseUrl + '/');
        if (!['https:', 'http:'].includes(this.base.protocol))
            throw new Error('Ontology URL must use HTTP or HTTPS');
        this.fetcher = options.fetch ?? globalThis.fetch;
    }
    get ontology() {
        return this.options.ontology;
    }
    async request(path, body, signal, headers) {
        const url = new URL(path, this.base);
        if (url.origin !== this.base.origin || !url.pathname.startsWith(this.base.pathname))
            throw new Error('Request must target the configured gateway');
        const token = typeof this.options.token === 'function' ? await this.options.token() : this.options.token;
        const response = await this.fetcher(url, {
            method: body === undefined ? 'GET' : 'POST',
            headers: {
                ...headers,
                Authorization: `Bearer ${token}`,
                Accept: 'application/json',
                ...(body === undefined ? {} : { 'Content-Type': 'application/json' }),
            },
            body: body === undefined ? undefined : JSON.stringify(body),
            signal,
        });
        const text = await response.text();
        let value;
        try {
            value = text ? JSON.parse(text) : null;
        }
        catch {
            throw new OntologyHttpError(response.status, { error: 'Ontology response was not JSON' });
        }
        if (!response.ok)
            throw new OntologyHttpError(response.status, value);
        return value;
    }
    query(query, options = {}) {
        const { signal, ...scope } = options;
        return this.request('ontology/query', { query, ontology: this.ontology, ...scope }, signal);
    }
    async *evaluateStream(name, input, options = {}) {
        const token = typeof this.options.token === 'function' ? await this.options.token() : this.options.token;
        const response = await this.fetcher(new URL('ontology/functions', this.base), {
            method: 'POST', signal: options.signal, headers: { Authorization: `Bearer ${token}`, Accept: 'text/event-stream', 'Content-Type': 'application/json' },
            body: JSON.stringify({ function: name, input, ontology: this.ontology, taskId: options.taskId, scenarioId: options.scenarioId }),
        });
        if (!response.ok)
            throw new OntologyHttpError(response.status, await response.json().catch(() => ({})));
        for await (const raw of sseData(response, 16 << 20)) {
            const item = JSON.parse(raw);
            if (item.type === 'chunk' && typeof item.text === 'string')
                yield { type: 'chunk', text: item.text };
            else if (item.type === 'result' && Object.hasOwn(item, 'value')) {
                yield { type: 'result', value: item.value };
                return;
            }
            else
                throw new Error('Function stream failed');
        }
        throw new Error('Incomplete Function stream');
    }
    evaluate(name, input, options = {}) {
        const { signal, ...scope } = options;
        return this.request('ontology/functions', { function: name, input, ontology: this.ontology, ...scope }, signal);
    }
    apply(input, options = {}) {
        const { signal, ...scope } = options;
        return this.request('ontology/actions', { ...input, ontology: this.ontology, ...scope }, signal);
    }
    validateAction(input, signal) {
        return this.service('validate_action', input, signal);
    }
    applyActionBatch(input, signal) {
        return this.service('apply_action_batch', input, signal);
    }
    listActionLog(input = {}, signal) {
        return this.service('list_action_log', input, signal);
    }
    service(operation, input, signal) {
        return this.request(`ontology/services/${encodeURIComponent(operation)}`, { ...input, _ontology: this.ontology }, signal);
    }
    async createScenario(input, signal) {
        const result = await this.request('ontology/scenarios', { ...input, ontology: this.ontology }, signal);
        return this.scenario(result.id, input.sessionId);
    }
    compareScenarios(input, signal) {
        return this.service('compare_scenarios', input, signal);
    }
    trialScenarios(input, signal) {
        return this.service('trial_scenarios', input, signal);
    }
    pendingScenarioReviews(page = 1, signal) {
        return this.service('pending_scenario_reviews', { page }, signal);
    }
    scenario(id, sessionId) {
        return new ScenarioClient(this, id, sessionId);
    }
    describe(signal) {
        return this.request('ontology' + (this.ontology ? '?ontology=' + encodeURIComponent(this.ontology) : ''), undefined, signal);
    }
    async listScenarios(cursor, signal) {
        const parameters = new URLSearchParams();
        if (this.ontology)
            parameters.set('ontology', this.ontology);
        if (cursor)
            parameters.set('cursor', cursor);
        const result = await this.request('ontology/scenarios' + (parameters.size ? '?' + parameters : ''), undefined, signal);
        return {
            ...result,
            items: result.items.map((row) => ({
                id: row.id,
                name: row.name,
                revision: Number(row.revision),
                state: row.state,
                expiresAt: row.expiresAt ?? row.expires_at,
            })),
        };
    }
    async openSession(ttlSeconds = 3600, signal) {
        return this.service('open_scenario_session', { ttlSeconds }, signal);
    }
    closeSession(sessionId, signal) {
        return this.service('close_scenario_session', { sessionId }, signal);
    }
    undo(originalRequestId, requestId, signal) {
        return this.service('undo_action', { originalRequestId, requestId }, signal);
    }
}
export class ScenarioClient {
    client;
    id;
    sessionId;
    constructor(client, id, sessionId) {
        this.client = client;
        this.id = id;
        this.sessionId = sessionId;
    }
    query(query, signal) {
        return this.client.query(query, { scenarioId: this.id, signal });
    }
    evaluate(name, input, signal) {
        return this.client.evaluate(name, input, { scenarioId: this.id, signal });
    }
    apply(input, signal) {
        return this.client.apply(input, { scenarioId: this.id, signal });
    }
    inspect(signal) {
        const search = this.client.ontology ? '?ontology=' + encodeURIComponent(this.client.ontology) : '';
        return this.client.request(`ontology/scenarios/${encodeURIComponent(this.id)}${search}`, undefined, signal);
    }
    discard(revision, signal) {
        return this.client.request(`ontology/scenarios/${encodeURIComponent(this.id)}/discard`, { revision, ontology: this.client.ontology }, signal);
    }
    share(revision, readers, signal) {
        return this.client.service('share_scenario', { id: this.id, revision, readers }, signal);
    }
    rebase(revision, signal) {
        return this.client.service('rebase_scenario', { id: this.id, revision }, signal);
    }
    inviteReviewers(revision, reviewers, signal) {
        return this.client.service('invite_scenario_reviewers', { id: this.id, revision, reviewers }, signal);
    }
    inspectReview(signal) {
        return this.client.service('inspect_scenario_review', { id: this.id }, signal);
    }
    approveReview(revision, snapshot, options) {
        const review = options && 'decision' in options ? options : { signal: options };
        return this.client.service('approve_scenario_review', { id: this.id, revision, snapshot, decision: review.decision }, review.signal);
    }
    rejectReview(revision, snapshot, signal) {
        return this.client.service('reject_scenario_review', { id: this.id, revision, snapshot }, signal);
    }
    /** Authorize one exact published merge. Its input must target the revision created by this submission. */
    submitForMerge(revision, reviewers, merge, requestId, signal) {
        return this.client.apply({ action: 'SubmitScenarioReviewForMerge', requestId, input: { id: this.id, revision, reviewers, merge } }, { signal });
    }
    approveAndMerge(revision, snapshot, requestId, options = {}) {
        return this.client.apply({ action: 'ApproveAndMergeScenarioReview', requestId,
            input: { id: this.id, revision, snapshot, ...(options.decision ? { decision: options.decision } : {}) } }, { signal: options.signal });
    }
    /** Merge Actions conventionally bind scenarioId and the explicitly reviewed revision. */
    merge(action, requestId, revision, input = {}, signal) {
        return this.client.apply({ action, requestId, input: { ...input, scenarioId: this.id, revision } }, { signal });
    }
    closeSession(signal) {
        if (!this.sessionId)
            throw new Error('This scenario is not attached to a temporary session');
        return this.client.closeSession(this.sessionId, signal);
    }
}
