const record = (value) => Boolean(value && typeof value === 'object' && !Array.isArray(value));
const literal = (value) => value === null || typeof value === 'boolean' || typeof value === 'number' || typeof value === 'string'
    ? JSON.stringify(value) : 'unknown';
const joined = (parts, operator) => parts.length === 1 ? parts[0] : '(' + parts.join(operator) + ')';
function fields(entries) {
    return Object.entries(entries).map(([key, field]) => `${JSON.stringify(key)}${field.required ? '' : '?'}: ${field.type};`).join(' ');
}
function shape(schema) {
    const properties = record(schema.properties) ? schema.properties : {};
    const required = new Set(Array.isArray(schema.required) ? schema.required : []);
    const members = Object.fromEntries(Object.entries(properties).map(([key, value]) => [key, { type: schemaType(value), required: required.has(key) }]));
    if (!Object.keys(members).length)
        return `Record<string, ${schema.additionalProperties === false ? 'never' : schemaType(schema.additionalProperties)}>`;
    const extra = schema.additionalProperties === false ? '' : ' [key: string]: unknown;';
    return `{ ${fields(members)}${extra} }`;
}
function schemaType(raw) {
    if (raw === false)
        return 'never';
    if (!record(raw))
        return 'unknown';
    if (Object.hasOwn(raw, 'const'))
        return literal(raw.const);
    if (Array.isArray(raw.enum) && raw.enum.length)
        return joined(raw.enum.map(literal), ' | ');
    if (Array.isArray(raw.type) && raw.type.length)
        return joined(raw.type.map(type => schemaType({ ...raw, type })), ' | ');
    const alternatives = Array.isArray(raw.oneOf) ? raw.oneOf : raw.anyOf;
    if (Array.isArray(alternatives) && alternatives.length)
        return joined(alternatives.map(schemaType), ' | ');
    if (Array.isArray(raw.allOf) && raw.allOf.length)
        return joined(raw.allOf.map(schemaType), ' & ');
    switch (raw.type) {
        case 'string':
        case 'boolean':
        case 'null': return raw.type;
        case 'number':
        case 'integer': return 'number';
        case 'array': return `Array<${schemaType(raw.items)}>`;
        case 'object': return shape(raw);
        default: return 'unknown';
    }
}
function inputType(schema) {
    // The invocation transports always require an argument object.
    return `Arguments<${schemaType(schema)}>`;
}
function whereFields(props) {
    const members = Object.fromEntries(Object.entries(props).map(([key, value]) => [key, { type: `WhereValue<${schemaType(value.schema)}>`, required: false }]));
    return `{ ${fields(members)} }`;
}
/** Select resources from an already authorized definition. Keep the server's access check on every call. */
export function generateOntologyTypes(document, selection) {
    const { id, version, objectTypes, interfaceTypes, linkTypes, actionTypes, functionTypes } = document;
    const selected = (resources, names) => {
        if (!names)
            return resources;
        const allowed = new Set(names);
        const result = resources.filter(resource => allowed.has(resource.apiName));
        if (result.length !== allowed.size)
            throw new Error('Requested SDK resource is unavailable');
        return result;
    };
    const chosenObjects = selected(objectTypes, selection?.objects);
    const chosenObjectNames = new Set(chosenObjects.map(type => type.apiName));
    const objects = chosenObjects.map(type => {
        const members = Object.fromEntries(Object.entries(type.properties).map(([key, value]) => [key, { type: schemaType(value.schema), required: value.required }]));
        return `${JSON.stringify(type.apiName)}: { ${fields(members)} };`;
    });
    const interfaces = interfaceTypes.map(iface => {
        const optional = new Set(iface.optionalProperties);
        const propMembers = Object.fromEntries(Object.entries(iface.properties).map(([key, value]) => [key, { type: schemaType(value.schema), required: value.required && !optional.has(key) }]));
        const actionMembers = Object.entries(iface.actions).sort(([a], [b]) => a.localeCompare(b)).map(([alias, constraint]) => `${JSON.stringify(alias)}: ${inputType(constraint.parameters)};`).join(' ');
        const linkMembers = Object.entries(iface.links).sort(([a], [b]) => a.localeCompare(b)).map(([alias, constraint]) => `${JSON.stringify(alias)}: { target: ${JSON.stringify(constraint.target)}; cardinality: ${JSON.stringify(constraint.cardinality)}; };`).join(' ');
        return `${JSON.stringify(iface.apiName)}: { properties: { ${fields(propMembers)} }; actions: { ${actionMembers} }; links: { ${linkMembers} }; };`;
    });
    const linkMap = new Map();
    const targetMap = {};
    const addLink = (source, relName, entry, target) => {
        const list = linkMap.get(source) ?? [];
        list.push(`${JSON.stringify(relName)}: ${entry};`);
        linkMap.set(source, list);
        (targetMap[source] ??= {})[relName] = target;
    };
    for (const link of linkTypes) {
        if (selection && (!chosenObjectNames.has(link.from.type) || !chosenObjectNames.has(link.to.type)))
            continue;
        addLink(link.from.type, link.from.name, `{ link: ${JSON.stringify(link.apiName)}; target: ${JSON.stringify(link.to.type)}; cardinality: ${JSON.stringify(link.from.cardinality)}; direction: "forward" }`, link.to.type);
        addLink(link.to.type, link.to.name, `{ link: ${JSON.stringify(link.apiName)}; target: ${JSON.stringify(link.from.type)}; cardinality: ${JSON.stringify(link.to.cardinality)}; direction: "reverse" }`, link.from.type);
    }
    const links = [...linkMap.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([source, entries]) => `${JSON.stringify(source)}: { ${entries.sort().join(' ')} };`);
    const sortedTargetMap = Object.fromEntries(Object.entries(targetMap)
        .sort(([a], [b]) => a.localeCompare(b))
        .map(([source, rels]) => [source, Object.fromEntries(Object.entries(rels).sort(([a], [b]) => a.localeCompare(b)))]));
    const where = [
        ...chosenObjects.map(type => `${JSON.stringify(type.apiName)}: ${whereFields(type.properties)};`),
        ...interfaceTypes.map(iface => `${JSON.stringify(iface.apiName)}: ${whereFields(iface.properties)};`),
    ];
    const actions = selected(actionTypes, selection?.actions).map(action => `${JSON.stringify(action.apiName)}: ${inputType(action.parameters)};`);
    const functions = selected(functionTypes.filter(fn => !fn.edits), selection?.functions).map(fn => `${JSON.stringify(fn.apiName)}: { input: ${inputType(fn.parameters)}; result: ${schemaType(fn.returns)} };`);
    const group = (name, entries) => [`  ${name}: {`, ...entries.sort().map(entry => `    ${entry}`), '  };'];
    return [
        '// Generated from a published Ontology definition.',
        `export const publication = ${JSON.stringify({ id, version })} as const;`,
        `export const linkTargets = ${JSON.stringify(sortedTargetMap)} as const;`,
        'type Arguments<T> = T extends Record<string, unknown> ? T : Record<string, unknown>;',
        'type Scalar = string | number | boolean | null;',
        'type WhereValue<T> = Extract<T, Scalar> | null;',
        'export type Bindings = {',
        ...group('objects', objects),
        ...group('interfaces', interfaces),
        ...group('links', links),
        ...group('where', where),
        ...group('actions', actions),
        ...group('functions', functions),
        '};',
        '',
    ].join('\n');
}
