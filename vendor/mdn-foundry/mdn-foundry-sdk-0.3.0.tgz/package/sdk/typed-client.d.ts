import type { ObjectRef } from '../ontology/schema.js';
import type { OntologyClient, QueryResult } from './client.js';
export type ScalarValue = string | number | boolean | null;
export type LinkBinding = {
    link: string;
    target: string;
    cardinality: 'one' | 'many';
    direction: 'forward' | 'reverse';
};
export type InterfaceBinding = {
    properties: Record<string, unknown>;
    actions?: Record<string, Record<string, unknown>>;
    links?: Record<string, {
        target: string;
        cardinality: 'one' | 'many';
    }>;
};
export type OntologyBindings = {
    objects: Record<string, Record<string, unknown>>;
    actions: Record<string, Record<string, unknown>>;
    functions: Record<string, {
        input: Record<string, unknown>;
        result: unknown;
    }>;
    interfaces?: Record<string, InterfaceBinding>;
    links?: Record<string, Record<string, LinkBinding>>;
    where?: Record<string, Record<string, ScalarValue | undefined>>;
};
type Name<T> = Extract<keyof T, string>;
type BatchAction<Actions> = {
    [K in Name<Actions>]: {
        action: K;
        input: Actions[K];
        requestId: string;
    };
}[Name<Actions>];
type Query = Parameters<OntologyClient['query']>[0];
type QueryOptions = Parameters<OntologyClient['query']>[1];
export type TypedObject<Props extends Record<string, unknown>> = {
    ref: ObjectRef;
    revision: number;
    properties: {
        [P in keyof Props]?: Props[P] | null;
    };
};
type DefaultWhere<Props extends Record<string, unknown>> = {
    [P in keyof Props]?: Extract<Props[P], ScalarValue> | null;
};
type WhereFor<T extends OntologyBindings, K extends string> = T['where'] extends Record<string, Record<string, ScalarValue | undefined>> ? K extends keyof T['where'] ? T['where'][K] : K extends keyof T['objects'] ? DefaultWhere<T['objects'][K]> : Record<string, ScalarValue> : K extends keyof T['objects'] ? DefaultWhere<T['objects'][K]> : Record<string, ScalarValue>;
type InterfacesOf<T extends OntologyBindings> = T['interfaces'] extends Record<string, InterfaceBinding> ? T['interfaces'] : Record<string, never>;
type InterfaceActionsOf<I> = I extends {
    actions: infer A extends Record<string, Record<string, unknown>>;
} ? A : Record<string, never>;
type LinksOf<T extends OntologyBindings, K extends string> = T['links'] extends Record<string, Record<string, LinkBinding>> ? K extends keyof T['links'] ? T['links'][K] : Record<string, never> : Record<string, never>;
type InterfaceActionTarget<T extends OntologyBindings, I extends string, A extends string> = ({
    object: ObjectRef;
} | {
    implementation: Name<T['objects']>;
}) & {
    type: I;
    action: A;
};
/** Fluent, immutable typed ObjectSet query builder over OntologyClient.query(). */
export declare class TypedObjectSet<T extends OntologyBindings, K extends Name<T['objects']>> {
    private readonly client;
    private readonly spec;
    constructor(client: OntologyClient, spec: Omit<Query, 'type'> & {
        type: K;
    });
    where(where: WhereFor<T, K>): TypedObjectSet<T, K>;
    filter(filter: NonNullable<Query['filter']>): TypedObjectSet<T, K>;
    orderBy(orderBy: NonNullable<Query['orderBy']>): TypedObjectSet<T, K>;
    select(select: (Name<T['objects'][K]> | (string & {}))[]): TypedObjectSet<T, K>;
    limit(limit: number): TypedObjectSet<T, K>;
    cursor(cursor: string): TypedObjectSet<T, K>;
    from(object: ObjectRef, link: string, as?: string): TypedObjectSet<T, K>;
    fetch(options?: QueryOptions): Promise<QueryResult<TypedObject<T['objects'][K]>>>;
    all(options?: QueryOptions): Promise<TypedObject<T['objects'][K]>[]>;
}
/** A TypeScript view of the existing client, parameterized by a published definition's generated types. */
export declare class TypedOntologyClient<T extends OntologyBindings> {
    private readonly client;
    private readonly linkTargets?;
    constructor(client: OntologyClient, linkTargets?: Record<string, Record<string, string>> | undefined);
    query<K extends Name<T['objects']>>(query: Omit<Query, 'type' | 'where'> & {
        type: K;
        where?: WhereFor<T, K>;
    }, options?: QueryOptions): Promise<QueryResult<TypedObject<T["objects"][K]>>>;
    objectSet<K extends Name<T['objects']>>(type: K): TypedObjectSet<T, K>;
    follow<K extends Name<T['objects']>, L extends Name<LinksOf<T, K>>, Target extends Name<T['objects']> = Extract<LinksOf<T, K>[L]['target'], Name<T['objects']>>>(from: {
        type: K;
        id: string;
    }, link: L, query?: Omit<Query, 'type' | 'from' | 'where'> & {
        type?: Target;
        as?: string;
        where?: WhereFor<T, Target>;
    }, options?: QueryOptions): Promise<QueryResult<TypedObject<T['objects'][Target]>>>;
    queryInterface<I extends Name<InterfacesOf<T>>>(query: Omit<Query, 'type' | 'where'> & {
        type: I;
        where?: WhereFor<T, I> | DefaultWhere<InterfacesOf<T>[I]['properties']>;
    }, options?: QueryOptions): Promise<QueryResult<TypedObject<InterfacesOf<T>[I]['properties']>>>;
    applyInterfaceAction<I extends Name<InterfacesOf<T>>, A extends Name<InterfaceActionsOf<InterfacesOf<T>[I]>>>(target: InterfaceActionTarget<T, I, A>, input: InterfaceActionsOf<InterfacesOf<T>[I]>[NoInfer<A>], requestId: string, options?: Parameters<OntologyClient['apply']>[1]): Promise<{
        type: string;
        id: string;
    }>;
    evaluate<K extends Name<T['functions']>>(name: K, input: T['functions'][NoInfer<K>]['input'], options?: QueryOptions): Promise<T["functions"][K]["result"]>;
    apply<K extends Name<T['actions']>>(action: K, input: T['actions'][NoInfer<K>], requestId: string, options?: Parameters<OntologyClient['apply']>[1]): Promise<{
        type: string;
        id: string;
    }>;
    validateAction<K extends Name<T['actions']>>(action: K, input: T['actions'][NoInfer<K>], options?: {
        scenarioId?: string;
        signal?: AbortSignal;
    }): Promise<{
        valid: true;
        phase: 'submission';
        action: string;
        release: string;
    }>;
    applyActionBatch(actions: BatchAction<T['actions']>[], signal?: AbortSignal): Promise<{
        release: string;
        items: {
            requestId: string;
            result: ObjectRef;
        }[];
    }>;
}
export {};
