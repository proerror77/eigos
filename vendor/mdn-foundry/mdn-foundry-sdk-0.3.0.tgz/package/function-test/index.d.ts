import { type FunctionLimits } from '../function-host/client.js';
type Data = Record<string, unknown>;
type Ref = {
    type: string;
    id: string;
};
export type FixtureObject = {
    ref: Ref;
    revision: number;
    properties: Data;
};
export type FixturePrincipal = {
    owner: string;
    scopes: readonly string[];
};
export type StagedOntologyEdit = {
    op: 'create';
    ref: Ref;
    properties: Data;
} | {
    op: 'update';
    ref: Ref;
    revision: number;
    properties: Data;
} | {
    op: 'delete';
    ref: Ref;
    revision: number;
} | {
    op: 'link' | 'unlink';
    type: string;
    from: Ref;
    to: Ref;
};
type StubContext = {
    principal: FixturePrincipal;
    get: (ref: Ref) => FixtureObject | null;
    edits: readonly StagedOntologyEdit[];
};
type Stub = (input: Data, context: StubContext) => unknown | Promise<unknown>;
export interface FunctionTestOptions {
    binary: string;
    component: Uint8Array<ArrayBuffer>;
    input: unknown;
    principal?: FixturePrincipal;
    objects?: readonly FixtureObject[];
    stubs?: Partial<Record<'get' | 'follow' | 'query' | 'evaluate' | 'aggregate', Stub>>;
    /** Offline, deterministic model outputs by declared alias. */
    models?: Readonly<Record<string, (messages: unknown, principal: FixturePrincipal) => readonly string[]>>;
    streaming?: boolean;
    allowEdits?: boolean;
    limits?: FunctionLimits;
    signal?: AbortSignal;
}
/** Run a real component on a fresh local host with an in-memory Ontology fixture. Edits never leave the fixture. */
export declare function runFunction(options: FunctionTestOptions): Promise<{
    output: string;
    error?: undefined;
    fuelUsed: number;
    ms: number;
    stderr?: string;
    value: unknown;
    stagedEdits: StagedOntologyEdit[];
    chunks: string[];
} | {
    output?: undefined;
    error: import("../function-host/client.js").FunctionError;
    fuelUsed: number;
    ms: number;
    stderr?: string;
    value: unknown;
    stagedEdits: StagedOntologyEdit[];
    chunks: string[];
}>;
export {};
